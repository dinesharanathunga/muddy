from properties import resources
from exception import MetagraphException
from numpy import matrix
#from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point
import matplotlib.pyplot as plt
import numpy as np
import copy
import math
from enums import Ipv4ProtocolNumbers

def singleton(cls):
    """A helper function to ease implementing singletons.
    This should be used as a decorator to the
    class that should be a singleton.
    :param cls: class that should be a singleton
    :return: singleton instance of the class
    """
    instances = {}

    def get_instance():
        if cls not in instances:
            instances[cls] = cls()
        return instances[cls]
    return get_instance

class Triple(object):
    """ Captures a set of co-inputs, co-outputs and edges between two metagraph elements.
    """

    def __init__(self, coinputs, cooutputs, edges):
        if edges is None:
            raise MetagraphException('edges', resources['value_null'])

        self.coinputs = coinputs
        self.cooutputs = cooutputs
        self.edges = edges

    def coinputs(self):
        """ The co-inputs of the Triple object
        :return: set
        """
        return self.coinputs

    def cooutputs(self):
        """ The co-outputs of the Triple object
        :return: set
        """
        return self.cooutputs

    def edges(self):
        """ The edges of the Triple object
        :return: set
        """
        return self.edges

    def __repr__(self):
        if isinstance(self.edges, list):
            edge_desc = [repr(edge) for edge in self.edges]
        else:
            edge_desc = [repr(self.edges)]
        full_desc = ''
        for desc in edge_desc:
            if full_desc == '':
                full_desc = desc
            else:
                full_desc += ', ' + desc
        return 'Triple(%s, %s, %s)' % (self.coinputs, self.cooutputs, full_desc)

    def __eq__(self, other):
        if other is None:
            return False
        if not isinstance(other,Triple):
            return False

        return (self.coinputs == other.coinputs and
                self.cooutputs == other.cooutputs and
                len(self.edges) == len(other.edges) and
                self.edges == other.edges)

class Node(object):
    """ Represents a metagraph node.
    """

    def __init__(self, element_set):
        if element_set is None or len(element_set) == 0:
            raise MetagraphException('element_set', resources['value_null'])
        if not isinstance(element_set, set):
            raise MetagraphException('element_set', resources['format_invalid'])

        self.element_set = element_set

    def get_element_set(self):
        """ Returns the node elements
        :return: set
        """
        return self.element_set

    def __repr__(self):
        return 'Node(%s)' % self.element_set

class Edge(object):
    """ Represents a metagraph edge.
    """

    def __init__(self, invertex, outvertex, attributes=None, label=None):
        if invertex is None or len(invertex) == 0:
            raise MetagraphException('invertex', resources['value_null'])
        if outvertex is None or len(outvertex) == 0:
            raise MetagraphException('outvertex', resources['value_null'])
        if not isinstance(invertex, set):
            raise MetagraphException('invertex', resources['format_invalid'])
        if not isinstance(outvertex, set):
            raise MetagraphException('outvertex', resources['format_invalid'])

        self.invertex = invertex
        self.outvertex = outvertex
        self.attributes = attributes
        self.label = label

        # include attributes as part if invertex
        if attributes is not None:
            invertex = list(self.invertex)
            for attribute in attributes:
                if attribute not in invertex:
                    invertex.append(attribute)
            self.invertex = set(invertex)

    def __repr__(self):
        return 'Edge(%s, %s)' % (self.invertex, self.outvertex)

    def invertex(self):
        """ Returns the invertex of the edge.
        :return: set
        """
        return self.invertex

    def outvertex(self):
        """ Returns the outvertex of the edge.
        :return: set
        """
        return self.outvertex

    def label(self):
        """ Returns the label of the edge.
        :return: string
        """
        return self.label

    def __eq__(self, other):
        if other is None:
            return False
        if not isinstance(other, Edge):
            return False

        return (self.invertex == other.invertex and
                self.outvertex == other.outvertex and
                self.attributes == other.attributes)

class Metapath(object):
    """ Represents a metapath between a source and a target node in a metagraph.
    """

    def __init__(self, source, target, edge_list):
        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])

        self.source = source
        self.target = target
        self.edge_list = edge_list

    def source(self):
        """ Returns the source of the metapath.
        :return: set
        """
        return self.source

    def target(self):
        """ Returns the target of the metapath.
        :return: set
        """
        return self.target

    def edge_list(self):
        """ Returns the list of edges of the metapath.
        :return: set
        """
        return self.edge_list

    def __repr__(self):
        edge_desc = [repr(edge) for edge in self.edge_list]
        full_desc = 'source: %s, target: %s' % (self.source, self.target)
        for desc in edge_desc:
            if full_desc == '':
                full_desc = desc
            else:
                full_desc += ", " + desc
        return 'Metapath({ %s })' % full_desc

    def dominates(self, metapath):
        """Checks whether current metapath dominates that provided.
        :param metapath: Metapath object
        :return: boolean
        """
        if metapath is None:
            raise MetagraphException('metapath', resources['value_null'])

        input1 = self.source
        input2 = metapath.source

        output1 = self.target
        output2 = metapath.target

        if input1.issubset(input2) and output2.issubset(output1):
            return True

        return False

class Metagraph(object):
    """ Represents a metagraph.
    """

    def __init__(self, generator_set):
        if generator_set is None or len(generator_set) == 0:
            raise MetagraphException('generator_set', resources['value_null'])
        if not isinstance(generator_set, set):
            raise MetagraphException('generator_set', resources['format_invalid'])

        self.nodes = []
        self.edges = []
        self.generating_set = generator_set
        self.a_star = None

    def add_node(self, node):
        """ Adds a node to the metagraph.
        :param node: Node object
        :return: None
        """
        if not isinstance(node, Node):
            raise MetagraphException('node', resources['format_invalid'])

        # nodes cant be null or empty
        if node is None:
            raise MetagraphException('node', resources['value_null'])

        # each element in node must be in the generating set
        not_found = [element not in self.generating_set for element in node.element_set]
        if True in not_found:
            raise MetagraphException('node', resources['range_invalid'])

        if not MetagraphHelper().is_node_in_list(node, self.nodes):
            self.nodes.append(node)

    def remove_node(self, node):
        """ Removes a specified node from the metagraph.
        :param node: Node object
        :return: None
        """

        if not isinstance(node, Node):
            raise MetagraphException('node', resources['format_invalid'])

        # nodes cant be null or empty
        if node is None:
            raise MetagraphException('node', resources['value_null'])

        if not MetagraphHelper().is_node_in_list(node, self.nodes):
            raise MetagraphException('node', resources['value_not_found'])

        self.nodes.remove(node)

    def add_nodes_from(self, nodes_list):
        """ Adds nodes from the given list to the metagraph.
        :param nodes_list: list of Node objects
        :return: None
        """

        if nodes_list is None or len(nodes_list) == 0:
            raise MetagraphException('nodes_list', resources['value_null'])

        for node in nodes_list:
            if not isinstance(node, Node):
                raise MetagraphException('nodes_list', resources['format_invalid'])

        for node in nodes_list:
            if not MetagraphHelper().is_node_in_list(node, self.nodes):
                self.nodes.append(node)

    def remove_nodes_from(self, nodes_list):
        """ Removes nodes from the given list from the metagraph.
        :param nodes_list: list of Node objects
        :return: None
        """

        if nodes_list is None or len(nodes_list) == 0:
                raise MetagraphException('nodes_list', resources['value_null'])

        for node in nodes_list:
            if not isinstance(node, set):
                raise MetagraphException('nodes_list', resources['format_invalid'])
            if not MetagraphHelper().is_node_in_list(node, self.nodes):
                raise MetagraphException('nodes_list', resources['value_not_found'])

        for node in nodes_list:
            self.nodes.remove(node)

    def add_edge(self, edge):
        """ Adds the given edge to the metagraph.
        :param edge: Edge object
        :return: None
        """

        if not isinstance(edge, Edge):
            raise MetagraphException('edge', resources['format_invalid'])

        # add to list of nodes first
        node1 = Node(edge.invertex)
        node2 = Node(edge.outvertex)
        if not MetagraphHelper().is_node_in_list(node1, self.nodes):
            self.nodes.append(node1)
        if not MetagraphHelper().is_node_in_list(node2, self.nodes):
            self.nodes.append(node2)

        #..then edges
        if not MetagraphHelper().is_edge_in_list(edge, self.edges):
            self.edges.append(edge)

    def remove_edge(self, edge):
        """ Removes the given edge from the metagraph.
        :param edge: Edge object
        :return:None
        """

        if not isinstance(edge, Edge):
            raise MetagraphException('edge', resources['format_invalid'])

        # remove edge
        if edge in self.edges:
            self.edges.remove(edge)

    def add_edges_from(self, edge_list):
        """ Adds the given list of edges to the metagraph.
        :param edge_list: list of Edge objects
        :return: None
        """

        if edge_list is None or len(edge_list) == 0:
            raise MetagraphException('edge_list', resources['value_null'])

        for edge in edge_list:
            if not isinstance(edge, Edge):
                raise MetagraphException('edge', resources['format_invalid'])

        for edge in edge_list:
            node1 = Node(edge.invertex)
            node2 = Node(edge.outvertex)
            if not MetagraphHelper().is_node_in_list(node1, self.nodes):
                self.nodes.append(node1)
            if not MetagraphHelper().is_node_in_list(node2, self.nodes):
                self.nodes.append(node2)
            if edge not in self.edges:
                self.edges.append(edge)

    def remove_edges_from(self, edge_list):
        """ Removes edges from the given list from the metagraph.
        :param edge_list: list of Edge objects
        :return: None
        """

        if edge_list is None or len(edge_list) == 0:
            raise MetagraphException('edge_list', resources['value_null'])

        for edge in edge_list:
            if not isinstance(edge, Edge):
                raise MetagraphException('edge', resources['format_invalid'])

        for edge in edge_list:
            if MetagraphHelper().is_edge_in_list(edge, self.edges):
                self.edges.remove(edge)

    def nodes(self):
        """ Returns a list of metagraph nodes.
        :return: list of Node objects
        """
        return self.nodes

    def edges(self):
        """ Returns a list of metagraph edges.
        :return: list of Edge objects.
        """
        return self.edges

    def get_edges(self, invertex, outvertex):
        """ Retrieves all edges between a given invertex and outvertex.
        :param invertex: set
        :param outvertex: set
        :return: list of Edge objects.
        """

        if invertex is None:
            raise MetagraphException('invertex', resources['value_null'])
        if outvertex is None:
            raise MetagraphException('outvertex', resources['value_null'])

        result = []
        if len(self.edges) > 0:
            for edge in self.edges:
                if (invertex.issubset(edge.invertex)) and (outvertex.issubset(edge.outvertex)) and (edge not in result):
                    result.append(edge)

        return result

    @staticmethod
    def get_coinputs(edge, x_i):
        """ Returns the set of co-inputs for element x_i in the given edge.
        :param edge: Edge object
        :param x_i: invertex element
        :return: set
        """

        coinputs = None
        all_inputs = edge.invertex
        if x_i in list(all_inputs):
            coinputs = list(all_inputs)
            coinputs.remove(x_i)
        if coinputs is not None and len(coinputs) > 0:
            return set(coinputs)
        return None

    @staticmethod
    def get_cooutputs(edge, x_j):
        """ Returns the set of co-outputs for element x_j in the given edge.
        :param edge: Edge object
        :param x_j: outvertex element
        :return: set
        """

        cooutputs = None
        all_outputs = edge.outvertex
        if x_j in list(all_outputs):
            cooutputs = list(all_outputs)
            cooutputs.remove(x_j)
        if cooutputs is not None and len(cooutputs) > 0:
            return set(cooutputs)
        return None

    def adjacency_matrix1(self):
        """ Returns the adjacency matrix of the metagraph.
        :return: numpy.matrix
        """
        # get matrix size
        size = len(self.generating_set)
        adj_matrix = MetagraphHelper().get_null_matrix(size, size)

        # one triple for each edge e connecting x_i to x_j
        count=1
        for i in range(size):
            for j in range(size):
                x_i = list(self.generating_set)[i]
                x_j = list(self.generating_set)[j]
                # multiple edges may exist between x_i and x_j
                edges = self.get_edges({x_i}, {x_j})
                if len(edges) > 0:
                   triples_list = []
                   for edge in edges:
                        coinputs = self.get_coinputs(edge, x_i)
                        cooutputs = self.get_cooutputs(edge, x_j)
                        triple = Triple(coinputs, cooutputs, edge)
                        if triple not in triples_list:
                           triples_list.append(triple)

                   adj_matrix[i][j] = triples_list
                print('count= %s'%count)
                count +=1

        # return adj_matrix
        # noinspection PyCallingNonCallable
        return matrix(adj_matrix)

    def adjacency_matrix(self):
        """ Returns the adjacency matrix of the metagraph.
        :return: numpy.matrix
        """
        # get matrix size
        size = len(self.generating_set)
        adj_matrix = MetagraphHelper().get_null_matrix(size, size)

        # create lookup table
        #print('here1')
        count=1
        triples_lookup=dict()
        for edge in self.edges:
             for elt1 in edge.invertex:
                  for elt2 in edge.outvertex:
                      coinputs = self.get_coinputs(edge, elt1)
                      cooutputs = self.get_cooutputs(edge, elt2)
                      triple = Triple(coinputs, cooutputs, edge)
                      if (elt1,elt2) not in triples_lookup:
                         triples_lookup[(elt1,elt2)] = []
                      triples_lookup[(elt1,elt2)].append(triple)
                      #print('count1=%s'%count)
                      count+=1

        #print('here2')
        count=1
        gen_elts = list(self.generating_set)
        for i in range(size):
             for j in range(size):
                  x_i = gen_elts[i]
                  x_j = gen_elts[j]
                  try:
                      adj_matrix[i][j] = triples_lookup[(x_i,x_j)]
                  except BaseException,e:
                      pass
             #print('count2=%s'%count)
             #count+=1

        # return adj_matrix
        # noinspection PyCallingNonCallable
        return matrix(adj_matrix)

    def equivalent(self, metagraph2):
        """Checks if current metagraph is equivalent to the metagraph provided.
        :param metagraph2: Metagraph object
        :return: boolean
        """

        if metagraph2 is None:
            raise MetagraphException('metagraph2', resources['value_null'])

        if self.dominates(metagraph2) and metagraph2.dominates(self):
            return True

        return False

    def add_metagraph(self, metagraph2):
        """ Adds the given metagraph to current and returns the composed result.
        :param metagraph2: Metagraph object
        :return: Metagraph object
        """

        if metagraph2 is None:
            raise MetagraphException('metagraph2', resources['value_null'])

        generating_set1 = self.generating_set
        generating_set2 = metagraph2.generating_set

        if generating_set2 is None or len(generating_set2) == 0:
            raise MetagraphException('metagraph2.generating_set', resources['value_null'])

        # check if the generating sets of the matrices overlap (otherwise no sense in combining metagraphs)
        #intersection=generating_set1.intersection(generating_set2)
        #if intersection==None:
        #    raise MetagraphException('generating_sets', resources['no_overlap'])

        if len(generating_set1.difference(generating_set2)) == 0 and \
           len(generating_set2.difference(generating_set1)) == 0:
            # generating sets are identical..simply add edges
            # size = len(generating_set1)
            for edge in metagraph2.edges:
                if edge not in self.edges:
                    self.add_edge(edge)
        else:
            # generating sets overlap but are different...combine generating sets and then add edges
            # combined_generating_set = generating_set1.union(generating_set2)
            self.generating_set = generating_set1.union(generating_set2)
            for edge in metagraph2.edges:
                if edge not in self.edges:
                    self.add_edge(edge)

        return self

    def multiply_metagraph(self, metagraph2):
        """ Multiplies the metagraph with that provided and returns the result.
        :param metagraph2: Metagraph object
        :return: Metagraph object
        """

        if metagraph2 is None:
            raise MetagraphException('metagraph2', resources['value_null'])

        generating_set1 = self.generating_set
        generating_set2 = metagraph2.generating_set

        if generating_set2 is None or len(generating_set2) == 0:
            raise MetagraphException('metagraph2.generator_set', resources['value_null'])

        # check generating sets are identical
        if not(len(generating_set1.difference(generating_set2)) == 0 and
           len(generating_set2.difference(generating_set1)) == 0):
            raise MetagraphException('generator_sets', resources['not_identical'])

        adjacency_matrix1 = self.adjacency_matrix().tolist()
        adjacency_matrix2 = metagraph2.adjacency_matrix().tolist()
        size = len(generating_set1)
        resultant_adjacency_matrix = MetagraphHelper().get_null_matrix(size, size)

        for i in range(size):
            for j in range(size):
                resultant_adjacency_matrix[i][j] = MetagraphHelper().multiply_components(
                    adjacency_matrix1, adjacency_matrix2, generating_set1, i, j, size)

        # extract new edge list
        new_edge_list = MetagraphHelper().get_edges_in_matrix(resultant_adjacency_matrix, self.generating_set)
        # clear current edge list and append new
        self.edges = []
        if len(new_edge_list) > 0:
            self.add_edges_from(new_edge_list)

        return self

    def get_closure(self, iterations=0):#0
        """ Returns the closure matrix (i.e., A*) of the metagraph.
        :return: numpy.matrix
        """

        # gen set size N
        # edge count C
        # proj elts M

        print('get adjacency_matrix')
        adjacency_matrix = self.adjacency_matrix().tolist()

        i = 0
        size = len(self.generating_set)
        a = dict()
        a[i] = adjacency_matrix
        a_star = adjacency_matrix

        #TODO: re-enable
        if iterations==0:
            iterations = size
        print('iterations:%s'%iterations)

        # O(N4C2)
        for i in range(iterations):
            #print(' iteration %s --------------'%i)
            # O(N3C2)
            print('multiply_adjacency_matrices')
            a[i+1] = MetagraphHelper().multiply_adjacency_matrices(a[i],
                                                                   self.generating_set,
                                                                   adjacency_matrix,
                                                                   self.generating_set)
            print('add_adjacency_matrices')
            a_star = MetagraphHelper().add_adjacency_matrices(a_star,
                                                              self.generating_set,
                                                              a[i+1],
                                                              self.generating_set)
            #print('add_adjacency_matrices complete')
            if a[i+1] == a[i]:
                break

        # noinspection PyCallingNonCallable
        return matrix(a_star)

    def get_all_metapaths_from2(self, source, target, props=None):
        """ Retrieves all metapaths between given source and target in the metagraph.
        :param source: set
        :param target: set
        :return: list of Metapath objects
        """

        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])

        # check subset
        if not source.intersection(self.generating_set) == source:
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.intersection(self.generating_set) == target:
            raise MetagraphException('target', resources['not_a_subset'])

        # compute A* first
        if self.a_star is None:
            #print('computing closure..')
            self.a_star = self.get_closure().tolist()
            #print('closure computation- %s'%(time.time()- start))

        metapaths = []
        all_applicable_input_rows = []
        for x_i in source:
            index = list(self.generating_set).index(x_i)
            if index not in all_applicable_input_rows:
                all_applicable_input_rows.append(index)

        cumulative_output_global = []
        cumulative_edges_global = []
        for i in all_applicable_input_rows:
            mp_exist_for_row=False
            cumulative_output_local = []
            cumulative_edges_local = []
            for x_j in target:
                j = list(self.generating_set).index(x_j)

                if self.a_star[i][j] is not None:
                    mp_exist_for_row = True

                    # x_j is already an output
                    cumulative_output_local.append(x_j)
                    triples = MetagraphHelper().get_triples(self.a_star[i][j])
                    for triple in triples:
                        # retain cooutputs
                        output = triple.cooutputs
                        if output is not None:
                            cumulative_output_local += output
                        if output is not None:
                            cumulative_output_global += output

                        #... and edges
                        if isinstance(triple.edges, Edge):
                            edges = MetagraphHelper().get_edge_list([triple.edges])
                        else:
                            edges = MetagraphHelper().get_edge_list(triple.edges)

                        for edge in edges:
                            if edge not in cumulative_edges_local:
                                cumulative_edges_local.append(edge)
                            if edge not in cumulative_edges_global:
                                cumulative_edges_global.append(edge)

            if not mp_exist_for_row:
               continue

            # check if cumulative outputs form a cover for the target
            if set(target).issubset(set(cumulative_output_local)):
                if set(cumulative_edges_local) not in metapaths:
                    metapaths.append(set(cumulative_edges_local))

            elif set(target).issubset(set(cumulative_edges_global)):
                if set(cumulative_edges_global) not in metapaths:
                    metapaths.append(set(cumulative_edges_global))

            #else:
            #    break

        if len(metapaths)>0:
            #result=[]
            #for path in metapaths:
            #    mp = Metapath(source, target, list(path))
            #    result.append(mp)
            #return result

            if True:
                valid_metapaths = []
                processed_edge_lists=[]
                from itertools import combinations
                for metapath in metapaths:
                    all_subsets = sum(map(lambda r: list(combinations(list(metapath), r)), range(1, len(list(metapath))+1)), [])
                    for path in all_subsets:
                        if len(path) <= len(metapath): # metapaths
                            edge_list2 = self.get_edge_list2(path)
                            if len(processed_edge_lists)>0:
                                if MetagraphHelper().is_edge_list_included(edge_list2,processed_edge_lists):
                                    continue
                            if props is not None:
                                mp = Metapath(source.union(props), target, edge_list2)
                            else:
                                mp = Metapath(source, target, edge_list2)
                            if self.is_metapath(mp): # is_edge_dominant_metapath
                               valid_metapaths.append(mp)
                return valid_metapaths

        return None

        ''' NEW
        if len(metapaths)>0:
            result=[]
            for path in metapaths:
                mp = Metapath(source, target, list(path))
                if self.is_metapath(mp):
                   result.append(mp)
            return result
        else:
            return None'''

        ''' OLD
        valid_metapaths = []
        from itertools import combinations
        all_subsets = sum(map(lambda r: list(combinations(metapaths, r)), range(1, len(metapaths)+1)), [])
        for path in all_subsets:
            if len(path) <= len(metapaths):
                mp = Metapath(source, target, list(path))
                if self.is_metapath(mp):
                    valid_metapaths.append(mp)

        if len(valid_metapaths)>0:
            return valid_metapaths

        return None'''

    def get_all_metapaths_from200(self, source, target):
        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])

        # check subset
        if not source.intersection(self.generating_set) == source:
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.intersection(self.generating_set) == target:
            raise MetagraphException('target', resources['not_a_subset'])

        # compute A* first
        if self.a_star is None:
            print('computing closure..')
            self.a_star = self.get_closure().tolist()
            #print('closure computation complete')
            #print('closure computation- %s'%(time.time()- start))

        print('find mps')
        metapaths = []
        all_applicable_input_rows = []
        for x_i in source:
            index = list(self.generating_set).index(x_i)
            if index not in all_applicable_input_rows:
                all_applicable_input_rows.append(index)

        cumulative_output_global = []
        cumulative_edges_global = []
        for j in all_applicable_input_rows:
            mp_exists=False
            for i in all_applicable_input_rows:
                if self.a_star[i][j] is not None:
                    # metapath from {x_i | i in I} to C exists
                    mp_exists = True
                    break
            if not mp_exists:
               # TODO: return to step1 and repeat with another set of rows
               return None

        metapaths=[]
        for x_j in target:
            j = list(self.generating_set).index(x_j)
            triples_set=set()
            for i in all_applicable_input_rows:
                triples = MetagraphHelper().get_triples(self.a_star[i][j])
                triples_set = triples_set.union(set(triples))
                if MetagraphHelper().forms_cover(triples_set, target):
                    metapath = MetagraphHelper().get_metapath_from_triples(triples_set)
                    metapaths.append(metapath)

        for i in all_applicable_input_rows:
            triples_set=set()
            for x_j in target:
                j = list(self.generating_set).index(x_j)
                triples = MetagraphHelper().get_triples(self.a_star[i][j])
                triples_set = triples_set.union(set(triples))
                if MetagraphHelper().forms_cover(triples_set, target):
                    metapath = MetagraphHelper().get_metapath_from_triples(triples_set)
                    metapaths.append(metapath)

        return metapaths

    def get_all_metapaths_from100(self, source, target):
        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])

        # check subset
        if not source.intersection(self.generating_set) == source:
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.intersection(self.generating_set) == target:
            raise MetagraphException('target', resources['not_a_subset'])

        # compute A* first
        if self.a_star is None:
            print('computing closure..')
            self.a_star = self.get_closure().tolist()
            #print('closure computation complete')
            #print('closure computation- %s'%(time.time()- start))

        print('find mps')
        metapaths = []
        all_applicable_input_rows = []
        for x_i in source:
            index = list(self.generating_set).index(x_i)
            if index not in all_applicable_input_rows:
                all_applicable_input_rows.append(index)

        cumulative_output_global = []
        cumulative_edges_global = []
        for i in all_applicable_input_rows:
            mp_exist_for_row=False
            cumulative_output_local = []
            cumulative_edges_local = []
            for x_j in target:
                j = list(self.generating_set).index(x_j)

                if self.a_star[i][j] is not None:
                    mp_exist_for_row = True

                    # x_j is already an output
                    cumulative_output_local.append(x_j)
                    triples = MetagraphHelper().get_triples(self.a_star[i][j])
                    for triple in triples:
                        # retain cooutputs
                        output = triple.cooutputs
                        if output is not None:
                            cumulative_output_local += output
                        if output is not None:
                            cumulative_output_global += output

                        #... and edges
                        if isinstance(triple.edges, Edge):
                            edges = MetagraphHelper().get_edge_list([triple.edges])
                        else:
                            edges = MetagraphHelper().get_edge_list(triple.edges)

                        for edge in edges:
                            if edge not in cumulative_edges_local:
                                cumulative_edges_local.append(edge)
                            if edge not in cumulative_edges_global:
                                cumulative_edges_global.append(edge)

            if not mp_exist_for_row:
               continue

            # check if cumulative outputs form a cover for the target
            if set(target).issubset(set(cumulative_output_local)):
                if set(cumulative_edges_local) not in metapaths:
                    metapaths.append(set(cumulative_edges_local))

            elif set(target).issubset(set(cumulative_edges_global)):
                if set(cumulative_edges_global) not in metapaths:
                    metapaths.append(set(cumulative_edges_global))

            #else:
            #    break

        print('check result')
        from itertools import combinations
        if len(metapaths)>0:
            result=[]
            for path in metapaths:
                # all_subsets = sum(map(lambda r: list(combinations(list(path), r)), range(1, len(list(path))+1)), [])
                all_subsets = []
                print('path= %s'%path)
                i=1
                for p in all_subsets:
                    print('counter=%s'%i)
                    i+=1
                #for path2 in all_subsets:
                #    if len(path2) <= len(path):
                #        mp = Metapath(source, target, list(path2))
                #        if self.is_metapath(mp): # is_edge_dominant_metapath
                #           result.append(mp)


                # check no loops
                #if self.check_no_loops(list(path)):
                #    mp = Metapath(source, target, list(path))
                #    #print('mp src= %s, target= %s'%(source,target))
                #    #if self.is_metapath(mp):
                #    result.append(mp)
                    # TODO:compare this with coursex alg
            return result
        else:
            return None

    def get_all_metapaths_from(self, source, target, props=None):
        """ Retrieves all metapaths between given source and target in the metagraph.
        :param source: set
        :param target: set
        :return: list of Metapath objects
        """

        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])

        # check subset
        if not source.intersection(self.generating_set) == source:
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.intersection(self.generating_set) == target:
            raise MetagraphException('target', resources['not_a_subset'])

        # compute A* first
        if self.a_star is None:
            #print('computing closure..')
            self.a_star = self.get_closure().tolist()
            #print('closure computation- %s'%(time.time()- start))

        metapaths = []
        all_applicable_input_rows = []
        for x_i in source:
            index = list(self.generating_set).index(x_i)
            if index not in all_applicable_input_rows:
                all_applicable_input_rows.append(index)

        cumulative_output_global = []
        cumulative_edges_global = []
        for i in all_applicable_input_rows:
            mp_exist_for_row=False
            cumulative_output_local = []
            cumulative_edges_local = []
            for x_j in target:
                j = list(self.generating_set).index(x_j)

                if self.a_star[i][j] is not None:
                    mp_exist_for_row = True

                    # x_j is already an output
                    cumulative_output_local.append(x_j)
                    triples = MetagraphHelper().get_triples(self.a_star[i][j])
                    for triple in triples:
                        # retain cooutputs
                        output = triple.cooutputs
                        if output is not None:
                            cumulative_output_local += output
                        if output is not None:
                            cumulative_output_global += output

                        #... and edges
                        if isinstance(triple.edges, Edge):
                            edges = MetagraphHelper().get_edge_list([triple.edges])
                        else:
                            edges = MetagraphHelper().get_edge_list(triple.edges)

                        for edge in edges:
                            if edge not in cumulative_edges_local:
                                cumulative_edges_local.append(edge)
                            if edge not in cumulative_edges_global:
                                cumulative_edges_global.append(edge)

            if not mp_exist_for_row:
               continue

            # check if cumulative outputs form a cover for the target
            if set(target).issubset(set(cumulative_output_local)):
                if set(cumulative_edges_local) not in metapaths:
                    metapaths.append(set(cumulative_edges_local))

            elif set(target).issubset(set(cumulative_edges_global)):
                if set(cumulative_edges_global) not in metapaths:
                    metapaths.append(set(cumulative_edges_global))

            #else:
            #    break

        if len(metapaths)>0:
            #result=[]
            #for path in metapaths:
            #    mp = Metapath(source, target, list(path))
            #    result.append(mp)
            #return result

            if True:
                valid_metapaths = []
                processed_edge_lists=[]
                from itertools import combinations
                for metapath in metapaths:
                    if len(metapath)>25:
                        continue
                    all_subsets = sum(map(lambda r: list(combinations(list(metapath), r)), range(1, len(list(metapath))+1)), [])
                    for path in all_subsets:
                        if len(path) <= len(metapath): # metapaths
                            edge_list2 = self.get_edge_list2(path)
                            # TODO: enable
                            #if len(processed_edge_lists)>0:
                            #    if MetagraphHelper().is_edge_list_included(edge_list2,processed_edge_lists):
                            #        continue
                            if props is not None:
                                mp = Metapath(source.union(props), target, edge_list2)
                            else:
                                mp = Metapath(source, target, edge_list2)
                            if self.is_metapath(mp): # is_edge_dominant_metapath
                               valid_metapaths.append(mp)

                return valid_metapaths

        return None

        ''' NEW
        if len(metapaths)>0:
            result=[]
            for path in metapaths:
                mp = Metapath(source, target, list(path))
                if self.is_metapath(mp):
                   result.append(mp)
            return result
        else:
            return None'''

        ''' OLD
        valid_metapaths = []
        from itertools import combinations
        all_subsets = sum(map(lambda r: list(combinations(metapaths, r)), range(1, len(metapaths)+1)), [])
        for path in all_subsets:
            if len(path) <= len(metapaths):
                mp = Metapath(source, target, list(path))
                if self.is_metapath(mp):
                    valid_metapaths.append(mp)

        if len(valid_metapaths)>0:
            return valid_metapaths

        return None'''

    def get_all_metapaths_from_2000(self, source, target):
        """ Retrieves all metapaths between given source and target in the metagraph.
        :param source: set
        :param target: set
        :return: list of Metapath objects
        """

        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])

        # check subset
        if not source.intersection(self.generating_set) == source:
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.intersection(self.generating_set) == target:
            raise MetagraphException('target', resources['not_a_subset'])

        # compute A* first
        if self.a_star is None:
            #print('computing closure..')
            self.a_star = self.get_closure().tolist()
            #print('closure computation- %s'%(time.time()- start))

        metapaths = []
        all_applicable_input_rows = []
        for x_i in source:
            index = list(self.generating_set).index(x_i)
            if index not in all_applicable_input_rows:
                all_applicable_input_rows.append(index)

        cumulative_output_global = []
        cumulative_edges_global = []
        for i in all_applicable_input_rows:
            mp_exist_for_row=False
            cumulative_output_local = []
            cumulative_edges_local = []
            for x_j in target:
                j = list(self.generating_set).index(x_j)

                if self.a_star[i][j] is not None:
                    mp_exist_for_row = True

                    # x_j is already an output
                    cumulative_output_local.append(x_j)
                    triples = MetagraphHelper().get_triples(self.a_star[i][j])
                    for triple in triples:
                        # retain cooutputs
                        output = triple.cooutputs
                        if output is not None:
                            cumulative_output_local += output
                        if output is not None:
                            cumulative_output_global += output

                        #... and edges
                        if isinstance(triple.edges, Edge):
                            edges = MetagraphHelper().get_edge_list([triple.edges])
                        else:
                            edges = MetagraphHelper().get_edge_list(triple.edges)

                        for edge in edges:
                            if edge not in cumulative_edges_local:
                                cumulative_edges_local.append(edge)
                            if edge not in cumulative_edges_global:
                                cumulative_edges_global.append(edge)

            if not mp_exist_for_row:
               continue

            # check if cumulative outputs form a cover for the target
            if set(target).issubset(set(cumulative_output_local)):
                if set(cumulative_edges_local) not in metapaths:
                    metapaths.append(set(cumulative_edges_local))

            elif set(target).issubset(set(cumulative_edges_global)):
                if set(cumulative_edges_global) not in metapaths:
                    metapaths.append(set(cumulative_edges_global))

            else:
                break

        if len(metapaths)>0:
            #result=[]
            #for path in metapaths:
            #    mp = Metapath(source, target, list(path))
            #    result.append(mp)
            #return result

            valid_metapaths = []
            processed_edge_lists=[]
            from itertools import combinations
            for metapath in metapaths:
                if len(metapath)>25:
                   continue
                all_subsets = sum(map(lambda r: list(combinations(list(metapath), r)), range(1, len(list(metapath))+1)), [])
                for path in all_subsets:
                    if len(path) <= len(metapath): # metapaths
                        edge_list2 = self.get_edge_list2(path)
                        if len(processed_edge_lists)>0:
                            if MetagraphHelper().is_edge_list_included(edge_list2,processed_edge_lists):
                                continue
                        mp = Metapath(source, target, edge_list2)
                        if self.is_metapath(mp):
                            valid_metapaths.append(mp)
            return valid_metapaths

        return None

    def get_all_metapaths_from_600(self, source, target):
        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])

        # check subset
        if not source.intersection(self.generating_set) == source:
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.intersection(self.generating_set) == target:
            raise MetagraphException('target', resources['not_a_subset'])

        # compute A* first
        if self.a_star is None:
            print('computing closure..')
            self.a_star = self.get_closure().tolist()

        print('find mps')
        metapaths = []
        all_applicable_input_rows = []
        for x_i in source:
            index = list(self.generating_set).index(x_i)
            if index not in all_applicable_input_rows:
                all_applicable_input_rows.append(index)

        for x_j in target:
            mp_exists=False
            j = list(self.generating_set).index(x_j)
            for i in all_applicable_input_rows:
                if self.a_star[i][j] is not None:
                    mp_exists=True
                    break
        if not mp_exists:
            return None

        metapaths=[]
        for x_j in target:
            j = list(self.generating_set).index(x_j)
            triples_set=set()
            for i in all_applicable_input_rows:
                triples = MetagraphHelper().get_triples(self.a_star[i][j])
                triples_set = triples_set.union(set(triples))
                if MetagraphHelper().forms_cover(triples_set, target, x_j):
                    metapath = MetagraphHelper().get_metapath_from_triples(source, target, triples_set)
                    metapaths.append(metapath)

        for i in all_applicable_input_rows:
            triples_set=set()
            for x_j in target:
                j = list(self.generating_set).index(x_j)
                triples = MetagraphHelper().get_triples(self.a_star[i][j])
                triples_set = triples_set.union(set(triples))
                if MetagraphHelper().forms_cover(triples_set, target, x_j):
                    metapath = MetagraphHelper().get_metapath_from_triples(source, target, triples_set)
                    metapaths.append(metapath)


        for x_j in target:
            j = list(self.generating_set).index(x_j)
            for i in all_applicable_input_rows:
                triples_set=set()
                triples = MetagraphHelper().get_triples(self.a_star[i][j])
                triples_set = triples_set.union(set(triples))
                if MetagraphHelper().forms_cover(triples_set, target, x_j):
                    metapath = MetagraphHelper().get_metapath_from_triples(source, target, triples_set)
                    metapaths.append(metapath)

        for i in all_applicable_input_rows:
            for x_j in target:
                j = list(self.generating_set).index(x_j)
                triples_set=set()
                triples = MetagraphHelper().get_triples(self.a_star[i][j])
                triples_set = triples_set.union(set(triples))
                if MetagraphHelper().forms_cover(triples_set, target, x_j):
                    metapath = MetagraphHelper().get_metapath_from_triples(source, target, triples_set)
                    metapaths.append(metapath)

        triples_set=set()
        for i in all_applicable_input_rows:
            for x_j in target:
                j = list(self.generating_set).index(x_j)
                triples = MetagraphHelper().get_triples(self.a_star[i][j])
                triples_set = triples_set.union(set(triples))
                if MetagraphHelper().forms_cover(triples_set, target, x_j):
                    metapath = MetagraphHelper().get_metapath_from_triples(source, target, triples_set)
                    metapaths.append(metapath)

        triples_set=set()
        for x_j in target:
            j = list(self.generating_set).index(x_j)
            for i in all_applicable_input_rows:
                triples = MetagraphHelper().get_triples(self.a_star[i][j])
                triples_set = triples_set.union(set(triples))
                if MetagraphHelper().forms_cover(triples_set, target, x_j):
                    metapath = MetagraphHelper().get_metapath_from_triples(source, target, triples_set)
                    metapaths.append(metapath)

        #TODO : check for duplicates
        result=[]
        for mp in metapaths:
            if self.is_metapath(mp):
                result.append(mp)

        # A*[i][j]:   paths from x_i to x_j
        # metapaths from B to C - pure inputs/outputs: edges that connect exactly B or its subset to exactly C or its superset

        return result


    def check_no_loops(self, edges):
        import networkx as nx
        g = nx.DiGraph()
        for edge in edges:
            invertex=edge.invertex
            if edge.attributes is not None:
                invertex=edge.invertex.difference(edge.attributes)
            outvertex=edge.outvertex
            g.add_edge(frozenset(invertex), frozenset(outvertex))

        try:
            cycle = nx.simple_cycles(g)
            if len(cycle)>0:
                return False
            else:
                return True
        except BaseException, e:
            return True

    def get_edge_list(self, path):
        result=set()
        for elt in path:
            result = result.union(elt)

        return list(result)

    def get_edge_list2(self, path):
        result=set()
        for elt in path:
            result = result.union({elt})

        return list(result)

    def get_all_metapaths_from2(self, source, target):
        """ Retrieves all metapaths between given source and target in the metagraph.
        :param source: set
        :param target: set
        :return: list of Metapath objects
        """

        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])

        # check subset
        if not source.intersection(self.generating_set) == source:
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.intersection(self.generating_set) == target:
            raise MetagraphException('target', resources['not_a_subset'])

        # compute A* first
        if self.a_star is None:
            #print('computing closure..')
            self.a_star = self.get_closure().tolist()
            #print('closure computation- %s'%(time.time()- start))

        metapaths = []
        all_applicable_input_rows = []
        for x_i in source:
            index = list(self.generating_set).index(x_i)
            if index not in all_applicable_input_rows:
                all_applicable_input_rows.append(index)

        for i in all_applicable_input_rows:
            metapath_exist = False
            cumulative_output = []
            cumulative_edges = []
            for x_j in target:
                j = list(self.generating_set).index(x_j)
                if self.a_star[i][j] is not None:
                    metapath_exist = True
                    # x_j is already an output
                    cumulative_output.append(x_j)
                    triples = MetagraphHelper().get_triples(self.a_star[i][j])
                    for triple in triples:
                        # retain cooutputs
                        output = triple.cooutputs
                        if output is not None and output not in cumulative_output:
                            cumulative_output.append(output)
                        #... and edges
                        if isinstance(triple.edges, Edge):
                            edges = MetagraphHelper().get_edge_list([triple.edges])
                        else:
                            edges = MetagraphHelper().get_edge_list(triple.edges)

                        for edge in edges:
                            if edge not in cumulative_edges:
                                cumulative_edges.append(edge)

            if not metapath_exist:
                return None

            is_subset = True
            for elt in list(target):
                if elt not in cumulative_output:
                    is_subset = False
                    break
            if is_subset:
                for edge in cumulative_edges:
                    if edge not in metapaths:
                        metapaths.append(edge)

        valid_metapaths = []
        from itertools import combinations
        all_subsets = sum(map(lambda r: list(combinations(metapaths, r)), range(1, len(metapaths)+1)), [])
        for path in all_subsets:
            if len(path) <= len(metapaths):
                mp = Metapath(source, target, list(path))
                if self.is_metapath(mp):
                    valid_metapaths.append(mp)

        #print('valid metapath computation- %s'%(time.time()- start))
        return valid_metapaths

    def get_all_metapaths_from3(self, source, target):
        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])

        # check subset
        if not source.intersection(self.generating_set) == source:
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.intersection(self.generating_set) == target:
            raise MetagraphException('target', resources['not_a_subset'])

        # compute A* first
        if self.a_star is None:
            self.a_star = self.get_closure().tolist()

        metapaths = []
        all_applicable_input_rows = []
        for x_i in source:
            index = list(self.generating_set).index(x_i)
            if index not in all_applicable_input_rows:
                all_applicable_input_rows.append(index)


        cumulative_output_global = []
        cumulative_edges_global = []
        for i in all_applicable_input_rows:
            mp_exist_for_row=False
            cumulative_output_local = []
            cumulative_edges_local = []
            for x_j in target:
                j = list(self.generating_set).index(x_j)

                if self.a_star[i][j] is not None:
                    mp_exist_for_row = True

                    # x_j is already an output
                    cumulative_output_local.append(x_j)
                    triples = MetagraphHelper().get_triples(self.a_star[i][j])
                    for triple in triples:
                        # retain cooutputs
                        output = triple.cooutputs
                        if output is not None:
                            cumulative_output_local += output
                        if output is not None:
                            cumulative_output_global += output

                        #... and edges
                        if isinstance(triple.edges, Edge):
                            edges = MetagraphHelper().get_edge_list([triple.edges])
                        else:
                            edges = MetagraphHelper().get_edge_list(triple.edges)

                        for edge in edges:
                            if edge not in cumulative_edges_local:
                                cumulative_edges_local.append(edge)
                            if edge not in cumulative_edges_global:
                                cumulative_edges_global.append(edge)

            if not mp_exist_for_row:
               continue

            # check if cumulative outputs form a cover for the target
            if set(target).issubset(set(cumulative_output_local)):
                if set(cumulative_edges_local) not in metapaths:
                    metapaths.append(set(cumulative_edges_local))

            elif set(target).issubset(set(cumulative_edges_global)):
                if set(cumulative_edges_global) not in metapaths:
                    metapaths.append(set(cumulative_edges_global))

            else:
                break

        if len(metapaths)>0:
            result=[]
            for path in metapaths:
                # check no loops
                #if self.check_no_loops(list(path)):
                mp = Metapath(source, target, list(path))
                if self.is_metapath(mp):
                   result.append(mp)
            return result
        else:
            return None

    def is_metapath(self, metapath_candidate):
        """ Checks if the given candidate is a metapath.
        :param metapath_candidate: Metapath object
        :return: boolean
        """

        if metapath_candidate is None:
            raise MetagraphException('metapath_candidate', resources['value_null'])

        all_inputs=[]
        all_outputs=[]
        for edge in metapath_candidate.edge_list:
            for input_elt in list(edge.invertex):
                if input_elt not in all_inputs:
                    all_inputs.append(input_elt)
            for output_elt in list(edge.outvertex):
                if output_elt not in all_outputs:
                    all_outputs.append(output_elt)

        # now check input and output sets
        if (set(all_inputs).difference(set(all_outputs)).issubset(metapath_candidate.source)) and \
           set(metapath_candidate.target).issubset(all_outputs):
            return True

        return False

    def is_edge_dominant_metapath(self, metapath):
        """ Checks if the given metapath is an edge-dominant metapath.
        :param metapath: Metapath object
        :return: boolean
        """

        if metapath is None:
            raise MetagraphException('metapath', resources['value_null'])

        from itertools import combinations
        # check input metapath is valid
        if not self.is_metapath(metapath):
            return False

        all_subsets = sum(map(lambda r: list(combinations(metapath.edge_list, r)),
                              range(1, len(metapath.edge_list)+1)), [])
        # if one proper subset is a metapath then not edge dominant
        for path in all_subsets:
            # must be a proper subset
            if len(path) < len(metapath.edge_list):
                mp = Metapath(metapath.source, metapath.target, list(path))
                if self.is_metapath(mp):
                    return False

        return True

    def is_input_dominant_metapath(self, metapath):
        """ Checks if the given metapath is an input-dominant metapath.
        :param metapath: Metapath object
        :return: boolean
        """

        if metapath is None:
            raise MetagraphException('metapath', resources['value_null'])

        from itertools import combinations
        # check input metapath is valid
        if not self.is_metapath(metapath):
            return False

        # get all proper subsets of subset1
        all_subsets = sum(map(lambda r: list(combinations(metapath.source, r)), range(1, len(metapath.source)+1)), [])
        # if one proper subset has a metapath to subset2 then not input dominant
        for subset in all_subsets:
            # must be proper subset
            if len(subset) < len(metapath.source):
                if isinstance(subset, tuple):
                    subset = set(list(subset))
                metapath1 = self.get_all_metapaths_from(subset, metapath.target)
                if metapath1 is not None and len(metapath1) > 0:
                    #print('source: %s, target: %s'%(subset, metapath.target))
                    return False
        return True

    def is_dominant_metapath(self, metapath):
        """ Checks if the given metapath is a dominant metapath.
        :param metapath: Metapath object
        :return: boolean
        """

        if metapath is None:
            raise MetagraphException('metapath', resources['value_null'])

        # check input metapath is valid
        if not self.is_metapath(metapath):
            return False

        if (self.is_edge_dominant_metapath(metapath) and
           self.is_input_dominant_metapath(metapath)):

            return True

        return False

    def is_redundant_edge(self, edge, metapath, source, target):
        """ Checks if the given edge is redundant for the given metapath.
        :param edge: Edge object
        :param metapath: Metapath object
        :param source: set
        :param target: set
        :return: boolean
        """

        if edge is None:
            raise MetagraphException('edge', resources['value_null'])
        if metapath is None:
            raise MetagraphException('metapath', resources['value_null'])
        if source is None:
            raise MetagraphException('source', resources['value_null'])
        if target is None:
            raise MetagraphException('target', resources['value_null'])

        # check input metapath is valid
        if not self.is_metapath(metapath):
            raise MetagraphException('metapath', resources['arguments_invalid'])

        from itertools import combinations
        all_subsets = sum(map(lambda r: list(combinations(target, r)), range(1, len(target)+1)), [])
        # get all metapaths from subset1 to proper subsets of subset2
        for subset in all_subsets:
            if len(subset) < len(target):
                metapaths = self.get_all_metapaths_from(source, target)
                # check if edges is in every metapath found
                if metapaths is not None and len(metapaths) > 0:
                    for mp in metapaths:
                        if not MetagraphHelper().is_edge_in_list(edge, mp.edge_list):
                            # redundant
                            return True

                    # non redundant
                    return False
        return False

    def is_cutset_temp(self, edge_list, source, target):
        """ Checks if an edge list is a cutset between a given source and target.
        :param edge_list: list of Edge objects
        :param source: set
        :param target: set
        :return: boolean
        """

        if edge_list is None:
            raise MetagraphException('edges', resources['value_null'])
        if source is None:
            raise MetagraphException('source', resources['value_null'])
        if target is None:
            raise MetagraphException('target', resources['value_null'])

        # remove input edge list from original list
        original_edges = self.edges
        modified_edge_list = []
        for edge1 in original_edges:
            included = False
            for edge2 in edge_list:
                if edge1.invertex == edge2.invertex and edge1.outvertex == edge2.outvertex:
                    included = True
                    break
            if not included:
                modified_edge_list.append(edge1)

        mg = Metagraph(self.generating_set)
        mg.add_edges_from(modified_edge_list)
        #adjacency_matrix = mg.adjacency_matrix().tolist()

        metapaths = mg.get_all_metapaths_from(source, target)

        if metapaths is not None and len(metapaths) > 0:
            return False

        return True

    def is_cutset(self, edge_list, source, target):
        """ Checks if an edge list is a cutset between a given source and target.
        :param edge_list: list of Edge objects
        :param source: set
        :param target: set
        :return: boolean
        """

        if edge_list is None:
            raise MetagraphException('edges', resources['value_null'])
        if source is None:
            raise MetagraphException('source', resources['value_null'])
        if target is None:
            raise MetagraphException('target', resources['value_null'])

        # get all metapaths
        metapaths = self.get_all_metapaths_from(source, target)
        if metapaths is not None and len(metapaths)>0:
           for metapath in metapaths:
                updated = MetagraphHelper().remove_edge_list(edge_list, metapath.edge_list)
                mpc = Metapath(source, target, updated)
                if self.is_metapath(mpc):
                    # not a cutset
                    return False

           # is a cutset
           return True

        return False

    def get_minimal_cutset(self, source, target):
        """ Retrieves the minimal cutset between a given source and target.
        :param source: set
        :param target: set
        :return: list of Edge objects
        """

        if source is None:
            raise MetagraphException('source', resources['value_null'])
        if target is None:
            raise MetagraphException('target', resources['value_null'])

        metapaths = self.get_all_metapaths_from(source, target)
        if metapaths is None or len(metapaths) == 0:
            return None

        cutsets = []
        from itertools import combinations
        # noinspection PyTypeChecker
        for metapath in metapaths:
            all_combinations = sum(map(lambda r: list(combinations(metapath.edge_list, r)),
                                   range(1, len(metapath.edge_list)+1)), [])
            for combination in all_combinations:
                if self.is_cutset(list(combination), source, target) and list(combination) not in cutsets:
                    cutsets.append(list(combination))

        # return smallest cutset
        if len(cutsets) > 0:
            smallest = cutsets[0]
            for cutset in cutsets:
                if len(cutset) < len(smallest):
                    smallest = cutset
            return smallest

        return None

    def is_bridge(self, edge_list, source, target):
        """ Checks if a given edge list forms a bridge between a source and a target.
        :param edge_list: list of Edge objects
        :param source: set
        :param target: set
        :return: boolean
        """
        if edge_list is None:
            raise MetagraphException('edge_list', resources['value_null'])
        if source is None:
            raise MetagraphException('source', resources['value_null'])
        if target is None:
            raise MetagraphException('target', resources['value_null'])
        if len(edge_list)!=1:
            return False

        if not isinstance(edge_list, list):
            raise MetagraphException('edge_list', resources['arguments_invalid'])

        return self.is_cutset(edge_list, source, target)

    def get_projection(self, generator_subset):
        """ Gets the metagraph projection for a subset of the generating set.
        :param generator_subset: set
        :return: Metagraph object
        """

        # gen set size N
        # edge count C
        # proj elts M

        if generator_subset is None:
            raise MetagraphException('generator_subset', resources['value_null'])

        # step1. reduce A* by removing unwanted rows, cols
        applicable_rows_and_cols = []
        for x_i in generator_subset:
            index = list(self.generating_set).index(x_i)
            if index not in applicable_rows_and_cols:
                applicable_rows_and_cols.append(index)

        a_star = self.get_closure().tolist()

        # sort list
        applicable_rows_and_cols = sorted(applicable_rows_and_cols)

        size = len(generator_subset)
        a_star_new = MetagraphHelper().get_null_matrix(size, size)

        # O(M2)
        m = 0
        for i in applicable_rows_and_cols:
            n = 0
            for j in applicable_rows_and_cols:
                a_star_new[m][n] = a_star[i][j]
                n += 1
            m += 1

        # step2. create list L from edges in E (not E') s.t. V_e is a subset of X'
        edge_list1 = []
        all_triples = []
        k = len(applicable_rows_and_cols)
        # O(M2C2)
        for i in range(k):
            for j in range(k):
                if a_star_new[i][j] is not None:
                    triples = MetagraphHelper().get_triples(a_star_new[i][j])
                    for triple in triples:
                        if isinstance(triple.edges, Edge):
                            new_triple = Triple(triple.coinputs, triple.cooutputs, [triple.edges])
                            if new_triple not in all_triples:
                                all_triples.append(new_triple)
                            edges = MetagraphHelper().extract_edge_list([triple.edges])
                        else:
                            if triple not in all_triples:
                                all_triples.append(triple)
                            edges = MetagraphHelper().extract_edge_list(triple.edges)

                        # select edges with invertices in generator_subset
                        for edge in edges:
                            if edge.invertex.issubset(set(generator_subset)) and ([edge] not in edge_list1):
                                edge_list1.append([edge])

        # step3. find combinations of triples s.t. union(CI_t_i)\ union(CO_t_i) is a subset of generator_subset
        from itertools import combinations
        #all_combs=nCr=n!/r!(n-r)! = C, C(C-1)/2, C(C-1)(C-2)/3 to 1  (r=1 to C)
        all_combinations = sum(map(lambda r: list(combinations(all_triples, r)), range(1, len(all_triples)+1)), [])
        # O(NC!))
        for combination in all_combinations:
            # O(NC)
            coinput = MetagraphHelper().get_coinputs_from_triples(combination)
            cooutput = MetagraphHelper().get_cooutputs_from_triples(combination)
            diff = set(coinput).difference(set(cooutput))
            if diff.issubset(set(generator_subset)):
                # add edges in combination to L
                edges2 = MetagraphHelper().get_edges_from_triple_list(list(combination))
                included = MetagraphHelper().is_edge_list_included_recursive(edges2, edge_list1)
                if not included:
                    edge_list1.append(edges2)

        # step4. construct L0 from L
        triples_list_l0 = []
        # O(C2N)
        for element in edge_list1:
            all_inputs = MetagraphHelper().get_netinputs(element)
            all_outputs = MetagraphHelper().get_netoutputs(element)
            net_inputs = list(set(all_inputs).difference(all_outputs))
            net_outputs = all_outputs
            new_triple = Triple(set(net_inputs), set(net_outputs), element)
            if new_triple not in triples_list_l0:
                triples_list_l0.append(new_triple)

        # step5. reduce L0
        to_eliminate = []
        # O(C4)
        for i in triples_list_l0:
            for j in triples_list_l0:
                if i != j:
                    # check if i is subsumed by j
                    edges_i = MetagraphHelper().get_edge_list(i.edges)
                    edges_j = MetagraphHelper().get_edge_list(j.edges)
                    outputs_i = i.cooutputs
                    outputs_j = j.coinputs

                    # check j's edges are a subset of i's edges
                    subset = True
                    for edge in edges_j:
                        if edge not in edges_i:
                            subset = False
                            break

                    inclusive = True
                    if subset:
                        # edges form a subset..check outputs are inclusive
                        outputs_j_in_x = []
                        for output in outputs_j:
                            if (output in generator_subset) and (output not in outputs_j_in_x):
                                outputs_j_in_x.append(output)

                        outputs_i_in_x = []
                        for output in outputs_i:
                            if (output in generator_subset) and (output not in outputs_i_in_x):
                                outputs_i_in_x.append(output)

                        for output in outputs_i_in_x:
                            if output not in outputs_j_in_x:
                                inclusive = False
                                break

                        if inclusive and (i not in to_eliminate):
                            to_eliminate.append(i)
                            break

        for elt in to_eliminate:
            triples_list_l0.remove(elt)

        to_drop = []

        for i in triples_list_l0:
            for j in triples_list_l0:
                if i != j:
                    inputs_i = i.coinputs
                    inputs_j = j.coinputs
                    outputs_i = i.cooutputs
                    outputs_j = j.cooutputs

                    # check if input and output of j are a subset of i
                    input_subset = True
                    for input_elt in inputs_j:
                        if input_elt not in inputs_i:
                            input_subset = False
                            break

                    if input_subset:
                        output_subset = True
                        for output in outputs_j:
                            if output not in outputs_i:
                                output_subset = False
                                break

                        if output_subset:
                            for elt in j.cooutputs:
                                i.cooutputs.remove(elt)
                            if (i.cooutputs is None or len(i.cooutputs) == 0) and (i not in to_drop):
                                to_drop.append(i)

        for item in to_drop:
            triples_list_l0.remove(item)

        #step6. merge triples based on identical inputs and outputs
        triples_to_merge = dict()
        index = 0
        for triple1 in triples_list_l0:
            for triple2 in triples_list_l0:
                if triple1 != triple2:
                    # merge if same input and output
                    if triple1.coinputs == triple2.coinputs and triple1.cooutputs == triple2.cooutputs:
                        if index not in triples_to_merge:
                            triples_to_merge[index] = []
                        if triple2 not in triples_to_merge[index]:
                            triples_to_merge[index].append(triple2)
            index += 1

        post_merge_triples = dict()
        for index, triples_list in triples_to_merge.iteritems():
            triple1 = triples_to_merge[index]
            if triple1 in triples_list_l0:
                triples_list_l0.remove(triple1)
                for triple2 in triples_list:
                    if triple2 in triples_list_l0:
                        triples_list_l0.remove(triple2)
                    if index not in post_merge_triples:
                        post_merge_triples[index] = Triple(triple1.coinputs, triple1.cooutputs,
                                                           [triple1.edges, triple2.edges])
                    else:
                        post_merge_triples[index].edges.append(triple2.edges)
                triples_list_l0.append(post_merge_triples[index])

        #step7. and triples with identical inputs only
        triples_to_merge = dict()
        index = 0
        for triple1 in triples_list_l0:
            for triple2 in triples_list_l0:
                if triple1 != triple2:
                    # merge if same input
                    if triple1.coinputs == triple2.coinputs:
                        if index not in triples_to_merge:
                            triples_to_merge[index] = []
                        if triple2 not in triples_to_merge[index]:
                            triples_to_merge[index].append(triple2)
            index += 1

        triple_list_l0_copy = copy.copy(triples_list_l0)

        post_merge_triples = dict()
        #O(C3)
        for index, triples_list in triples_to_merge.iteritems():
            triple1 = triple_list_l0_copy[index]
            if triple1 in triples_list_l0:
                triples_list_l0.remove(triple1)
                for triple2 in triples_list:
                    if triple2 in triples_list_l0:
                        triples_list_l0.remove(triple2)
                    if index not in post_merge_triples:
                        edges_to_merge = list(triple1.edges)
                        for elt in list(triple2.edges):
                            if elt not in edges_to_merge:
                                edges_to_merge.append(elt)
                        post_merge_triples[index] = Triple(triple1.coinputs, triple1.cooutputs.union(triple2.cooutputs),
                                                           edges_to_merge)
                    else:
                        edges_to_merge = list(post_merge_triples[index].edges)
                        for elt in list(triple2.edges):
                            if elt not in edges_to_merge:
                                edges_to_merge.append(elt)
                        post_merge_triples[index] = Triple(post_merge_triples[index].coinputs,
                                                           post_merge_triples[index].cooutputs.union(triple2.cooutputs),
                                                           edges_to_merge)  # triple1
                triples_list_l0.append(post_merge_triples[index])

        temp_list = []
        for triple in triples_list_l0:
            # remove all inputs and outputs that are not in generator_subset
            valid_inputs = triple.coinputs.intersection(set(generator_subset))
            valid_outputs = triple.cooutputs.intersection(set(generator_subset))
            new_triple = Triple(valid_inputs, valid_outputs, triple.edges)
            if new_triple not in temp_list:
                temp_list.append(new_triple)

        # remove any tuples with zero input or output
        final_triples_list = []
        for triple in temp_list:
            if triple.coinputs is not None and triple.cooutputs is not None and \
               len(triple.coinputs) > 0 and len(triple.cooutputs) > 0 and \
               (triple not in final_triples_list):
                final_triples_list.append(triple)

        edge_list = []
        for triple in final_triples_list:
            edge = Edge(triple.coinputs, triple.cooutputs, None, repr(triple.edges))
            if edge not in edge_list:
                edge_list.append(edge)

        if edge_list is None or len(edge_list) == 0:
            return None

        mg = Metagraph(set(generator_subset))
        mg.add_edges_from(edge_list)

        return mg

    def incidence_matrix(self):
        """ Gets the metagraph projection for a subset of the generating set.
        :return: numpy.matrix
        """

        rows = len(self.generating_set)
        cols = len(self.edges)

        incidence_matrix = MetagraphHelper().get_null_matrix(rows, cols)

        for i in range(rows):
            x_i = list(self.generating_set)[i]
            for j in range(cols):
                e_j = self.edges[j]
                if x_i in e_j.invertex:
                    incidence_matrix[i][j] = -1
                elif x_i in e_j.outvertex:
                    incidence_matrix[i][j] = 1
                else:
                    incidence_matrix[i][j] = None

        # noinspection PyCallingNonCallable
        return matrix(incidence_matrix)

    def get_inverse(self):
        """ Gets the inverse metagraph.
        :return: Metagraph object
        """

        # gen set size N
        # edge count C
        # proj elts M

        incidence_m = self.incidence_matrix().tolist()

        edge_list = []
        # step1: extract indices
        col_index = 0
        # O(N3)
        for i in range(len(incidence_m[0])):
            negative_item_indices = []
            positive_item_indices = []
            column = [row[col_index] for row in incidence_m]
            row_index = 0
            for item1 in column:
                if item1 == -1:
                   # get all elements with +1 across the row
                    row = incidence_m[row_index]
                    eligible = []
                    local_index = 0
                    for item2 in row:
                        if item2 == 1 and local_index not in eligible:
                            eligible.append(local_index)
                        local_index += 1

                    if len(eligible) == 0:
                        row_index += 1  # debug dr check this
                        continue

                    # TODO: how do we handle multiple occurrences of +1?
                    # keep a track of -1 and + 1 indices
                    if (row_index, col_index) not in negative_item_indices:
                        negative_item_indices.append((row_index, col_index))

                    for local_index in eligible:
                        if (row_index, local_index) not in positive_item_indices:
                            positive_item_indices.append((row_index, local_index))

                row_index += 1

            # construct edges from indices
            invertex = []
            outvertex = []
            edge_label = None
            for negative_item_index in negative_item_indices:
                if repr(self.edges[negative_item_index[1]]) not in outvertex:
                    outvertex.append(repr(self.edges[negative_item_index[1]]))

            for positive_item_index in positive_item_indices:
                if repr(self.edges[positive_item_index[1]]) not in invertex:
                    invertex.append(repr(self.edges[positive_item_index[1]]))

                # generate label
                if edge_label is None:
                    edge_label = '<%s,%s>' % (list(self.generating_set)[positive_item_index[0]],
                                              repr(self.edges[positive_item_index[1]]))
                else:
                    edge_label += ', <%s,%s>' % (list(self.generating_set)[positive_item_index[0]],
                                                 repr(self.edges[positive_item_index[1]]))

            if invertex is not None and outvertex is not None and len(invertex) > 0 and len(outvertex) > 0:
                edge = Edge(set(invertex), set(outvertex), None, edge_label)
                if edge not in edge_list:
                    edge_list.append(edge)
            col_index += 1

        # compress the edges
        compressed_edges = []
        for edge1 in edge_list:
            compressed = False
            for edge2 in edge_list:
                if edge1 != edge2:
                    if edge1.invertex == edge2.invertex and edge1.label == edge2.label:
                        new_edge = Edge(edge1.invertex, edge1.outvertex.union(edge2.outvertex), None, edge1.label)
                        if not MetagraphHelper().is_edge_in_list(new_edge, compressed_edges):
                            compressed_edges.append(new_edge)
                        compressed = True
            if not compressed and (not MetagraphHelper().is_edge_in_list(edge1, compressed_edges)):
                compressed_edges.append(edge1)

        # add links to alpha and beta
        row_index = 0
        occurrences = lambda s, lst: (y for y, e in enumerate(lst) if e == s)
        for row in incidence_m:
            if row.__contains__(-1) and (not row.__contains__(1)):
                col_indices = list(occurrences(-1, row))
                for col_index in col_indices:
                    label = '<%s, alpha>' % (list(self.generating_set)[row_index])
                    new_edge = Edge({'alpha'}, {repr(self.edges[col_index])}, None, label)
                    if not MetagraphHelper().is_edge_in_list(new_edge, compressed_edges):
                        compressed_edges.append(new_edge)

            elif row.__contains__(1) and (not row.__contains__(-1)):
                col_indices = list(occurrences(1, row))
                for col_index in col_indices:
                    label = '<%s, %s>' % (list(self.generating_set)[row_index], repr(self.edges[col_index]))
                    new_edge = Edge({repr(self.edges[col_index])}, {'beta'}, None, label)
                    if not MetagraphHelper().is_edge_in_list(new_edge, compressed_edges):
                        compressed_edges.append(new_edge)
            row_index += 1

        mg = Metagraph(MetagraphHelper().get_generating_set(compressed_edges))
        mg.add_edges_from(compressed_edges)
        return mg

    def get_efm(self, generator_subset):
        """ Gets the element-flow metagraph.
        :param generator_subset: set
        :return: Metagraph object
        """

        # gen set size N
        # edge count C
        # efm elts M

        if generator_subset is None or len(generator_subset) == 0:
            raise MetagraphException('generator_subset', resources['value_null'])

        incidence_m = self.incidence_matrix().tolist()
        excluded = self.generating_set.difference(generator_subset)

        # compute G1 and G2
        applicable_rows = []
        # O(M)
        for x_i in generator_subset:
            index = list(self.generating_set).index(x_i)
            if index not in applicable_rows:
                applicable_rows.append(index)

        # sort list
        applicable_rows = sorted(applicable_rows)
        inapplicable_rows = sorted(set(range(len(self.generating_set))).difference(applicable_rows))

        rows1 = len(generator_subset)
        cols1 = len(incidence_m[0])
        rows2 = len(excluded)
        g1 = MetagraphHelper().get_null_matrix(rows1, cols1)
        g2 = MetagraphHelper().get_null_matrix(rows2, cols1)

        m = 0
        for i in applicable_rows:
            n = 0
            for j in range(cols1):
                g1[m][n] = incidence_m[i][j]
                n += 1
            m += 1

        m = 0
        for i in inapplicable_rows:
            n = 0
            for j in range(cols1):
                g2[m][n] = incidence_m[i][j]
                n += 1
            m += 1

        g1_t = MetagraphHelper().transpose_matrix(g1)
        # O(N3)
        mult_r = MetagraphHelper().custom_multiply_matrices(g2, g1_t, self.edges)
        row_index = 0
        edge_list = []
        lookup = dict()
        # O(N3)
        for row in mult_r:
            col_index = 0
            invertices = []
            outvertices = []
            # O(N2)
            for elt in row:
                if len(elt) > 0 and isinstance(list(elt)[0], tuple):
                    extracted = list(elt)[0]
                    if 1 in extracted:
                        invertex = []
                        local_indices = [row.index(elt2) for elt2 in row if elt.issubset(elt2)]
                        #O(N)
                        for local_index in local_indices:
                            value = list(self.generating_set)[applicable_rows[local_index]]
                            if value not in invertex:
                                invertex.append(value)

                        if set(invertex) not in invertices:
                            invertices.append(set(invertex))
                        if repr(invertex) not in lookup:
                            lookup[repr(invertex)] = extracted[1]

                    elif -1 in extracted:
                        outvertex = []
                        local_indices = [row.index(elt2) for elt2 in row if elt.issubset(elt2)]
                        for local_index in local_indices:
                            value = list(self.generating_set)[applicable_rows[local_index]]
                            if value not in outvertex:
                                outvertex.append(value)

                        if set(outvertex) not in outvertices:
                            outvertices.append(set(outvertex))
                        if repr(outvertex) not in lookup:
                            lookup[repr(outvertex)] = extracted[1]

                col_index += 1

            # combine the invertices and outvertices
            for invertex in invertices:
                for outvertex in outvertices:
                    # create flow composition
                    label = '%s <%s; %s>' % (list(self.generating_set)[inapplicable_rows[row_index]],
                                             lookup[repr(list(invertex))], lookup[repr(list(outvertex))])
                    edge = Edge(invertex, outvertex, None, label)
                    if not MetagraphHelper().is_edge_in_list(edge, edge_list):
                        edge_list.append(edge)

            row_index += 1

        # combine edges
        final_edge_list = []
        for edge1 in edge_list:
            match = False
            for edge2 in edge_list:
                if edge1 != edge2:
                    if edge1.invertex == edge2.invertex and edge1.outvertex == edge1.outvertex:
                        match = True
                        comp1 = MetagraphHelper().extract_edge_label_components(edge1.label)
                        comp2 = MetagraphHelper().extract_edge_label_components(edge2.label)
                        combined = (comp1[0].union(comp2[0]), comp1[1].union(comp2[1]), comp1[2].union(comp2[2]))
                        label = '%s <%s; %s>' % (list(combined[0]), list(combined[1]), list(combined[2]))
                        combined_edge = Edge(edge1.invertex, edge1.outvertex, None, label)
                        if not MetagraphHelper().is_edge_in_list(combined_edge, final_edge_list):
                            final_edge_list.append(combined_edge)
            if not match:
                if not MetagraphHelper().is_edge_in_list(edge1, final_edge_list):
                    final_edge_list.append(edge1)

        if len(final_edge_list) > 0:
            gen_set = MetagraphHelper().get_generating_set(final_edge_list)
            mg = Metagraph(gen_set)
            mg.add_edges_from(final_edge_list)
            return mg

        return None

    def dominates(self, metagraph2):
        """Checks if the metagraph dominates that provided.
        :param metagraph2: Metagraph object
        :return: boolean
        """

        if metagraph2 is None:
            raise MetagraphException('metagraph2', resources['value_null'])

        #adjacency_matrix = self.adjacency_matrix().tolist()
        #all_metapaths1 = []

        from itertools import combinations
        all_sources1 = sum(map(lambda r: list(combinations(self.generating_set, r)),
                               range(1, len(self.generating_set))), [])
        all_targets1 = copy.copy(all_sources1)

        all_sources2 = sum(map(lambda r: list(combinations(metagraph2.generating_set, r)),
                               range(1, len(metagraph2.generating_set))), [])
        all_targets2 = copy.copy(all_sources2)

        all_metapaths1 = []
        i = 1
        #s1 =  len(all_sources1)
        #t1 =  len(all_targets1)
        #s2 =  len(all_sources2)
        #t2 =  len(all_targets2)

        for source in all_sources1:
            for target in all_targets1:
                if source != target:
                    mp = self.get_all_metapaths_from(set(source), set(target))
                    if mp is not None and len(mp) > 0 and (mp not in all_metapaths1):
                        all_metapaths1.append(mp)
                    #print(i)
                    i += 1

        all_metapaths2 = []
        for source in all_sources2:
            for target in all_targets2:
                if source != target:
                    mp = self.get_all_metapaths_from(set(source), set(target))
                    if mp is not None and len(mp) > 0 and (mp not in all_metapaths2):
                        all_metapaths2.append(mp)

        for mp1 in all_metapaths2:
            dominated = False
            for mp2 in all_metapaths1:
                if mp2.dominates(mp1):
                    dominated = True
                    break
            if not dominated:
                return False

        return True

    def __repr__(self):
        edge_desc = [repr(edge) for edge in self.edges]
        full_desc = ''
        for desc in edge_desc:
            if full_desc == '':
                full_desc = desc
            else:
                full_desc += ", " + desc
        desc = '%s(%s)' % (str(type(self)), full_desc)
        desc = desc.replace('\\', '')
        return desc

class ConditionalMetagraph(Metagraph):
    """ Represents a conditional metagraph that is instantiated using a set of variables and a set of propositions.
    """

    def __init__(self, variables_set, propositions_set):
        if not isinstance(variables_set, set):
            raise MetagraphException('variable_set', resources['format_invalid'])
        if not isinstance(propositions_set, set):
            raise MetagraphException('propositions_set', resources['format_invalid'])
        if len(variables_set.intersection(propositions_set)) > 0:
            raise MetagraphException('variables_and_propositions', resources['partition_invalid'])
        self.nodes = []
        self.edges = []
        self.mg = None
        self.variables_set = variables_set
        self.propositions_set = propositions_set
        self.generating_set = variables_set.union(propositions_set)
        super(ConditionalMetagraph, self).__init__(self.generating_set)

    def add_edges_from(self, edge_list):
        """ Adds the given list of edges to the conditional metagraph.
        :param edge_list: list of Edge objects
        :return: None
        """
        if edge_list is None or len(edge_list) == 0:
            raise MetagraphException('edge_list', resources['value_null'])

        for edge in edge_list:
            if not isinstance(edge, Edge):
                raise MetagraphException('edge', resources['format_invalid'])
            if len(edge.invertex.union(edge.outvertex)) == 0:
                raise MetagraphException('edge', resources['value_null'])
             # if outvertex contains a proposition, the outvertex cannot contain any other element
            for proposition in self.propositions_set:
                if proposition in edge.outvertex:
                    if len(edge.outvertex) > 1:
                        raise MetagraphException('edge', resources['value_invalid'])

        for edge in edge_list:
            node1 = Node(edge.invertex)
            node2 = Node(edge.outvertex)
            if not MetagraphHelper().is_node_in_list(node1, self.nodes):
                self.nodes.append(node1)
            if not MetagraphHelper().is_node_in_list(node2, self.nodes):
                self.nodes.append(node2)
            if edge not in self.edges: #debug dr dr
               self.edges.append(edge)

        self.edges = edge_list

    def add_metagraph(self, metagraph2):
        """ Adds the given conditional metagraph to current and returns the composed result.
        :param metagraph2: ConditonalMetagraph object
        :return: ConditonalMetagraph object
        """

        if metagraph2 is None:
            raise MetagraphException('metagraph2', resources['value_null'])

        generating_set1 = self.generating_set
        generating_set2 = metagraph2.generating_set

        if generating_set2 is None or len(generating_set2) == 0:
            raise MetagraphException('metagraph2.generating_set', resources['value_null'])

        # check if the generating sets of the matrices overlap (otherwise no sense in combining metagraphs)
        #intersection=generating_set1.intersection(generating_set2)
        #if intersection==None:
        #    raise MetagraphException('generating_sets', resources['no_overlap'])

        if len(generating_set1.difference(generating_set2)) == 0 and \
           len(generating_set2.difference(generating_set1)) == 0:
            # generating sets are identical..simply add edges
            # size = len(generating_set1)
            self.variables_set = self.variables_set.union(metagraph2.variables_set)
            self.propositions_set = self.variables_set.union(metagraph2.propositions_set)
            for edge in metagraph2.edges:
                if edge not in self.edges:
                    self.add_edge(edge)
        else:
            # generating sets overlap but are different...combine generating sets and then add edges
            # combined_generating_set = generating_set1.union(generating_set2)
            self.generating_set = generating_set1.union(generating_set2)
            self.variables_set = self.variables_set.union(metagraph2.variables_set)
            self.propositions_set = self.propositions_set.union(metagraph2.propositions_set)
            for edge in metagraph2.edges:
                if edge not in self.edges:
                    self.add_edge(edge)

        return self

    def get_context(self, true_propositions, false_propositions):
        """Retrieves the context metagraph for the given true and false propositions.
        :param true_propositions: set
        :param false_propositions: set
        :return: ConditionalMetagraph object
        """
        if true_propositions is None or len(true_propositions) == 0:
            raise MetagraphException('true_propositions', resources['value_null'])
        if false_propositions is None or len(false_propositions) == 0:
            raise MetagraphException('false_propositions', resources['value_null'])

        for proposition in true_propositions:
            if proposition not in self.propositions_set:
                raise MetagraphException('true_propositions', resources['range_invalid'])
        for proposition in false_propositions:
            if proposition not in self.propositions_set:
                raise MetagraphException('false_propositions', resources['range_invalid'])

        edges_to_remove = []
        edges_copy = copy.copy(self.edges)
        for edge in edges_copy:
            for proposition in list(true_propositions):
                if proposition in edge.invertex:
                    edge.invertex.difference({proposition})
                    # remove if this results in an invertex that is null
                    if len(edge.invertex) == 0 and edge not in edges_to_remove:
                        edges_to_remove.append(edge)
                if proposition in edge.outvertex:
                    edge.outvertex.difference({proposition})
                    # remove if this results in an outvertex that is null
                    if len(edge.outvertex) == 0 and edge not in edges_to_remove:
                        edges_to_remove.append(edge)

            for proposition in list(false_propositions):
                if proposition in edge.invertex or proposition in edge.outvertex:
                    # remove edge
                    if edge not in edges_to_remove:
                        edges_to_remove.append(edge)

        # create new conditional metagraph describing context
        context = ConditionalMetagraph(self.variables_set, self.propositions_set)
        for edge in edges_to_remove:
            if edge in edges_copy:
                edges_copy.remove(edge)
        context.add_edges_from(edges_copy)

        return context

    def get_projection(self, variables_subset):
        """ Gets the conditional metagraph projection for a subset of its variable set.
        :param variables_subset: set
        :return: Metagraph object
        """
        if variables_subset is None or len(variables_subset) == 0:
            raise MetagraphException('variables_subset', resources['value_null'])

        subset = variables_subset.union(self.propositions_set)
        generator_set = self.variables_set.union(self.propositions_set)
        mg = Metagraph(generator_set)
        mg.add_edges_from(self.edges)
        return mg.get_projection(subset)

    def get_all_metapaths_from_old(self, source, target, prop_subset=None):
        """ Retrieves all metapaths between given source and target in the conditional metagraph.
        :param source: set
        :param target: set
        :return: list of Metapath objects
        """

        if source is None or len(source) == 0:
            raise MetagraphException('subset1', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('subset2', resources['value_null'])
        if not source.issubset(self.generating_set):
            raise MetagraphException('subset1', resources['not_a_subset'])
        if not target.issubset(self.generating_set):
            raise MetagraphException('subset2', resources['not_a_subset'])

        generator_set = self.variables_set.union(self.propositions_set)
        if self.mg is None:
            self.mg = Metagraph(generator_set)
            self.mg.add_edges_from(self.edges)
        if prop_subset is not None:
            return self.mg.get_all_metapaths_from(source.union(prop_subset), target)
        else:
            return self.mg.get_all_metapaths_from(source.union(self.propositions_set), target)

    def get_all_metapaths_from(self, source, target, include_propositions=False):
        if source==None or len(source)==0:
            raise MetagraphException('subset1', resources['value_null'])
        if target==None or len(target)==0:
            raise MetagraphException('subset2', resources['value_null'])
        if not source.issubset(self.generating_set):
            raise MetagraphException('subset1', resources['not_a_subset'])
        if not target.issubset(self.generating_set):
            raise MetagraphException('subset2', resources['not_a_subset'])

        generator_set=self.variables_set.union(self.propositions_set)
        if self.mg==None:
            self.mg=Metagraph(generator_set)
            self.mg.add_edges_from(self.edges)

        if include_propositions:
            return self.mg.get_all_metapaths_from(source.union(self.propositions_set), target)

        return self.mg.get_all_metapaths_from(source, target)

    # debug dr
    def get_all_metapaths(self):
        """ Retrieves all metapaths in the conditional metagraph.
        :return: List of Metapath objects
        """

        from itertools import combinations
        all_subsets=sum(map(lambda r: list(combinations(self.nodes, r)), range(1, len(self.nodes)+1)), [])
        #all_subsets = self.nodes

        cap_reached = False
        all_metapaths = []
        for subset1 in all_subsets:
            for subset2 in all_subsets:
                if subset1 != subset2:

                    if len(subset1)>1:
                        element_set=set()
                        for node in subset1:
                            element_set = element_set.union(node.element_set)
                        node1 = Node(element_set)
                    else:
                        node1=subset1[0]

                    if len(subset2)>1:
                        element_set=set()
                        for node in subset2:
                            element_set = element_set.union(node.element_set)
                        node2 = Node(element_set)
                    else:
                        node2=subset2[0]

                    # TODO: can source and target in a metapath overlap?
                    if not MetagraphHelper().nodes_overlap([node1], [node2]):
                        source = MetagraphHelper().get_element_set([node1])
                        target = MetagraphHelper().get_element_set([node2])
                        mps = self.get_all_metapaths_from(source, target)
                        if mps is None or len(mps) == 0:
                            continue
                        # noinspection PyTypeChecker
                        for mp in mps:
                            if mp not in all_metapaths:
                                all_metapaths.append(mp)
                        #if len(all_metapaths) >= 10:
                        #    cap_reached = True
                        #    break

            #if cap_reached:
            #    break

        return all_metapaths

    def has_conflicts1(self, metapath):
        """Checks whether the given metapath has any conflicts.
        :param metapath: Metapath object
        :return: boolean
        """

        invertices = set()
        intersec = set()
        edges = metapath.edge_list
        for edge in edges:
            invertices = invertices.union(edge.invertex)
            if len(intersec)==0:
                intersec = set(edge.attributes)
            else:
                intersec = intersec.intersection(set(edge.attributes))

        potential_conflicts_set = invertices.intersection(self.propositions_set)
        if self.edge_attributes_conflict(potential_conflicts_set, intersec):
            return True

        return False

    def has_conflicts_1(self, metapath, conflict_sources=[]):
        edges=metapath.edge_list
        filtered=[]

        for edge in edges:
            # check if edge should be discarded
            inv = edge.invertex.difference(edge.attributes)
            inv_int = inv.intersection(metapath.source)
            outv_int = edge.outvertex.intersection(metapath.target)
            if (inv_int is None or len(inv_int)==0) or \
               (outv_int is None or len(outv_int)==0):
                # discard edge
                continue

            if edge not in filtered:
                filtered.append(edge)

        invertices=set()
        intersec=set()
        for edge1 in filtered:
            for edge2 in filtered:
                if edge1!=edge2:
                    invertices= edge1.invertex.union(edge2.invertex)
                    intersec = set(edge1.attributes).intersection(set(edge2.attributes))
                    potential_conflicts_set = invertices.intersection(self.propositions_set)
                    if self.edge_attributes_conflict(potential_conflicts_set, intersec, conflict_sources):
                        return True

        return False

    def has_conflicts(self, metapath, conflict_sources=[], conflicting_edges=[]):
        edges=metapath.edge_list
        filtered=[]
        conflicts=False

        for edge in edges:
            # check if edge should be discarded
            inv = edge.invertex.difference(edge.attributes)
            inv_int = inv.intersection(metapath.source)
            outv_int = edge.outvertex.intersection(metapath.target)
            if (inv_int is None or len(inv_int)==0) or \
               (outv_int is None or len(outv_int)==0):
                # discard edge
                continue

            if edge not in filtered:
                filtered.append(edge)

        invertices=set()
        intersec=set()
        for edge1 in filtered:
            for edge2 in filtered:
                if edge1!=edge2:
                    invertices= edge1.invertex.union(edge2.invertex)
                    intersec = set(edge1.attributes).intersection(set(edge2.attributes))
                    potential_conflicts_set = invertices.intersection(self.propositions_set)
                    conflict_sources=[]
                    if self.edge_attributes_conflict(potential_conflicts_set, intersec, conflict_sources):
                        conflicting_edges.append((edge1,edge2, conflict_sources))
                        conflicts= True

        return conflicts

    def has_redundancies2(self, metapath, redundant_edges=[]):
        edges=metapath.edge_list
        filtered=[]
        redundancies=False

        for edge in edges:
            # check if edge should be discarded
            inv = edge.invertex.difference(edge.attributes)
            inv_int = inv.intersection(metapath.source)
            outv_int = edge.outvertex.intersection(metapath.target)
            if (inv_int is None or len(inv_int)==0) or \
               (outv_int is None or len(outv_int)==0):
                # discard edge
                continue

            if edge not in filtered:
                filtered.append(edge)

        for edge1 in filtered:
            for edge2 in filtered:
                if edge1!=edge2:
                    invertices= edge1.invertex.union(edge2.invertex)
                    prop_int = invertices.intersection(self.propositions_set)
                    #print('check edge overlap: %s, %s'%(edge1,edge2))
                    if self.edge_attributes_overlap(prop_int):
                        #print('actual redundancy')
                        redundant_edges.append((edge1,edge2))
                        redundancies= True

        return redundancies


    def has_redundancies(self, metapath):
        """ Checks if given metapath has redundancies.
        :param metapath: Metapath object
        :return: boolean
        """

        # check input metapath is valid
        if not self.is_metapath(metapath):
            raise MetagraphException('metapath', resources['arguments_invalid'])

        return not self.is_dominant_metapath(metapath)

    def edge_attributes_conflict1(self, potential_conflicts_set, intersecting_attr_set):
        """ Checks if given edge attributes conflict.
        :param potential_conflicts_set: set
        :return: boolean
        """

        if potential_conflicts_set is None:
            raise MetagraphException('potential_conflicts_set', resources['value_null'])

        # currently checks if actions conflict
        # extend later to include active times etc
        actions = self.get_actions(potential_conflicts_set)

        malware_sigs = self.get_malware_sigs(potential_conflicts_set)
        sig_present = self.get_sig_present(potential_conflicts_set)

        # TODO: extend to support more attributes
        if len(intersecting_attr_set)>0:
            # check if diff response actions are applied to same malware sig list
            if len(actions)>1 and len(malware_sigs)>1 and len(sig_present)==1:
                intersection = set(malware_sigs[0])
                for sig_list in malware_sigs:
                    intersection = intersection.intersection(set(sig_list))
                if len(intersection)>0:
                    return True

            # check if same response action is applied to different sig lists
            if len(malware_sigs)>1 and len(actions)==1 and len(sig_present)==1:
                return True

        if ('allow' in actions or 'permit' in actions) and 'deny' in actions: # len(intersecting_attr_set)>0 and
            return True

        return False

    def edge_attributes_conflict(self, potential_conflicts_set, intersecting_attr_set, conflict_sources):
        if potential_conflicts_set==None:
           raise MetagraphException('potential_conflicts_set',resources['value_null'])

        # currently checks if actions conflict
        # extend later to include active times etc
        actions= self.get_actions(potential_conflicts_set)
        protocols = self.get_protocols(potential_conflicts_set)
        tcp_dports = self.get_tcp_ports(potential_conflicts_set,True)
        udp_dports = self.get_udp_ports(potential_conflicts_set,True)
        tcp_sports = self.get_tcp_ports(potential_conflicts_set,False)
        udp_sports = self.get_udp_ports(potential_conflicts_set,False)

        priorities= self.get_priorities(potential_conflicts_set)
        interfaces= self.get_interfaces(potential_conflicts_set)
        middlebox1_devices= self.get_middleboxes(potential_conflicts_set,1)
        middlebox2_devices= self.get_middleboxes(potential_conflicts_set,2)
        malware_profiles= self.get_malware_profiles(potential_conflicts_set)
        url_filter_profiles= self.get_url_filter_profiles(potential_conflicts_set)
        spyware_profiles= self.get_spyware_profiles(potential_conflicts_set)

        #spyware_sev_lists = self.get_spyware_severity_lists(potential_conflicts_set)
        spyware_alert_lists= self.get_url_filter_lists('spyware_alert_list=', potential_conflicts_set)
        spyware_block_lists= self.get_url_filter_lists('spyware_block_list=', potential_conflicts_set)
        spyware_allow_lists= self.get_url_filter_lists('spyware_allow_list=', potential_conflicts_set)

        malware_profile_data = self.get_malware_profile_data(potential_conflicts_set)
        malware_alert_lists = self.get_malware_alert_list(potential_conflicts_set)
        malware_block_lists = self.get_malware_block_list(potential_conflicts_set)
        malware_allow_lists = self.get_malware_allow_list(potential_conflicts_set)

        url_block_lists = self.get_url_filter_lists('url_block_list=', potential_conflicts_set)
        url_alert_lists = self.get_url_filter_lists('url_alert_list=', potential_conflicts_set)
        url_allow_lists = self.get_url_filter_lists('url_allow_list=', potential_conflicts_set)
        url_override_lists = self.get_url_filter_lists('url_override_list=', potential_conflicts_set)
        url_none_lists = self.get_url_filter_lists('url_none_list=', potential_conflicts_set)

        log_events = self.get_url_filter_lists('log_events=', potential_conflicts_set)
        notifications = self.get_notifications(potential_conflicts_set)

        # TODO: add later when active times are mandatory
        # common_active_times = self.get_policy_active_times(intersecting_attr_set)
        # temp workaround
        common_active_times = [1]
        protocols_overlap=False
        ports_overlap=False

        if len(protocols)==1:
            protocols_overlap = True
            if 'any' in protocols: #1
                ports_overlap = True
            elif '6' in protocols: #TCP
                if tcp_dports is not None and tcp_sports is not None and len(tcp_dports)==1 and len(tcp_sports)==1:
                    ports_overlap = True
            elif '17' in protocols: #UDP
                if udp_dports is not None and udp_sports is not None and len(udp_dports)==1 and len(udp_sports)==1:
                    ports_overlap = True
            elif '1' in protocols: #ICMP
                    ports_overlap = True

        elif len(protocols)>1:
            if '6' in protocols and 'any' in protocols and '17' in protocols: # 6, 1, 17
                # one is an all-IP flow
                protocols_overlap=True
                ports_overlap=True

        if len(actions) > 1 and len(common_active_times)>0 and protocols_overlap and ports_overlap:
            conflict_sources.append('Access-control actions')
            return True

        if len(priorities) > 1 and len(common_active_times)>0 and protocols_overlap and ports_overlap:
            conflict_sources.append('QoS Priorities')
            return True

        if len(interfaces) > 1 and len(common_active_times)>0 and protocols_overlap and ports_overlap:
            return True

        if len(middlebox1_devices) > 1 and len(common_active_times)>0 and protocols_overlap and ports_overlap:
            return True

        if len(middlebox2_devices) > 1 and len(common_active_times)>0 and protocols_overlap and ports_overlap:
            return True

        # check if malware/spyware/url_filter profile data provided/populated
        if 'N/A' in malware_profiles and 'N/A' in spyware_profiles and \
            'N/A' in url_filter_profiles:
            # not provided
            if len(actions) > 1 and len(common_active_times)>0 and protocols_overlap and ports_overlap:
                conflict_sources.append('Access-control Actions')
                return True
        else:

            if len(common_active_times)>0 and len(actions)==1 and protocols_overlap and ports_overlap:
               if self.malware_profiles_conflict(malware_alert_lists, malware_block_lists, malware_allow_lists, malware_profiles, actions[0]):
                        conflict_sources.append('Malware-signature lists')
                        return True

               if self.url_filter_profiles_conflict(url_alert_lists, url_block_lists, url_allow_lists,
                                                     url_override_lists, url_none_lists, url_filter_profiles, actions[0]):
                    conflict_sources.append('URL-Filter lists')
                    return True

               if self.session_log_profiles_conflict(log_events):
                    conflict_sources.append('Session-log events')
                    return True

               if self.spyware_profiles_conflict(spyware_alert_lists, spyware_block_lists, spyware_allow_lists, spyware_profiles, actions[0]):
                    conflict_sources.append('Spyware-severity lists')
                    return True

               if len(notifications) > 1:
                   conflict_sources.append('IPS-notifications')
                   return True

        return False

    def edge_attributes_overlap(self, propositions):
        if propositions==None:
           raise MetagraphException('propositions',resources['value_null'])

        # currently checks if actions conflict
        # extend later to include active times etc
        actions= self.get_actions(propositions)
        protocols = self.get_protocols(propositions)
        tcp_dports = self.get_tcp_ports(propositions,True)
        udp_dports = self.get_udp_ports(propositions,True)
        tcp_sports = self.get_tcp_ports(propositions,False)
        udp_sports = self.get_udp_ports(propositions,False)

        malware_profiles= self.get_malware_profiles(propositions)
        url_filter_profiles= self.get_url_filter_profiles(propositions)
        spyware_profiles= self.get_spyware_profiles(propositions)

        spyware_alert_lists= self.get_url_filter_lists('spyware_alert_list=', propositions)
        spyware_block_lists= self.get_url_filter_lists('spyware_block_list=', propositions)
        spyware_allow_lists= self.get_url_filter_lists('spyware_allow_list=', propositions)

        malware_alert_lists = self.get_malware_alert_list(propositions)
        malware_block_lists = self.get_malware_block_list(propositions)
        malware_allow_lists = self.get_malware_allow_list(propositions)


        protocols_overlap=False
        ports_overlap=False

        if len(protocols)==1:
            protocols_overlap = True
            if 'any' in protocols: #1
                ports_overlap = True
            elif '6' in protocols: #TCP
                if tcp_dports is not None and tcp_sports is not None and len(tcp_dports)==1 and len(tcp_sports)==1:
                    ports_overlap = True
            elif '17' in protocols: #UDP
                if udp_dports is not None and udp_sports is not None and len(udp_dports)==1 and len(udp_sports)==1:
                    ports_overlap = True
            elif '1' in protocols: #ICMP
                    ports_overlap = True

        elif len(protocols)>1:
            if '6' in protocols and 'any' in protocols and '17' in protocols: # 6, 1, 17
                # one is an all-IP flow
                protocols_overlap=True
                ports_overlap=True

        if len(actions) == 1 and protocols_overlap and ports_overlap:
            return True

        # check if malware/spyware/url_filter profile data provided/populated
        if 'N/A' in malware_profiles and 'N/A' in spyware_profiles and \
            'N/A' in url_filter_profiles:
            # not provided
            if len(actions) == 1 and protocols_overlap and ports_overlap:
                return True

        return False


    def malware_profiles_conflict(self, malware_alert_sig_data, malware_block_sig_data, malware_allow_sig_data, malware_profiles, action):
        import ast

        malware_alert_sig_lists = []
        malware_block_sig_lists = []
        malware_allow_sig_lists = []

        if len(malware_profiles)==1: return False

        try:

            for alert_sig_data in malware_alert_sig_data:
                if alert_sig_data!='{}' and alert_sig_data!='[]':
                    data = ast.literal_eval(alert_sig_data)
                    if data not in malware_alert_sig_lists:
                        malware_alert_sig_lists.append(data)
                else:
                    if dict() not in malware_alert_sig_lists:
                        malware_alert_sig_lists.append(dict())

            for block_sig_data in malware_block_sig_data:
                if block_sig_data!='{}' and block_sig_data!='[]':
                    data = ast.literal_eval(block_sig_data)
                    if data not in malware_block_sig_lists:
                        malware_block_sig_lists.append(data)
                else:
                    if dict() not in malware_block_sig_lists:
                        malware_block_sig_lists.append(dict())

            for allow_sig_data in malware_allow_sig_data:
                if allow_sig_data!='{}' and allow_sig_data!='[]':
                    data = ast.literal_eval(allow_sig_data)
                    if data not in malware_allow_sig_lists:
                        malware_allow_sig_lists.append(data)
                else:
                    if dict() not in malware_allow_sig_lists:
                        malware_allow_sig_lists.append(dict())

            # check if different types of signature lists overlap
            if self.malware_signature_lists_overlap(malware_alert_sig_lists, malware_block_sig_lists):
                return True

            if self.malware_signature_lists_overlap(malware_alert_sig_lists, malware_allow_sig_lists):
                return True

            if self.malware_signature_lists_overlap(malware_block_sig_lists, malware_allow_sig_lists):
                return True

            # check if there are distinct sig lists of same type
            if self.distinct_malware_signature_lists(malware_alert_sig_lists, action):
                return True

            if self.distinct_malware_signature_lists(malware_block_sig_lists, action):
                return True

            if self.distinct_malware_signature_lists(malware_allow_sig_lists, action, True):
                return True


        except BaseException, e:
            pass
            #print('error::malware_profiles_conflict: %s'%str(e))

        return False

    def spyware_profiles_conflict(self, spyware_alert_data, spyware_block_data, spyware_allow_data, spyware_profiles, action):
        import ast

        spyware_alert_lists = []
        spyware_block_lists = []
        spyware_allow_lists = []

        if len(spyware_profiles)==1: return False

        for alert_data in spyware_alert_data:
            if alert_data!='{}' and alert_data!='[]':
                data = ast.literal_eval(alert_data)
                if data not in spyware_alert_lists:
                    spyware_alert_lists.append(data)
            else:
                if dict() not in spyware_alert_lists:
                    spyware_alert_lists.append(dict())

        for block_data in spyware_block_data:
            if block_data!='{}' and block_data!='[]':
                data = ast.literal_eval(block_data)
                if data not in spyware_block_lists:
                    spyware_block_lists.append(data)
            else:
                if dict() not in spyware_block_lists:
                    spyware_block_lists.append(dict())

        for allow_data in spyware_allow_data:
            if allow_data!='{}' and allow_data!='[]':
                data = ast.literal_eval(allow_data)
                if data not in spyware_allow_lists:
                    spyware_allow_lists.append(data)
            else:
                if dict() not in spyware_allow_lists:
                    spyware_allow_lists.append(dict())

        # check if different types of severity lists overlap
        if self.spyware_severity_lists_overlap(spyware_alert_lists, spyware_block_lists):
            return True

        if self.spyware_severity_lists_overlap(spyware_alert_lists, spyware_allow_lists):
            return True

        if self.spyware_severity_lists_overlap(spyware_block_lists, spyware_allow_lists):
            return True

        # check if there are distinct severity lists of same type
        if self.distinct_spyware_severity_lists(spyware_alert_lists, action):
            return True

        if self.distinct_spyware_severity_lists(spyware_block_lists, action):
            return True

        if self.distinct_spyware_severity_lists(spyware_allow_lists, action, True):
            return True

        return False

    def url_filter_profiles_conflict(self, url_alert_data, url_block_data, url_allow_data, url_override_data, url_none_data, url_filter_profiles, action):

        if len(url_filter_profiles)==1: return False

        url_alert_lists= self.get_url_lists(url_alert_data)
        url_block_lists= self.get_url_lists(url_block_data)
        url_allow_lists= self.get_url_lists(url_allow_data)
        url_override_lists= self.get_url_lists(url_override_data)
        url_none_lists= self.get_url_lists(url_none_data)

        # check if different types of url filter lists overlap
        # overlap with none_list does not cause any conflicts
        if self.url_filter_lists_overlap(url_alert_lists, url_block_lists):
            return True

        if self.url_filter_lists_overlap(url_alert_lists, url_allow_lists):
            return True

        if self.url_filter_lists_overlap(url_alert_lists, url_override_lists):
            return True

        if self.url_filter_lists_overlap(url_block_lists, url_allow_lists):
            return True

        if self.url_filter_lists_overlap(url_block_lists, url_override_lists):
            return True

        if self.url_filter_lists_overlap(url_allow_lists, url_override_lists):
            return True

        # check if distinct url filter lists of same type exist
        if self.distinct_url_filter_lists(url_alert_lists, action):
            return True

        if self.distinct_url_filter_lists(url_block_lists, action):
            return True

        if self.distinct_url_filter_lists(url_allow_lists, action, True):
            return True

        if self.distinct_url_filter_lists(url_override_lists, action, True):
            return True

        return False

    def session_log_profiles_conflict(self, log_events):

        return self.distinct_log_event_lists(log_events)

    def url_filter_lists_overlap(self, filter_list1, filter_list2):

        for list1 in filter_list1:
            for list2 in filter_list2:
                intersection = set(list1).intersection(set(list2))
                if intersection is not None:
                    return True

        return False

    def malware_signature_lists_overlap(self, sig_list1, sig_list2):
        for elt1 in sig_list1:
            for elt2 in sig_list2:
                apps_elt1 = set(elt1.keys())
                apps_elt2 = set(elt2.keys())
                apps_intersection = apps_elt1.intersection(apps_elt2)
                if apps_intersection is not None:
                    for app in list(apps_intersection):
                         sigs1 = set(sig_list1[app])
                         sigs2 = set(sig_list2[app])
                         intersection = sigs1.intersection(sigs2)
                         if intersection is not None:
                             return True


        return False

    def spyware_severity_lists_overlap(self, severity_list1, severity_list2):
        for elt1 in severity_list1:
            for elt2 in severity_list2:
                severity1 = set(elt1.keys())
                severity2 = set(elt2.keys())
                intersection = severity1.intersection(severity2)
                if intersection is not None:
                    for severity in list(intersection):
                         threat_names1 = severity_list1[severity]['threat-name']
                         threat_names2 = severity_list2[severity]['threat-name']
                         intersection1 = set(threat_names1).intersection(set(threat_names2))

                         threat_categories1 = severity_list2[severity]['threat-category']
                         threat_categories2 = severity_list2[severity]['threat-category']

                         intersection2 = set(threat_categories1).intersection(set(threat_categories2))

                         if intersection1 is not None and intersection2 is not None:
                             return True


        return False

    def distinct_malware_signature_lists(self, sig_lists, action, check_action_allow=False):

        for sig_list1 in sig_lists:
            for sig_list2 in sig_lists:
                if sig_list1 != sig_list2:
                    # case when one list is empty and one is not
                    if (sig_list1 is None or len(sig_list1)==0) and \
                       (sig_list2 is not None and len(sig_list2) > 0):
                       if check_action_allow:
                           # additional criteria for allow list
                           if action!='1':
                              return True
                       else:
                           return True

                    elif (sig_list2 is None or len(sig_list2)==0) and \
                       (sig_list1 is not None and len(sig_list1) > 0):
                       if check_action_allow:
                           # additional criteria for allow list
                           if action!='1':
                              return True
                       else:
                           return True

                    # case when both lists are non empty
                    apps1 = set(sig_list1.keys())
                    apps2 = set(sig_list2.keys())
                    apps_intersection = apps1.intersection(apps2)
                    for app in apps_intersection:
                        sigs1 = set(sig_list1[app])
                        sigs2 = set(sig_list2[app])
                        if sigs1!=sigs2:
                            return True

        return False

    def distinct_spyware_severity_lists(self, severity_lists, action, check_action_allow=False):

        for list1 in severity_lists:
            for list2 in severity_lists:
                if list1 != list2:
                    # case when one list is empty and one is not
                    if (list1 is None or len(list1)==0) and \
                       (list2 is not None and len(list2) > 0):
                       if check_action_allow:
                           # additional criteria for allow list
                           if action!='1':
                              return True
                       else:
                           return True

                    elif (list2 is None or len(list2)==0) and \
                       (list1 is not None and len(list1) > 0):
                       if check_action_allow:
                           # additional criteria for allow list
                           if action!='1':
                              return True
                       else:
                           return True

                    # case when both lists are non empty
                    severities1 = set(list1.keys())
                    severities2 = set(list2.keys())
                    sev_intersection = severities1.intersection(severities2)

                    for severity in sev_intersection:
                        threat_names1 = list1[severity]['threat-name']
                        threat_names2 = list2[severity]['threat-name']
                        threat_categories1 = list2[severity]['threat-category']
                        threat_categories2 = list2[severity]['threat-category']

                        if set(threat_names1)!=set(threat_names2):
                            return True
                        if set(threat_categories1)!=set(threat_categories2):
                            return True

        return False

    def distinct_url_filter_lists(self, filter_lists, action, check_action_allow=False):

        for list1 in filter_lists:
            for list2 in filter_lists:
                if list1!=list2:
                    # check if only one list is empty
                    if (list1 is None or len(list1)==0) and \
                       (list2 is not None and len(list2) > 0):
                         if check_action_allow:
                           # additional criteria for allow list
                           if action!='1':
                              return True
                         else:
                           return True

                    elif (list2 is None or len(list2)==0) and \
                         (list1 is not None and len(list1) > 0):
                         if check_action_allow:
                           # additional criteria for allow list
                           if action!='1':
                              return True
                         else:
                           return True

                    # both lists are non empty
                    if (list1 is not None and len(list1) >0) and \
                       (list2 is not None and len(list2) >0) and \
                       set(list1)!=set(list2):
                        return True


        return False

    def distinct_log_event_lists(self, log_event_lists):
        for list1 in log_event_lists:
            for list2 in log_event_lists:
                if list1!=list2:
                    # check if only one list is empty
                    if (list1 is None or len(list1)==0) and \
                       (list2 is not None and len(list2) >0) :
                        return True
                    elif (list2 is None or len(list2)==0) and \
                       (list1 is not None and len(list1) >0) :
                        return True

                    # both lists are non empty
                    if (list1 is not None and len(list1) >0) and \
                       (list2 is not None and len(list2) >0) and \
                       set(list1)!=set(list2):
                        return True

        return False

    def get_url_lists(self, url_data):
        url_lists=[]

        for data in url_data:
            if data!='{}' and data!='[]':
                data = data.replace('[','')
                data = data.replace(']','')
                items = data.split(',')
                if items not in url_lists:
                    url_lists.append(items)
            else:
                if [] not in url_lists:
                    url_lists.append([])

        return url_lists

    def get_protocols(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])

        protocols=[]
        for attribute in attributes:
            if 'protocol=' in attribute:
                value= attribute.replace('protocol=','')
                if value not in protocols:
                    protocols.append(value)
        return protocols

    def get_tcp_ports(self, attributes, dport):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])

        tcp_ports=[]
        for attribute in attributes:
            if dport and 'TCP.dport=' in attribute:
                value= attribute.replace('TCP.dport=','')
                #if value not in tcp_ports:
                # allow duplicates
                tcp_ports.append(value)
            elif not dport and 'TCP.sport=' in attribute:
                value= attribute.replace('TCP.sport=','')
                #if value not in tcp_ports:
                # allow duplicates
                tcp_ports.append(value)
        result = list(set(tcp_ports))
        if '0-65535' in result and len(result)>1:
            result.remove('0-65535')

        return result

    def get_udp_ports(self, attributes, dport):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])

        udp_ports=[]
        for attribute in attributes:
            if dport and 'UDP.dport=' in attribute:
                value= attribute.replace('UDP.dport=','')
                #if value not in udp_ports:
                # allow duplicates
                udp_ports.append(value)
            elif not dport and 'UDP.sport=' in attribute:
                value= attribute.replace('UDP.sport=','')
                #if value not in udp_ports:
                # allow duplicates
                udp_ports.append(value)

        result = list(set(udp_ports))
        if '0-65535' in result and len(result)>1:
            result.remove('0-65535')

        return result

    def get_malware_profiles(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        profiles=[]
        for attribute in attributes:
            if 'profile_malware=' in attribute:
                value= attribute.replace('profile_malware=','')
                if value not in profiles:
                    profiles.append(value)
        return profiles

    def get_malware_signature_lists(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        sig_lists=[]
        for attribute in attributes:
            if 'malware_signature_list=' in attribute:
                value= attribute.replace('malware_signature_list=','')
                if value not in sig_lists:
                    sig_lists.append(value)
        return sig_lists

    def get_malware_app_lists(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        app_lists=[]
        for attribute in attributes:
            if 'malware_app_list=' in attribute:
                value= attribute.replace('malware_app_list=','')
                if value not in app_lists:
                    app_lists.append(value)
        return app_lists

    def get_malware_profile_data(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        profile_data=[]
        for attribute in attributes:
            if 'malware_profile_details=' in attribute:
                value= attribute.replace('malware_profile_details=','')
                if value not in profile_data:
                    profile_data.append(value)
        return profile_data

    def get_malware_alert_list(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        alert_list=[]
        for attribute in attributes:
            if 'malware_alert_list=' in attribute:
                value= attribute.replace('malware_alert_list=','')
                if value not in alert_list:
                    alert_list.append(value)
        return alert_list

    def get_malware_allow_list(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        allow_list=[]
        for attribute in attributes:
            if 'malware_allow_list=' in attribute:
                value= attribute.replace('malware_allow_list=','')
                if value not in allow_list:
                    allow_list.append(value)
        return allow_list

    def get_malware_block_list(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        block_list=[]
        for attribute in attributes:
            if 'malware_block_list=' in attribute:
                value= attribute.replace('malware_block_list=','')
                if value not in block_list:
                    block_list.append(value)
        return block_list

    def get_spyware_severity_lists(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        sev_lists=[]
        for attribute in attributes:
            if 'spyware_severity_list=' in attribute:
                value= attribute.replace('spyware_severity_list=','')
                if value not in sev_lists:
                    sev_lists.append(value)
        return sev_lists

    def get_spyware_profiles(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        profiles=[]
        for attribute in attributes:
            if 'profile_spyware=' in attribute:
                value= attribute.replace('profile_spyware=','')
                if value not in profiles:
                    profiles.append(value)
        return profiles

    def get_url_filter_profiles(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        profiles=[]
        for attribute in attributes:
            if 'profile_url_filter=' in attribute:
                value= attribute.replace('profile_url_filter=','')
                if value not in profiles:
                    profiles.append(value)
        return profiles

    def get_url_block_lists(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        block_lists=[]
        for attribute in attributes:
            if 'url_block_list=' in attribute:
                value= attribute.replace('url_block_list=','')
                if value not in block_lists:
                    block_lists.append(value)
        return block_lists

    def get_url_alert_lists(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        alert_lists=[]
        for attribute in attributes:
            if 'url_alert_list=' in attribute:
                value= attribute.replace('url_alert_list=','')
                if value not in alert_lists:
                    alert_lists.append(value)
        return alert_lists

    def get_url_filter_lists(self, attribute_key, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        result=[]
        for attribute in attributes:
            if attribute_key in attribute:
                value= attribute.replace(attribute_key,'')
                if value not in result:
                    result.append(value)
        return result

    def get_log_events(self, attributes):
        if attributes==None:
            raise MetagraphException('attributes', resources['value_null'])
        profiles=[]
        for attribute in attributes:
            if 'log_event=' in attribute:
                value=attribute.replace('log_event=','')
                if value!='None' and value not in profiles:
                    profiles.append(value)
        return profiles

    def get_notifications(self, attributes):
        if attributes==None:
            raise MetagraphException('attributes', resources['value_null'])
        profiles=[]
        for attribute in attributes:
            if 'notification=' in attribute:
                value=attribute.replace('notification=','')
                if value not in profiles:
                    profiles.append(value)
        return profiles

    def get_priorities(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        priorities=[]
        for attribute in attributes:
            if 'priority=' in attribute:
                value= attribute.replace('priority=','')
                if value not in priorities:
                    priorities.append(value)
        return priorities

    def get_interfaces(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        interfaces=[]
        for attribute in attributes:
            if 'interface=' in attribute:
                value= attribute.replace('interface=','')
                if value not in interfaces:
                    interfaces.append(value)
        return interfaces

    def get_middleboxes(self, attributes, middlebox_id):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        middleboxes = []
        middlebox_attr = 'middlebox%s=' % middlebox_id
        for attribute in attributes:
            if middlebox_attr in attribute:
                value= attribute.replace(middlebox_attr,'')
                if value not in middleboxes:
                    middleboxes.append(value)
        return middleboxes

    def get_policy_active_times(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        active_times=[]
        for attribute in attributes:
            if 'active_time=' in attribute:
                value= attribute.replace('active_time=','')
                if value not in active_times:
                    active_times.append(value)
        return active_times

    def get_active_times(self, attributes):
        if attributes==None:
           raise MetagraphException('attributes',resources['value_null'])
        active_times=[]
        max_mins=60*24
        for attribute in attributes:
            if 'time' in attribute:
                temp= attribute.replace('time','')
                gt=False
                lt=False
                eq=False
                if '>'in temp:
                    gt=True
                    temp=temp.replace('>','')
                if '=' in temp:
                    eq=True
                    temp=temp.replace('=','')
                if '<' in temp:
                    lt=True
                    temp=temp.replace('<','')

                hours_comp= math.floor(float(temp))
                mins_comp=(float(temp)-hours_comp)*60
                total_mins = 60*hours_comp + mins_comp
                if eq and (not lt and not gt) and [total_mins,total_mins] not in active_times:
                    active_times.append([total_mins,total_mins])
                elif eq and lt and [0,total_mins] not in active_times:
                    active_times.append([0,total_mins])
                elif eq and gt and [total_mins,max_mins] not in active_times:
                    active_times.append([total_mins,max_mins])
                elif lt and [0,total_mins-1] not in active_times:
                    active_times.append([0,total_mins-1])
                elif gt and [total_mins+1,max_mins] not in active_times:
                    active_times.append([total_mins+1,max_mins])

        return active_times

    @staticmethod
    def get_actions(attributes):
        """ Filters the given list of attributes and returns a list of action-attribute values.
        :param attributes:  list
        :return: list of strings
        """

        if attributes is None:
            raise MetagraphException('attributes', resources['value_null'])
        actions = []
        for attribute in attributes:
            if 'action' in attribute:
                value = attribute.replace('action=', '')
                if value not in actions:
                    actions.append(value)
        return actions

    @staticmethod
    def get_malware_sigs(attributes):
        if attributes is None:
            raise MetagraphException('attributes', resources['value_null'])
        sigs = []
        for attribute in attributes:
            if 'malware_sigs' in attribute:
                value = attribute.replace('malware_sigs=', '')
                value = value.replace('[','')
                value = value.replace(']','')
                value = value.split(',')
                if value not in sigs:
                    sigs.append(value)
        return sigs

    @staticmethod
    def get_sig_present(attributes):
        if attributes is None:
            raise MetagraphException('attributes', resources['value_null'])
        present = []
        for attribute in attributes:
            if 'sig_present' in attribute:
                value = attribute.replace('sig_present=', '')
                if value not in present:
                    present.append(value)
        return present

    def is_connected(self, source, target, logical_expressions, interpretations):
        """Checks if subset1 is connected to subset2.
        :param source: set
        :param target: set
        :param logical_expressions: list of strings
        :param interpretations: lists of tuples
        :return: boolean
        """

        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])
        if logical_expressions is None or len(logical_expressions) == 0:
            raise MetagraphException('logical_expressions', resources['value_null'])
        if interpretations is None or len(interpretations) == 0:
            raise MetagraphException('interpretations', resources['value_null'])
        if not source.issubset(self.variables_set):
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.issubset(self.variables_set):
            raise MetagraphException('target', resources['not_a_subset'])

        # check expressions are over X_p
        for logical_expression in logical_expressions:
            logical_expression_copy = copy.copy(logical_expression)
            logical_expression_copy = logical_expression_copy.replace('.', ' ')
            logical_expression_copy = logical_expression_copy.replace('|', ' ')
            logical_expression_copy = logical_expression_copy.replace('!', ' ')
            logical_expression_copy = logical_expression_copy.replace('(', '')
            logical_expression_copy.replace(')', '')
            items = logical_expression_copy.split(' ')
            for item in items:
                item = item.replace(' ', '')
                if item != '' and item not in self.propositions_set:
                    raise MetagraphException('logical_expression', resources['arguments_invalid'])

        # check metapath exists for at least one interpretation
        for interpretation in interpretations:
            true_propositions = []
            false_propositions = []
            for tuple_elt in interpretation:
                if tuple_elt[0] not in self.propositions_set:
                    raise MetagraphException('interpretations', resources['arguments_invalid'])
                if tuple_elt[1] and tuple_elt[0] not in true_propositions:
                    true_propositions.append(tuple_elt[0])
                elif tuple_elt[0] not in true_propositions:
                    false_propositions.append(tuple_elt[0])

            # compute context metagraph
            context = self.get_context(true_propositions, false_propositions)
            metapaths = context.get_all_metapaths_from(source, target)

            if metapaths is not None and len(metapaths) >= 1:
                return True

        return False

    def is_fully_connected(self, source, target, logical_expressions, interpretations):
        """Checks if subset1 is fully connected to subset2.
        :param source: set
        :param target: set
        :param logical_expressions: list of strings
        :param interpretations: lists of tuples
        :return: boolean
        """

        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])
        if logical_expressions is None or len(logical_expressions) == 0:
            raise MetagraphException('logical_expressions', resources['value_null'])
        if interpretations is None or len(interpretations) == 0:
            raise MetagraphException('interpretations', resources['value_null'])
        if not source.issubset(self.variables_set):
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.issubset(self.variables_set):
            raise MetagraphException('target', resources['not_a_subset'])

        # check expressions are over X_p
        for logical_expression in logical_expressions:
            logical_expression_copy = copy.copy(logical_expression)
            logical_expression_copy = logical_expression_copy.replace('.', ' ')
            logical_expression_copy = logical_expression_copy.replace('|', ' ')
            logical_expression_copy = logical_expression_copy.replace('!', ' ')
            logical_expression_copy = logical_expression_copy.replace('(', '')
            logical_expression_copy.replace(')', '')
            items = logical_expression_copy.split(' ')
            for item in items:
                item = item.replace(' ', '')
                if item != '' and item not in self.propositions_set:
                    raise MetagraphException('logical_expression', resources['arguments_invalid'])

        # check metapath exists for every interpretation
        for interpretation in interpretations:
            true_propositions = []
            false_propositions = []
            for tuple_elt in interpretation:
                if tuple_elt[0] not in self.propositions_set:
                    raise MetagraphException('interpretations', resources['arguments_invalid'])
                if tuple_elt[1] and tuple_elt[0] not in true_propositions:
                    true_propositions.append(tuple_elt[0])
                elif tuple_elt[0] not in true_propositions:
                    false_propositions.append(tuple_elt[0])

            # compute context metagraph
            context = self.get_context(true_propositions, false_propositions)
            metapaths = context.get_all_metapaths_from(source, target)

            if not(metapaths is not None and len(metapaths) >= 1):
                return False

        return True

    def is_redundantly_connected(self, source, target, logical_expressions, interpretations):
        """Checks if subset1 is non-redundantly connected to subset2.
        :param source: set
        :param target: set
        :param logical_expressions: list of strings
        :param interpretations: lists of tuples
        :return: boolean
        """

        if source is None or len(source) == 0:
            raise MetagraphException('source', resources['value_null'])
        if target is None or len(target) == 0:
            raise MetagraphException('target', resources['value_null'])
        if logical_expressions is None or len(logical_expressions) == 0:
            raise MetagraphException('logical_expressions', resources['value_null'])
        if interpretations is None or len(interpretations) == 0:
            raise MetagraphException('interpretations', resources['value_null'])
        if not source.issubset(self.variables_set):
            raise MetagraphException('source', resources['not_a_subset'])
        if not target.issubset(self.variables_set):
            raise MetagraphException('target', resources['not_a_subset'])

        # check expressions are over X_p
        for logical_expression in logical_expressions:
            logical_expression_copy = copy.copy(logical_expression)
            logical_expression_copy = logical_expression_copy.replace('.', ' ')
            logical_expression_copy = logical_expression_copy.replace('|', ' ')
            logical_expression_copy = logical_expression_copy.replace('!', ' ')
            logical_expression_copy = logical_expression_copy.replace('(', '')
            logical_expression_copy.replace(')', '')
            items = logical_expression_copy.split(' ')
            for item in items:
                item = item.replace(' ', '')
                if item != '' and item not in self.propositions_set:
                    raise MetagraphException('logical_expression', resources['arguments_invalid'])

        # check metapath exists for every interpretation
        for interpretation in interpretations:
            true_propositions = []
            false_propositions = []
            for tuple_elt in interpretation:
                if tuple_elt[0] not in self.propositions_set:
                    raise MetagraphException('interpretations', resources['arguments_invalid'])
                if tuple_elt[1] and tuple_elt[0] not in true_propositions:
                    true_propositions.append(tuple_elt[0])
                elif tuple_elt[0] not in true_propositions:
                    false_propositions.append(tuple_elt[0])

            # compute context metagraph
            context = self.get_context(true_propositions, false_propositions)
            metapaths = context.get_all_metapaths_from(source, target)

            if metapaths is not None and len(metapaths) > 1:
                return False

        return True

    def is_non_redundant(self, logical_expressions, interpretations):
        """ Checks if a conditional metagraph is non redundant.
        :param logical_expressions: list of strings
        :param interpretations: lists of tuples
        :return: boolean
        """

        if logical_expressions is None or len(logical_expressions) == 0:
            raise MetagraphException('logical_expressions', resources['value_null'])
        if interpretations is None or len(interpretations) == 0:
            raise MetagraphException('interpretations', resources['value_null'])

        # check expressions are over X_p
        for logical_expression in logical_expressions:
            logical_expression_copy = copy.copy(logical_expression)
            logical_expression_copy = logical_expression_copy.replace('.', ' ')
            logical_expression_copy = logical_expression_copy.replace('|', ' ')
            logical_expression_copy = logical_expression_copy.replace('!', ' ')
            logical_expression_copy = logical_expression_copy.replace('(', '')
            logical_expression_copy.replace(')', '')
            items = logical_expression_copy.split(' ')
            for item in items:
                item = item.replace(' ', '')
                if item != '' and item not in self.propositions_set:
                    raise MetagraphException('logical_expression', resources['arguments_invalid'])

        # check metapath exists for at least one interpretation
        for interpretation in interpretations:
            true_propositions = []
            false_propositions = []
            for tuple_elt in interpretation:
                if tuple_elt[0] not in self.propositions_set:
                    raise MetagraphException('interpretations', resources['arguments_invalid'])
                if tuple_elt[1] and tuple_elt[0] not in true_propositions:
                    true_propositions.append(tuple_elt[0])
                elif tuple_elt[0] not in true_propositions:
                    false_propositions.append(tuple_elt[0])

            # compute context metagraph
            context = self.get_context(true_propositions, false_propositions)

            for x in self.variables_set:
                edge_list = []
                for edge in context.edges:
                    if x in edge.outvertex and edge not in edge_list:
                        edge_list.append(edge)
                if len(edge_list) > 1:
                    return False

            return True

    def get_associated_edges(self, element):
         return [edge for edge in self.edges if element in edge.invertex]

    def get_protocol_propositions(self, original_propositions):
        result=[]
        for prop in list(original_propositions):
            if 'protocol' in prop:
               result.append(prop)

        return set(result)

    def get_port_propositions(self, original_propositions):
        result=[]
        for prop in list(original_propositions):
            if 'dport' in prop:
                result.append(prop)

        return set(result)

    def get_sport_propositions(self, original_propositions):
        result=[]
        for prop in list(original_propositions):
            if 'sport' in prop:
                result.append(prop)

        return set(result)

    def check_conflicts(self):

        result=[]
        potentially_conflicting_edges1=dict()
        potentially_conflicting_edges2=dict()

        for edge1 in self.edges:
            for edge2 in self.edges:
                if not MetagraphHelper().are_edges_equal(edge1,edge2):
                   invertex1 = edge1.invertex.difference(self.propositions_set)
                   outvertex1 = edge1.outvertex.difference(self.propositions_set)
                   invertex2 = edge2.invertex.difference(self.propositions_set)
                   outvertex2 = edge2.outvertex.difference(self.propositions_set)

                   invertex_int= invertex1.intersection(invertex2)
                   outvertex_int= outvertex1.intersection(outvertex2)

                   if (invertex_int is not None and len(invertex_int)>0):
                      # invertex EPGs overlap
                      # check if flows overlap
                      flow_overlap=False
                      prot_propositions1 = self.get_protocol_propositions(edge1.invertex)
                      prot_propositions2 = self.get_protocol_propositions(edge2.invertex)
                      prot_int = prot_propositions1.intersection(prot_propositions2)

                      if (prot_int is not None and len(prot_int)>0):
                         # protocols overlap
                         if 'protocol=any' not in prot_int: #1
                             # TCP or UDP flow -check port overlap
                             port_propositions1 = self.get_port_propositions(edge1.invertex)
                             port_propositions2 = self.get_port_propositions(edge2.invertex)
                             port_int = port_propositions1.intersection(port_propositions2)
                             if (port_int is not None and len(port_int)>0):
                                # port overlap
                                flow_overlap=True
                         else:
                             flow_overlap=True

                      if flow_overlap:
                          # check if already accounted
                          if edge2 in potentially_conflicting_edges1 and \
                             edge1 in potentially_conflicting_edges1[edge2]:
                              continue

                          if edge1 not in potentially_conflicting_edges1:
                            potentially_conflicting_edges1[edge1]=[]

                          if edge2 not in potentially_conflicting_edges1[edge1]:
                            potentially_conflicting_edges1[edge1].append(edge2)


                   if (outvertex_int is not None and len(outvertex_int)>0):
                      # outvertex EPGs overlap
                      # check if flows overlap
                      flow_overlap=False
                      prot_propositions1 = self.get_protocol_propositions(edge1.invertex)
                      prot_propositions2 = self.get_protocol_propositions(edge2.invertex)
                      prot_int = prot_propositions1.intersection(prot_propositions2)

                      if (prot_int is not None and len(prot_int)>0):
                         # protocols overlap
                         if 'protocol=any' not in prot_int: #1
                             # TCP or UDP flow -check port overlap
                             port_propositions1 = self.get_port_propositions(edge1.invertex)
                             port_propositions2 = self.get_port_propositions(edge2.invertex)
                             port_int = port_propositions1.intersection(port_propositions2)
                             if (port_int is not None and len(port_int)>0):
                                # port overlap
                                flow_overlap=True
                         else:
                             flow_overlap=True

                      if flow_overlap:
                          # check if already accounted
                          if edge2 in potentially_conflicting_edges2 and \
                             edge1 in potentially_conflicting_edges2[edge2]:
                              continue

                          if edge1 not in potentially_conflicting_edges2:
                            potentially_conflicting_edges2[edge1]=[]

                          if edge2 not in potentially_conflicting_edges2[edge1]:
                            potentially_conflicting_edges2[edge1].append(edge2)

        #print('step1')
        # determine metapath sources and targets
        processed=[]
        for edge1, value in potentially_conflicting_edges1.iteritems():
            source_set = edge1.invertex.difference(self.propositions_set)
            for edge2 in potentially_conflicting_edges1[edge1]:
               source_set = source_set.union(edge2.invertex.difference(self.propositions_set))

            for edge3, value in potentially_conflicting_edges2.iteritems():
                if len(potentially_conflicting_edges2[edge3])< 1:
                    continue
                target_set = edge3.outvertex

                # check if edges apply to overlapping flows
                flow_overlap=False
                prot_propositions1 = self.get_protocol_propositions(edge1.invertex)
                prot_propositions3 = self.get_protocol_propositions(edge3.invertex)
                prot_int = prot_propositions1.intersection(prot_propositions3)

                if (prot_int is not None and len(prot_int)>0):
                  # protocols overlap
                  if 'protocol=any' not in prot_int: #1
                     # TCP or UDP flow -check port overlap
                     port_propositions1 = self.get_port_propositions(edge1.invertex)
                     port_propositions3 = self.get_port_propositions(edge3.invertex)
                     port_int = port_propositions1.intersection(port_propositions3)
                     if (port_int is not None and len(port_int)>0):
                        # port overlap
                        flow_overlap=True
                  else:
                     flow_overlap=True

                if flow_overlap:
                   if (str(list(source_set)), str(list(target_set)))  in processed:
                       continue
                   processed.append((str(list(source_set)), str(list(target_set))))
                   mps= self.get_all_metapaths_from(source_set, target_set, True)
                   if mps is not None and len(mps)>0:
                       for mp in mps:
                          if mp not in result:
                             result.append(mp)

        #print('step2')
        #print('returning result..')
        if len(result)==0:
            #print('NO conflicts found')
            return None

        #print('inconsistencies found')
        potential_conflicts = result
        conflicts_final=None
        if potential_conflicts is not None and len(potential_conflicts)>0:
            conflicting_metapaths=[]
            self.conflict_source_lookup=dict()
            for mp in potential_conflicts:
                conflicting_edges=[]
                #conflict_sources=[]
                if self.has_conflicts(mp, conflicting_edges=conflicting_edges):
                   self.conflict_source_lookup[mp]=conflicting_edges
                   conflicting_metapaths.append(mp)
                #else:
                #    print "Policy inconsistency Detected for metapath::"
                #    for edge in mp.edge_list:
                #       print "edge- %s"%(edge)
                #       #self.print_original_policy(edge)
                #    #pass

            filtered= MetagraphHelper().remove_duplicates(conflicting_metapaths)
            if len(filtered)==0:
                #print('NO conflicts found')
                return None
            #else:
            #    print('conflicts found found')

            if False:
                count=1
                conflicts_final = filtered
                for mp in filtered:
                       conflicting_edges = self.conflict_source_lookup[mp]
                       for edge_tuple in conflicting_edges: #mp.edge_list:
                           conflict_source_desc= '.'.join(edge_tuple[2])
                           #print "%s. Policy Conflicts Detected:: cause- %s"%(count,conflict_source_desc)
                           count+=1
                           self.print_original_policy(edge_tuple[0])
                           self.print_original_policy(edge_tuple[1])

            #print(' ')
            #print('-------------------------------------------------')


        return conflicts_final

    def check_redundancies(self):

        result=[]
        potentially_redundant_edges1=dict()
        potentially_redundant_edges2=dict()

        for edge1 in self.edges:
            for edge2 in self.edges:
                if edge1!=edge2:
                   invertex1 = edge1.invertex.difference(self.propositions_set)
                   outvertex1 = edge1.outvertex.difference(self.propositions_set)
                   invertex2 = edge2.invertex.difference(self.propositions_set)
                   outvertex2 = edge2.outvertex.difference(self.propositions_set)

                   invertex_int= invertex1.intersection(invertex2)
                   outvertex_int= outvertex1.intersection(outvertex2)

                   if (invertex_int is not None and len(invertex_int)>0):
                      # invertex EPGs overlap
                      # check if flows overlap
                      flow_overlap=False
                      prot_propositions1 = self.get_protocol_propositions(edge1.invertex)
                      prot_propositions2 = self.get_protocol_propositions(edge2.invertex)
                      prot_int = prot_propositions1.intersection(prot_propositions2)

                      if (prot_int is not None and len(prot_int)>0):
                         # protocols overlap
                         if 'protocol=1' not in prot_int:
                             # TCP or UDP flow -check port overlap
                             dport_propositions1 = self.get_port_propositions(edge1.invertex)
                             dport_propositions2 = self.get_port_propositions(edge2.invertex)
                             sport_propositions1 = self.get_sport_propositions(edge1.invertex)
                             sport_propositions2 = self.get_sport_propositions(edge2.invertex)
                             dport_int = dport_propositions1.intersection(dport_propositions2)
                             sport_int = sport_propositions1.intersection(sport_propositions2)
                             if (dport_int is not None and len(dport_int)>0) and (sport_int is not None and len(sport_int)>0):
                                # port overlap
                                flow_overlap=True
                         else:
                             flow_overlap=True

                      if flow_overlap:
                          # check if already accounted
                          if edge2 in potentially_redundant_edges1 and \
                             edge1 in potentially_redundant_edges1[edge2]:
                              continue

                          if edge1 not in potentially_redundant_edges1:
                            potentially_redundant_edges1[edge1]=[]

                          if edge2 not in potentially_redundant_edges1[edge1]:
                            potentially_redundant_edges1[edge1].append(edge2)

                   if (outvertex_int is not None and len(outvertex_int)>0):
                      # outvertex EPGs overlap
                      # check if flows overlap
                      flow_overlap=False
                      prot_propositions1 = self.get_protocol_propositions(edge1.invertex)
                      prot_propositions2 = self.get_protocol_propositions(edge2.invertex)
                      prot_int = prot_propositions1.intersection(prot_propositions2)

                      if (prot_int is not None and len(prot_int)>0):
                         # protocols overlap
                         if 'protocol=1' not in prot_int:
                             # TCP or UDP flow -check port overlap
                             dport_propositions1 = self.get_port_propositions(edge1.invertex)
                             dport_propositions2 = self.get_port_propositions(edge2.invertex)
                             sport_propositions1 = self.get_sport_propositions(edge1.invertex)
                             sport_propositions2 = self.get_sport_propositions(edge2.invertex)
                             dport_int = dport_propositions1.intersection(dport_propositions2)
                             sport_int = sport_propositions1.intersection(sport_propositions2)
                             if (dport_int is not None and len(dport_int)>0) and (sport_int is not None and len(sport_int)>0):
                                # port overlap
                                flow_overlap=True
                         else:
                             flow_overlap=True

                      if flow_overlap:
                          # check if already accounted
                          if edge2 in potentially_redundant_edges2 and \
                             edge1 in potentially_redundant_edges2[edge2]:
                              continue

                          if edge1 not in potentially_redundant_edges2:
                            potentially_redundant_edges2[edge1]=[]

                          if edge2 not in potentially_redundant_edges2[edge1]:
                            potentially_redundant_edges2[edge1].append(edge2)

        # determine metapath sources and targets
        processed=[]
        for edge1, value in potentially_redundant_edges1.iteritems():
            source_set = edge1.invertex.difference(self.propositions_set)
            for edge2 in potentially_redundant_edges1[edge1]:
               source_set = source_set.union(edge2.invertex.difference(self.propositions_set))

            for edge3, value in potentially_redundant_edges2.iteritems():
                if len(potentially_redundant_edges2[edge3])< 1:
                    continue
                target_set = edge3.outvertex

                # check if edges apply to overlapping flows
                flow_overlap=False
                prot_propositions1 = self.get_protocol_propositions(edge1.invertex)
                prot_propositions3 = self.get_protocol_propositions(edge3.invertex)
                prot_int = prot_propositions1.intersection(prot_propositions3)

                if (prot_int is not None and len(prot_int)>0):
                  # protocols overlap
                  if 'protocol=1' not in prot_int:
                     # TCP or UDP flow -check port overlap
                     dport_propositions1 = self.get_port_propositions(edge1.invertex)
                     dport_propositions3 = self.get_port_propositions(edge3.invertex)
                     sport_propositions1 = self.get_sport_propositions(edge1.invertex)
                     sport_propositions3 = self.get_sport_propositions(edge3.invertex)
                     dport_int = dport_propositions1.intersection(dport_propositions3)
                     sport_int = sport_propositions1.intersection(sport_propositions3)
                     if (dport_int is not None and len(dport_int)>0) and (sport_int is not None and len(sport_int)>0):
                        # port overlap
                        flow_overlap=True
                  else:
                     flow_overlap=True

                if flow_overlap:
                   if (str(list(source_set)), str(list(target_set)))  in processed:
                       continue
                   processed.append((str(list(source_set)), str(list(target_set))))
                   mps= self.get_all_metapaths_from(source_set, target_set, True)
                   if mps is not None and len(mps)>0:
                       for mp in mps:
                          if mp not in result:
                             result.append(mp)

        #print('returning result..')
        if len(result)==0:
            #print('NO redundancies found1')
            return None

        #print('redundancies found')
        redundancies = result
        if redundancies is not None and len(redundancies)>0:
            actual_redundancies=[]
            for mp in redundancies:
                redundant_edges=[]
                if self.has_redundancies2(mp, redundant_edges=redundant_edges):
                   actual_redundancies += redundant_edges

        filtered= MetagraphHelper().remove_duplicate_redundancies(actual_redundancies)
        if len(filtered)==0:
            #print('NO redundancies found')
            #count=1
            #for mp in result:
            #   print("Policy error %s"%count)
            #   for edge in mp.edge_list:
            #       print "%s"%(str(edge))
            #   count+=1
            #print('NO redundancies found2: END')
            return None

        if True:
            count=1
            for redundancy in filtered:
               print("Policy redundancy %s"%count)
               print "edge0- %s"%(str(redundancy[0]))
               print "edge1- %s"%(str(redundancy[1]))
               count+=1

        return filtered


    def classify_redundancy(self, edge_list):
        classifications=[]
        for edge1 in edge_list:
            for edge2 in edge_list:
                if edge1!=edge2:
                    if int(edge1.label) > int(edge2.label):
                        rule1= PolicyRule(edge1)
                        rule2= PolicyRule(edge2)
                    else:
                        rule1= PolicyRule(edge2)
                        rule2= PolicyRule(edge1)

                    if self.IsShadowedRule(rule1, rule2):
                        desc = 'edge-%s shadowed by edge-%s'%(rule1.Id,rule2.Id)
                        if desc not in classifications:
                            classifications.append(desc) #('edge-%s shadowed by edge-%s'%(edge1.label,edge2.label))

                    elif self.IsGeneralisation(rule1, rule2):
                        desc = 'edge-%s is a generalisation of edge-%s'%(rule1.Id,rule2.Id)
                        if desc not in classifications:
                            classifications.append(desc)

                    elif self.IsPartialOverlap(rule1, rule2):
                        desc = 'edge-%s is a partial overlap of edge-%s'%(rule1.Id,rule2.Id)
                        if desc not in classifications:
                            classifications.append()

        return classifications

    def has_redundancies(self, metapath):
        return (not self.is_dominant_metapath(metapath))

    def print_original_policy(self, edge):
        try:
            source = edge.invertex.difference(edge.attributes)
            #cons = Constraint.query.get(edge_label)
            dest = edge.outvertex
            protocol = self.get_protocols(edge.attributes)
            action = self.get_actions(edge.attributes)
            dports = self.get_tcp_ports(edge.attributes,True)
            if dports is None or len(dports)==0:
                dports = self.get_udp_ports(edge.attributes, True)

            sports = self.get_tcp_ports(edge.attributes, False)
            if sports is None or len(sports)==0:
                sports = self.get_udp_ports(edge.attributes, False)


            #TODO
            attack_sig = None
            log_event = None
            notification = None
            priority = None
            profile_log = None
            profile_malware = None
            profile_spyware = None
            profile_url_filter = None

            print('policy:: source=%s, dest=%s, protocol=%s, sport=%s, dport=%s, action=%s'%
                  (source, dest, protocol, sports, dports, action))

            #print('policy:: source=%s, dest=%s, protocol=%s, sport=%s, dport=%s, action=%s, priority=%s, malware_profile=%s, '
            #      'spyware_profile=%s, url_filter=%s, log_profile=%s, attack_sig=%s, log_event=%s, notification=%s'%
            #      (source, dest, protocol, sports, dports, action, priority, profile_malware,
            #       profile_spyware, profile_url_filter, profile_log, attack_sig, log_event, notification))


        except BaseException, e:
            print('Error::print_original_policy: %s'%str(e))


    def __repr__(self):
        edge_desc = [repr(edge) for edge in self.edges]
        full_desc = ''
        for desc in edge_desc:
            if full_desc == '':
                full_desc = desc
            else:
                full_desc += ', ' + desc
        desc = '%s(%s)' % (str(type(self)), full_desc)
        desc = desc.replace('\\', '')
        return desc

# noinspection PyShadowingNames,PyShadowingNames
@singleton
class MetagraphHelper:
    """ Helper class that facilitates metagraph operations.
    """

    def __init__(self):
        pass

    def add_adjacency_matrices(self, adjacency_matrix1, generator_set1, adjacency_matrix2, generator_set2):
        """ Adds the two adjacency matrices provided and returns a combined matrix.
        :param adjacency_matrix1: numpy.matrix
        :param generator_set1: set
        :param adjacency_matrix2: numpy.matrix
        :param generator_set2: set
        :return: numpy.matrix
        """

        if adjacency_matrix1 is None:
            raise MetagraphException('adjacency_matrix1', resources['value_null'])
        if adjacency_matrix2 is None:
            raise MetagraphException('adjacency_matrix2', resources['value_null'])

        if generator_set1 is None:
            raise MetagraphException('generator_set1', resources['value_null'])
        if generator_set2 is None:
            raise MetagraphException('generator_set2', resources['value_null'])

        # check if the generating sets of the matrices overlap (otherwise no sense in combining metagraphs)
        intersection = generator_set1.intersection(generator_set2)
        if intersection is None:
            raise MetagraphException('generator_sets', resources['no_overlap'])

        #combined_adjacency_matrix = None
        if len(generator_set1.difference(generator_set2)) == 0 and len(generator_set2.difference(generator_set1)) == 0:
            # generating sets are identical..use adjacency matrices as is
            size = len(generator_set1)
            combined_adjacency_matrix = MetagraphHelper().get_null_matrix(size, size)
            for i in range(size):
                for j in range(size):
                    # take the union
                    if adjacency_matrix1[i][j] is None:
                        combined_adjacency_matrix[i][j] = adjacency_matrix2[i][j]
                    elif adjacency_matrix2[i][j] is None:
                        combined_adjacency_matrix[i][j] = adjacency_matrix1[i][j]
                    else:
                        temp = list()
                        temp.append(adjacency_matrix1[i][j])
                        temp.append(adjacency_matrix2[i][j])
                        combined_adjacency_matrix[i][j] = temp

        else:
            # generating sets overlap but are different...need to redefine adjacency matrices before adding them
            combined_generating_set = generator_set1.union(generator_set2)
            mg1 = Metagraph(combined_generating_set)

            # add all metagraph1 edges
            edge_list1 = self.get_edges_in_matrix(adjacency_matrix1, generator_set1)
            for edge in edge_list1:
                mg1.add_edge(edge)
            modified_adjacency_matrix1 = mg1.adjacency_matrix().tolist()

            mg2 = Metagraph(combined_generating_set)
            # add all metagraph2 edges
            edge_list2 = self.get_edges_in_matrix(adjacency_matrix2, generator_set2)
            for edge in edge_list2:
                mg2.add_edge(edge)
            modified_adjacency_matrix2 = mg2.adjacency_matrix().tolist()

            #combined_mg = Metagraph(combined_generating_set)
            size = len(combined_generating_set)
            combined_adjacency_matrix = MetagraphHelper().get_null_matrix(size, size)
            for i in range(size):
                for j in range(size):
                    # take the union
                    if modified_adjacency_matrix1[i][j] is None:
                        combined_adjacency_matrix[i][j] = modified_adjacency_matrix2[i][j]
                    elif modified_adjacency_matrix2[i][j] is None:
                        combined_adjacency_matrix[i][j] = modified_adjacency_matrix1[i][j]
                    else:
                        temp = modified_adjacency_matrix1[i][j]
                        for triple in modified_adjacency_matrix2[i][j]:
                            if not triple in modified_adjacency_matrix1[i][j]:
                                temp.append(triple)
                        combined_adjacency_matrix[i][j] = temp

        return combined_adjacency_matrix

    def get_triples(self, nested_triples_list):
        """ Returns a list of non-nested Triple objects.
        :param nested_triples_list: list of nested Triple objects
        :return: list of Triple objects
        """

        if nested_triples_list is None or len(nested_triples_list) == 0:
            raise MetagraphException('triples_list', resources['value_null'])

        result = []
        if isinstance(nested_triples_list, list):
            for elt in nested_triples_list:
                if isinstance(elt, Triple):
                    result.append(elt)
                else:
                    temp = self.get_triples(elt)
                    for item in temp:
                        result.append(item)

        return result

    def forms_cover(self,triples_set, target, x_j):
        cumulative_output = {x_j}
        for triple in triples_set:
            # retain cooutputs
            cumulative_output = cumulative_output.union(triple.cooutputs)

        return target.issubset(cumulative_output)

    def get_metapath_from_triples(self, source, target, triples_set):
        edges=set()
        for triple in triples_set:
            if isinstance(triple.edges, Edge):
                edges = edges.union({triple.edges})
            else:
                edges = edges.union(triple.edges)

        return Metapath(source,target,edges)

    def multiply_adjacency_matrices(self, adjacency_matrix1, generator_set1, adjacency_matrix2, generator_set2):
        """ Multiplies the two adjacency matrices provided and returns the result.
        :param adjacency_matrix1: numpy.matrix
        :param generator_set1: set
        :param adjacency_matrix2: numpy.matrix
        :param generator_set2: set
        :return: numpy.matrix
        """

        if adjacency_matrix1 is None:
            raise MetagraphException('adjacency_matrix1', resources['value_null'])
        if adjacency_matrix2 is None:
            raise MetagraphException('adjacency_matrix2', resources['value_null'])

        if generator_set1 is None:
            raise MetagraphException('generator_set1', resources['value_null'])
        if generator_set2 is None:
            raise MetagraphException('generator_set2', resources['value_null'])

        # check generating sets are identical
        if not(len(generator_set1.difference(generator_set2)) == 0 and
               len(generator_set2.difference(generator_set1)) == 0):
            raise MetagraphException('generator_sets', resources['not_identical'])

        size = len(generator_set1)
        resultant_adjacency_matrix = MetagraphHelper().get_null_matrix(size, size)

        # O(N3C2)
        for i in range(size):
            for j in range(size):
                # O(NC2)
                resultant_adjacency_matrix[i][j] = self.multiply_components(adjacency_matrix1,
                                                                            adjacency_matrix2,
                                                                            generator_set1, i,
                                                                            j, size)
                #print('multiply_components')

        return resultant_adjacency_matrix

    def multiply_components(self, adjacency_matrix1, adjacency_matrix2, generator_set1, i, j, size):
        """ Multiplies elements of two adjacency matrices.
        :param adjacency_matrix1: numpy.matrix
        :param adjacency_matrix2: numpy.matrix
        :param generator_set1: set
        :param i: int
        :param j: int
        :param size: int
        :return: list of Triple objects.
        """

        if adjacency_matrix1 is None:
            raise MetagraphException('adjacency_matrix1', resources['value_null'])
        if adjacency_matrix2 is None:
            raise MetagraphException('adjacency_matrix2', resources['value_null'])
        if generator_set1 is None or len(generator_set1) == 0:
            raise MetagraphException('generator_set1', resources['value_null'])

        result = []
        # computes the outermost loop (ie., k=1...K where K is the size of each input matrix)
        for k in range(size):
            a_ik = adjacency_matrix1[i][k]
            b_kj = adjacency_matrix2[k][j]
            #print('multiply_triple_lists')
            temp = self.multiply_triple_lists(a_ik, b_kj, list(generator_set1)[i],
                                              list(generator_set1)[j], list(generator_set1)[k])
            if temp is not None:
                #print('len(temp): %s'%len(temp))
                for triple in temp:
                    if not MetagraphHelper().is_triple_in_list(triple, result):
                        result.append(triple)
                    #if triple not in result: result.append(triple)
        if len(result) == 0:
            return None

        return result

    def multiply_components(self, adjacency_matrix1, adjacency_matrix2, generator_set1, i, j, size):
        """ Multiplies elements of two adjacency matrices.
        :param adjacency_matrix1: numpy.matrix
        :param adjacency_matrix2: numpy.matrix
        :param generator_set1: set
        :param i: int
        :param j: int
        :param size: int
        :return: list of Triple objects.
        """

        if adjacency_matrix1 is None:
            raise MetagraphException('adjacency_matrix1', resources['value_null'])
        if adjacency_matrix2 is None:
            raise MetagraphException('adjacency_matrix2', resources['value_null'])
        if generator_set1 is None or len(generator_set1) == 0:
            raise MetagraphException('generator_set1', resources['value_null'])

        result = []
        # computes the outermost loop (ie., k=1...K where K is the size of each input matrix)
        for k in range(size):
            a_ik = adjacency_matrix1[i][k]
            b_kj = adjacency_matrix2[k][j]
            temp = self.multiply_triple_lists(a_ik, b_kj, list(generator_set1)[i],
                                              list(generator_set1)[j], list(generator_set1)[k])

            if temp is not None and len(temp)>0:
                result+=temp

        if len(result) == 0:
            return None

        return list(set(result))

    def multiply_triple_lists(self, triple_list1, triple_list2, x_i, x_j, x_k):
        """ Multiplies two list of Triple objects and returns the result.
        :param triple_list1: list of Triple objects
        :param triple_list2: list of Triple objects
        :param x_i: generator set element
        :param x_j: generator set element
        :param x_k: generator set element
        :return: list of Triple objects
        """

        if triple_list1 is None or triple_list2 is None:
            return None

        triples_list=[]
        # computes the middle loop (ie., n=1...N where N is the size of triple_list1
        for triple1 in triple_list1:
            # computes the innermost loop (ie., m=1...M where M is the size of triple_list2
            for triple2 in triple_list2:
                temp = self.multiply_triples(triple1, triple2, x_i, x_j, x_k)
                if temp is not None:
                    triples_list.append(temp)

        if len(triples_list)>0:
            return list(set(triples_list))

        return []

    @staticmethod
    def multiply_triples(triple1, triple2, x_i, x_j, x_k):
        """ Multiplies two Triple objects and returns the result.
        :param triple1: Triple object
        :param triple2: Triple object
        :param x_i: generator set element
        :param x_j: generator set element
        :param x_k: generator set element
        :return: Triple object
        """

        if triple1 is None or triple2 is None:
            return None

        # compute alpha(R)
        alpha_r = triple2.coinputs
        if triple2.coinputs is None:
            alpha_r = triple1.coinputs
        elif triple1.coinputs is not None:
            alpha_r = triple1.coinputs.union(triple2.coinputs)
        if alpha_r is not None and triple1.cooutputs is not None:
            alpha_r = alpha_r.difference(({x_i}).union(triple1.cooutputs))
        elif alpha_r is not None:
            alpha_r = alpha_r.difference(({x_i}))

        # compute beta(R)
        beta_r = triple2.cooutputs
        if triple2.cooutputs is None:
            beta_r = triple1.cooutputs
        elif triple1.cooutputs is not None:
            beta_r = triple1.cooutputs.union(triple2.cooutputs)
        if beta_r is not None:
            beta_r = beta_r.union({x_k})
            beta_r = beta_r.difference({x_j})
        else:
            beta_r = {x_k}
            beta_r = beta_r.difference(({x_j}))

        # compute gamma(R)
        truncated = []
        if triple1.edges not in truncated:
            if isinstance(triple1.edges, Edge):
                truncated.append(triple1.edges)
            else:
                if isinstance(triple1.edges, list):
                    truncated = copy.copy(triple1.edges)

        if triple2.edges not in truncated:
            if isinstance(triple2.edges, Edge):
                truncated.append(triple2.edges)
            else:
                truncated.append = copy.copy(triple2.edges)

        gamma_r = truncated

        return Triple(alpha_r, beta_r, gamma_r)

    @staticmethod
    def get_null_matrix(rows, cols):
        """ Returns a null matrix of dimension rows x cols.
        :param rows: int
        :param cols: int
        :return: list
        """
        psi = None
        result = []
        for i in range(rows):
            # noinspection PyUnusedLocal
            item = [psi for j in range(cols)]
            result.append(item)
        return result

    @staticmethod
    def get_edges_in_matrix(adjacency_matrix, generator_set):
        """ Returns the list of edges in the provided adjacency matrix.
        :param adjacency_matrix: numpy.matrix
        :param generator_set: set
        :return: list of Edge objects
        """

        if adjacency_matrix is None:
            raise MetagraphException('adjacency_matrix', resources['value_null'])
        if generator_set is None or len(generator_set) == 0:
            raise MetagraphException('generator_set', resources['value_null'])

        size = len(generator_set)
        edge_list = []
        for i in range(size):
            for j in range(size):
                if adjacency_matrix[i][j] is not None:
                    # list of triples
                    triples_list = adjacency_matrix[i][j]
                    for triple in triples_list:
                        # gamma_R describes the edge
                        if triple[2] not in edge_list:
                            edge_list.append(triple[2])

        return edge_list

    def get_edge_list(self, nested_edges):
        """ Returns a non-nested list of edges.
        :param nested_edges: nested list of Edge objects
        :return: non-nested list of Edge objects.
        """

        edge_list = []
        if nested_edges is None or len(nested_edges) == 0:
            return edge_list

        for element in nested_edges:
            if isinstance(element, list):
                temp = self.get_edge_list(element)
                for edge in temp:
                    if edge not in edge_list:
                        edge_list.append(edge)
            elif isinstance(element, Edge):
                if element not in edge_list:
                    edge_list.append(element)

        return edge_list

    def remove_edge_list(self, edges_to_remove, target_edge_list):
        """ Removes a given set of edges from a target set.
        :param edges_to_remove: a list of edges to remove
        :param target_edge_list: a list of target edges
        :return: a list of Edge objects.
        """
        updated = []
        for edge in target_edge_list:
            if not self.is_edge_in_list(edge, edges_to_remove):
                updated.append(edge)

        return updated

    def get_edges_from_triple_list(self, nested_triples):
        """ Returns the edges present in a nested list of Triple objects.
        :param nested_triples: nested list of Triple objects
        :return: non-nested list of Triple objects
        """

        result = []
        if nested_triples is None:
            return result

        if isinstance(nested_triples, Triple):
            return nested_triples.edges

        elif isinstance(nested_triples, list):
            for element in nested_triples:
                temp = self.get_edges_from_triple_list(element)
                if isinstance(temp, list):
                    for elt in temp:
                        if isinstance(elt, Edge) and (elt not in result):
                            result.append(elt)
                        elif isinstance(elt, list):
                            for elt2 in elt:
                                if elt2 not in result:
                                    result.append(elt2)
                elif isinstance(temp, Edge) and (temp not in result):
                    result.append(temp)

        return result

    def is_triple_in_list(self, triple, triples_list):
        """ Checks whether a particular Triple object is in a given list of Triples.
        :param triple: Triple object
        :param triples_list: list of Triple object
        :return: boolean
        """

        if triple==None:
            raise MetagraphException('triple', resources['value_null'])
        if triples_list==None:
            raise MetagraphException('triples_list', resources['value_null'])

        result=False

        for element in triples_list:
            if self.are_triples_equal(triple, element):
               result= True
               break

        return result

    def is_edge_in_list(self, edge, nested_edges):
        """ Checks whether a particular edge is in the nested list of edges.
        :param edge: Edge object
        :param nested_edges: nested list of Edge objects
        :return: boolean
        """

        if edge is None:
            raise MetagraphException('edge', resources['value_null'])
        if nested_edges is None:
            raise MetagraphException('nested_edges', resources['value_null'])
        result = False

        if isinstance(nested_edges, list):
            for element in nested_edges:
                result = self.is_edge_in_list(edge, element)
                if result:
                    break

        elif isinstance(nested_edges, Edge):
            if self.are_edges_equal(edge, nested_edges):
                result = True

        return result

    def is_node_in_list(self, node, node_list):
        """ Checks if a particular node is in the given list of nodes.
        :param node: Node object
        :param node_list: list of Node objects
        :return: boolean
        """

        if node is None:
            raise MetagraphException('node', resources['value_null'])
        if node_list is None:
            raise MetagraphException('node_list', resources['value_null'])
        result = False

        if isinstance(node_list, list):
            for element in node_list:
                result = self.is_node_in_list(node, element)
                if result:
                    break

        elif isinstance(node_list, Node):
            if self.are_nodes_equal(node, node_list):
                result = True

        return result

    def are_triples_equal(self, triple1, triple2):
        """ Checks if the two given triples are equal.
        :param triple1: Triple object
        :param triple2: Triple object
        :return: boolean
        """

        if triple1 is None:
            raise MetagraphException('triple1', resources['value_null'])
        if triple2 is None:
            raise MetagraphException('triple2', resources['value_null'])
        if not isinstance(triple1, Triple):
            raise MetagraphException('triple1', resources['format_invalid'])
        if not isinstance(triple2, Triple):
            raise MetagraphException('triple2', resources['format_invalid'])

        edge_list_match = True
        for edge in triple1.edges:
            if not self.is_edge_in_list(edge, triple2.edges):
                edge_list_match = False
                break

        for edge in triple2.edges:
            if not self.is_edge_in_list(edge, triple1.edges):
                edge_list_match = False
                break

        return (triple1.coinputs == triple2.coinputs and
                triple1.cooutputs == triple2.cooutputs and
                len(triple1.edges) == len(triple2.edges) and
                edge_list_match)

    @staticmethod
    def are_edges_equal(edge1, edge2):
        """ Checks if the two given edges are equal.
        :param edge1: Edge object
        :param edge2: Edge object
        :return: boolean
        """

        if edge1 is None:
            raise MetagraphException('edge1', resources['value_null'])
        if edge2 is None:
            raise MetagraphException('edge2', resources['value_null'])
        if not isinstance(edge1, Edge):
            raise MetagraphException('edge1', resources['format_invalid'])
        if not isinstance(edge2, Edge):
            raise MetagraphException('edge2', resources['format_invalid'])

        if edge1.attributes is not None and edge2.attributes is not None:
            return (edge1.invertex == edge2.invertex and
                    edge1.outvertex == edge2.outvertex and
                    set(edge1.attributes) == set(edge2.attributes) and
                    edge1.label == edge2.label)
        else:
            return (edge1.invertex == edge2.invertex and
                    edge1.outvertex == edge2.outvertex and
                    edge1.label == edge2.label)

    @staticmethod
    def are_nodes_equal(node1, node2):
        """ Checks if two given nodes are equal.
        :param node1: Node object
        :param node2: Node object
        :return: boolean
        """

        if node1 is None:
            raise MetagraphException('node1', resources['value_null'])
        if node2 is None:
            raise MetagraphException('node2', resources['value_null'])
        if not isinstance(node1, Node):
            raise MetagraphException('node1', resources['format_invalid'])
        if not isinstance(node2, Node):
            raise MetagraphException('node2', resources['format_invalid'])

        return node1.element_set == node2.element_set

    @staticmethod
    def is_edge_list_included_recursive(edges, reference_edge_list):
        """ Checks if an edge list is included in the reference edge list.
        :param edges: list of Edge objects
        :param reference_edge_list: reference lists of Edge objects
        :return: boolean
        """

        if edges is None or len(edges) == 0:
            raise MetagraphException('edges', resources['value_null'])
        if reference_edge_list is None or len(reference_edge_list) == 0:
            raise MetagraphException('reference_edge_list', resources['value_null'])

        for ref_edges in reference_edge_list:
            inclusive_list = True
            for edge1 in edges:
                if not MetagraphHelper().is_edge_in_list(edge1, ref_edges):
                #match=False
                #for edge2 in ref_edges:
                #    if edge1.invertex==edge2.invertex and edge1.outvertex==edge2.outvertex:
                #        match=True
                #        break
                #if not match:
                    inclusive_list = False
                    break
            if inclusive_list and len(edges) == len(ref_edges):
                return True

        return False

    @staticmethod
    def is_edge_list_included(edge_list1, edge_list2):
        """ Checks if an edge list is included in edge_list2.
        :param edge_list1: first  list of Edge objects
        :param edge_list2: second list of Edge objects
        :return: boolean
        """

        if edge_list1 is None or len(edge_list1) == 0:
            raise MetagraphException('edge_list1', resources['value_null'])
        if edge_list2 is None or len(edge_list2) == 0:
            raise MetagraphException('edge_list2', resources['value_null'])

        return set(edge_list1).issubset(set(edge_list2))


    @staticmethod
    def is_metapath_included(metapath, metapath_list):
        """ Checks if a metapath is included in a list of metapaths.
        :param metapath: metapath object
        :param metapath_list: metapath list
        :return: boolean
        """
        if metapath_list is None or len(metapath_list) == 0:
            raise MetagraphException('metapath_list', resources['value_null'])
        if metapath is None or len(metapath.edge_list) == 0:
            raise MetagraphException('metapath', resources['value_null'])

        for mp in metapath_list:
            if set(metapath.edge_list).issubset(set(mp.edge_list)):
                return True

            if metapath.source.issubset(mp.source) and \
               metapath.target.issubset(mp.target) and \
               MetagraphHelper().is_attributes_subset(mp.edge_list, metapath.edge_list):
                print('metapath included in mp::')
                print('  metapath=%s,'%(metapath.edge_list))
                print('  mp=%s')%(mp.edge_list)
                #filepath='/Users/a1070571/Documents/ITS/inclusion.dot'
                #edge_list = []
                #edge_list = mp.edge_list + metapath.edge_list
                #MetagraphHelper().generate_visualisation(edge_list,filepath)
                #print('test')
                return True

        return False

    @staticmethod
    def is_attributes_subset(edge_list1, edge_list2):
        """ Checks if the attributes of edge_list1 is included
        in the attributes of the edge_list2.
        :param edge_list1: first edge list
        :param edge_list2: second edge list
        :return: boolean
        """
        # TODO: how should this logic work for >1 edge?
        attr_list1=[]
        attr_list2=[]
        for edge in edge_list1:
            attr_list1 += edge.attributes
        for edge in edge_list2:
            attr_list2 += edge.attributes

        return set(attr_list1).issubset(set(attr_list2))


    def get_netinputs(self, edge_list):
        """ Retrieves a list of net inputs corresponding to the given edge list.
        :param edge_list: list of Edge objects
        :return: list
        """

        if edge_list is None or len(edge_list) == 0:
            raise MetagraphException('edge_list', resources['value_null'])

        all_inputs = []
        for edge in edge_list:
            if isinstance(edge, Edge):
                for input_elt in edge.invertex:
                    if input_elt not in all_inputs:
                        all_inputs.append(input_elt)
            elif isinstance(edge, list):
                temp = self.get_netinputs(edge)
                for item in temp:
                    if item not in all_inputs:
                        all_inputs.append(item)

        return all_inputs

    def get_netoutputs(self, edge_list):
        """ Retrieves a list of net outputs corresponding to the given edge list.
        :param edge_list: list of Edge objects
        :return: list
        """

        if edge_list is None or len(edge_list) == 0:
            raise MetagraphException('edge_list', resources['value_null'])

        all_outputs = []
        for edge in edge_list:
            if isinstance(edge, Edge):
                for output in edge.outvertex:
                    if output not in all_outputs:
                        all_outputs.append(output)
            elif isinstance(edge, list):
                temp = self.get_netoutputs(edge)
                for item in temp:
                    if item not in all_outputs:
                        all_outputs.append(item)

        return all_outputs

    @staticmethod
    def get_coinputs_from_triples(triples_list):
        """ Retrieves a list of co-inputs corresponding to the given triples list.
        :param triples_list: list of Triple objects
        :return: list
        """

        if triples_list is None or len(triples_list) == 0:
            raise MetagraphException('triples_list', resources['value_null'])

        all_coinputs = []
        for triple in triples_list:
            if triple.coinputs is not None:
                for coinput in triple.coinputs:
                    if coinput not in all_coinputs:
                        all_coinputs.append(coinput)

        return all_coinputs

    @staticmethod
    def get_cooutputs_from_triples(triples_list):
        """ Retrieves a list of co-outputs corresponding to the given triples list.
        :param triples_list: list of Triple objects
        :return: list
        """

        if triples_list is None or len(triples_list) == 0:
            raise MetagraphException('triples_list', resources['value_null'])

        all_cooutputs = []
        for triple in triples_list:
            if triple.cooutputs is not None:
                for cooutput in triple.cooutputs:
                    if cooutput not in all_cooutputs:
                        all_cooutputs.append(cooutput)

        return all_cooutputs

    def extract_edge_list(self, nested_edge_list):
        """ Retrieves a non-nested edge list from the given nested list.
        :param nested_edge_list: nested list of Edge objects
        :return: non-nested list of Edge objects.
        """

        if nested_edge_list is None or len(nested_edge_list) == 0:
            raise MetagraphException('nested_edge_list', resources['value_null'])
        result = []

        for element in nested_edge_list:
            if isinstance(element, list):
                temp = self.extract_edge_list(element)
                for item in temp:
                    result.append(item)

            elif isinstance(element, Edge):
                result.append(element)

        return result

    def node_lists_overlap(self, nodes_list1, nodes_list2):
        """ Checks if two lists of nodes overlap.
        :param nodes_list1: list of Node objects
        :param nodes_list2: list of Node objects
        :return: boolean
        """

        for node1 in nodes_list1:
            if self.is_node_in_list(node1, nodes_list2):
                return True

        return False

    def generate_visualisation(self, edge_list, file_path, enable_ranking=False,highlight_nodes=False,highlight_edges=False,nodes_subset=None, resize=False):
        try:
            clusters = dict()
            edges = []
            index = 0
            gen_set = set()
            for edge in edge_list:
                inv=None
                outv=None
                temp_invertex = edge.invertex
                if edge.attributes is not None and len(edge.attributes) >0:
                   temp_invertex = edge.invertex.difference(edge.attributes)

                gen_set = gen_set.union(temp_invertex)
                if len(list(temp_invertex))>1:
                    # is a cluster
                    if temp_invertex not in clusters.values():
                        # create new
                        clusters[index] = temp_invertex
                        inv = index
                        index+=1
                    else:
                        # use existing
                        inv = clusters.values().index(temp_invertex)

                else:
                    # indiv node
                    inv = list(temp_invertex)[0]
                    inv = inv.strip()
                    inv = inv.replace(' ','_')
                    inv = inv.replace('-','_')
                    inv = inv.replace('"','')
                    inv = inv.replace(';','')

                if len(list(edge.outvertex))>1:
                    # a cluster
                    if edge.outvertex not in clusters.values():
                        # create new
                        clusters[index] = edge.outvertex
                        gen_set = gen_set.union(edge.outvertex)
                        outv=index
                        index+=1
                    else:
                        # use existing
                        outv = clusters.values().index(edge.outvertex)

                else:
                    # indiv node
                    gen_set = gen_set.union(edge.outvertex)
                    outv = list(edge.outvertex)[0]
                    outv = outv.strip()
                    outv = outv.replace(' ','_')
                    outv = outv.replace('-','_')
                    outv = outv.replace('"','')
                    outv = outv.replace(';','')

                if (inv, outv, edge.attributes) not in edges:
                    edges.append((inv, outv, edge.attributes))

            #TODO: update overlapping cluster elts
            clusters = self.update_clusters(clusters)

            dot_output=[]
            dot_output.append('digraph G { \n')
            if resize:
                elts = len(list(gen_set))
                if elts <5:
                    dot_output.append('size="8,3"; \n')
                elif elts <10:
                    dot_output.append('size="12,4"; \n')
                else:
                    dot_output.append('size="30,10"; \n')
                dot_output.append('ratio=fill; \n')

            dot_output.append('compound=true; \n')

            elt_tracker=dict()

            # clusters first
            for index, content in clusters.iteritems():
                dot_output.append('subgraph cluster%s { \n'%index)
                for elt in list(content):
                    elt = elt.strip()
                    original=None
                    if '_' in elt:
                        original = elt.replace('_','')
                        original = original.replace(' ','_')

                    elt = elt.replace(' ','_')
                    elt = elt.replace('-','_')
                    elt = elt.replace('"','')
                    elt = elt.replace(';','')
                    if original is not None:
                       if elt not in elt_tracker:
                           elt_tracker[elt]=original
                       elt = elt + ' [label=%s]'%original

                    dot_output.append('%s; \n'%elt)
                dot_output.append('} \n')

            # add edges for tracking duplicate cluster elts
            for key,value in elt_tracker.iteritems():
                dot_output.append('%s -> %s [dir=none color="blue"]; \n'%(value,key))

            if highlight_nodes and nodes_subset is None:
                for elt in list(gen_set):
                    temp = elt.replace(' ','_')
                    dot_output.append('%s [color="blue"];'%temp)

            if highlight_nodes and nodes_subset is not None:
                for elt in list(nodes_subset):
                    temp = elt.replace(' ','_')
                    dot_output.append('%s [color="darkorchid"];'%temp) #darkorchid turquoise

            color = 'black'
            if highlight_edges:
                color='red'

            # add all edges
            for edge in edges:
                inv = None
                outv=None
                inv_cluster=None
                outv_cluster=None
                if isinstance(edge[0],int):
                    # invertex is a cluster
                    inv_cluster='cluster%s'%edge[0]
                    inv = clusters[edge[0]]
                else:
                    # invertex is an individual node
                    inv = edge[0]

                if isinstance(edge[1],int):
                    # outvertex is a cluster
                    outv_cluster='cluster%s'%edge[0]
                    outv = clusters[edge[1]]
                else:
                    # outvertex is an individual node
                    outv = edge[1]

                attributes = None
                attrs = edge[2]
                if attrs is not None and len(attrs)>0:
                    attributes = ','.join(attrs)

                if isinstance(inv,set) and isinstance(outv,set):
                    # inv, outv both clusters
                    a = list(inv)[0]
                    b = list(outv)[0]
                    a = a.strip()
                    a = a.replace(' ','_')
                    a = a.replace('-','_')
                    a = a.replace('"','')
                    a = a.replace(';','')
                    b = b.strip()
                    b = b.replace(' ','_')
                    b = b.replace('-','_')
                    b = b.replace('"','')
                    b = b.replace(';','')
                    if attributes is not None:
                        dot_output.append('%s -> %s [ltail=%s,lhead=%s,label="[%s]",color="%s"]; \n'%(a,b,inv_cluster,outv_cluster,attributes,color))
                    else:
                        dot_output.append('%s -> %s [ltail=%s,lhead=%s,color="%s"]; \n'%(a,b,inv_cluster,outv_cluster,color))

                elif isinstance(inv,set) and isinstance(outv,str):
                    # inv is cluster, outv is string
                    a = list(inv)[0]
                    a = a.strip()
                    a = a.replace(' ','_')
                    a = a.replace('-','_')
                    a = a.replace('"','')
                    a = a.replace(';','')
                    if attributes is not None:
                        dot_output.append('%s -> %s [ltail=%s,label="[%s]",color="%s"]; \n'%(a,outv,inv_cluster,attributes,color))
                    else:
                        dot_output.append('%s -> %s [ltail=%s,color="%s"]; \n'%(a,outv,inv_cluster,color))

                elif isinstance(inv,str) and isinstance(outv,set):
                    # inv is string, outv is cluster
                    b = list(outv)[0]
                    b = b.strip()
                    b = b.replace(' ','_')
                    b = b.replace('-','_')
                    b = b.replace('"','')
                    b = b.replace(';','')
                    if attributes is not None:
                        dot_output.append('%s -> %s [lhead=%s,label="[%s]",color="%s"]; \n'%(inv,b,outv_cluster,attributes,color))
                    else:
                        dot_output.append('%s -> %s [lhead=%s,color="%s"]; \n'%(inv,b,outv_cluster,color))

                else:
                    # inv, outv both string
                    if attributes is not None:
                        dot_output.append('%s -> %s [label="[%s]",color="%s"]; \n'%(inv,outv,attributes,color))
                    else:
                        dot_output.append('%s -> %s [color="%s"]; \n'%(inv,outv,color))

            # enable ranking
            if enable_ranking:
                course_groups = self.get_course_groups(list(gen_set),clusters, MetagraphHelper().lookup_table)
                if course_groups is not None:
                   for key, group in course_groups.iteritems():
                       group_str=''
                       for elt in group:
                           group_str = group_str + '"%s"; '%elt
                       dot_output.append('{ rank = same; %s }'% group_str)

            # write output to .dot file
            dot_output.append('} \n')
            dot_file_text=''
            for line in dot_output:
                dot_file_text +=line

            #write policy file
            dot_file=open(file_path,'w')
            dot_file.write(dot_file_text)
            dot_file.close()

            return clusters

        except BaseException, e:
            print('generate_visualisation:: Error- %s'%e)

        return None

    def generate_visualisation2(self, edge_list, file_path, display_attributes=True, use_temp_label=False, use_edge_label=False):
        try:
            clusters = dict()
            edges = []
            index = 0
            for edge in edge_list:
                inv=None
                outv=None
                label=edge.label
                temp_invertex = edge.invertex
                if edge.attributes is not None and len(edge.attributes) >0:
                   temp_invertex = edge.invertex.difference(edge.attributes)

                if len(list(temp_invertex))>1:
                    # is a cluster
                    if temp_invertex not in clusters.values():
                        # create new
                        clusters[index] = temp_invertex
                        inv = index
                        index+=1
                    else:
                        # use existing
                        inv = clusters.values().index(temp_invertex)

                else:
                    # indiv node
                    inv = str(list(temp_invertex)[0])
                    inv = inv.strip()
                    inv = inv.replace(' ','_')
                    inv = inv.replace('"','')
                    inv = inv.replace(';','')
                    # TODO fix
                    # inv = inv.replace('-','_')
                    if '-' in inv:
                        items=inv.split('-')
                        if items[0]==items[1]:
                            inv="%s"%items[0]
                        else:
                            inv="%s-%s"%(items[0],items[1])

                if len(list(edge.outvertex))>1:
                    # a cluster
                    if edge.outvertex not in clusters.values():
                        # create new
                        clusters[index] = edge.outvertex
                        outv=index
                        index+=1
                    else:
                        # use existing
                        outv = clusters.values().index(edge.outvertex)

                else:
                    # indiv node
                    outv = str(list(edge.outvertex)[0])
                    outv = outv.strip()
                    outv = outv.replace(' ','_')
                    outv = outv.replace('"','')
                    outv = outv.replace(';','')
                    #TODO fix
                    #outv = outv.replace('-','_')
                    if '-' in outv:
                        items=outv.split('-')
                        if items[0]==items[1]:
                           outv="%s"%items[0]
                        else:
                           outv="%s-%s"%(items[0],items[1])


                if (inv, outv, edge.attributes, label) not in edges:
                    edges.append((inv, outv, edge.attributes, label))

            dot_output=[]
            dot_output.append('digraph G { \n')
            dot_output.append('compound=true; \n')
            dot_output.append('size="14,5"; \n')
            dot_output.append('ratio=fill; \n')

            # clusters first
            for index, content in clusters.iteritems():
                dot_output.append('subgraph cluster%s { \n'%index)
                for elt in list(content):
                    #if '2202' in elt:
                    #    print('test')

                    elt = elt.strip()
                    elt = elt.replace(' ','_')
                    elt = elt.replace('"','')
                    elt = elt.replace(';','')
                    if '-' in elt:
                        items=elt.split('-')
                        if items[0]==items[1]:
                           elt="%s"%items[0]
                        else:
                           elt="%s_%s"%(items[0],items[1])

                    dot_output.append('%s; \n'%elt)
                dot_output.append('} \n')

            # add all edges
            index=1
            label_map=dict()
            for edge in edges:
                inv = None
                outv=None
                inv_cluster=None
                outv_cluster=None
                temp_label='e%s'%index
                edge_label=edge[3]
                index+=1
                if isinstance(edge[0],int):
                    # invertex is a cluster
                    inv_cluster='cluster%s'%edge[0]
                    inv = clusters[edge[0]]
                else:
                    # invertex is an individual node
                    inv = edge[0]

                if isinstance(edge[1],int):
                    # outvertex is a cluster
                    outv_cluster='cluster%s'%edge[1]
                    outv = clusters[edge[1]]
                else:
                    # outvertex is an individual node
                    outv = edge[1]

                attributes = None
                attrs = edge[2]
                if attrs is not None and len(attrs)>0:
                    attributes = ','.join(attrs)

                label_map[temp_label]=attributes

                if isinstance(inv,set) and isinstance(outv,set):
                    # inv, outv both clusters
                    a = list(inv)[0]
                    b = list(outv)[0]
                    a = a.strip()
                    a = a.replace(' ','_')
                    #a = a.replace('-','_')
                    a = a.replace('"','')
                    a = a.replace(';','')

                    if '-' in a:
                        items=a.split('-')
                        if items[0]==items[1]:
                           a="%s"%items[0]
                        else:
                           a="%s_%s"%(items[0],items[1])

                    b = b.strip()
                    b = b.replace(' ','_')
                    b = b.replace('-','_')
                    b = b.replace('"','')
                    b = b.replace(';','')

                    if '-' in b:
                        items=b.split('-')
                        if items[0]==items[1]:
                           b="%s"%items[0]
                        else:
                           b="%s_%s"%(items[0],items[1])

                    if display_attributes and attributes is not None:
                        dot_output.append('%s -> %s [ltail=%s,lhead=%s,label="[%s]"]; \n'%(a,b,inv_cluster,outv_cluster,attributes))
                    elif use_temp_label:
                        dot_output.append('%s -> %s [ltail=%s,lhead=%s,label="[%s]"]; \n'%(a,b,inv_cluster,outv_cluster,temp_label))
                    elif use_edge_label:
                        dot_output.append('%s -> %s [ltail=%s,lhead=%s,label="[%s]"]; \n'%(a,b,inv_cluster,outv_cluster,edge_label))
                    else:
                        dot_output.append('%s -> %s [ltail=%s,lhead="[%s]"]; \n'%(a,b,inv_cluster,outv_cluster))

                elif isinstance(inv,set) and isinstance(outv,str):
                    # inv is cluster, outv is string
                    a = list(inv)[0]
                    a = a.strip()
                    a = a.replace(' ','_')
                    #a = a.replace('-','_')
                    a = a.replace('"','')
                    a = a.replace(';','')

                    if '-' in a:
                        items=a.split('-')
                        if items[0]==items[1]:
                           a="%s"%items[0]
                        else:
                           a="%s_%s"%(items[0],items[1])

                    if display_attributes and attributes is not None:
                        dot_output.append('%s -> %s [ltail=%s,label="[%s]"]; \n'%(a,outv,inv_cluster,attributes))
                    elif use_temp_label:
                        dot_output.append('%s -> %s [ltail=%s,label="[%s]"]; \n'%(a,outv,inv_cluster,temp_label))
                    elif use_edge_label:
                        dot_output.append('%s -> %s [ltail=%s,label="[%s]"]; \n'%(a,outv,inv_cluster,edge_label))
                    else:
                        dot_output.append('%s -> %s [ltail="[%s]"]; \n'%(a,outv,inv_cluster))

                elif isinstance(inv,str) and isinstance(outv,set):
                    # inv is string, outv is cluster
                    b = list(outv)[0]
                    b = b.strip()
                    b = b.replace(' ','_')
                    #b = b.replace('-','_')
                    b = b.replace('"','')
                    b = b.replace(';','')

                    if '-' in b:
                        items=b.split('-')
                        if items[0]==items[1]:
                           b="%s"%items[0]
                        else:
                           b="%s_%s"%(items[0],items[1])

                    if display_attributes and attributes is not None:
                        dot_output.append('%s -> %s [lhead=%s,label="[%s]"]; \n'%(inv,b,outv_cluster,attributes))
                    elif use_temp_label:
                        dot_output.append('%s -> %s [lhead=%s,label="[%s]"]; \n'%(inv,b,outv_cluster,temp_label))
                    elif use_edge_label:
                        dot_output.append('%s -> %s [lhead=%s,label="[%s]"]; \n'%(inv,b,outv_cluster,edge_label))
                    else:
                        dot_output.append('%s -> %s [lhead="[%s]"]; \n'%(inv,b,outv_cluster))

                else:
                    # inv, outv both string
                    if display_attributes and attributes is not None:
                        dot_output.append('%s -> %s [label="[%s]"]; \n'%(inv,outv,attributes))
                    elif use_temp_label:
                        dot_output.append('%s -> %s [label="[%s]"]; \n'%(inv,outv,temp_label))
                    elif use_edge_label:
                        dot_output.append('%s -> %s [label="[%s]"]; \n'%(inv,outv,edge_label))
                    else:
                        dot_output.append('%s -> %s; \n'%(inv,outv))


            # write output to .dot file
            dot_output.append('} \n')
            dot_file_text=''
            for line in dot_output:
                dot_file_text +=line

            #write policy file
            dot_file=open(file_path,'w')
            dot_file.write(dot_file_text)
            dot_file.close()

            # write service list
            services_text = ''
            for key, services in label_map.iteritems():
                services_text = services_text + '%s: %s \n'%(key,str(services))

            import os
            folder = os.path.dirname(file_path)
            filename = os.path.join(folder,'services.txt')
            svc_file=open(filename,'w')
            svc_file.write(services_text)
            svc_file.close()

            #print(label_map)

        except BaseException, e:
            print('generate_visualisation:: Error- %s'%e)

    def generate_visualisation1(self, edge_list, file_path):
        try:
            clusters = dict()
            edges = []
            index = 0
            for edge in edge_list:
                inv=None
                outv=None

                if len(list(edge.invertex))>1:
                    # is a cluster
                    if edge.invertex not in clusters.values():
                        # create new
                        clusters[index] = edge.invertex
                        inv = index
                        index+=1
                    else:
                        # use existing
                        inv = clusters.values().index(edge.invertex)

                else:
                    # indiv node
                    inv = list(edge.invertex)[0]
                    inv = inv.strip()
                    inv = inv.replace(' ','_')
                    inv = inv.replace('-','_')
                    inv = inv.replace('"','')
                    inv = inv.replace(';','')

                if len(list(edge.outvertex))>1:
                    # a cluster
                    if edge.outvertex not in clusters.values():
                        # create new
                        clusters[index] = edge.outvertex
                        outv=index
                        index+=1
                    else:
                        # use existing
                        outv = clusters.values().index(edge.outvertex)

                else:
                    # indiv node
                    outv = list(edge.outvertex)[0]
                    outv = outv.strip()
                    outv = outv.replace(' ','_')
                    outv = outv.replace('-','_')
                    outv = outv.replace('"','')
                    outv = outv.replace(';','')

                if (inv, outv) not in edges:
                    edges.append((inv, outv))

            dot_output=[]
            dot_output.append('digraph G { \n')
            dot_output.append('compound=true; \n')

            # clusters first
            for index, content in clusters.iteritems():
                dot_output.append('subgraph cluster%s { \n'%index)
                for elt in list(content):
                    #if '2202' in elt:
                    #    print('test')

                    elt = elt.strip()
                    elt = elt.replace(' ','_')
                    elt = elt.replace('-','_')
                    elt = elt.replace('"','')
                    elt = elt.replace(';','')
                    dot_output.append('%s; \n'%elt)
                dot_output.append('} \n')

            # add all edges
            for edge in edges:
                inv = None
                outv=None
                inv_cluster=None
                outv_cluster=None
                if isinstance(edge[0],int):
                    # invertex is a cluster
                    inv_cluster='cluster%s'%edge[0]
                    inv = clusters[edge[0]]
                else:
                    # invertex is an individual node
                    inv = edge[0]

                if isinstance(edge[1],int):
                    # outvertex is a cluster
                    outv_cluster='cluster%s'%edge[0]
                    outv = clusters[edge[1]]
                else:
                    # outvertex is an individual node
                    outv = edge[1]

                if isinstance(inv,set) and isinstance(outv,set):
                    # inv, outv both clusters
                    a = list(inv)[0]
                    b = list(outv)[0]
                    a = a.strip()
                    a = a.replace(' ','_')
                    a = a.replace('-','_')
                    a = a.replace('"','')
                    a = a.replace(';','')
                    b = b.strip()
                    b = b.replace(' ','_')
                    b = b.replace('-','_')
                    b = b.replace('"','')
                    b = b.replace(';','')
                    dot_output.append('%s -> %s [ltail=%s,lhead=%s]; \n'%(a,b,inv_cluster,outv_cluster))
                elif isinstance(inv,set) and isinstance(outv,str):
                    # inv is cluster, outv is string
                    a = list(inv)[0]
                    a = a.strip()
                    a = a.replace(' ','_')
                    a = a.replace('-','_')
                    a = a.replace('"','')
                    a = a.replace(';','')
                    dot_output.append('%s -> %s [ltail=%s]; \n'%(a,outv,inv_cluster))
                elif isinstance(inv,str) and isinstance(outv,set):
                    # inv is string, outv is cluster
                    b = list(outv)[0]
                    b = b.strip()
                    b = b.replace(' ','_')
                    b = b.replace('-','_')
                    b = b.replace('"','')
                    b = b.replace(';','')
                    dot_output.append('%s -> %s [lhead=%s]; \n'%(inv,b,outv_cluster))
                else:
                    # inv, outv both string
                    dot_output.append('%s -> %s; \n'%(inv,outv))

            # write output to .dot file
            dot_output.append('} \n')
            dot_file_text=''
            for line in dot_output:
                dot_file_text +=line

            #write policy file
            dot_file=open(file_path,'w')
            dot_file.write(dot_file_text)
            dot_file.close()

        except BaseException, e:
            print('generate_visualisation:: Error- %s'%e)

    @staticmethod
    def update_clusters(clusters):
        cluster_overlaps=dict()
        for index, cluster in clusters.iteritems():
            for elt in list(cluster):
                if elt not in cluster_overlaps:
                    cluster_overlaps[elt]=[]
                if index not in cluster_overlaps[elt]:
                    cluster_overlaps[elt].append(index)

        for elt, cluster_indices in cluster_overlaps.iteritems():
            if len(cluster_indices)>1:
                # duplicate element
                sorted_indices = sorted(cluster_indices)
                # mark primary
                primary = sorted_indices[0]
                # mark secondaries
                updated_elt=elt
                for index in sorted_indices[1:]:
                    clusters[index].remove(elt)
                    updated_elt = updated_elt + '_'
                    updated = list(clusters[index])
                    updated.append(updated_elt)
                    clusters[index] = set(updated)

        return clusters

    @staticmethod
    def nodes_overlap(nodes_list1, nodes_list2):
        """ Checks if two lists of nodes overlap.
        :param nodes_list1: list of Node objects
        :param nodes_list2: list of Node objects
        :return: boolean
        """

        for node1 in nodes_list1:
            for node2 in nodes_list2:
                intersection = node1.get_element_set().intersection(node2.get_element_set())
                if intersection is not None and len(intersection) > 0:
                    return True

        return False

    @staticmethod
    def get_generating_set(edge_list):
        """ Retrieves the generating set of the metagraph from its edge list.
        :param edge_list: list of Edge objects
        :return: set
        """

        if edge_list is None or len(edge_list) == 0:
            raise MetagraphException('edge_list', resources['value_null'])

        generating_set = []
        for edge in edge_list:
            for input_elt in edge.invertex:
                if input_elt not in generating_set:
                    generating_set.append(input_elt)

            for output in edge.outvertex:
                if output not in generating_set:
                    generating_set.append(output)

        return set(generating_set)

    @staticmethod
    def get_element_set(nodes_list):
        """ Retrieves the set of elements within a given list of nodes
        :param nodes_list: list of Node objects
        :return: set
        """
        if nodes_list is not None and len(nodes_list) > 0:
            result = set()
            for node in nodes_list:
                result = result.union(node.get_element_set())

            return result

        return set()

    @staticmethod
    def transpose_matrix(matrix):
        """ Computes the transpose matrix of given matrix
        :param matrix: 2D array
        :return: 2D array
        """

        if matrix is None:
            raise MetagraphException('matrix', resources['value_null'])

        #rows = len(matrix)
        cols = len(matrix[0])

        result = []

        for j in range(cols):
            column = [row[j] for row in matrix]
            result.append(column)

        return result

    @staticmethod
    def custom_multiply_matrices(matrix1, matrix2, edge_list):
        """Multiplies the Triple lists of two matrices
        :param matrix1: 2D array
        :param matrix2: 2D array
        :param edge_list: list of Edge objects
        :return: 2D array
        """

        if matrix1 is None:
            raise MetagraphException('matrix1', resources['value_null'])
        if matrix2 is None:
            raise MetagraphException('matrix2', resources['value_null'])
        if edge_list is None or len(edge_list) == 0:
            raise MetagraphException('edge_list', resources['value_null'])

        matrix1_cols = len(matrix1[0])
        matrix2_rows = len(matrix2)
        if matrix1_cols != matrix2_rows:
            raise MetagraphException('matrix1, matrix2', resources['structures_incompatible'])

        result = MetagraphHelper().get_null_matrix(len(matrix1), len(matrix2[0]))

        for i in range(len(matrix1)):
            for j in range(len(matrix2[0])):
                intermediate_result = set()
                for k in range(len(matrix1[0])):
                    a_ik = matrix1[i][k]
                    b_kj = matrix2[k][j]
                    temp = MetagraphHelper().custom_add_matrix_elements(k, a_ik, b_kj, edge_list)
                    intermediate_result = intermediate_result.union(temp)

                result[i][j] = intermediate_result

        return result

    @staticmethod
    def custom_add_matrix_elements(k, a_ik, b_kj, y):
        """Custom addition of matrix elements.
        :param k: int
        :param a_ik: int
        :param b_kj: int
        :param y: list
        :return: set
        """

        if len(y) < k+1:
            raise MetagraphException('k', resources['value_out_of_bounds'])

        if a_ik == 1 and b_kj == -1:
            return {(1, y[k])}
        elif a_ik == -1 and b_kj == -1:
            return {(-1, y[k])}
        else:
            return set()

    @staticmethod
    def extract_edge_label_components(label):
        """Extracts components of an edge label.
        :param label: string
        :return: string tuple
        """

        if label is None or label == '':
            raise MetagraphException('label', resources['value_null'])

        label = label.replace('>', '')
        items = label.split('<')
        if len(items) < 2:
            raise MetagraphException('label', resources['format_invalid'])

        r_ij = {items[0]}
        tuples = items[1].split(';')
        if len(tuples) < 2:
            raise MetagraphException('label', resources['format_invalid'])

        t_a = {tuples[0]}
        t_b = {tuples[1]}

        # noinspection PyRedundantParentheses
        return (r_ij, t_a, t_b)

    @staticmethod
    def get_pre_requisites_list(pre_requisites_desc):
        result=[]
        if pre_requisites_desc=='NA' or pre_requisites_desc=='':
            return result
        items= pre_requisites_desc.split(' or ')
        for item in items:
            item = item.replace('(','')
            item = item.replace(')','')
            sub_items = item.split(' and ')
            if len(sub_items)>1 and sub_items not in result:
                result.append(sub_items)
            elif item not in result:
                result.append(item)

        return result

    @staticmethod
    def CreateLineGraph(multi_digraph):
        import networkx as nx
        #multi_digraph = MetagraphHelper().GetMultiDigraph(conditional_metagraph)

        if multi_digraph:
            line_graph_edges = []
            for v in multi_digraph.nodes():
                incoming=[]
                outgoing=[]
                for edge1 in multi_digraph.in_edges(nbunch=[v]):
                    incoming.append(edge1)
                for edge2 in multi_digraph.out_edges(nbunch=[v]):
                    outgoing.append(edge2)
                line_graph_edges.extend((e1, e2) for e1 in incoming for e2 in outgoing)

            line_graph = nx.DiGraph()
            line_graph.add_edges_from(line_graph_edges)
            line_graph_nodes=[]
            for source,dest in line_graph.nodes():
                # get corresponding attribute
                node_label = multi_digraph.get_edge_data(source,dest)[0]['label']
                line_graph.node[(source,dest)]['label']=node_label
                if node_label not in line_graph_nodes:
                    line_graph_nodes.append(node_label)

            # add disconnected edges from original graph as nodes
            missing=dict()
            for source,dest in multi_digraph.edges():
                matches=multi_digraph.get_edge_data(source,dest)
                for key,val in matches.iteritems():
                    edge_label=val['label']
                    if (edge_label not in line_graph_nodes):
                        if ((source,dest) not in missing):
                            missing[(source,dest)]= []
                        if edge_label not in missing[(source,dest)]:
                           missing[(source,dest)].append(edge_label)

            # node_index=len(line_graph_nodes)+1
            for key,val in missing.iteritems():
                line_graph.add_node(key)
                line_graph.node[key]['label']=val

            return line_graph

        return None


    @staticmethod
    def print_duplicate_edges(edge_list):
        temp = []
        duplicates=[]
        for edge in edge_list:
            if edge in temp and edge not in duplicates:
                duplicates.append(edge)
            else:
                temp.append(edge)

        count=1
        for edge in duplicates:
            print('%s. duplicate edge: %s'%(count,str(edge)))
            count+=1

    @staticmethod
    def GetMultiDigraph(conditional_metagraph):
        import networkx as nx
        multi_digraph= nx.MultiDiGraph()
        # add nodes
        temp=[]
        elts=[]
        index=1
        #for node in conditional_metagraph.nodes:
        #    multi_digraph.add_node(node)
        #    elts.append(list(node.element_set))
        #    temp.append(node)
        #..and edges
        for edge in conditional_metagraph.edges:
            inv=edge.invertex.difference(edge.attributes)
            outv=edge.outvertex.difference(edge.attributes)
            for inv_elt in inv:
                for outv_elt in outv:
                    inv_node=Node({inv_elt})
                    outv_node=Node({outv_elt})
                    if inv_elt not in elts:
                        elts.append(inv_elt)
                        temp.append(inv_node)
                    else:
                        # use existing
                        inv_node= MetagraphHelper().GetNode({inv_elt},temp)
                    if outv_elt not in elts:
                        elts.append(outv_elt)
                        temp.append(outv_node)
                    else:
                        # use existing
                        outv_node= MetagraphHelper().GetNode({outv_elt},temp)

                    #label='e%s'%index
                    multi_digraph.add_edge(inv_node,outv_node,attributes=edge.attributes,label=edge.label)
                    index+=1

        return multi_digraph

    @staticmethod
    def GetNode(vertex_elts, nodes_list):
        for node in nodes_list:
            if node.element_set==vertex_elts: return node
        return None

    @staticmethod
    def is_policy_consistent(original_cmg, surpress_message_output= False, conflict_resolution_scheme=None):
        try:
            nw_rule_count=0

            # convert original metagraph to an intermediate metagraph that can be analysed
            # reformat attributes
            # TCP
            tcp_port_attributes = MetagraphHelper().filter_port_attributes("TCP", original_cmg.propositions_set)
            non_overlapping_tcp_port_ranges = MetagraphHelper().get_minimal_non_overlapping_port_ranges('TCP','dport',tcp_port_attributes)
            # UDP
            udp_port_attributes = MetagraphHelper().filter_port_attributes("UDP", original_cmg.propositions_set)
            non_overlapping_udp_port_ranges = MetagraphHelper().get_minimal_non_overlapping_port_ranges('UDP','dport',udp_port_attributes)

            timestamp_attributes=[]
            for edge in original_cmg.edges:
                # timestamp
                start = MetagraphHelper().filter_timestamp_attributes("start", edge.attributes)
                end = MetagraphHelper().filter_timestamp_attributes("end", edge.attributes)
                if len(start)>0 and len(end)>0:
                    # convert 24 hour timestamps to mins
                    time_range = '%s-%s'%(start[0].replace('start=',''), end[0].replace('end=',''))
                    time_range_mins = MetagraphHelper().get_timestamp_minutes(time_range)
                    if time_range_mins not in timestamp_attributes:
                        timestamp_attributes.append(time_range_mins)

            non_overlapping_timestamp_ranges = MetagraphHelper().get_minimal_non_overlapping_timestamp_ranges(timestamp_attributes)

            propositions_set=original_cmg.propositions_set
            #numeric_ipadresses =  MetagraphHelper().get_ipaddresses_numeric(original_cmg.variables_set)
            #non_overlapping_ipaddress_ranges = MetagraphHelper().get_minimal_non_overlapping_ipaddress_ranges(numeric_ipadresses)

            #converted=[]
            #for ipaddr_range in non_overlapping_ipaddress_ranges:
            #    range_string = '%s-%s'%(ipaddr_range[0],ipaddr_range[1])
            #    converted.append(range_string)

            variable_set = original_cmg.variables_set #set(converted)

            new_edge_list=[]
            for edge in original_cmg.edges:
                edge_attributes= copy.copy(edge.attributes)
                # convert tcp port attributes to non-overlapping ranges via lookup
                invertex = edge.invertex.difference(edge_attributes)
                outvertex = edge.outvertex
                #invertex = MetagraphHelper().get_ipaddresses_numeric(invertex)
                #outvertex = MetagraphHelper().get_ipaddresses_numeric(outvertex)
                #invertex = MetagraphHelper().get_ipaddresses_canonical_form(invertex, non_overlapping_ipaddress_ranges)
                #outvertex = MetagraphHelper().get_ipaddresses_canonical_form(outvertex, non_overlapping_ipaddress_ranges)

                temp= edge.attributes
                # TCP
                edge_tcp_attr= MetagraphHelper().filter_port_attributes("TCP", edge_attributes)
                if len(edge_tcp_attr)>0:
                    canonical_tcp_attr= MetagraphHelper().get_ports_canonical_form('TCP.dport=', edge_tcp_attr[0], non_overlapping_tcp_port_ranges)
                # UDP
                edge_udp_attr= MetagraphHelper().filter_port_attributes("UDP", edge_attributes)
                if len(edge_udp_attr)>0:
                    canonical_udp_attr= MetagraphHelper().get_ports_canonical_form('UDP.dport=', edge_udp_attr[0], non_overlapping_udp_port_ranges)

                # timestamp
                timestamp_start= MetagraphHelper().filter_timestamp_attributes("start", edge_attributes)
                timestamp_end = MetagraphHelper().filter_timestamp_attributes("end", edge_attributes)
                if len(timestamp_start)>0 and len(timestamp_end)>0:
                    # convert 24 hour timestamps to mins
                    time_range = '%s-%s'%(timestamp_start[0].replace('start=',''), timestamp_end[0].replace('end=',''))
                    edge_time_attr = MetagraphHelper().get_timestamp_minutes(time_range)
                    canonical_time_attr= MetagraphHelper().get_timestamp_canonical_form(edge_time_attr, non_overlapping_timestamp_ranges)

                # update temp and propositions_set
                # TCP
                if len(edge_tcp_attr)>0:
                    if edge_tcp_attr[0] in temp: temp.remove(edge_tcp_attr[0])
                    if edge_tcp_attr[0] in propositions_set: propositions_set.remove(edge_tcp_attr[0])
                    for canonical_attr in canonical_tcp_attr:
                        if canonical_attr not in temp:
                            temp.append(canonical_attr)
                        if canonical_attr not in propositions_set:
                            propositions_set= propositions_set.union({canonical_attr})
                # UDP
                if len(edge_udp_attr)>0:
                    if edge_udp_attr[0] in temp: temp.remove(edge_udp_attr[0])
                    if edge_udp_attr[0] in propositions_set: propositions_set.remove(edge_udp_attr[0])
                    for canonical_attr in canonical_udp_attr:
                        if canonical_attr not in temp:
                            temp.append(canonical_attr)
                        if canonical_attr not in propositions_set:
                            propositions_set= propositions_set.union({canonical_attr})

                # time
                if len(timestamp_start)>0 and len(timestamp_end)>0:
                    temp.remove(timestamp_start[0])
                    temp.remove(timestamp_end[0])
                    propositions_set= propositions_set.difference({timestamp_start[0]})
                    propositions_set= propositions_set.difference({timestamp_end[0]})
                    for canonical_attr in canonical_time_attr:
                        if canonical_attr not in temp:
                            temp.append(canonical_attr)
                        if canonical_attr not in propositions_set:
                            propositions_set= propositions_set.union({canonical_attr})

                new_edge= Edge(invertex, outvertex, temp, label=edge.label)
                new_edge_list.append(new_edge)

            # create intermediate metagraph suitable for performing analysis
            converted_cmg= ConditionalMetagraph(variable_set, propositions_set)
            converted_cmg.add_edges_from(new_edge_list)

            if False:
                # reduce metagraph complexity by generating an equivalent metagraph
                if not surpress_message_output:
                    print('generating complexity reduced, equivalent metagraph..')
                group_name_index=1
                new_edge_list=[]
                new_var_set=set()
                invertex_element_group_lookup=dict()
                outvertex_element_group_lookup=dict()

                for edge in converted_cmg.edges:
                    invertex_elts = list(edge.invertex.difference(propositions_set))
                    outvertex_elts = list(edge.outvertex.difference(propositions_set))

                    for elt in invertex_elts:
                        result= converted_cmg.get_associated_edges(elt)
                        edge_list_string=repr(result)
                        if edge_list_string not in invertex_element_group_lookup:
                            invertex_element_group_lookup[edge_list_string]=[]
                        if elt not in invertex_element_group_lookup[edge_list_string]:
                            invertex_element_group_lookup[edge_list_string].append(elt)

                    for elt in outvertex_elts:
                        result= converted_cmg.get_associated_edges(elt)
                        edge_list_string=repr(result)
                        if edge_list_string not in outvertex_element_group_lookup:
                            outvertex_element_group_lookup[edge_list_string]=[]
                        if elt not in outvertex_element_group_lookup[edge_list_string]:
                            outvertex_element_group_lookup[edge_list_string].append(elt)

                import json
                group_details_lookup=dict()

                for edge_list_string, elt_list in invertex_element_group_lookup.iteritems():
                    group_elts = set(elt_list)
                    if len(group_elts)>1:
                        # group
                        group_elts_string = json.dumps(list(group_elts))
                        if group_elts_string not in group_details_lookup:
                            group_name= 'group_%s'%group_name_index
                            group_details_lookup[group_elts_string]=group_name
                            group_name_index+=1

                for edge_list_string, elt_list in outvertex_element_group_lookup.iteritems():
                    group_elts = set(elt_list)
                    if len(group_elts)>1:
                        # group
                        group_elts_string = json.dumps(list(group_elts))
                        if group_elts_string not in group_details_lookup:
                            group_name= 'group_%s'%group_name_index
                            group_details_lookup[group_elts_string]=group_name
                            group_name_index+=1

                # replace original invertices with groups
                for edge in converted_cmg.edges:
                    invertex_elts = list(edge.invertex.difference(propositions_set))
                    outvertex_elts = list(edge.outvertex)
                    new_invertex=set()
                    new_outvertex=set()

                    for group_elts, group_name in group_details_lookup.iteritems():
                        group_elts_list = json.loads(group_elts)
                        group_elts_list = [elt2.encode('ascii', errors='backslashreplace') for elt2 in group_elts_list]
                        if set(group_elts_list).issubset(set(invertex_elts)):
                            new_invertex = new_invertex.union({group_name})
                            invertex_elts = list(set(invertex_elts).difference(set(group_elts_list)))

                    for group_elts, group_name in group_details_lookup.iteritems():
                        group_elts_list = json.loads(group_elts)
                        group_elts_list = [elt2.encode('ascii', errors='backslashreplace') for elt2 in group_elts_list]
                        if set(group_elts_list).issubset(set(outvertex_elts)):
                            new_outvertex = new_outvertex.union({group_name})
                            outvertex_elts = list(set(outvertex_elts).difference(set(group_elts_list)))

                    new_invertex=new_invertex.union(set(invertex_elts))
                    new_outvertex=new_outvertex.union(set(outvertex_elts))
                    new_var_set = new_var_set.union(new_invertex)
                    new_var_set = new_var_set.union(new_outvertex)
                    new_edge_list.append(Edge(new_invertex, new_outvertex,
                                                      attributes=list(edge.invertex.intersection(propositions_set)),
                                                      label=edge.label))

                # create complexity reduced, equivalent metagraph
                reduced_cmg= ConditionalMetagraph(new_var_set, propositions_set)
                reduced_cmg.add_edges_from(new_edge_list)

            # temp
            reduced_cmg = converted_cmg

            #print('Converted Metagraph: %s'%type(reduced_cmg))
            #display_metagraph(reduced_cmg)
            conflict=False

            if not surpress_message_output:
               print('generator-set comparison: original=%s ,reduced=%s'%(len(converted_cmg.generating_set), len(reduced_cmg.generating_set)))

            # print('checking for conflicts...')
            potential_conflicts = reduced_cmg.check_conflicts() # check_conflicts check_conflicts_simple
            if potential_conflicts:
                return "Policy is Inconsistent!"
            else:
                return "Policy is Consistent!"

        except BaseException,e:
            print('Error::is_policy_consistent- %s'%str(e))
            return "Policy is Inconsistent!"

    @staticmethod
    def remove_duplicates(metapaths_list):

        result=[]
        # sort the metapaths
        sorted_metapaths=[]
        lookup= dict()
        for metapath in metapaths_list:
            count = len(metapath.edge_list)
            if count not in lookup:
                lookup[count]=[]
            lookup[count].append(metapath)

        keys = sorted(lookup.keys())
        #print('keys= %s'%keys)
        #for key, value in lookup.iteritems():
        #    print('key(# edges)= %s, count(# occurrences)= %s'%(key,len(value)))

        for key in keys:
            for metapath in lookup[key]:
                sorted_metapaths.append(metapath)

        for metapath1 in sorted_metapaths:
            ignore=False
            for metapath2 in result:
                if MetagraphHelper().is_edge_list_included(metapath1.edge_list, metapath2.edge_list):
                # intersection = set(metapath1.edge_list).intersection(set(metapath2.edge_list))
                # if intersection is not None and len(intersection)>1:
                #   conflict_sources=[]
                #   metapath = Metapath(metapath1.source,metapath1.target,intersection)
                #   if reduced_cmg.has_conflicts(metapath, conflict_sources):
                       # already covered..ignore
                       ignore=True
                       #print('ignore')
                       break

            if not ignore and metapath1 not in result:
                result.append(metapath1)

        return result

    @staticmethod
    def remove_duplicate_redundancies(redundancies):

        result=[]
        for edge_pair1 in redundancies:
            ignore=False
            for edge_pair2 in result:
                if MetagraphHelper().is_edge_list_included(list(edge_pair1),list(edge_pair2)):
                     # already covered..ignore
                     ignore=True
                     break

            if not ignore and edge_pair1 not in result:
                result.append(edge_pair1)

        return result

    @staticmethod
    def filter_port_attributes(protocol, all_attributes):
        filtered=[]
        for attribute in all_attributes:
            if (('%s.dport'%(protocol)) in attribute) and (attribute not in filtered):
                filtered.append(attribute)

        return filtered

    @staticmethod
    def filter_timestamp_attributes(prefix, all_attributes):
        filtered=[]
        for attribute in all_attributes:
            if (prefix in attribute) and (attribute not in filtered):
                filtered.append(attribute)

        return filtered

    @staticmethod
    def get_timestamp_minutes(timestamp_hrs_mins):
        converted_timestamp= timestamp_hrs_mins.encode('ascii', errors='backslashreplace')
        items = converted_timestamp.split('-')
        hrs_start = items[0].split(':')[0]
        mins_start = items[0].split(':')[1]
        total_mins_start= int(hrs_start)*60 + int(mins_start)

        hrs_end = items[1].split(':')[0]
        mins_end = items[1].split(':')[1]
        total_mins_end = int(hrs_end)*60 + int(mins_end)

        if total_mins_end< total_mins_start:
           # ends the next day
           total_mins_end = total_mins_end + 24*60

        return '%s-%s'%(total_mins_start,total_mins_end)

    @staticmethod
    def get_ports_canonical_form(attr_descriptor, edge_tcp_attr, non_overlapping_tcp_port_ranges):
        source = None
        result=[]
        edge_tcp_attr = edge_tcp_attr.replace(attr_descriptor,'')
        if '-' in edge_tcp_attr:
            # port range
            converted_port = edge_tcp_attr.encode('ascii', errors='backslashreplace')
            items= converted_port.split('-')
            source = (int(items[0]), int(items[1]))
        else:
            # single value
            converted_port = edge_tcp_attr.encode('ascii', errors='backslashreplace')
            source=(int(converted_port), int(converted_port))

        for non_overlapping_port_range in non_overlapping_tcp_port_ranges:
            if non_overlapping_port_range[0] >= source[0] and \
               non_overlapping_port_range[1] <= source[1]:
                 formatted = '%s%s-%s'%(attr_descriptor,non_overlapping_port_range[0],non_overlapping_port_range[1])
                 result.append(formatted)

        return result

    @staticmethod
    def get_ipaddresses_canonical_form(ipaddress_ranges, non_overlapping_ipaddress_ranges):
        source = None
        result=[]

        for ipaddress_range in ipaddress_ranges:
            if '-' in ipaddress_range:
                items= ipaddress_range.split('-')
                source = (long(items[0]), long(items[1]))
            else:
                converted_address = ipaddress_range.encode('ascii', errors='backslashreplace')
                source=(long(converted_address), long(converted_address))

            for non_overlapping_ipaddress_range in non_overlapping_ipaddress_ranges:
                if non_overlapping_ipaddress_range[0] >= source[0] and \
                   non_overlapping_ipaddress_range[1] <= source[1]:
                     formatted = '%s-%s'%(non_overlapping_ipaddress_range[0], non_overlapping_ipaddress_range[1])
                     result.append(formatted)

        return set(result)

    @staticmethod
    def get_timestamp_canonical_form(edge_time_attr, non_overlapping_time_ranges):
        source = None
        result=[]
        converted_timestamp = edge_time_attr.encode('ascii', errors='backslashreplace')
        if '-' in edge_time_attr:
            # port range
            items= converted_timestamp.split('-')
            source = (int(items[0]), int(items[1]))
        else:
            # single value
            source=(int(converted_timestamp), int(converted_timestamp))

        for non_overlapping_time_range in non_overlapping_time_ranges:
            if non_overlapping_time_range[0] >= source[0] and \
               non_overlapping_time_range[1] <= source[1]:
                 formatted = 'active_time=%s-%s'%(non_overlapping_time_range[0],non_overlapping_time_range[1])
                 result.append(formatted)

        return result

    @staticmethod
    def get_minimal_non_overlapping_port_ranges(protocol, port_type, overlapping_port_ranges):
         desc_tag='%s.%s='%(protocol,port_type)
         temp=[]

         index=1
         for port_or_range in overlapping_port_ranges:
             if desc_tag in port_or_range:
                port_or_range = port_or_range.replace(desc_tag,'')
                if '-' in port_or_range:
                    # range
                    items=port_or_range.split('-')
                    val=(int(items[0]), int(items[1]), str(index))
                    if val not in temp: temp.append(val)
                else:
                    # single port value
                    val = (int(port_or_range), int(port_or_range), str(index))
                    if val not in temp: temp.append(val)
             index+=1

         endpoints = sorted(list(set([r[0] for r in temp] + [r[1] for r in temp])))
         final=[]
         index=0
         last_end=None
         for e in endpoints:
             # look for tuples beginning with e
             matches= MetagraphHelper().get_tuples_starting_with(e,temp)
             # check if point exists
             points= [match for match in matches if match[0]==match[1]]
             if len(points)>0 and ((e,e) not in final):
                 final.append((e,e))
                 last_end=e
             # check if range(s) exist
             ranges= [match for match in matches if match[0]!=match[1]]
             if len(ranges)>0:
                for range in ranges:
                    start=range[0]
                    end=range[1]
                    # get next endpoint value
                    next_val = endpoints[index+1]
                    ref_tuples1= MetagraphHelper().get_tuples_starting_with(next_val,temp)
                    ref_tuples2= MetagraphHelper().get_tuples_ending_with(next_val,temp)
                    if len(ref_tuples1)>0:
                       end=next_val-1
                       if (start<=end) and (start,end) not in final:
                         final.append((start,end))
                    elif len(ref_tuples2)>0:
                       end=next_val
                       if (start<=end) and (start,end) not in final:
                         final.append((start,end))

                    last_end=end

             # look for tuples ending with e
             matches2= MetagraphHelper().get_tuples_ending_with(e,temp)
             if len(matches2)>0 and index < len(endpoints)-1:
                 start=last_end+1
                 next_val = endpoints[index+1]
                 ref_tuples1= MetagraphHelper().get_tuples_starting_with(next_val,temp)
                 ref_tuples2= MetagraphHelper().get_tuples_ending_with(next_val,temp)
                 if len(ref_tuples1)>0:
                    end=next_val-1
                    if (start<=end) and (start,end) not in final:
                      final.append((start,end))
                 elif len(ref_tuples2)>0:
                    end=next_val
                    if (start<=end) and (start,end) not in final:
                      final.append((start,end))

                 last_end=end
             index+=1
         return final

    @staticmethod
    def get_minimal_non_overlapping_timestamp_ranges(overlapping_time_ranges):
         result=[]
         temp=[]

         index=1
         for time_range in overlapping_time_ranges:
            if '-' in time_range:
                items=time_range.split('-')
                val=(int(items[0]), int(items[1]), str(index))
                if val not in temp: temp.append(val)
            index+=1

         endpoints = sorted(list(set([r[0] for r in temp] + [r[1] for r in temp])))
         final=[]
         index=0
         last_end=None
         for e in endpoints:
             # look for tuples beginning with e
             matches= MetagraphHelper().get_tuples_starting_with(e,temp)
             # check if point exists
             points= [match for match in matches if match[0]==match[1]]
             if len(points)>0 and ((e,e) not in final):
                 final.append((e,e))
                 last_end=e
             # check if range(s) exist
             ranges= [match for match in matches if match[0]!=match[1]]
             if len(ranges)>0:
                for range in ranges:
                    start=range[0]
                    end=range[1]
                    # get next endpoint value
                    next_val = endpoints[index+1]
                    ref_tuples1= MetagraphHelper().get_tuples_starting_with(next_val,temp)
                    ref_tuples2= MetagraphHelper().get_tuples_ending_with(next_val,temp)
                    if len(ref_tuples1)>0:
                       end=next_val-1
                       if (start<=end) and (start,end) not in final:
                         final.append((start,end))
                    elif len(ref_tuples2)>0:
                       end=next_val
                       if (start<=end) and (start,end) not in final:
                         final.append((start,end))

                    last_end=end

             # look for tuples ending with e
             matches2= MetagraphHelper().get_tuples_ending_with(e,temp)
             if len(matches2)>0 and index < len(endpoints)-1:
                 start=last_end+1
                 next_val = endpoints[index+1]
                 ref_tuples1= MetagraphHelper().get_tuples_starting_with(next_val,temp)
                 ref_tuples2= MetagraphHelper().get_tuples_ending_with(next_val,temp)
                 if len(ref_tuples1)>0:
                    end=next_val-1
                    if (start<=end) and (start,end) not in final:
                      final.append((start,end))
                 elif len(ref_tuples2)>0:
                    end=next_val
                    if (start<=end) and (start,end) not in final:
                      final.append((start,end))

                 last_end=end
             index+=1
         return final

    @staticmethod
    def get_minimal_non_overlapping_ipaddress_ranges(overlapping_ipaddress_ranges):
         result=[]
         temp=[]

         index=1
         for ipaddress_range in overlapping_ipaddress_ranges:
            if '-' in ipaddress_range:
                items=ipaddress_range.split('-')
                val=(long(items[0]), long(items[1]), str(index))
                if val not in temp: temp.append(val)
            index+=1

         endpoints = sorted(list(set([r[0] for r in temp] + [r[1] for r in temp])))
         final=[]
         index=0
         last_end=None
         for e in endpoints:
             # look for tuples beginning with e
             matches= MetagraphHelper().get_tuples_starting_with(e,temp)
             # check if range(s) exist
             # check if point exists
             points= [match for match in matches if match[0]==match[1]]
             if len(points)>0 and ((e,e) not in final):
                 final.append((e,e))
                 last_end=e
             ranges= [match for match in matches if match[0]!=match[1]]
             if len(ranges)>0:
                for range in ranges:
                    start=range[0]
                    end=range[1]
                    # get next endpoint value
                    next_val = endpoints[index+1]
                    ref_tuples1= MetagraphHelper().get_tuples_starting_with(next_val,temp)
                    ref_tuples2= MetagraphHelper().get_tuples_ending_with(next_val,temp)
                    if len(ref_tuples1)>0:
                       end=next_val-1
                       if (start<=end) and (start,end) not in final:
                         final.append((start,end))
                    elif len(ref_tuples2)>0:
                       end=next_val
                       if (start<=end) and (start,end) not in final:
                         final.append((start,end))
                    last_end=end

             # look for tuples ending with e
             matches2= MetagraphHelper().get_tuples_ending_with(e,temp)
             if len(matches2)>0 and index < len(endpoints)-1:
                 start=last_end+1
                 next_val = endpoints[index+1]
                 ref_tuples1= MetagraphHelper().get_tuples_starting_with(next_val,temp)
                 ref_tuples2= MetagraphHelper().get_tuples_ending_with(next_val,temp)
                 if len(ref_tuples1)>0:
                    end=next_val-1
                    if (start<=end) and (start,end) not in final:
                      final.append((start,end))
                 elif len(ref_tuples2)>0:
                    end=next_val
                    if (start<=end) and (start,end) not in final:
                      final.append((start,end))

                 last_end=end
             index+=1
         return final

    @staticmethod
    def get_tuples_starting_with(start_val,tuples_list):
         return [t for t in tuples_list if t[0]==start_val]

    @staticmethod
    def get_tuples_ending_with(end_val,tuples_list):
         return [t for t in tuples_list if t[1]==end_val]




    #TODO: put these in a separate helper class (MUD related)

    @staticmethod
    def get_device_acl_details(extracted_data,ignore_rules=False):
        from exception import InvalidMUDFileException

        acl_details= dict()

        # TODO: what are these subnets (ayyoob/hassan)?
        local_networks = {'192.168.1.0/24'}
        local_gateway = {'192.168.1.1/32'}

        if extracted_data is not None:
            from_device_acls = extracted_data['ietf-mud:mud']['from-device-policy']['access-lists']['access-list']
            if len(from_device_acls)>0:
                for acl in extracted_data['ietf-mud:mud']['from-device-policy']['access-lists']['access-list']:
                    acl_name = acl['name']
                    # lookup ACL data
                    data = extracted_data['ietf-access-control-list:access-lists']['acl']
                    if len(data)>0:
                        for acl_data in data:
                            if acl_name == acl_data['name']:
                                aces= acl_data['aces']
                                if len(aces)>0:
                                    for ace in aces['ace']:
                                        source='device' # ace['matches']['l3']['ietf-mud:direction-initiated']
                                        dest=set(['0.0.0.0/0'])
                                        substituted=False
                                        if 'ietf-mud:mud' in ace['matches']:
                                            if 'controller' in ace['matches']['ietf-mud:mud']: # local-networks
                                               dest = ace['matches']['ietf-mud:mud']['controller'] # dest.union({"10.10.0.7/32"}) # dest.union({'controllers'}) #["10.10.0.7/32"]     #  ace['matches']['ietf-mud:mud']['controller']
                                               if 'urn:ietf:params:mud:gateway' in dest or \
                                                  'urn:ietf:params:mud:dns' in dest or \
                                                  'urn:ietf:params:mud:ntp' in dest:
                                                     dest = local_gateway
                                                     substituted=True
                                            if 'local-networks' in ace['matches']['ietf-mud:mud']: #internet
                                               dest = ace['matches']['ietf-mud:mud']['local-networks'] #dest.union({"10.10.0.0/24"}) #dest.union(local_networks) #["0.0.0.0/0"]
                                               if len(dest)==1 and dest[0]==None:
                                                   dest = local_networks
                                                   substituted=True
                                            if 'manufacturer' in ace['matches']['ietf-mud:mud']: #internet
                                               dest = ace['matches']['ietf-mud:mud']['manufacturer'] #dest.union({"201.10.0.5/32"}) #dest.union({'manufacturer domains'}) #["0.0.0.0/0"]

                                            if 'model' in ace['matches']['ietf-mud:mud']: #internet
                                               dest = ace['matches']['ietf-mud:mud']['model']#dest.union({"10.10.0.8/32"}) #dest.union({'same-model devices'}) #["0.0.0.0/0"]
                                            if '*' in ace['matches']['ietf-mud:mud']: #internet
                                               dest = ace['matches']['ietf-mud:mud']['local-networks'] #dest.union({"10.10.0.0/24"}) #dest.union(local_networks) #["0.0.0.0/0"]


                                        if 'ipv4' in ace['matches']:
                                            protocol = ace['matches']['ipv4']['protocol']
                                            sports_start=None
                                            sports_end=None
                                            dports_start=None
                                            dports_end=None
                                            action= str(ace['actions']['forwarding']).strip().lower()

                                            if action!='drop' and action!='accept':
                                                raise InvalidMUDFileException("%s : %s"%(resources['mud_file_action_invalid'],action))

                                            if 'ietf-acldns:dst-dnsname' in ace['matches']['ipv4']:
                                               dest = [ace['matches']['ipv4']['ietf-acldns:dst-dnsname']]
                                            if 'destination-ipv4-network' in ace['matches']['ipv4']:
                                               dest = [ace['matches']['ipv4']['destination-ipv4-network']]

                                               if not substituted and CanonicalPolicyHelper().is_private_ipaddress(list(dest)[0]): #.split('/')[0]
                                                   raise InvalidMUDFileException("%s : %s"%(resources['mud_file_has_local_ipaddress_details'],list(dest)[0]))

                                            if 'udp' in ace['matches'] and \
                                                'destination-port' in ace['matches']['udp'] and \
                                                ace['matches']['udp']['destination-port'] is not None:
                                                dports_start= ace['matches']['udp']['destination-port']['port']
                                                dports_end= ace['matches']['udp']['destination-port']['port']
                                            elif 'tcp' in ace['matches'] and \
                                                'destination-port' in ace['matches']['tcp'] and \
                                                ace['matches']['tcp']['destination-port'] is not None:
                                                dports_start= ace['matches']['tcp']['destination-port']['port']
                                                dports_end= ace['matches']['tcp']['destination-port']['port']
                                            elif 'udp' in ace['matches'] and \
                                                'source-port' in ace['matches']['udp'] and \
                                                ace['matches']['udp']['source-port'] is not None:
                                                sports_start= ace['matches']['udp']['source-port']['port']
                                                sports_end= ace['matches']['udp']['source-port']['port']
                                            elif 'tcp' in ace['matches'] and \
                                                'source-port' in ace['matches']['tcp'] and \
                                                ace['matches']['tcp']['source-port'] is not None:
                                                sports_start= ace['matches']['tcp']['source-port']['port']
                                                sports_end= ace['matches']['tcp']['source-port']['port']

                                            if protocol==6 or protocol==17:
                                                sports = (1024,65535) #(0,65535)
                                                dports = (1024,65535) #(0,65535)
                                            else:
                                                sports=None
                                                dports=None

                                            if dports_end==0:
                                                continue

                                            if sports_start is not None and sports_end is not None:
                                                sports=(sports_start,sports_end)
                                            if dports_start is not None and dports_end is not None:
                                                dports=(dports_start,dports_end)

                                            if ignore_rules and protocol==6 and sports!=(1024,65535): #sports!=(0,65535):
                                                continue

                                            extracted_ace = ACE(source,dest,protocol,dports,sports,action)
                                            if 'from' not in acl_details:
                                                acl_details['from']=[]

                                            acl_details['from'].append(extracted_ace)

                                        if 'l2' in ace['matches']:
                                            #TODO: handle
                                            print('L2 tag not yet handled')

            to_device_acls = extracted_data['ietf-mud:mud']['to-device-policy']['access-lists']['access-list']
            if len(to_device_acls)>0:
                for acl in extracted_data['ietf-mud:mud']['to-device-policy']['access-lists']['access-list']:
                    acl_name = acl['name']
                    # lookup ACL data
                    data = extracted_data['ietf-access-control-list:access-lists']['acl']
                    if len(data)>0:
                        for acl_data in data:
                            if acl_name == acl_data['name']:
                                aces= acl_data['aces']
                                if len(aces)>0:
                                    for ace in aces['ace']:
                                        dest='device'#ace['matches']['tcp-acl']['ietf-mud:direction-initiated']
                                        source=set(['0.0.0.0/0'])
                                        substituted=False
                                        if 'ietf-mud:mud' in ace['matches']:
                                            if 'controller' in ace['matches']['ietf-mud:mud']: # local-networks
                                               source = ace['matches']['ietf-mud:mud']['controller'] # dest.union({"10.10.0.7/32"}) # dest.union({'controllers'}) #["10.10.0.7/32"]     #  ace['matches']['ietf-mud:mud']['controller']
                                               if 'urn:ietf:params:mud:gateway' in source or \
                                                  'urn:ietf:params:mud:dns' in source or \
                                                  'urn:ietf:params:mud:ntp' in source:
                                                   source = local_gateway
                                                   substituted=True
                                            if 'local-networks' in ace['matches']['ietf-mud:mud']: #internet
                                               source = ace['matches']['ietf-mud:mud']['local-networks'] #dest.union({"10.10.0.0/24"}) #dest.union(local_networks) #["0.0.0.0/0"]
                                               if len(source)==1 and source[0]==None:
                                                  source = local_networks
                                                  substituted=True
                                            if 'manufacturer' in ace['matches']['ietf-mud:mud']: #internet
                                               source = ace['matches']['ietf-mud:mud']['manufacturer'] #dest.union({"201.10.0.5/32"}) #dest.union({'manufacturer domains'}) #["0.0.0.0/0"]
                                            if 'model' in ace['matches']['ietf-mud:mud']: #internet
                                               source = ace['matches']['ietf-mud:mud']['model']#dest.union({"10.10.0.8/32"}) #dest.union({'same-model devices'}) #["0.0.0.0/0"]

                                            #if 'controller' in ace['matches']['ietf-mud:mud']: # local-networks
                                            #   source = source.union({"10.10.0.7/32"}) # dest.union({'controllers'}) #["10.10.0.7/32"]     #  ace['matches']['ietf-mud:mud']['controller']
                                            #if 'local-networks' in ace['matches']['ietf-mud:mud']: #internet
                                            #   source = source.union({"10.10.0.0/24"}) #dest.union(local_networks) #["0.0.0.0/0"]
                                            #if 'manufacturer' in ace['matches']['ietf-mud:mud']: #internet
                                            #   source = source.union({"201.10.0.5/32"}) #dest.union({'manufacturer domains'}) #["0.0.0.0/0"]
                                            #if 'model' in ace['matches']['ietf-mud:mud']: #internet
                                            #   source = source.union({"10.10.0.8/32"}) #dest.union({'same-model devices'}) #["0.0.0.0/0"]


                                        if 'ipv4' in ace['matches']:
                                            protocol = ace['matches']['ipv4']['protocol']
                                            sports_start=None
                                            sports_end=None
                                            dports_start=None
                                            dports_end=None
                                            action= str(ace['actions']['forwarding']).strip().lower()

                                            if action!='drop' and action!='accept':
                                                raise InvalidMUDFileException("%s : %s"%(resources['mud_file_action_invalid'],action))

                                            if 'ietf-acldns:src-dnsname' in ace['matches']['ipv4']: # local-networks
                                               source = [ace['matches']['ipv4']['ietf-acldns:src-dnsname']] # dest.union({"10.10.0.7/32"}) # dest.union({'controllers'}) #["10.10.0.7/32"]     #  ace['matches']['ietf-mud:mud']['controller']
                                            if 'source-ipv4-network' in ace['matches']['ipv4']: # local-networks
                                               source = [ace['matches']['ipv4']['source-ipv4-network']] # dest.union({"10.10.0.7/32"}) # dest.union({'controllers'}) #["10.10.0.7/32"]     #  ace['matches']['ietf-mud:mud']['controller']

                                            if not substituted and CanonicalPolicyHelper().is_private_ipaddress(list(source)[0]):
                                                   raise InvalidMUDFileException("%s : %s"%(resources['mud_file_has_local_ipaddress_details'], list(source)[0]))

                                            if 'udp' in ace['matches'] and \
                                               'source-port' in ace['matches']['udp'] and \
                                                ace['matches']['udp']['source-port'] is not None:
                                                sports_start= ace['matches']['udp']['source-port']['port']
                                                sports_end= ace['matches']['udp']['source-port']['port']
                                            elif 'tcp' in ace['matches'] and \
                                                'source-port' in ace['matches']['tcp'] and \
                                                ace['matches']['tcp']['source-port'] is not None:
                                                sports_start= ace['matches']['tcp']['source-port']['port']
                                                sports_end= ace['matches']['tcp']['source-port']['port']
                                            elif 'udp' in ace['matches'] and \
                                                'destination-port' in ace['matches']['udp'] and \
                                                ace['matches']['udp']['destination-port'] is not None:
                                                dports_start= ace['matches']['udp']['destination-port']['port']
                                                dports_end= ace['matches']['udp']['destination-port']['port']
                                            elif 'tcp' in ace['matches'] and \
                                                'destination-port' in ace['matches']['tcp'] and \
                                                ace['matches']['tcp']['destination-port'] is not None:
                                                dports_start= ace['matches']['tcp']['destination-port']['port']
                                                dports_end= ace['matches']['tcp']['destination-port']['port']


                                            if protocol==6 or protocol==17:
                                                sports = (1024,65535) #(0,65535)
                                                dports = (1024,65535) #(0,65535)
                                            else:
                                                sports=None
                                                dports=None

                                            if dports_end==0:
                                                continue

                                            if sports_start is not None and sports_end is not None:
                                                sports=(sports_start,sports_end)
                                            if dports_start is not None and dports_end is not None:
                                                dports=(dports_start,dports_end)

                                            if ignore_rules and protocol==6 and sports!=(1024,65535): #sports!=(0,65535):
                                                continue

                                            extracted_ace = ACE(source,dest,protocol,dports,sports,action)
                                            if 'to' not in acl_details:
                                                acl_details['to']=[]

                                            acl_details['to'].append(extracted_ace)

                                        if 'l2' in ace['matches']:
                                            #TODO: handle
                                            print('L2 tag not yet handled')


            #print(extracted['ietf-mud:mud']['from-device-policy']['access-lists']['access-list'][0]['acl-name'])
            #print(extracted['ietf-access-control-list:access-lists']['acl'][0]['access-list-entries']['ace'][0]['matches']['ipv6-acl']['ietf-acldns:src-dnsname'])

            return acl_details

    def get_device_acl_details2(extracted_data):

        acl_details= dict()
        #acl_details = MetagraphHelper().lookup_acl_details_by_direction(extracted_data,'from-device-policy',acl_details)
        #acl_details = MetagraphHelper().lookup_acl_details_by_direction(extracted_data,'to-device-policy',acl_details)
        #return acl_details

        local_networks = {'controllers', 'same-model devices'}

        # format - as used by mudmaker.com
        if extracted_data is not None:

            from_device_acls = extracted_data['ietf-mud:mud']['from-device-policy']['access-lists']['access-list']
            if len(from_device_acls)>0:
                for acl in extracted_data['ietf-mud:mud']['from-device-policy']['access-lists']['access-list']:
                    acl_name = acl['name']
                    # lookup ACL data
                    data = extracted_data['ietf-access-control-list:access-lists']['acl']
                    if len(data)>0:
                        for acl_data in data:
                            if acl_name == acl_data['name']:
                                aces= acl_data['aces']
                                if len(aces)>0:
                                    for ace in aces['ace']:
                                        source='device' # ace['matches']['l3']['ietf-mud:direction-initiated']
                                        dest=set()
                                        if 'controller' in ace['matches']['ietf-mud:mud']: # local-networks
                                           dest = dest.union({"10.10.0.7/32"}) # dest.union({'controllers'}) #["10.10.0.7/32"]     #  ace['matches']['ietf-mud:mud']['controller']
                                        if 'local-networks' in ace['matches']['ietf-mud:mud']: #internet
                                           dest = dest.union({"10.10.0.0/24"}) #dest.union(local_networks) #["0.0.0.0/0"]
                                        if 'manufacturer' in ace['matches']['ietf-mud:mud']: #internet
                                           dest = dest.union({"201.10.0.5/32"}) #dest.union({'manufacturer domains'}) #["0.0.0.0/0"]
                                        if 'model' in ace['matches']['ietf-mud:mud']: #internet
                                           dest = dest.union({"10.10.0.8/32"}) #dest.union({'same-model devices'}) #["0.0.0.0/0"]

                                        protocol = ace['matches']['l3']['ipv4']['protocol']
                                        sports_start=None
                                        sports_end=None
                                        dports_start=None
                                        dports_end=None
                                        action=ace['actions']['forwarding']
                                        if 'l4' in ace['matches'] and 'udp' in ace['matches']['l4'] and \
                                            'destination-port-range-or-operator' in ace['matches']['l4']['udp'] and \
                                            ace['matches']['l4']['udp']['destination-port-range-or-operator'] is not None:
                                            dports_start= ace['matches']['l4']['udp']['destination-port-range-or-operator']['port']
                                            dports_end= ace['matches']['l4']['udp']['destination-port-range-or-operator']['port']
                                        elif 'l4' in ace['matches'] and 'tcp' in ace['matches']['l4'] and \
                                            'destination-port-range-or-operator' in ace['matches']['l4']['tcp'] and \
                                            ace['matches']['l4']['tcp']['destination-port-range-or-operator'] is not None:
                                            dports_start= ace['matches']['l4']['tcp']['destination-port-range-or-operator']['port']
                                            dports_end= ace['matches']['l4']['tcp']['destination-port-range-or-operator']['port']
                                        elif 'l4' in ace['matches'] and 'udp' in ace['matches']['l4'] and \
                                            'source-port' in ace['matches']['l4']['udp'] and \
                                            ace['matches']['l4']['udp']['source-port'] is not None:
                                            sports_start= ace['matches']['l4']['udp']['source-port']['port']
                                            sports_end= ace['matches']['l4']['udp']['source-port']['port']
                                        elif 'l4' in ace['matches'] and 'tcp' in ace['matches']['l4'] and \
                                            'source-port' in ace['matches']['l4']['tcp'] and \
                                            ace['matches']['l4']['tcp']['source-port'] is not None:
                                            sports_start= ace['matches']['l4']['tcp']['source-port']['port']
                                            sports_end= ace['matches']['l4']['tcp']['source-port']['port']

                                        if protocol==6 or protocol==17:
                                            sports = (0,65535)
                                            dports = (0,65535)
                                        else:
                                            sports=None
                                            dports=None

                                        if sports_start is not None and sports_end is not None:
                                            sports=(sports_start,sports_end)
                                        if dports_start is not None and dports_end is not None:
                                            dports=(dports_start,dports_end)

                                        ace = ACE(source,dest,protocol,dports,sports,action)
                                        if 'from' not in acl_details:
                                            acl_details['from']=[]

                                        acl_details['from'].append(ace)


            to_device_acls = extracted_data['ietf-mud:mud']['to-device-policy']['access-lists']['access-list']
            if len(to_device_acls)>0:
                for acl in extracted_data['ietf-mud:mud']['to-device-policy']['access-lists']['access-list']:
                    acl_name = acl['name']
                    # lookup ACL data
                    data = extracted_data['ietf-access-control-list:access-lists']['acl']
                    if len(data)>0:
                        for acl_data in data:
                            if acl_name == acl_data['name']:
                                aces= acl_data['aces']
                                if len(aces)>0:
                                    for ace in aces['ace']:
                                        dest='device'#ace['matches']['tcp-acl']['ietf-mud:direction-initiated']
                                        source=set()
                                        #if 'controller' in ace['matches']['ietf-mud:mud']: # local-networks
                                        #   source = source.union({'controllers'}) #["10.10.0.7/32"]     #  ace['matches']['ietf-mud:mud']['controller']
                                        #if 'local-networks' in ace['matches']['ietf-mud:mud']: #internet
                                        #   source  = source.union(local_networks) #["0.0.0.0/0"]
                                        #if 'manufacturer' in ace['matches']['ietf-mud:mud']: #internet
                                        #   source  = source.union({'manufacturer domains'}) #["0.0.0.0/0"]
                                        #if 'model' in ace['matches']['ietf-mud:mud']: #internet
                                        #   source  = source.union({'same-model devices'}) #["0.0.0.0/0"]

                                        if 'controller' in ace['matches']['ietf-mud:mud']: # local-networks
                                           source = source.union({"10.10.0.7/32"}) # dest.union({'controllers'}) #["10.10.0.7/32"]     #  ace['matches']['ietf-mud:mud']['controller']
                                        if 'local-networks' in ace['matches']['ietf-mud:mud']: #internet
                                           source = source.union({"10.10.0.0/24"}) #dest.union(local_networks) #["0.0.0.0/0"]
                                        if 'manufacturer' in ace['matches']['ietf-mud:mud']: #internet
                                           source = source.union({"201.10.0.5/32"}) #dest.union({'manufacturer domains'}) #["0.0.0.0/0"]
                                        if 'model' in ace['matches']['ietf-mud:mud']: #internet
                                           source = source.union({"10.10.0.8/32"}) #dest.union({'same-model devices'}) #["0.0.0.0/0"]


                                        protocol = ace['matches']['l3']['ipv4']['protocol']
                                        sports_start=None
                                        sports_end=None
                                        dports_start=None
                                        dports_end=None
                                        action=ace['actions']['forwarding']
                                        if 'l4' in ace['matches'] and 'udp' in ace['matches']['l4'] and \
                                           'source-port-range-or-operator' in ace['matches']['l4']['udp'] and \
                                            ace['matches']['l4']['udp']['source-port-range-or-operator'] is not None:
                                            sports_start= ace['matches']['l4']['udp']['source-port-range-or-operator']['port']
                                            sports_end= ace['matches']['l4']['udp']['source-port-range-or-operator']['port']
                                        elif 'l4' in ace['matches'] and 'tcp' in ace['matches']['l4'] and \
                                            'source-port-range-or-operator' in ace['matches']['l4']['tcp'] and \
                                            ace['matches']['l4']['tcp']['source-port-range-or-operator'] is not None:
                                            sports_start= ace['matches']['l4']['tcp']['source-port-range-or-operator']['port']
                                            sports_end= ace['matches']['l4']['tcp']['source-port-range-or-operator']['port']
                                        elif 'l4' in ace['matches'] and 'udp' in ace['matches']['l4'] and \
                                            'destination-port-range-or-operator' in ace['matches']['l4']['udp'] and \
                                            ace['matches']['l4']['udp']['destination-port-range-or-operator'] is not None:
                                            dports_start= ace['matches']['l4']['udp']['destination-port-range-or-operator']['port']
                                            dports_end= ace['matches']['l4']['udp']['destination-port-range-or-operator']['port']
                                        elif 'l4' in ace['matches'] and 'tcp' in ace['matches']['l4'] and \
                                            'destination-port-range-or-operator' in ace['matches']['l4']['tcp'] and \
                                            ace['matches']['l4']['tcp']['destination-port-range-or-operator'] is not None:
                                            dports_start= ace['matches']['l4']['tcp']['destination-port-range-or-operator']['port']
                                            dports_end= ace['matches']['l4']['tcp']['destination-port-range-or-operator']['port']


                                        if protocol==6 or protocol==17:
                                            sports = (0,65535)
                                            dports = (0,65535)
                                        else:
                                            sports=None
                                            dports=None

                                        if sports_start is not None and sports_end is not None:
                                            sports=(sports_start,sports_end)
                                        if dports_start is not None and dports_end is not None:
                                            dports=(dports_start,dports_end)

                                        ace = ACE(source,dest,protocol,dports,sports,action)
                                        if 'to' not in acl_details:
                                            acl_details['to']=[]

                                        acl_details['to'].append(ace)


            #print(extracted['ietf-mud:mud']['from-device-policy']['access-lists']['access-list'][0]['acl-name'])
            #print(extracted['ietf-access-control-list:access-lists']['acl'][0]['access-list-entries']['ace'][0]['matches']['ipv6-acl']['ietf-acldns:src-dnsname'])

            return acl_details

    def get_device_acl_details1(extracted_data):

        acl_details= dict()
        #acl_details = MetagraphHelper().lookup_acl_details_by_direction(extracted_data,'from-device-policy',acl_details)
        #acl_details = MetagraphHelper().lookup_acl_details_by_direction(extracted_data,'to-device-policy',acl_details)
        #return acl_details

        # format as per IETF spec (expires april 2018)
        if extracted_data is not None:

            from_device_acls = extracted_data['ietf-mud:mud']['from-device-policy']['access-lists']['access-list']
            if len(from_device_acls)>0:
                for acl in extracted_data['ietf-mud:mud']['from-device-policy']['access-lists']['access-list']:
                    acl_name = acl['acl-name']
                    # lookup ACL data
                    data = extracted_data['ietf-access-control-list:access-lists']['acl']
                    if len(data)>0:
                        for acl_data in data:
                            if acl_name == acl_data['acl-name']:
                                aces= acl_data['access-list-entries']['ace']
                                if len(aces)>0:
                                    for ace in aces:
                                        source=ace['matches']['tcp-acl']['ietf-mud:direction-initiated']
                                        dest = ace['matches']['ipv6-acl']['ietf-acldns:dst-dnsname']
                                        protocol = ace['matches']['ipv6-acl']['protocol']
                                        sports_start=None
                                        sports_end=None
                                        dports_start=None
                                        dports_end=None
                                        action=ace['actions']['forwarding']
                                        if ace['matches']['ipv6-acl']['destination-port-range'] is not None:
                                            dports_start= ace['matches']['ipv6-acl']['destination-port-range']['lower-port']
                                            dports_end= ace['matches']['ipv6-acl']['destination-port-range']['upper-port']

                                        sports = (0,65535)
                                        dports = (0,65535)
                                        if sports_start is not None and sports_end is not None:
                                            sports=(sports_start,sports_end)
                                        if dports_start is not None and dports_end is not None:
                                            dports=(dports_start,dports_end)

                                        ace = ACE(source,dest,protocol,dports,sports,action)
                                        if 'from' not in acl_details:
                                            acl_details['from']=[]

                                        acl_details['from'].append(ace)


            to_device_acls = extracted_data['ietf-mud:mud']['to-device-policy']['access-lists']['access-list']
            if len(to_device_acls)>0:
                for acl in extracted_data['ietf-mud:mud']['to-device-policy']['access-lists']['access-list']:
                    acl_name = acl['acl-name']
                    # lookup ACL data
                    data = extracted_data['ietf-access-control-list:access-lists']['acl']
                    if len(data)>0:
                        for acl_data in data:
                            if acl_name == acl_data['acl-name']:
                                aces= acl_data['access-list-entries']['ace']
                                if len(aces)>0:
                                    for ace in aces:
                                        dest=ace['matches']['tcp-acl']['ietf-mud:direction-initiated']
                                        source = ace['matches']['ipv6-acl']['ietf-acldns:src-dnsname']
                                        protocol = ace['matches']['ipv6-acl']['protocol']
                                        sports_start=None
                                        sports_end=None
                                        dports_start=None
                                        dports_end=None
                                        action=ace['actions']['forwarding']
                                        if ace['matches']['ipv6-acl']['source-port-range'] is not None:
                                            sports_start= ace['matches']['ipv6-acl']['source-port-range']['lower-port']
                                            sports_end= ace['matches']['ipv6-acl']['source-port-range']['upper-port']

                                        sports = (0,65535)
                                        dports = (0,65535)
                                        if sports_start is not None and sports_end is not None:
                                            sports=(sports_start,sports_end)
                                        if dports_start is not None and dports_end is not None:
                                            dports=(dports_start,dports_end)

                                        ace = ACE(source,dest,protocol,dports,sports,action)
                                        if 'to' not in acl_details:
                                            acl_details['to']=[]

                                        acl_details['to'].append(ace)


            #print(extracted['ietf-mud:mud']['from-device-policy']['access-lists']['access-list'][0]['acl-name'])
            #print(extracted['ietf-access-control-list:access-lists']['acl'][0]['access-list-entries']['ace'][0]['matches']['ipv6-acl']['ietf-acldns:src-dnsname'])

            return acl_details

    @staticmethod
    def lookup_acl_details_by_direction(extracted_data, direction_tag, acl_details):

        if extracted_data is not None:
            from_device_acls = extracted_data['ietf-mud:mud'][direction_tag]['access-lists']['access-list']
            if len(from_device_acls)>0:
                for acl in extracted_data['ietf-mud:mud'][direction_tag]['access-lists']['access-list']:
                    acl_name = acl['acl-name']
                    # lookup ACL data
                    data = extracted_data['ietf-access-control-list:access-lists']['acl']
                    if len(data)>0:
                        for acl_data in data:
                            if acl_name == acl_data['acl-name']:
                                aces= acl_data['access-list-entries']['ace']
                                if len(aces)>0:
                                    for ace in aces:
                                        dest=ace['matches']['tcp-acl']['ietf-mud:direction-initiated']
                                        source = ace['matches']['ipv6-acl']['ietf-acldns:src-dnsname']
                                        protocol = ace['matches']['ipv6-acl']['protocol']
                                        sports_start=None
                                        sports_end=None
                                        dports_start=None
                                        dports_end=None
                                        action=ace['actions']['forwarding']
                                        if ace['matches']['ipv6-acl']['source-port-range'] is not None:
                                            sports_start= ace['matches']['ipv6-acl']['source-port-range']['lower-port']
                                            sports_end= ace['matches']['ipv6-acl']['source-port-range']['upper-port']

                                        sports = (0,65535)
                                        dports = (0,65535)
                                        if sports_start is not None and sports_end is not None:
                                            sports=(sports_start,sports_end)
                                        if dports_start is not None and dports_end is not None:
                                            dports=(dports_start,dports_end)

                                        ace = ACE(source,dest,protocol,dports,sports,action)
                                        if 'from' in direction_tag:
                                            if 'from' not in acl_details:
                                                acl_details['from']=[]
                                            acl_details['from'].append(ace)
                                        elif 'to' in direction_tag:
                                            if 'to' not in acl_details:
                                                acl_details['to']=[]
                                            acl_details['to'].append(ace)


            #print(extracted['ietf-mud:mud']['from-device-policy']['access-lists']['access-list'][0]['acl-name'])
            #print(extracted['ietf-access-control-list:access-lists']['acl'][0]['access-list-entries']['ace'][0]['matches']['ipv6-acl']['ietf-acldns:src-dnsname'])

    @staticmethod
    def get_port_descriptor(protocol, port_tuple, type):
        port_descriptor=None
        if port_tuple is not None:
            if protocol==6:
                if port_tuple[0]!=port_tuple[1]:
                    port_descriptor = 'TCP.%s=%s-%s'%(type,port_tuple[0],port_tuple[1])
                else:
                    port_descriptor = 'TCP.%s=%s'%(type,port_tuple[0])

            elif protocol==17:
                if port_tuple[0]!=port_tuple[1]:
                    port_descriptor = 'UDP.%s=%s-%s'%(type,port_tuple[0],port_tuple[1])
                else:
                    port_descriptor = 'UDP.%s=%s'%(type,port_tuple[0])

        return port_descriptor

    @staticmethod
    def get_ipaddresses_numeric(ipaddress_list):
        import ipaddr
        numeric_ipaddresses=[]
        for ipaddress in ipaddress_list:
            if ipaddress=='0.0.0.0/0':
                end = int(ipaddr.IPv4Network('255.255.255.255/32'))
                value='0-%s'%end
            else:
                ipv4address = ipaddr.IPv4Network(ipaddress)
                value= '%s-%s'%(int(ipv4address.network), int(ipv4address.broadcast))
            if value not in numeric_ipaddresses:
                numeric_ipaddresses.append(value)

        return numeric_ipaddresses


    def get_associated_edges(self, element, edge_list):
         return [edge for edge in edge_list if element in edge.invertex]

    def get_pathways_to(self, source, target, metagraph):
        # compute all metapaths
        metapaths = metagraph.get_all_metapaths_from(source,target,True)

        # extract dominant metapaths
        extracted=[]
        if metapaths is not None and len(metapaths)>0:
            for mp in metapaths:
                if metagraph.is_edge_dominant_metapath(mp) and \
                   self.is_metapath_absent(mp,extracted):
                   extracted.append(mp)

        return extracted

    def is_metapath_absent(self, mp, mp_list):
        for mp1 in mp_list:
            if self.is_edge_list_included(mp.edge_list, mp1.edge_list):
                return False

        return True

    def get_edge_attributes(self, key, attr_list):
        result=[]
        for attr in attr_list:
            if key in attr: result.append(attr)

        return set(result)

class CVE(object):
    def __init__(self, id, vendor_product_data, lastmodified, published, description, references):
        self.id = id
        self.vendor_product_data=vendor_product_data
        self.lastmodified=lastmodified
        self.published=published
        self.description = description
        self.references = references
        self.exp_score = None
        self.impact_score = None
        self.cvss_v3 = None
        self.attack_complexity = None
        self.attack_vector = None
        self.priv_required = None
        self.scope = None
        self.user_interaction = None
        self.avail_impact = None
        self.confidentiality_impact = None
        self.integrity_impact = None
        self.base_score = None
        self.base_severity = None
        self.cvss2=False
        self.cvss3=False

class ACL(object):
    def __init__(self, name=None):
        self.aces = []
        self.name=name

    def add_ace(self,ace):
        self.aces.append(ace)

class ACE(object):
    def __init__(self, source, dest, protocol, dports, sports, action, direction=None, ethertype=None):
        self.source = source
        self.dest = dest
        self.protocol = protocol
        self.dports=dports
        self.sports=sports
        self.action=action
        self.direction=direction
        self.protocol_desc=None
        self.ethertype=ethertype
        if self.protocol=='6':
            self.protocol_desc = "tcp"
        elif self.protocol=='17':
            self.protocol_desc = "udp"

class MudPolicy(object):
    def __init__(self, create_datetime, device_name, device_desc, from_acls, to_acls):
        self.datetime = create_datetime
        self.device_name = device_name
        self.device_desc = device_desc
        self.from_acls = from_acls
        self.to_acls = to_acls

@singleton
class CanonicalPolicyHelper(object):
    def __init__(self):
        self.canonical_policies={}
        return

    def GetRuleAction(self, rule_attributes_list):
        action=None
        for attribute in rule_attributes_list:
            if 'action=' in attribute:
                action = attribute.replace('action=','').lower()
                break

        return action

    def GetProtocol(self, rule_attributes_list):
        from enums import Ipv4ProtocolNumbers
        protocol=None
        for attribute in rule_attributes_list:
            if 'protocol=' in attribute:
                protocol = attribute.replace('protocol=','').lower()
                break
        if protocol is not None:
            if protocol=='tcp' or protocol=='6':
                return Ipv4ProtocolNumbers.tcp
            if protocol=='udp'  or protocol=='17':
                return Ipv4ProtocolNumbers.udp
            if protocol=='icmp' or protocol=='1':
                return Ipv4ProtocolNumbers.icmp
            if protocol=='ip' or protocol=='any':
                return Ipv4ProtocolNumbers.all

        return None

    def GetSourcePorts(self, rule_attributes_list):
        sports= None
        for attribute in rule_attributes_list:
            if 'TCP.sport=' in attribute:
                sports = attribute.replace('TCP.sport=','').lower()
                break
            elif 'tcp.source_port=' in attribute:
                sports = attribute.replace('tcp.source_port=','').lower()
                break
            elif 'UDP.sport=' in attribute:
                sports = attribute.replace('UDP.sport=','').lower()
                break
            elif 'udp.source_port=' in attribute:
                sports = attribute.replace('udp.source_port=','').lower()
                break

        if sports is not None:
            if '-' in sports:
                #range
                values = sports.split('-')
                start = int(values[0])
                end = int(values[1])
                return (start,end)
            else:
                return (int(sports),int(sports))

        return (0,65535)


    def GetDestPorts(self, rule_attributes_list):
        dports=None
        for attribute in rule_attributes_list:
            #print('attribute: %s'%attribute)
            if 'TCP.dport=' in attribute:
                dports = attribute.replace('TCP.dport=','').lower()
                break
            elif 'tcp.dest_port=' in attribute:
                dports = attribute.replace('tcp.dest_port=','').lower()
                break
            elif 'UDP.dport=' in attribute:
                dports = attribute.replace('UDP.dport=','').lower()
                break
            elif 'udp.dest_port=' in attribute:
                dports = attribute.replace('udp.dest_port=','').lower()
                break

        if dports is not None:
            if '-' in dports:
                #range
                values = dports.split('-')
                start = int(values[0])
                end = int(values[1])
                return (start,end)
            else:
                return (int(dports),int(dports))

        #print('return default')
        return (0,65535)

    def GetTcpState(self, protocol, rule_attributes_list):
        ##from enums import Ipv4ProtocolNumbers

        if protocol!=Ipv4ProtocolNumbers.tcp:
            return None

        tcp_state=None
        for attribute in rule_attributes_list:
            if 'TCP.state=' in attribute:
                tcp_state = attribute.replace('TCP.state=','')
                break

        if tcp_state is not None:
            if '-' in tcp_state:
                #range
                values = tcp_state.split('-')
                start = int(values[0])
                end = int(values[1])
                return (start,end)
            else:
                return (int(tcp_state),int(tcp_state))

        return (0,1)

    def GenerateCanonicalForm(self, security_policy):
        ## from enums import Ipv4ProtocolNumbers
        # converts HL policy to its canonical representation
        if security_policy:
            tcp_plots={}
            udp_plots={}
            icmp_plots={}
            ip_plots={}
            self.line_segments={}
            self.indiv_points={}
            self.polygon_vertices_original={}
            self.canonical_policies={}

            try:
                for item in security_policy.edges:
                    # deal with tcp and udp rules first
                    elts = security_policy.get_edge_data(item[0],item[1])
                    for rule in elts.values():
                        rule_attributes = rule['attributes']
                        if self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.tcp:
                            tcp_plots=self.AddPlot(item, rule_attributes, tcp_plots)
                        elif self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.udp:
                            udp_plots=self.AddPlot(item, rule_attributes, udp_plots)
                        # ..and icmp, and other IP based rules
                        elif self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.icmp:
                            icmp_plots=self.AddPlot(item, rule_attributes, icmp_plots)
                        elif self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.all:
                            ip_plots=self.AddPlot(item, rule_attributes, ip_plots)

                #for key, services in tcp_plots.iteritems():
                #    for service in services:
                #        print('key= %s, service= %s %s %s'%(key,service.protocol,service.sports,service.dports))

                #print('Create2DGraph..')

                # prepare 2D graphs
                if len(tcp_plots.values())>0:
                    self.Create2DGraph(tcp_plots,Ipv4ProtocolNumbers.tcp,1)
                if len(udp_plots.values())>0:
                    self.Create2DGraph(udp_plots,Ipv4ProtocolNumbers.udp,1)

                #print('ExtractCanonicalForm..')

                # parse each plot to generate its canonical representation - intermediate form
                self.ExtractCanonicalForm()

                #print('done')

                # generate canonical form
                # sort order : for zone_pair Zx,Zy:
                #    Zx->Zy rules
                #       - order by IP protocol number (asc)
                #       - order by dest-port number (asc) - for TCP/UDP
                #       - 0rder by source-port number (asc) - for TCP/UDP - will not have 2 rules with same source and dest-port numbers (we prevent overlaps)
                #    followed by Zy->Zx rule
                #       - same as before

                # create lookup table by grouping rules under Zx->Zy
                lookup_table=dict()
                for protocol, tuples in self.canonical_policies.iteritems():
                    for key, rules in tuples.iteritems():
                        source_zone=key[0]
                        dest_zone=key[1]

                        lookup_key1='%s->%s'%(source_zone,dest_zone)
                        if lookup_key1 not in lookup_table:
                            lookup_table[lookup_key1]=[]

                        lookup_table[lookup_key1] += rules

                # sort the lookup table by key (alphanum asc)
                import collections
                ordered = collections.OrderedDict(sorted(lookup_table.items(), key=lambda t: t[0]) )
                import copy
                ordered_copy=copy.deepcopy(ordered)

                # next sort the rule-set under each key
                for key, ruleset in ordered_copy.iteritems():
                    # first order by ip protocol number
                    # then by dest port
                    # then by source port
                    # the way we have stored the policy rules as string, we do all of this simply by
                    # sorting the strings in alphanum order (asc)
                    sorted_ruleset = self.SortAlphanumAsc(ruleset)
                    # finally remove source and dest in the rule (already part of the key) and keep service details only
                    service_set=[]
                    for rule in sorted_ruleset:
                        cleaned= ((rule.split('{')[1]).split('}')[0]).lstrip()
                        service_set.append(cleaned)

                    ordered[key]=service_set

                # update final result
                self.canonical_policies['final'] = ordered

            except BaseException,e:
                print("%s : %s" %(resources['canonical_policy_generation_failed'],str(e)))

        return self.canonical_policies

    def SortAlphanumAsc(self, string_list ):
        """ Sort the given iterable in the way that humans expect."""
        import re
        l=set(string_list)
        convert = lambda text: int(text) if text.isdigit() else text
        alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ]
        return sorted(l, key = alphanum_key)

    def GetTuples(self,mappings):
        tuple_values=[]
        for value in mappings:
            if isinstance(value, tuple):
                if isinstance(value[0],tuple) and isinstance(value[1],tuple):
                    tuple_values += self.GetTuples(list(value))
                else:
                    tuple_values.append(value)

        return tuple_values

    def GetGroupElements(self, mapping, id):
        elts = []
        if isinstance(mapping,tuple):
            if id==1:
                if isinstance(mapping[0],tuple):
                   value = self.GetTupleElements(mapping[0])
                   if len(value)>1:
                      elts.append(tuple(value))
                   else:
                      elts.append(value[0])
            else:
                if isinstance(mapping[1],tuple):
                   value = self.GetTupleElements(mapping[1])
                   if len(value)>1:
                      elts.append(tuple(value))
                   else:
                      elts.append(value[0])

                elif isinstance(mapping[1],list):
                    for item in mapping[1]:
                        value = self.GetTupleElements(item)
                        if len(value)>1:
                          elts.append(tuple(value))
                        else:
                          elts.append(value[0])

        return elts

    def GetTupleElements(self, tuple_value):
        elts = []
        for value in tuple_value:
            if isinstance(value, tuple):
                elts +=self.GetTupleElements(value)
            else:
                elts.append(tuple_value)
                break

        return elts

    def GetMapping(self,tuple_value):
        mapping=[]
        for elt in tuple_value:
            if isinstance(elt,tuple):
                mapping += self.GetMapping(elt)
            else:
                mapping.append(elt)

        return mapping

    def NodeAndEdgeCountEqual(self, graph1, graph2):
        node_count1 = len(graph1.nodes())
        edge_count1 = len(graph1.edges())
        node_count2 = len(graph2.nodes())
        edge_count2 = len(graph2.edges())

        if (node_count1==node_count2 and edge_count1==edge_count2): return True
        return  False

    def CheckPolicyEquivalence(self, zf1_graph, zf_line1, flow_policies1, zf2_graph, zf_line2, flow_policies2,policy1_filename,policy2_filename,is_single_network):
        print('Check policy equivalence..')
        from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point

        if zf_line1 and flow_policies1 and zf_line2 and flow_policies2:

            if is_single_network:
                # single network scenarios very simple do later
                return self.CheckPolicyEquivalenceDirectly(flow_policies1,flow_policies2)
            else:
                # check for equivalence of flow policies
                # either via the exhaustive approach
                # or the semantic grouping method
                return self.CheckPolicyEquivalenceViaPartitions(zf1_graph,zf_line1, flow_policies1, zf2_graph,zf_line2, flow_policies2,policy1_filename,policy2_filename)

        return False

    def CheckPolicyStrictIncorporation(self, zf1_graph, zf_line1, flow_policies1, zf2_graph, zf_line2, flow_policies2,policy1_filename,policy2_filename):
        incorporates=False
        from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point

        print('Check policy strict incoporation (%s,%s)..'%(policy1_filename,policy2_filename))
        node_count1 = len(zf_line1.nodes())
        node_count2 = len(zf_line2.nodes())
        edge_count1 = len(zf_line1.edges())
        edge_count2 = len(zf_line2.edges())

        # check initial conditions
        # can P2 incorporate P1? i.e., P1 = P2(G1)
        # we ignore case where P1=P2 (ie P1=P2(G1)=P1(G2)=P2)
        # otherwise (node_count2 >= node_count1 and edge_count2 >= edge_count1) is sufficient
        if( (node_count2 >= node_count1 and edge_count2 >= edge_count1) or
            (node_count2 == node_count1 and edge_count2 > edge_count1)):

            group_map1=[]
            group_map2=[]
            semantic_partition1 = self.GetSemanticPartition(flow_policies1, group_map1)
            semantic_partition2 = self.GetSemanticPartition(flow_policies2, group_map2)
            inter_group_map=[]
            semantic_partition3=[]

            print('Semantic Partition (SP) details of policy- %s'%policy1_filename)
            print('%s Equivalence class(es): '%len(semantic_partition1))
            #for group in group_map1:
            #    print('  %s'%group)
            #print('-----------------------------------')
            print('Semantic Partition (SP) details of policy- %s'%policy2_filename)
            print('%s Equivalence class(es): '%len(semantic_partition2))
            #for group in group_map2:
            #    print('  %s'%group)

            # for P1 = P2(G1) to occur, every SP1 class must have an equivalent class in SP2 (with equal or higher class size)
            # try substitute policies based on equal semantics
            if self.CanSubstitutePolicies(semantic_partition1, semantic_partition2, flow_policies1, flow_policies2, group_map1, group_map2, inter_group_map, semantic_partition3, True):

                print('Generate mappings between equivalent classes..')

                # process every possible group mapping for an adjacency matrix match
                # group1, group2 consist of policy sets (each set has elts with similar semantics)
                group_permutations=dict()
                index=0
                # group_permutations hold Mapping sets (M1,M2,...)?
                for map in inter_group_map:
                    len_group1=len(map[0])
                    len_group2=len(map[1])
                    if index not in group_permutations: group_permutations[index]=[]
                    if len_group1==len_group2:
                        # permutations of group1 that can directly map to group2
                        group1_mappings=itertools.permutations(map[0])
                        #print('group1:%s, mappings(1):%s'%(map[0],len(list(group1_mappings))))
                        for mapping in group1_mappings:
                            group_permutations[index].append((tuple(mapping),tuple(map[1])))
                    elif len_group1<len_group2:
                        # permutations of group1 maps to selected combinations (of some length) in group2
                        target=itertools.combinations(map[1],len_group1)
                        target_mappings=[item for item in target]
                        group1_mappings=itertools.permutations(map[0])
                        #print('group1:%s, mappings(2):%s'%(map[0],len(list(group1_mappings))))
                        for mapping in group1_mappings:
                            group_permutations[index].append((tuple(mapping),target_mappings))
                    elif len_group1>len_group2:
                        # permutations of group1 maps to selected combinations (of some length) in group2
                        group1_mappings=itertools.permutations(map[0],len_group2)
                        #print('group1:%s, mappings(3):%s'%(map[0],len(list(group1_mappings))))
                        for mapping in group1_mappings:
                            group_permutations[index].append((tuple(mapping), tuple(map[1])))
                    index+=1

                #for group,perm in group_permutations.iteritems():
                #    print('group:%s permutations:%s'%(group,len(perm)))

                print('generate final mappings set(FM)..')
                expanded_group_permutations=dict()
                for group, mappings in group_permutations.iteritems():
                    tuple_list=[]
                    for mapping in mappings:
                        if isinstance(mapping[1],tuple):
                            tuple_list.append(tuple(list(mapping[0])+list(mapping[1])))
                        elif isinstance(mapping[1],list):
                            for item in mapping[1]:
                                tuple_list.append(tuple(list(mapping[0])+ list(item)))
                    expanded_group_permutations[group]=tuple_list

                #for group,perm in expanded_group_permutations.iteritems():
                #    print('expanded_group:%s permutations:%s'%(group,len(perm)))

                index=0
                intermediate=None
                # calculate final mapping set (FM)?
                while index < len(expanded_group_permutations):
                    set1=set(expanded_group_permutations[index])
                    temp=set1
                    if index+1< len(expanded_group_permutations):
                        set2=set(expanded_group_permutations[index+1])
                        temp=itertools.product(set1,set2)
                    if intermediate==None:
                        intermediate=temp
                    else:
                        intermediate=itertools.product(intermediate,temp)
                    index+=2

                pre_result=list(intermediate)
                #print('full mappings count:%s'%(len(pre_result)))

                # check for isomorphisms
                print('check for isomorphisms..')
                for tuple1 in pre_result:
                    group1=[]
                    group2=[]
                    possible_mapping= self.GetTuples(tuple1)
                    for item in possible_mapping:
                        elements = (list(item))
                        # get left items
                        group1 += elements[0:(len(elements)/2)]
                        #..and right elements
                        group2 += elements[(len(elements)/2):len(elements)]
                    if len(group1)!= len(set(group1)):
                        # duplicates in left group- invalid combination
                        continue
                    if len(group2)!= len(set(group2)):
                        # duplicates in right group- invalid combination
                        continue
                    # compare adjacency matrices
                    node_labels1=[]
                    for policy in group1:
                        for node, attributes in zf_line1.node.iteritems():
                            if attributes['label']==policy: node_labels1.append(node)

                    node_labels2=[]
                    for policy in group2:
                        for node, attributes in zf_line2.node.iteritems():
                            if attributes['label']==policy: node_labels2.append(node)

                    A1 = nx.adjacency_matrix(zf_line1,node_labels1)
                    A2 = nx.adjacency_matrix(zf_line2,node_labels2)

                    if (A1==A2).all():
                        # check zones corresponding to the policy-node matches have identical semantic type
                        index=0
                        iso=True
                        while index<len(group1):
                            flow_policy1=group1[index]
                            flow_policy2=group2[index]
                            zones1=flow_policy1.split('->')
                            zones2=flow_policy2.split('->')
                            # check semantic types match
                            if ( zf1_graph.node[zones1[0]]['device_subtype'] != zf2_graph.node[zones2[0]]['device_subtype'] or
                                 zf1_graph.node[zones1[1]]['device_subtype'] != zf2_graph.node[zones2[1]]['device_subtype'] ):
                                    iso=False
                                    break

                            index+=1

                        if iso:
                            print('Isomorphism found.')
                            return True

                print('Isomorphism NOT found.')
                return False

    def CheckPolicyPartialIncorporation(self, zf1_graph, zf_line1, flow_policies1, zf2_graph, zf_line2, flow_policies2,policy1_filename,policy2_filename):
        incorporates=False
        from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point

        print('Check policy partial incoporation (%s,%s)..'%(policy1_filename,policy2_filename))

        node_count1 = len(zf_line1.nodes())
        node_count2 = len(zf_line2.nodes())
        edge_count1 = len(zf_line1.edges())
        edge_count2 = len(zf_line2.edges())

        # check initial conditions
        # can P2 incorporate P1? i.e., P1< P2(G1)
        # we ignore case where P1=P2 (ie P1< P2(G1) and P2< P1(G2))
        # otherwise (node_count2 >= node_count1 and edge_count2 >= edge_count1) is sufficient
        if( (node_count2 >= node_count1 and edge_count2 >= edge_count1) or
            (node_count2 == node_count1 and edge_count2 > edge_count1)):

            group_map1=[]
            group_map2=[]
            semantic_partition1 = self.GetSemanticPartition(flow_policies1, group_map1)
            semantic_partition2 = self.GetSemanticPartition(flow_policies2, group_map2)
            inter_group_map=dict()
            semantic_partition3=[]

            print('Semantic Partition (SP) details of policy- %s'%policy1_filename)
            print('%s Equivalence class(es): '%len(semantic_partition1))
            #for group in group_map1:
            #    print('  %s'%group)
            #print('-----------------------------------')
            print('Semantic Partition (SP) details of policy- %s'%policy2_filename)
            print('%s Equivalence class(es): '%len(semantic_partition2))
            #for group in group_map2:
            #    print('  %s'%group)

            # for P1 < P2(G1) to occur, every SP1 class must have and inclusive class in SP2 (with equal or higher total-class size)
            if self.CanIncludePolicies(semantic_partition1,semantic_partition2,flow_policies1,flow_policies2,group_map1,group_map2,inter_group_map):
                print('Generate mappings between inclusive classes..')
                # process every possible group mapping for an adjacency matrix match
                # group1, group2 consist of policy sets (each set has elts with similar semantics)
                group_permutations=dict()
                index=0
                # group_permutations hold Mapping sets (M1,M2,...)?
                for group1_tuple, group2 in inter_group_map.iteritems():
                    group1=list(group1_tuple)
                    len_group1=len(group1)
                    len_group2=len(group2)
                    if index not in group_permutations: group_permutations[index]=[]
                    if len_group1==len_group2:
                        # permutations of group1 that can directly map to group2
                        group1_mappings=itertools.permutations(group1)
                        for mapping in group1_mappings:
                            group_permutations[index].append((tuple(mapping),tuple(group2)))

                    elif len_group1<len_group2:
                        # permutations of group1 maps to selected combinations (of some length) in group2
                        target=itertools.combinations(group2,len_group1)
                        target_mappings=[item for item in target]
                        group1_mappings=itertools.permutations(group1)
                        for mapping in group1_mappings:
                            group_permutations[index].append((tuple(mapping),target_mappings))

                    elif len_group1>len_group2:
                        # not enough group2 classes..so cannot be inclusive
                        return False

                    index+=1

                #for group,perm in group_permutations.iteritems():
                    #print('group:%s permutations:%s'%(group,len(perm)))

                print('Generate Feasible Mappings Set(FMS)..')
                expanded_group_permutations=dict()
                for group, mappings in group_permutations.iteritems():
                    tuple_list=[]
                    for mapping in mappings:
                        if isinstance(mapping[1],tuple):
                            tuple_list.append(tuple(list(mapping[0])+list(mapping[1])))
                        elif isinstance(mapping[1],list):
                            for item in mapping[1]:
                                tuple_list.append(tuple(list(mapping[0])+ list(item)))
                    expanded_group_permutations[group]=tuple_list


                index=0
                intermediate=None
                # calculate final mapping set (FM)?
                while index < len(expanded_group_permutations):
                    set1=set(expanded_group_permutations[index])
                    temp=set1
                    if index+1< len(expanded_group_permutations):
                        set2=set(expanded_group_permutations[index+1])
                        temp=itertools.product(set1,set2)
                    if intermediate==None:
                        intermediate=temp
                    else:
                        intermediate=itertools.product(intermediate,temp)
                    index+=2

                pre_result=list(intermediate)

                # check for isomorphisms
                print('Check for isomorphisms..')
                for tuple1 in pre_result:
                    group1=[]
                    group2=[]
                    possible_mapping= self.GetTuples(tuple1)
                    for item in possible_mapping:
                        elements = (list(item))
                        #print('elements::%s'%elements)
                        # get left items
                        group1 += elements[0:(len(elements)/2)]
                        #..and right elements
                        group2 += elements[(len(elements)/2):len(elements)]
                        #print('group1::%s'%group1)
                        #print('group2::%s'%group2)
                    if len(group1)!= len(set(group1)):
                        # duplicates in left group- invalid combination
                        #print('group1 duplicates')
                        continue
                    if len(group2)!= len(set(group2)):
                        # duplicates in right group- invalid combination
                        #print('group2 duplicates')
                        continue
                    # compare adjacency matrices
                    node_labels1=[]
                    for policy in group1:
                        for node, attributes in zf_line1.node.iteritems():
                            if attributes['label']==policy: node_labels1.append(node)

                    node_labels2=[]
                    for policy in group2:
                        for node, attributes in zf_line2.node.iteritems():
                            if attributes['label']==policy: node_labels2.append(node)

                    #print('node_labels1:%s'%node_labels1)
                    #print('node_labels2:%s'%node_labels2)

                    A1 = nx.adjacency_matrix(zf_line1,node_labels1)
                    A2 = nx.adjacency_matrix(zf_line2,node_labels2)

                    if (A1==A2).all():
                        # check zones corresponding to the policy-node matches have identical semantic type
                        index=0
                        iso=True
                        while index<len(group1):
                            flow_policy1=group1[index]
                            flow_policy2=group2[index]
                            zones1=flow_policy1.split('->')
                            zones2=flow_policy2.split('->')
                            # check semantic types match
                            if ( zf1_graph.node[zones1[0]]['device_subtype'] != zf2_graph.node[zones2[0]]['device_subtype'] or
                                 zf1_graph.node[zones1[1]]['device_subtype'] != zf2_graph.node[zones2[1]]['device_subtype'] ):
                                    iso=False
                                    break

                            index+=1

                        if iso:
                            print('Isomorphism found.')
                            return True

                print('Isomorphism NOT found.')
                return False

    def CheckPolicyInclusion(self, flow_policies1, flow_policies2, zf_line1, zf_line2, zf1_graph, zf2_graph, policy1_name, policy2_name, is_single_network):
        #print('Check policy inclusion..')
        inclusive=False

        if is_single_network:
            if self.CheckPolicyInclusiveDirectly(flow_policies1, flow_policies2):
                inclusive=True
        else:
            if self.CheckPolicyInclusiveViaPartitions(flow_policies1, flow_policies2, zf_line1, zf_line2, zf1_graph, zf2_graph, policy1_name, policy2_name):
                inclusive=True

        return inclusive

    def CheckPolicyInclusiveDirectly(self, flow_policies1, flow_policies2):
        ''' checks whether flow_policies1 is a subset of flow_policies2 (same network) '''
        for key, policy1 in flow_policies1.iteritems():
            if key not in flow_policies2: return False
            policy2= flow_policies2[key]
            if not self.IsInclusiveFlowPolicy(policy1, policy2): return False

        return True

    def IsInclusiveFlowPolicy(self, policy1, policy2):
        ''' checks if policy1 is a subset of policy2'''
        if policy1 is None:
            return True
        if policy1 is not None and policy2 is not None:
            # check length first
            if len(policy1) <= len(policy2):
                policy1_set=set(policy1)
                policy2_set=set(policy2)

                union = (policy1_set | policy2_set)
                if union==policy2_set:
                    return True

        return False

    def GetSemanticDifference(self, security_policy1, security_policy2):
        ''' gets semantic discrepencies between policy1 and policy2 (same network)'''
        from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point
        ## from enums import Ipv4ProtocolNumbers

        result=dict()
        if security_policy1 and security_policy2:
            tcp_plots1={}
            udp_plots1={}
            icmp_plots1={}
            ip_plots1={}

            tcp_plots2={}
            udp_plots2={}
            icmp_plots2={}
            ip_plots2={}

            self.line_segments={}
            self.indiv_points={}
            self.polygon_vertices_original={}
            self.canonical_policies={}

            try:

                #print('here40')
                for item in security_policy1.edges:
                    # deal with tcp and udp rules first
                    elts = security_policy1.get_edge_data(item[0],item[1])
                    for rule in elts.values():
                        rule_attributes = rule['attributes']
                        if self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.tcp:
                            tcp_plots1=self.AddPlot(item, rule_attributes, tcp_plots1,True)
                        elif self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.udp:
                            udp_plots1=self.AddPlot(item, rule_attributes, udp_plots1,True)
                        # ..and icmp, and other IP based rules
                        elif self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.icmp:
                            icmp_plots1=self.AddPlot(item, rule_attributes, icmp_plots1,True)
                        elif self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.all:
                            ip_plots1=self.AddPlot(item, rule_attributes, ip_plots1,True)

                # prepare 2D graphs
                tcp_fig1=None
                udp_fig1=None
                icmp_fig1=None
                #print('here41')
                if tcp_plots1!=None and len(tcp_plots1.values())>0:
                    tcp_fig1= self.Create2DGraph(tcp_plots1,Ipv4ProtocolNumbers.tcp,1)
                if udp_plots1!=None and len(udp_plots1.values())>0:
                    udp_fig1=self.Create2DGraph(udp_plots1,Ipv4ProtocolNumbers.udp,1)
                if icmp_plots1!=None and len(icmp_plots1.values())>0:
                    icmp_fig1=self.Create1DGraph(icmp_plots1,Ipv4ProtocolNumbers.icmp)
                if ip_plots1!=None and len(ip_plots1.values())>0:
                    ip_fig1=self.Create1DGraph(ip_plots1,None)

                self.line_segments1=dict()
                self.indiv_points1=dict()
                self.polygon_vertices_original1=dict()

                for key,value in self.line_segments.iteritems():
                    self.line_segments1[key]=value
                for key,value in self.indiv_points.iteritems():
                    self.indiv_points1[key]=value
                for key,value in self.polygon_vertices_original.iteritems():
                    self.polygon_vertices_original1[key]=value

                self.line_segments={}
                self.indiv_points={}
                self.polygon_vertices_original={}
                self.canonical_policies={}

                #print('here42')
                for item in security_policy2.edges:
                    # deal with tcp and udp rules first
                    elts = security_policy2.get_edge_data(item[0],item[1])
                    for rule in elts.values():
                        rule_attributes = rule['attributes']
                        if self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.tcp:
                            tcp_plots2=self.AddPlot(item, rule_attributes, tcp_plots2,True)
                        elif self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.udp:
                            udp_plots2=self.AddPlot(item, rule_attributes, udp_plots2,True)
                        # ..and icmp, and other IP based rules
                        elif self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.icmp:
                            icmp_plots2=self.AddPlot(item, rule_attributes, icmp_plots2,True)
                        elif self.GetProtocol(rule_attributes)==Ipv4ProtocolNumbers.all:
                            ip_plots2=self.AddPlot(item, rule_attributes, ip_plots2,True)

                #print('..and 1D/2D plots')
                # prepare 2D graphs
                tcp_fig2=None
                udp_fig2=None
                if tcp_plots2!=None and len(tcp_plots2.values())>0:
                    #print('here42.1')
                    tcp_fig2= self.Create2DGraph(tcp_plots2,Ipv4ProtocolNumbers.tcp,2)
                if udp_plots2!=None and len(udp_plots2.values())>0:
                    #print('here42.2')
                    udp_fig2=self.Create2DGraph(udp_plots2,Ipv4ProtocolNumbers.udp,2)
                if icmp_plots2!=None and len(icmp_plots2.values())>0:
                    #print('here42.3')
                    icmp_fig2=self.Create1DGraph(icmp_plots2,Ipv4ProtocolNumbers.icmp)
                if ip_plots2!=None and len(ip_plots2.values())>0:
                    #print('here42.4')
                    ip_fig2=self.Create1DGraph(ip_plots2,None)

                self.line_segments2=dict()
                self.indiv_points2=dict()
                self.polygon_vertices_original2=dict()

                for key,value in self.line_segments.iteritems():
                    self.line_segments2[key]=value
                for key,value in self.indiv_points.iteritems():
                    self.indiv_points2[key]=value
                for key,value in self.polygon_vertices_original.iteritems():
                    self.polygon_vertices_original2[key]=value

                # get diff
                # line segments
                line_seg1_only=dict()
                line_seg2_only=dict()
                #print('here45')

                for protocol, line_plots in self.line_segments1.iteritems():
                    for key1, lines in line_plots.iteritems():
                        for key2, points1 in lines.iteritems():
                            ##print('line_segments1: prot: %s, key1: %s, line1: %s'%(protocol,key1,str(points1[0])))
                            if protocol in self.line_segments2 and key1 in self.line_segments2[protocol] and self.line_segments2[protocol][key1]!=None:
                                intersecting=False
                                for points2 in self.line_segments2[protocol][key1].values():
                                    ##print('line_segments2: prot: %s, key1: %s, line2: %s'%(protocol,key1,str(points2[0])))
                                    seg1=set(points1)
                                    seg2=set(points2)
                                    intersection=seg1.intersection(seg2)
                                    #print('intersection:%s'%intersection)
                                    if len(intersection) >0:
                                        #print('line intersect: prot: %s, key1: %s, seg1: %s, seg2: %s'%(protocol,key1, str(seg1[0]), str(seg2[0]))) #str(intersection)
                                        intersecting=True
                                        r=list(seg1)
                                        r=sorted(r, key=lambda tup: (tup[0],tup[1]) )
                                        q=list(seg2)
                                        q=sorted(q, key=lambda tup: (tup[0],tup[1]) )
                                        t=list(intersection)
                                        t=sorted(t, key=lambda tup: (tup[0],tup[1]) )

                                        if protocol not in line_seg1_only:
                                            line_seg1_only[protocol]=dict()
                                        if protocol not in line_seg2_only:
                                            line_seg2_only[protocol]=dict()

                                        seg1_only = list(seg1-intersection)
                                        seg2_only = list(seg2-intersection)

                                        if seg1_only and len(seg1_only)>0:
                                            # partial overlap
                                            try:
                                                #print('line intersect: prot: %s, key1: %s'%(protocol,key1)) #str(intersection)
                                                if key1 not in line_seg1_only[protocol]:
                                                    line_seg1_only[protocol][key1]=dict()
                                                result1= self.RemoveLineOverlap(r,t)#(list(seg1), list(intersection))
                                                line_seg1_only[protocol][key1][key2]=result1
                                                #print('line segment1 only(A): (%s,%s)'%(result1[0][0],result1[0][1]))
                                                #print('line intersect: prot: %s, key1: %s, result: (%s,%s)'%(protocol,key1,result1[0][0],result1[0][1])) #str(intersection)

                                            except BaseException,e:
                                                print(e.message)

                                        if seg2_only and len(seg2_only)>0:
                                            # partial overlap
                                            try:
                                                if key1 not in line_seg2_only[protocol]:
                                                    line_seg2_only[protocol][key1]=dict()
                                                result2= self.RemoveLineOverlap(q,t)#(list(seg2), list(intersection))
                                                line_seg2_only[protocol][key1][key2]=result2
                                                #print('line segment2 only(A): (%s,%s)'%(result2[0][0],result2[0][1]))
                                            except BaseException,e:
                                                print(e.message)

                                if not intersecting:
                                    if protocol not in line_seg1_only:
                                        line_seg1_only[protocol]=dict()
                                    if protocol not in line_seg2_only:
                                        line_seg2_only[protocol]=dict()

                                    if key1 not in line_seg1_only[protocol]:
                                                line_seg1_only[protocol][key1]=dict()
                                    if key1 not in line_seg2_only[protocol]:
                                                line_seg2_only[protocol][key1]=dict()

                                    line_seg1_only[protocol][key1][key2]=points1

                            else:
                                # not in segment2
                                if protocol not in line_seg1_only:
                                   line_seg1_only[protocol]=dict()
                                if key1 not in line_seg1_only[protocol]:
                                   line_seg1_only[protocol][key1]=dict()
                                if points1 and len(points1)>0:
                                    line_seg1_only[protocol][key1][key2]=points1
                                #print('line segment1 only(A3): (%s,%s)'%(points1[0][0],points1[0][1]))

                #print('here50')
                for protocol, line_plots in self.line_segments2.iteritems():
                    for key1, lines in line_plots.iteritems():
                        for key2, points in lines.iteritems():
                            if protocol not in self.line_segments1 or key1 not in self.line_segments1[protocol] or self.line_segments1[protocol][key1]==None or points not in self.line_segments1[protocol][key1].values() :
                                # if intersecting omit
                                if protocol in self.line_segments1 and key1 in self.line_segments1[protocol] and self.line_segments1[protocol][key1]!=None:
                                    omit=False
                                    for p1 in self.line_segments1[protocol][key1].values():
                                        intersection=set(p1).intersection(set(points))
                                        if len(intersection) >0:
                                            omit=True
                                            break

                                    if omit: continue

                                if protocol not in line_seg2_only:
                                   line_seg2_only[protocol]=dict()
                                if key1 not in line_seg2_only[protocol]:
                                   line_seg2_only[protocol][key1]=dict()

                                if points and len(points)>0:
                                    line_seg2_only[protocol][key1][key2]=points
                                    #print('line segment2 only(C2): (%s,%s)'%(points[0][0],points[0][1]))

                # individual points
                #print('..and indiv points')
                indiv_points1_only=dict()
                indiv_points2_only=dict()

                for protocol, point_plots in self.indiv_points1.iteritems():
                    for key, points in point_plots.iteritems():
                        #print("INDIV points: %s"%points)
                        if protocol in self.indiv_points2 and key in self.indiv_points2[protocol]:
                            points1=set(points)
                            points2=set(self.indiv_points2[protocol][key])
                            intersection=points1.intersection(points2)
                            #print('intersection2:%s'%intersection)
                            if len(intersection) >0:
                                if protocol not in indiv_points1_only:
                                    indiv_points1_only[protocol]=dict()
                                if protocol not in indiv_points2_only:
                                    indiv_points2_only[protocol]=dict()

                                points1_only = list(points1-intersection)
                                points2_only = list(points2-intersection)

                                if points1_only and len(points1_only)>0:
                                    # partial overlap
                                    try:
                                        indiv_points1_only[protocol][key]={0: points1_only}
                                    except BaseException,e:
                                        print(e.message)

                                if points2_only and len(points2_only)>0:
                                    # partial overlap
                                    try:
                                        indiv_points2_only[protocol][key]={0: points2_only}
                                    except BaseException,e:
                                        print(e.message)

                            else:
                                # non intersecting
                                if protocol not in indiv_points1_only:
                                    indiv_points1_only[protocol]=dict()
                                if protocol not in indiv_points2_only:
                                    indiv_points2_only[protocol]=dict()
                                indiv_points1_only[protocol][key]={0: list(points1)}
                                indiv_points2_only[protocol][key]={0: list(points2)}
                                #print('indiv_points2_only(A): %s'%(points2))
                        else:
                            # not in points collection2
                            if protocol not in indiv_points1_only:
                               indiv_points1_only[protocol]=dict()
                            if points and len(points)>0:
                                indiv_points1_only[protocol][key]={0: points}

                #print('here51')
                for protocol, point_plots in self.indiv_points2.iteritems():
                    for key, points in point_plots.iteritems():
                        if protocol not in self.indiv_points1 or key not in self.indiv_points1[protocol]:
                            if protocol not in indiv_points2_only:
                               indiv_points2_only[protocol]=dict()
                            if points and len(points)>0:
                                indiv_points2_only[protocol][key]={0: points}
                                #print('indiv_points2_only(B): %s'%(points))


                # polygons
                #print('here52')
                polygon1_only=dict()
                polygon2_only=dict()
                for protocol, polygon_plot in self.polygon_vertices_original1.iteritems():
                    for key, polygon in polygon_plot.iteritems():
                        if protocol in self.polygon_vertices_original2 and key in self.polygon_vertices_original2[protocol] and self.polygon_vertices_original2[protocol][key]!=None:
                            if polygon==None:
                                # not in polygon1
                                if protocol not in polygon2_only:
                                    polygon2_only[protocol]=dict()
                                if key not in polygon2_only[protocol]:
                                    polygon2_only[protocol][key]=dict()

                                vertices2=self.polygon_vertices_original2[protocol][key].values()[0]
                                if len(polygon2_only[protocol][key].keys())==0:
                                    polygons2=dict()
                                    index=0
                                    polygons2[index]=vertices2
                                    polygon2_only[protocol][key]=polygons2
                                else:
                                    index=len(polygon2_only[protocol][key].keys())
                                    polygon2_only[protocol][key][index]=vertices2

                                #polygon2_only[protocol][key]=Polygon(vertices2)
                                continue
                            # determine intersection
                            vertices1=polygon.values()[0]
                            vertices2=self.polygon_vertices_original2[protocol][key].values()[0]
                            poly1= Polygon(vertices1)#(*vertices1)
                            poly2= Polygon(vertices2) #Polygon(self.polygon_vertices_original2[protocol][key])
                            #print('POLYGON1: %s'%poly1)
                            #print('POLYGON2: %s'%poly2)
                            intersection= poly1.intersection(poly2)
                            #print('intersection: %s'%intersection)
                            if intersection:
                                if protocol not in polygon1_only:
                                    polygon1_only[protocol]=dict()
                                if protocol not in polygon2_only:
                                    polygon2_only[protocol]=dict()

                                poly1_only =  poly1.difference(intersection)
                                poly2_only =  poly2.difference(intersection)
                                if poly1_only.is_empty: poly1_only=None
                                if poly2_only.is_empty: poly2_only=None

                                polygons1=dict()
                                index=0
                                if isinstance(poly1_only,MultiPolygon):
                                    # convert to polygon list
                                    for poly in poly1_only.geoms:
                                        vertices=list(poly.exterior.coords)
                                        polygons1[index]=vertices[:len(vertices)-1]
                                        index +=1

                                    poly1_only=polygons1

                                polygons2=dict()
                                index=0
                                if isinstance(poly2_only,MultiPolygon):
                                    # convert to polygon list
                                    for poly in poly2_only.geoms:
                                        vertices=list(poly.exterior.coords)
                                        polygons2[index]=vertices[:len(vertices)-1]
                                        index +=1


                                    poly2_only=polygons2

                                #print('poly1_only: %s'%poly1_only)
                                #print('poly2_only: %s'%poly2_only)

                                if poly1_only is not None: # and len(poly1_only)>0:
                                    # partial overlap
                                    try:
                                        if isinstance(poly1_only,dict):
                                            polygon1_only[protocol][key] = poly1_only
                                        else:
                                            vertices=list(poly1_only.exterior.coords)
                                            polygon1_only[protocol][key] = dict()
                                            polygon1_only[protocol][key][0] = vertices
                                    except BaseException,e:
                                        print(e.message)

                                if poly2_only is not None: # and len(poly2_only)>0:
                                    # partial overlap
                                    try:
                                        if isinstance(poly2_only,dict):
                                            polygon2_only[protocol][key] = poly2_only
                                        else:
                                            vertices=list(poly2_only.exterior.coords)
                                            polygon2_only[protocol][key] = dict()
                                            polygon2_only[protocol][key][0] = vertices

                                    except BaseException,e:
                                        print(e.message)

                            else:
                                # non intersecting
                                if protocol not in polygon1_only:
                                    polygon1_only[protocol]=dict()
                                if protocol not in polygon2_only:
                                    polygon2_only[protocol]=dict()
                                polygon1_only[protocol][key]=polygon
                                polygon2_only[protocol][key]=self.polygon_vertices_original2[protocol][key]

                        else:
                            #not in polygon2
                            if protocol not in polygon1_only:
                               polygon1_only[protocol]=dict()
                            if polygon:
                                polygon1_only[protocol][key]=polygon

                #print('here52.7')
                for protocol, polygon_plot in self.polygon_vertices_original2.iteritems():
                    for key, polygon in polygon_plot.iteritems():
                        if protocol not in self.polygon_vertices_original1 or key not in self.polygon_vertices_original1[protocol]:
                            if protocol not in polygon2_only:
                               polygon2_only[protocol]=dict()
                            if polygon:
                                polygon2_only[protocol][key]= polygon


                # lines and polygons
                #print('here53')
                if True:
                    for protocol, polygon_plot in self.polygon_vertices_original2.iteritems():
                        for key, polygon in polygon_plot.iteritems():
                            if protocol in line_seg1_only and key in line_seg1_only[protocol] and line_seg1_only[protocol][key]!=None:
                                # check if line segment included in polygon
                                if self.polygon_vertices_original2[protocol][key] is None: continue
                                if len(self.polygon_vertices_original2[protocol][key].values())==0: continue
                                vertices=self.polygon_vertices_original2[protocol][key].values()[0]
                                #print('protocol: %s, key: %s, vertices: %s'%(protocol, str(key), str(vertices)))
                                #print('line_seg1_only: %s'%str(line_seg1_only[protocol][key]))
                                if vertices is None: continue
                                for index, val in line_seg1_only[protocol][key].iteritems():
                                    #if 0 not in line_seg1_only[protocol][key]: continue
                                    if line_seg1_only[protocol][key][index] is None: continue
                                    length =len(line_seg1_only[protocol][key][index])
                                    if length==0: continue
                                    start = line_seg1_only[protocol][key][index][0]
                                    end = line_seg1_only[protocol][key][index][length-1]
                                    if start[0]==end[0]:
                                        # vertical line
                                       if (start[0] >= vertices[0][0] and start[0] <= vertices[len(vertices)-1][0]) and \
                                           (start[1] >= vertices[0][1] and start[1] <= vertices[1][1]):
                                            line_seg1_only[protocol][key][index]=[]
                                    else:
                                        # horizontal line
                                        if (start[1] >= vertices[0][1] and start[1] <= vertices[1][1]) and \
                                           (start[0] >= vertices[0][0] and end[0] <= vertices[len(vertices)-1][0]):
                                            line_seg1_only[protocol][key][index]=[]

                #print('..get canonical forms')
                #for key,val in polygon1_only.iteritems():
                #    print('polygon1_only:: key: %s, val: %s'%(key,val))

                self.polygon_vertices_original=polygon1_only
                self.line_segments=line_seg1_only
                self.indiv_points=indiv_points1_only
                self.ExtractCanonicalForm()
                #print("canonical_policies1 len: %s"%len(self.canonical_policies))
                canonical_policy1=copy.deepcopy(self.canonical_policies)


                #for key,val in polygon2_only.iteritems():
                #    print('polygon2_only:: key: %s, val: %s'%(key,val))

                #print('extracting canonical2')
                # policy2 only
                self.polygon_vertices_original=polygon2_only
                self.line_segments=line_seg2_only
                self.indiv_points=indiv_points2_only
                self.ExtractCanonicalForm()
                canonical_policy2=copy.deepcopy(self.canonical_policies)

                result['1']=canonical_policy1
                result['2']=canonical_policy2

            except BaseException,e:
                print("%s : %s" %(resources['get_semantic_difference_failed'],e))

        return result

    def RemoveLineOverlap(self, line, overlap):
        #print('RemoveLineOverlap:: line:%s'%(line))
        #print('RemoveLineOverlap:: overlap:%s'%(overlap))
        from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point

        result=[]
        if line and overlap:
            # check whether multi-point overlap
            if len(overlap) > 1:
                overlap_start=overlap[0]
                overlap_end=overlap[len(overlap)-1]
                first_point=line[0]
                last_point=line[len(line)-1]
                #print('overlap_start: %s, overlap_end: %s, first_point: %s, last_point: %s'%(overlap_start,overlap_end,first_point,last_point))

                if overlap_start[0]==first_point[0] or overlap_end[0]==last_point[0]:
                    # overlap results in a single line segment
                    #print('result is single line(A)')
                    r=list(set(line)-set(overlap))
                    r=sorted(r, key=lambda tup: (tup[0],tup[1]) )
                    result.append(r)
                else:
                    # overlap results in two line segments
                    #print('result is 2 lines(A)')
                    seg1=[]
                    i=0
                    while i<len(line):
                       if line[i]==overlap_start: break
                       seg1.append(line[i])
                       i+=1
                    seg2=[]
                    j=len(line)-1
                    while j>=0:
                       if line[j]==overlap_end: break
                       seg2.append(line[j])
                       j-=1

                    seg1=sorted(seg1, key=lambda tup: (tup[0],tup[1]) )
                    seg2=sorted(seg2, key=lambda tup: (tup[0],tup[1]) )
                    #print('seg1: %s'%seg1)
                    #print('seg2: %s'%seg2)
                    result.append(seg1)
                    result.append(seg2)
                    #print('result: %s'%result)

            else:
                # single point overlap
                overlap_point=overlap[0]
                x=overlap_point[0]
                y=overlap_point[1]
                first_point=line[0]
                last_point=line[len(line)-1]
                if x==first_point[0] or x==last_point[0]:
                   # overlap results in a single line segment
                   #print('result is single line(B)')
                   t=list(set(line)-set(overlap))
                   t=sorted(t, key=lambda tup: (tup[0],tup[1]) )
                   result.append(t)
                else:
                   # overlap results in two line segments
                   #print('result is 2 lines(B)')
                   seg1=[]
                   i=0
                   while i<len(line):
                       if line[i]==overlap_point: break
                       seg1.append(line[i])
                       i+=1
                   seg2=[]
                   j=len(line)-1
                   while j>=0:
                       if line[j]==overlap_point: break
                       seg2.append(line[j])
                       j-=1

                   seg1=sorted(seg1, key=lambda tup: (tup[0],tup[1]) )
                   seg2=sorted(seg2, key=lambda tup: (tup[0],tup[1]) )
                   result.append(seg1)
                   result.append(seg2)

        return result

    def IsSubgraph(self, zc_graph1, zc_graph2, node_set_matches):
        '''checks whether zc_graph1 is a subgraph of zc_graph2'''
        if zc_graph1 and zc_graph2:
             gm = nx.algorithms.isomorphism.GraphMatcher(zc_graph2,zc_graph1)
             if gm.subgraph_is_isomorphic():
                 for isomorphism in gm.subgraph_isomorphisms_iter():
                     match=set(isomorphism.keys())
                     if match not in node_set_matches:
                         node_set_matches.append(match)
                 return True

        return False

    def IsIsomorphic(self, zc_graph1, zc_graph2):
        if zc_graph1 and zc_graph2:
            return nx.is_isomorphic(zc_graph1, zc_graph2)
        return False

    def CheckPolicyInclusiveDirectly(self, flow_policies1, flow_policies2):
        ''' checks whether flow_policies1 is a subset of flow_policies2 (same network) '''

        inclusive=True
        for key1, policy1 in flow_policies1.iteritems():
            key1_str='%s->%s'%(key1[0],key1[1])
            key_match=False
            for key2,policy2 in flow_policies2.iteritems():
                key2_str='%s->%s'%(key2[0],key2[1])
                if key1_str==key2_str:
                    key_match=True
                    break
            # if not key_match: return False find all errors
            if key_match:
                policy2= flow_policies2[key2]
                if not self.IsInclusiveFlowPolicy(policy1, policy2):
                    inclusive=False
                    print('intent::')
                    for rule in policy2:
                        print(key1_str+' '+rule)
                    print('implemented::')
                    for rule in policy1:
                        print(key1_str+' '+rule)
                    # return False find all errors
            else:
                print('implemented(no matching HL intent)::')
                for rule in policy1:
                    print(key1_str+' '+rule)

        if not inclusive: return False

        return True

    def are_tuples_equal(self, tuple1, tuple2):
        if tuple1 is not None and tuple2 is not None:
            if isinstance(tuple1,Node):
                if not isinstance(tuple2,Node):
                    return False
                if tuple1.element_set==tuple2.element_set:
                   return True
            elif isinstance(tuple2,Node):
                if not isinstance(tuple1,Node):
                    return False
                if tuple1.element_set==tuple2.element_set:
                   return True
            else:
                if len(tuple1)==len(tuple2):
                   index=0
                   while index < len(tuple1):
                       if isinstance(tuple1[index],tuple):
                           if not self.are_tuples_equal(tuple1[index],tuple2[index]):
                               return False
                       else:
                           if tuple1[index].element_set!=tuple2[index].element_set:
                               return False
                       index+=1
                   return True

        return False

    def GetOriginalEdges(self, edge_list, cmg1, cmg2):
        result=[]
        labels=[]
        for edge1 in edge_list:
            #print('GetOriginalEdges:: edge: %s'%str(edge1))
            for edge2 in cmg1.edges:
                inv = edge2.invertex.difference(edge2.attributes)
                if (edge1[0].element_set == inv and
                    edge1[1].element_set == edge2.outvertex):
                    print('set1: %s, inv: %s'%(edge1[0].element_set,edge2.invertex))
                    print('set2: %s, outv: %s'%(edge1[1].element_set,edge2.outvertex))
                    labels.append(edge2.label)

        print('labels: %s'%labels)

        for label in labels:
            for edge in cmg2.edges:
                if (edge.label == label):
                    inv = edge.invertex.difference(edge.attributes)
                    result.append(Edge(inv,edge.outvertex))
                    break

        return result

    def int_to_ipaddress(self, ipnum):
        o1 = int(ipnum / 16777216) % 256
        o2 = int(ipnum / 65536) % 256
        o3 = int(ipnum / 256) % 256
        o4 = int(ipnum) % 256
        return '%(o1)s.%(o2)s.%(o3)s.%(o4)s' % locals()


    def numeric_to_ipaddresses(self, edge_list):
        import ipaddr
        import ipaddress
        result=[]

        for edge in edge_list:
            invertex = list(edge[0].element_set)
            conv_inv = []
            for elt in invertex:
                if 'device' in elt:
                    conv_inv.append('device')
                    continue
                start = elt.split('-')[0]
                end = elt.split('-')[1]
                if start==end:
                    # host ipaddress
                    ip=self.int_to_ipaddress(int(start))
                    host_ip='%s/32'%(ip)
                    conv_inv.append(host_ip)
                else:
                    if start=='0' and end=='': # 255.255.255.255/32
                        # default
                        conv_inv.append('0.0.0.0/0')
                    else:
                        # subnet address
                        #mask = int(end)-int(start)
                        #network = self.int_to_ipaddress(int(start))
                        #broadcast = self.int_to_ipaddress(int(end))
                        #ip_subnet='%s/%s'%(network,mask)
                        #print('mask::%s'%mask)
                        #conv_inv.append(ip_subnet)

                        first_host = self.int_to_ipaddress(int(start))
                        broadcast = self.int_to_ipaddress(int(end))
                        ip_subnet = ipaddr.summarize_address_range(ipaddr.IPv4Address(first_host),ipaddr.IPv4Address(broadcast))
                        #ip_subnet = ipaddress.summarize_address_range(ipaddress.IPv4Address(first_host),
                        #                                              ipaddress.IPv4Address(broadcast))
                        #print('ip_subnet:: %s'%ip_subnet[0])
                        conv_inv.append(str(ip_subnet[0]))

            outvertex = list(edge[1].element_set)
            conv_outv=[]
            for elt in outvertex:
                if 'device' in elt:
                    conv_outv.append('device')
                    continue
                start = elt.split('-')[0]
                end = elt.split('-')[1]
                if start==end:
                    # host ipaddress
                    ip=self.int_to_ipaddress(int(start))
                    host_ip='%s/32'%(ip)
                    conv_outv.append(host_ip)
                else:
                    if start=='0' and end=='': # 255.255.255.255/32
                        # default
                        conv_outv.append('0.0.0.0/0')
                    else:
                        # subnet address
                        #mask = end-start
                        #network = self.int_to_ipaddress(int(start))
                        #broadcast = self.int_to_ipaddress(int(end))
                        #ip_subnet='%s/%s'%(network,mask)
                        #conv_outv.append(ip_subnet)

                        first_host = self.int_to_ipaddress(int(start))
                        broadcast = self.int_to_ipaddress(int(end))
                        ip_subnet = ipaddr.summarize_address_range(ipaddr.IPv4Address(first_host),ipaddr.IPv4Address(broadcast))
                        #ip_subnet = ipaddress.summarize_address_range(ipaddress.IPv4Address(first_host),
                        #                                              ipaddress.IPv4Address(broadcast))
                        #print('ip_subnet:: %s'%ip_subnet)
                        conv_outv.append(str(ip_subnet[0]))

            #print('result:: %s, %s'%(conv_inv,conv_outv))
            result.append((Node(set(conv_inv)), Node(set(conv_outv))))
            return result

    def numeric_to_ipaddresses2(self, edge_list):
        import ipaddr
        import ipaddress
        result=[]

        for edge in edge_list:
            invertex = list(edge.invertex.difference(edge.attributes))
            conv_inv = []
            for elt in invertex:
                if 'device' in elt:
                    conv_inv.append('device')
                    continue
                start = elt.split('-')[0]
                end = elt.split('-')[1]
                if start==end:
                    # host ipaddress
                    ip=self.int_to_ipaddress(int(start))
                    host_ip='%s/32'%(ip)
                    conv_inv.append(host_ip)
                else:
                    if start=='0' and end=='': # 255.255.255.255/32
                        # default
                        conv_inv.append('0.0.0.0/0')
                    else:
                        # subnet address
                        #mask = int(end)-int(start)
                        #network = self.int_to_ipaddress(int(start))
                        #broadcast = self.int_to_ipaddress(int(end))
                        #ip_subnet='%s/%s'%(network,mask)
                        #print('mask::%s'%mask)
                        #conv_inv.append(ip_subnet)

                        first_host = self.int_to_ipaddress(int(start))
                        broadcast = self.int_to_ipaddress(int(end))
                        ip_subnet = ipaddr.summarize_address_range(ipaddr.IPv4Address(first_host),ipaddr.IPv4Address(broadcast))
                        #ip_subnet = ipaddress.summarize_address_range(ipaddress.IPv4Address(first_host),
                        #                                              ipaddress.IPv4Address(broadcast))
                        #print('ip_subnet:: %s'%ip_subnet[0])
                        conv_inv.append(str(ip_subnet[0]))

            outvertex = list(edge.outvertex)
            conv_outv=[]
            for elt in outvertex:
                if 'device' in elt:
                    conv_outv.append('device')
                    continue
                start = elt.split('-')[0]
                end = elt.split('-')[1]
                if start==end:
                    # host ipaddress
                    ip=self.int_to_ipaddress(int(start))
                    host_ip='%s/32'%(ip)
                    conv_outv.append(host_ip)
                else:
                    if start=='0' and end=='': # 255.255.255.255/32
                        # default
                        conv_outv.append('0.0.0.0/0')
                    else:
                        # subnet address
                        #mask = end-start
                        #network = self.int_to_ipaddress(int(start))
                        #broadcast = self.int_to_ipaddress(int(end))
                        #ip_subnet='%s/%s'%(network,mask)
                        #conv_outv.append(ip_subnet)

                        first_host = self.int_to_ipaddress(int(start))
                        broadcast = self.int_to_ipaddress(int(end))
                        ip_subnet = ipaddr.summarize_address_range(ipaddr.IPv4Address(first_host),ipaddr.IPv4Address(broadcast))
                        #ip_subnet = ipaddress.summarize_address_range(ipaddress.IPv4Address(first_host),
                        #                                              ipaddress.IPv4Address(broadcast))
                        #print('ip_subnet:: %s'%ip_subnet)
                        conv_outv.append(str(ip_subnet[0]))

            #print('result:: %s, %s'%(conv_inv,conv_outv))
            result.append(Edge(set(conv_inv), set(conv_outv)))

        return result

    def is_private_ipaddress(self,ipaddress):
        from IPy import IP
        try:
            ip = IP(ipaddress)
            return ip.iptype()=='PRIVATE'

        except BaseException,e:
            #print('error: %s'%e)
            pass

        return False

    def is_public_ipaddress(self,ipaddress):
        from IPy import IP
        try:
            ip = IP(ipaddress)
            return ip.iptype()=='PUBLIC'

        except BaseException,e:
            #print('error: %s'%e)
            pass

        return False

    def check_mapping_valid(self, mapping, device_mapped_to=None):
        if device_mapped_to is None:
            device_mapped_to=[]
        zone_ip_map=dict()
        import ipaddr

        for item in mapping:
            src_edge = item.mapping[0]
            dest_edge = item.mapping[1]
            # print('src_edge:: %s, dest_edge:: %s'%(src_edge,dest_edge))
            src_inv = src_edge[0]
            src_outv = src_edge[1]
            dst_inv = dest_edge[0]
            dst_outv = dest_edge[1]

            src = list(src_inv.element_set)[0]
            dst = list(src_outv.element_set)[0]
            src_zone = list(dst_inv.element_set)[0]
            dst_zone = list(dst_outv.element_set)[0]

            #print('src:: %s'%src)
            #print('dst:: %s'%dst)
            #print('src_zone:: %s'%src_zone)
            #print('dst_zone:: %s'%dst_zone)

            if self.is_public_ipaddress(src) and 'internet_zone' not in src_zone:
                #print('src invalid1: %s'%src)
                return False
            if self.is_public_ipaddress(dst) and 'internet_zone' not in dst_zone:
                #print('dst invalid1: %s'%dst)
                return False

            if self.is_private_ipaddress(src) and 'internet_zone' in src_zone:
                #print('src invalid2: %s'%src)
                return False
            if self.is_private_ipaddress(dst) and 'internet_zone' in dst_zone:
                #print('dst invalid2: %s'%dst)
                return False

            if 'device' in src and 'internet_zone' in src_zone:
                #print('src invalid3: %s'%src)
                return False
            if 'device' in dst and 'internet_zone' in dst_zone:
                #print('dst invalid3: %s'%dst)
                return False

            if self.is_private_ipaddress(src) and 'device' not in src_zone:
               if src_zone not in zone_ip_map:
                  zone_ip_map[src_zone]=[]

               ipaddress=ipaddr.IPv4Network(src)
               if ipaddress not in zone_ip_map[src_zone]:
                  zone_ip_map[src_zone].append(ipaddress)

            if self.is_private_ipaddress(dst) and 'device' not in dst_zone:
               if dst_zone not in zone_ip_map:
                  zone_ip_map[dst_zone]=[]

               ipaddress=ipaddr.IPv4Network(dst)
               if ipaddress not in zone_ip_map[dst_zone]:
                  zone_ip_map[dst_zone].append(ipaddress)

            if 'device' in src and src_zone not in device_mapped_to:
                device_mapped_to.append(src_zone)
            if 'device' in dst and dst_zone not in device_mapped_to:
                device_mapped_to.append(dst_zone)

            # device can't be mapped to distinct zones simultaneously
            if len(device_mapped_to)>1:
                return False

        # check if zone ip ranges overlap
        for zone1, iprange1 in zone_ip_map.iteritems():
            for zone2, iprange2 in zone_ip_map.iteritems():
                if zone1!=zone2:
                   for ipaddress1 in iprange1:
                       for ipaddress2 in iprange2:
                           if ipaddress1.overlaps(ipaddress2):
                               #print('ipaddress overlap: %s, %s'%(ipaddress1,ipaddress2))
                               return False


        return True

    def get_device_zone_mapping(self, mapping):
        index=0
        print('in here')
        for item in mapping:
            for node in item.mapping[0]:
                print('node.element_set:: %s'%(list(node.element_set)))
                if 'device' in list(node.element_set):
                    return item.mapping[1][index].element_set #[0]

        return None


        for item in converted_mapping:
                           print('src_edge:%s, target_edge:%s'%(item.mapping[0],
                                                                item.mapping[1]))

    def is_duplicate(self, value, existing_list):
        for item in existing_list:
            if(item.mapping[0]== value.mapping[0] and
               item.mapping[1]== value.mapping[1]):
               return True

        return False

    def CheckPolicyInclusiveViaPartitions(self, flow_policies1, flow_policies2, zf_line1, zf_line2, zf1_graph, zf2_graph, policy1_name,policy2_name):
        '''checks whether flow_policies1 is a subset of flow_policies2 (different networks)'''
        import itertools
        import networkx as nx
        if flow_policies1 and flow_policies2 and zf_line1 and zf_line2:

            # TODO: reinstate debug dr new
            # if not self.NodeAndEdgeCountEqual(zf_line1, zf_line2): return False
            group_map1=[]
            group_map2=[]
            semantic_partition1 = self.GetSemanticPartition(flow_policies1, group_map1)
            semantic_partition2 = self.GetSemanticPartition(flow_policies2, group_map2)
            inter_group_map=[]
            semantic_partition3=[]

            #debug dr new new
            print('Semantic Partition (SP) details of %s'%policy1_name)
            print('%s Equivalence class(es): '%len(semantic_partition1))
            for group in group_map1:
               print('partition:  %s, policy: %s'%(group,flow_policies1[list(group)[0]]))
            print('-----------------------------------')
            print('Semantic Partition (SP) details of %s'%policy2_name)
            print('%s Equivalence class(es): '%len(semantic_partition2))
            for group in group_map2:
                print('partition:  %s, policy: %s'%(group,flow_policies2[list(group)[0]]))
            print('-----------------------------------')

            #print('SP2 partitions- %s'%(len(semantic_partition2)))
            #for group21 in semantic_partition2:
            #    policy21=flow_policies2[group21[0]]
            #    print('SP2 policy- %s, %s'%(group21, policy21))
            #for group in group_map2:
            #    print('group2: %s'%group)

            # determine the possible group mappings
            print('Find Feasible Mappings..')
            possible_flow_mappings=dict()
            for group1 in semantic_partition1:
                included=False
                if group1[0] not in possible_flow_mappings:
                        possible_flow_mappings[group1[0]]=[]
                policy1=flow_policies1[group1[0]]
                if policy1 is None:
                   included=True
                for group2 in semantic_partition2:
                    policy2=flow_policies2[group2[0]]
                    #print('key:: %s->%s'%(str(group1[0]), str(group2[0])))
                    if self.IsInclusiveFlowPolicy(policy1,policy2): #and policy2 is not None
                        #print('here4')
                        included=True
                        possible_flow_mappings[group1[0]].append(group2[0])
                # if a semantic partition cannot be included => non-inclusive
                #print('here5')
                if not included:
                    print('not included1: %s'%policy1)#group1[0]
                    return False

            #print('here6')
            group_mappings=dict()
            # get the entire set of policies (group1) foreach key (flow1)
            for flow1, mapping in possible_flow_mappings.iteritems():
                group1= [group for group in group_map1 if flow1 in group]
                group2=[]
                # get entire set of policies (group2) foreach policy that's included
                for flow2 in mapping:
                    group2 += [group for group in group_map2 if flow2 in group]
                # g1,g2 holds parent and child policy sets related through inclusion
                g1=[]
                g2=[]
                for elt1 in group1:
                    for elt2 in elt1:
                        g1.append(elt2)
                for elt3 in group2:
                    for elt4 in elt3:
                        g2.append(elt4)
                group_mappings[tuple(g1)]=tuple(g2)

            # process every possible group mapping for an adjacency matrix match
            # group1, group2 consist of policy sets (each set has elts with similar semantics)
            #print('here7')
            group_permutations=dict()
            index=0
            # group_permutations hold Mapping sets (M1,M2,...)?
            for group1, group2 in group_mappings.iteritems():
                len_group1=len(group1)
                len_group2=len(group2)
                if index not in group_permutations: group_permutations[index]=[]
                if len_group1==len_group2:
                    # permutations of group1 that can directly map to group2
                    group1_mappings=itertools.permutations(list(group1))
                    #print('len(group1_mappings):: %s'%(len(list(group1_mappings))))
                    for mapping in group1_mappings:
                        converted_edges = self.numeric_to_ipaddresses(tuple(mapping))
                        if converted_edges is not None:
                            converted =  MappingHolder((converted_edges[0], tuple(group2)[0]))
                            valid = self.check_mapping_valid([converted])
                            if valid:
                                group_permutations[index].append((tuple(mapping),tuple(group2)))
                            #print('index: %s, group_mapping1: %s'%(index,str((tuple(mapping),tuple(group2)))))
                elif len_group1<len_group2:
                    # permutations of group1 maps to selected combinations (of some length) in group2
                    target=itertools.combinations(list(group2),len_group1)
                    # g1 = <p1,p2>
                    # g2 = <q1,q2,q3>
                    #[<q1,q2>, <q2,q3>, <q1,q3>]
                    target_mappings=[item for item in target]
                    group1_mappings=itertools.permutations(list(group1))
                    #print('group1: %s'%(str(group1)))
                    #print('check this combination')
                    #print('len(group1_mappings):: %s, len(target_mappings):: %s'%(len(list(group1_mappings)), len(list(target_mappings))))
                    for mapping in group1_mappings:
                        for target_mapping in target_mappings:
                            converted_edges = self.numeric_to_ipaddresses(tuple(mapping))
                            if converted_edges is not None:
                                converted =  MappingHolder((converted_edges[0], target_mapping[0]))
                                valid = self.check_mapping_valid([converted])
                                if valid:
                                    group_permutations[index].append((tuple(mapping),target_mapping))
                                #print('index: %s, group_mapping2: %s'%(index,str((tuple(mapping),target_mapping))))
                                #group_permutations[index].append((tuple(mapping),target_mappings))
                elif len_group1>len_group2:
                    # permutations of group1 maps to selected combinations (of some length) in group2
                    group1_mappings=itertools.permutations(list(group1),len_group2)
                    #print('len(group1_mappings):: %s'%(len(list(group1_mappings))))
                    for mapping in group1_mappings:
                        converted_edges = self.numeric_to_ipaddresses(tuple(mapping))
                        if converted_edges is not None:
                            converted =  MappingHolder((converted_edges[0], tuple(group2)[0]))
                            valid = self.check_mapping_valid([converted])
                            if valid:
                                group_permutations[index].append((tuple(mapping),tuple(group2)))
                            #print('index: %s, group_mapping3: %s'%(index,str((tuple(mapping),tuple(group2)))))
                            #group_permutations[index].append((tuple(mapping),list(group2)))
                index+=1

            #print('here8')
            updated=dict()
            #from mgtoolkit.library import MappingHolder
            n=0
            for key,value in group_permutations.iteritems():
                ###print('key: %s, len(value): %s'%(key,len(value)))
                for mapping in value:
                    converted_edges = self.numeric_to_ipaddresses(mapping[0])
                    if converted_edges is None or mapping[1] is None:
                        continue
                    converted =  MappingHolder((converted_edges[0], mapping[1][0]))
                    # only include valid mappings (reduces computational cost)
                    valid = self.check_mapping_valid([converted])
                    if valid: # valid
                        mh = MappingHolder(mapping)
                        if n not in updated: # key
                            updated[n]=[] # key
                        # add if not duplicate
                        if not self.is_duplicate(mh,updated[n]):# key
                            updated[n].append(mh) # key
                if n in updated and len(updated)>0:
                   n+=1

            for key,val in updated.iteritems():
                print('updated:: key: %s, len(val): %s'%(key, len(val)))

            #print('here9')
            index=0
            intermediate=None
            # calculate final mapping set (FM)?
            while index < len(updated):
                if index in updated:
                    #print('len(updated[index]):: %s'%(len(updated[index])))
                    set1=set(updated[index])
                    temp=set1
                    if index+1< len(updated):
                        set2=set(updated[index+1])
                        #print('len(updated[index+1]):: %s'%(len(updated[index+1])))
                        temp=itertools.product(set1,set2)
                    if intermediate==None:
                        intermediate=temp
                    else:
                        intermediate=itertools.product(intermediate,temp)
                index+=2

            #print('here10')
            # check for isomorphisms
            #print('Check for policy node isomorphisms..')
            valid_mappings=[]
            count=1
            #mps = len(list(intermediate))
            mappings1=[]
            if intermediate is not None:
                mappings1= list(intermediate)
            #print('#mappings: %s'%(len(mappings1)))
            device_zone_mapping = []
            for tuple1 in mappings1: #intermediate
                #if count>50000: break
                #print('mapping: %s'%count)
                count+=1
                group1=[]
                group2=[]
                possible_mapping=[]
                try:
                    possible_mapping= self.GetMapping(tuple1)
                except:
                    pass
                for item in possible_mapping:
                    # get left items
                    #..and right elements
                    group1 += self.GetGroupElements(item.mapping,1)
                    group2 += self.GetGroupElements(item.mapping,2)
                if len(group1)!= len(set(group1)):
                    # duplicates in left group- invalid combination
                    #print('group1 duplicates')
                    continue
                # relax this constraint: distinct policies in group1 can map to the same policy in group2
                # if len(group2)!= len(set(group2)):
                #    # duplicates in right group- invalid combination
                #    print('group2 duplicates')
                #    continue
                # compare adjacency matrices
                #print('here11')
                ind=1
                converted_mapping=[]
                for item in possible_mapping:
                    # TODO: will this work when item.mapping[0] and [1] have more than a single element?
                    converted_edges = self.numeric_to_ipaddresses(item.mapping[0])
                    converted =  MappingHolder((converted_edges[0], item.mapping[1][0]))
                    # print('item.mapping:: option: %s, 0:%s, 1:%s, 2:%s'%(ind,item.mapping[0],
                    #                                                      item.mapping[1],
                    #                                                      converted_edges))
                    converted_mapping.append(converted)
                    ind +=1

                # mapping can be valid
                #print('here12')
                device_mapped_to=[]
                valid =  self.check_mapping_valid(converted_mapping,device_mapped_to)
                #print('device_mapped_to:: %s'%str(device_mapped_to))
                if valid: #valid
                   #zone = self.get_device_zone_mapping(converted_mapping)
                   #print('device_mapped_to:: %s, device_zone_mapping:: %s'%(device_mapped_to[0], str(device_zone_mapping)))
                   if len(device_mapped_to)>0 and (device_mapped_to[0] not in device_zone_mapping):
                       device_zone_mapping.append(device_mapped_to[0])
                       print('Feasible mapping::')
                       valid_mappings.append(converted_mapping)
                       ind=1
                       for item in converted_mapping:
                           print('src_edge:%s, target_edge:%s'%(item.mapping[0],
                                                                item.mapping[1]))
                           ind+=1
            #print('here14')
            if len(valid_mappings)==0:
                print('Feasible mapping NOT found')

            return True

    def GetSemanticPartition(self, flow_policies1, group_map):
        semantic_partition=[]
        if flow_policies1:
            for flow1, policy1 in flow_policies1.iteritems():
                #print('GetSemanticPartition::flow1-%s, policy1-%s'%(flow1,policy1))
                matches=[]
                for flow2, policy2 in flow_policies1.iteritems():
                    #print('GetSemanticPartition::flow2-%s, policy2-%s'%(flow2,policy2))
                    if flow1!=flow2:
                        if self.IsEquivalentFlowPolicy(policy1,policy2):
                            matches.append(flow2)
                matches.append(flow1)

                if set(matches) not in group_map:
                    group_map.append(set(matches))

            for group in group_map:
                semantic_partition.append((list(group)[0],len(group)))

        return  set(semantic_partition)

    def AreSemanticPartitionsEqual(self, flow_policies1, flow_policies2, inter_group_map,policy1_filename,policy2_filename):

        group_map1=[]
        group_map2=[]
        semantic_partition1 = self.GetSemanticPartition(flow_policies1, group_map1)
        semantic_partition2 = self.GetSemanticPartition(flow_policies2, group_map2)
        semantic_partition3=[]

        print('Semantic Partition (SP) details of policy- %s'%policy1_filename)
        print('%s Equivalence class(es): '%len(semantic_partition1))
        #for group in group_map1:
        #    print('  %s'%group)
        #print('-----------------------------------')
        print('Semantic Partition (SP) details of policy- %s'%policy2_filename)
        print('%s Equivalence class(es): '%len(semantic_partition2))
        #for group in group_map2:
        #    print('  %s'%group)

        # substitute policies based on equal semantics
        if self.CanSubstitutePolicies(semantic_partition1, semantic_partition2, flow_policies1, flow_policies2, group_map1, group_map2, inter_group_map, semantic_partition3, False): # should be true?
            return set(semantic_partition3)==semantic_partition2

        return False

    def CanSubstitutePolicies(self, group1, group2, policies1, policies2, map1, map2, inter_map, substituted, validate_cardinality):
        '''substitute group1 elements with group2 elements (considering equal semantics)'''
        if group1 and len(group1)>0:
            list1=list(group1)
            list2=list(group2)
            for tuple1 in list1:
                flow1=tuple1[0]
                policy1=policies1[flow1]
                full_group1= [list(item) for item in map1 if flow1 in list(item)][0]
                match_found=False
                # look for a match in the other group
                for tuple2 in list2:
                    flow2=tuple2[0]
                    policy2=policies2[flow2]
                    full_group2= [list(item) for item in map2 if flow2 in list(item)][0]
                    # check semantically equal
                    if self.IsEquivalentFlowPolicy(policy1, policy2): # omit- and tuple1[1]==tuple2[1]
                       if validate_cardinality and tuple1[1] <= tuple2[1]:
                           match_found=True
                           substituted.append((flow2,tuple1[1]))
                           inter_map.append((full_group1,full_group2))
                       elif not validate_cardinality:
                           match_found=True
                           substituted.append((flow2,tuple1[1]))
                           inter_map.append((full_group1,full_group2))

                if not match_found: return False
            return True
        return False

    def CanIncludePolicies(self, group1, group2, policies1, policies2, map1, map2, inter_map):
        '''substitute group1 elements with group2 elements (considering equal semantics)'''
        try:
            if group1 and len(group1)>0:
                list1=list(group1)
                list2=list(group2)
                for tuple1 in list1:
                    flow1=tuple1[0]
                    policy1=policies1[flow1]
                    full_group1=[list(item) for item in map1 if flow1 in list(item)][0]
                    match_found=False
                    # look for a match in the other group
                    for tuple2 in list2:
                        flow2=tuple2[0]
                        policy2=policies2[flow2]
                        full_group2= [list(item) for item in map2 if flow2 in list(item)][0]
                        # check semantically inclusive
                        if self.IsInclusiveFlowPolicy(policy1, policy2):
                           match_found=True
                           key=tuple(full_group1)
                           if key not in inter_map:
                               inter_map[key]=[]

                           inter_map[tuple(full_group1)] += full_group2

                    if not match_found: return False
                return True

        except BaseException,e:
            print(e.message)

        return False

    def CheckPolicyEquivalenceExhaustive(self, zf_line1, flow_policies1, zf_line2, flow_policies2):
        # prelim check
        if not self.NodeAndEdgeCountEqual(zf_line1, zf_line2): return False

        policy_set1=set(flow_policies1.keys())
        policy_set2=set(flow_policies2.keys())
        policy_comparator=tuple(policy_set2)

        mappings = itertools.permutations(policy_set1,len(policy_set1))
        #print('total permutations- %s'%(len(mappings)))
        index=1
        for mapping in mappings:
            print('index- %s'%index)
            if self.IsPolicyIsomorphic(mapping,policy_comparator,flow_policies1,flow_policies2,zf_line1,zf_line2):
                return True
            index+=1

        return False

    def CheckPolicyEquivalenceDirectly(self, flow_policies1, flow_policies2):
        ''' checks whether policies spanning a single network are equivalent'''
        flow_count1=len(flow_policies1.keys())
        flow_count2=len(flow_policies2.keys())
        if flow_count1 != flow_count2: return False

        for key, policy1 in flow_policies1.iteritems():
            if key not in flow_policies2: return False
            policy2= flow_policies2[key]
            if not self.IsEquivalentFlowPolicy(policy1, policy2): return False

        return True

    def CheckPolicyEquivalenceViaPartitions(self, zf1_graph, zf_line1, flow_policies1, zf2_graph, zf_line2, flow_policies2,policy1_filename,policy2_filename):
        # checks whether policies across multiple networks are equivalent
        inter_partition_map=[]
        partition_mappings_set=dict()
        index=0

        # prelim checks
        if not self.NodeAndEdgeCountEqual(zf_line1, zf_line2): return False
        if not self.AreSemanticPartitionsEqual(flow_policies1,flow_policies2, inter_partition_map,policy1_filename,policy2_filename): return False

        # create mappings sets (M_i); eg., mappings_set[0]=[(p0,p`1),(p1, p`2),...]
        print('Generating partition mappings...')
        for map_tuple in inter_partition_map:
            group1=map_tuple[0]
            group2=map_tuple[1]
            if len(group1)>1:
                mappings = itertools.permutations(group1,len(group1))
            else: mappings=[group1[0]]
            if len(group2)>1:
                target=tuple(group2)
            else: target=group2[0]
            if index not in partition_mappings_set:
                partition_mappings_set[index]=[]
            for mapping in mappings:
                partition_mappings_set[index].append((mapping,target))
            index+=1

        # workaround for above
        global_permutations=[]
        for group, permutations in partition_mappings_set.iteritems():
            new_values=[]
            if len(global_permutations)==0:
                for permutation in permutations:
                    global_permutations.append([permutation])
            else:
                for permutation in permutations:
                    for gp in global_permutations:
                        new_values.append(gp+[permutation])
                global_permutations=list(new_values)


        # workaround for above
        for permutation in global_permutations:
                nodes1=[]
                nodes2=[]
                #print(permutation)
                for tuple1 in permutation:
                    if isinstance(tuple1[0],tuple):
                        for elt in tuple1[0]: nodes1.append(elt)
                    else:
                        nodes1.append(tuple1[0])

                    if isinstance(tuple1[1],tuple):
                        for elt in tuple1[1]: nodes2.append(elt)
                    else:
                        nodes2.append(tuple1[1])

                # compare adjacency matrices
                node_labels1=[]
                for policy in nodes1:
                    for node, attributes in zf_line1.node.iteritems():
                        if attributes['label']==policy: node_labels1.append(node)

                node_labels2=[]
                for policy in nodes2:
                    for node, attributes in zf_line2.node.iteritems():
                        if attributes['label']==policy: node_labels2.append(node)

                A1 = nx.adjacency_matrix(zf_line1,node_labels1)
                A2 = nx.adjacency_matrix(zf_line2,node_labels2)

                if (A1==A2).all():
                    # check zones corresponding to the policy-node matches have identical semantic type
                    index=0
                    iso=True
                    while index<len(nodes1):
                        flow_policy1=nodes1[index]
                        flow_policy2=nodes2[index]
                        zones1=flow_policy1.split('->')
                        zones2=flow_policy2.split('->')
                        # check semantic types match
                        if ( zf1_graph.node[zones1[0]]['device_subtype'] != zf2_graph.node[zones2[0]]['device_subtype'] or
                             zf1_graph.node[zones1[1]]['device_subtype'] != zf2_graph.node[zones2[1]]['device_subtype'] ):
                                iso=False
                                break

                        index+=1

                    if iso:
                        print('Isomorphism found.')
                        return True

        print('Isomorphism NOT found.')
        return False

    def IsPolicyIsomorphic(self, mapping, target, flow_policies1, flow_policies2, zf_line1, zf_line2):
        size=len(mapping)
        index=0
        while index < size:
            if not self.ArePolicySemanticsIdentical(mapping[index],target[index],flow_policies1,flow_policies2):
                return False
            index+=1
        # compare adjacency matrices
        nodes1=[]
        for policy in list(mapping):
            for node, attributes in zf_line1.node.iteritems():
                if attributes['label']==policy: nodes1.append(node)

        nodes2=[]
        for policy in list(target):
            for node, attributes in zf_line2.node.iteritems():
                if attributes['label']==policy: nodes2.append(node)

        A1 = nx.adjacency_matrix(zf_line1,nodes1)
        A2 = nx.adjacency_matrix(zf_line2,nodes2)

        return (A1==A2).all()

    def ArePolicySemanticsIdentical(self, policy1, policy2, flow_policies1, flow_policies2):
        if policy1 and policy2 and flow_policies1 and flow_policies2:
           flow_policy1 = flow_policies1[policy1]
           flow_policy2 = flow_policies2[policy2]
           return self.IsEquivalentFlowPolicy(flow_policy1,flow_policy2)

        return False

    def AreHighLevelPoliciesEqual(self, high_level_policy1, zone_conduit_model1, high_level_policy2, zone_conduit_model2):

        # generate canonical forms of policies
        canonical_policies1 = self.GenerateCanonicalForm(high_level_policy1)
        canonical_policies2 = self.GenerateCanonicalForm(high_level_policy2)

        # set indiv conduit policies
        zone_conduit_model1 = self.UpdateModelWithPolicyInfo(zone_conduit_model1, canonical_policies1)
        zone_conduit_model2 = self.UpdateModelWithPolicyInfo(zone_conduit_model2, canonical_policies2)

    def UpdateModelWithPolicyInfo(self, zone_conduit_model, canonical_policy):

        # add conduit labeling to model and create conduit property describing its policy
        return zone_conduit_model

    def LookupCanonicalPolicy(self, lookup_id):
        canonical_policy={}
        if lookup_id:
            for protocol,plot in self.canonical_policies.iteritems():
                for id, policy_rules in plot.iteritems():
                    plot_id="%s->%s"%(id[0],id[1])
                    if plot_id==lookup_id:
                        if protocol not in canonical_policy:
                            canonical_policy[protocol]=[]
                        canonical_policy[protocol]+=policy_rules

        return canonical_policy

    def IsEquivalentFlowPolicy(self, policy1, policy2):
        '''checks if policy1 is equivalent to policy2'''
        # check for default explicit - BLOCK ALL policy match
        if not policy1 and not policy2 : return True
        if policy1 and policy2:
            # check length first
            if len(policy1) == len(policy2):
               # then check length of intersection
               policy1_set=set(policy1)
               policy2_set=set(policy2)

               intersection=policy1_set & policy2_set
               # check result (can alternatively compare lengths)
               if intersection==policy1_set:
                   return True

        return False

    def is_range_inclusive(self,ports1,ports2):
        port1_start=ports1[0]
        port1_end=ports1[1]
        port2_start=ports2[0]
        port2_end=ports2[1]

        if port1_start >= port2_start and port1_end <= port2_end:
           return True

        return False

    def is_range_overlap(self,range1,range2):
        r1= set(range1)
        r2= set(range2)

        if len(r1)>0 and len(r2)>0 and r1.intersection(r2) is not None:
            return True

        return False

    def remove_overlap(self,range1, range2):
        ''' computes range1 - range2 '''

        r1= set(range1)
        r2= set(range2)

        return r1.difference(r2)

    def is_included(self,item,reference):
        ''' checks if item is included in reference'''
        first = item.split(';')
        second = reference.split(';')

        protocol1=self.GetProtocol(first)
        dport1=self.GetDestPorts(first)
        sport1=self.GetSourcePorts(first)
        state1=self.GetTcpState(protocol1,first)
        action1=self.GetRuleAction(first)

        protocol2=self.GetProtocol(second)
        dport2=self.GetDestPorts(second)
        sport2=self.GetSourcePorts(second)
        state2=self.GetTcpState(protocol1,second)
        action2=self.GetRuleAction(second)

        if protocol1==protocol2 and action1==action2 and state1==state2:
           if self.is_range_inclusive(dport1,dport2) and \
              self.is_range_inclusive(sport1,sport2):
              return True

        return False

    def is_included_in_rule_collection(self, first, rules):

        #print('first: %s'%first)
        first_items = first.split(';')
        protocol1= self.GetProtocol(first_items) #.split(';')
        dport1= self.GetDestPorts(first_items)
        sport1 = self.GetSourcePorts(first_items)
        state1 = self.GetTcpState(protocol1,first_items)
        action1 = self.GetRuleAction(first_items)
        #print('sport1: %s, dport1: %s'%(str(sport1), str(dport1)))

        dport_range1 = range(dport1[0],dport1[1])
        sport_range1 = range(sport1[0],sport1[1])

        #print('len(rules): %s'%(len(rules)))

        for rule in rules:
            #print('here1')
            #print('rule: %s'%rule)
            rule_items=rule.split(';')
            protocol2 = self.GetProtocol(rule_items) #.split(';')
            dport2 = self.GetDestPorts(rule_items)
            sport2 = self.GetSourcePorts(rule_items)
            state2 = self.GetTcpState(protocol2,rule_items)
            action2 = self.GetRuleAction(rule_items)
            #print('sport2: %s, dport2: %s'%(str(sport2), str(dport2)))

            #print('here2')
            if protocol1==protocol2 and action1==action2 and state1==state2 and (len(dport_range1)>0 or len(sport_range1)>0):
               dport_range2 = range(dport2[0],dport2[1])
               sport_range2 = range(sport2[0],sport2[1])

               #print('len: dport_range1: %s, sport_range1: %s, dport_range2: %s, sport_range2: %s'%(len(dport_range1),len(sport_range1), len(dport_range2), len(sport_range2)))

               if self.is_range_overlap(dport_range1,dport_range2) and \
                  self.is_range_overlap(sport_range1,sport_range2) :
                   #print('dport range overlap: (%s,%s), (%s,%s)'%(dport_range1[0],dport_range1[len(dport_range1)-1],dport_range2[0],dport_range2[len(dport_range2)-1]))
                   #print('sport range overlap: (%s,%s), (%s,%s)'%(sport_range1[0],sport_range1[len(dport_range1)-1],sport_range2[0],sport_range2[len(sport_range2)-1]))
                   print('rules overlap: %s, %s'%(str(first), str(rule)))

                   #print('test12345')
                   dport_range1 = list(self.remove_overlap(dport_range1,dport_range2))
                   #print('test123456')
                   sport_range1 = list(self.remove_overlap(sport_range1,sport_range2))
                   #print('test123457')

                   #print('dport range final: %s'%(dport_range1))
                   #print('sport range final: %s'%(sport_range1))


        if (dport_range1 is None or len(dport_range1)==0) and \
           (sport_range1 is None or len(sport_range1)==0):
            #print('here3')
            return True

        #print('dport range final: %s'%(dport_range1))
        #print('sport range final: %s'%(sport_range1))
        return False


    def IsInclusiveFlowPolicy(self, policy1, policy2):
        ''' checks if policy1 is a subset of policy2'''
        if policy1 is None and policy2 is None:
            return True
        elif policy1 is None:
            return False

        if policy1 is not None and policy2 is not None:
            # check length first
            if len(policy1) <= len(policy2):
                policy1_set=set(policy1)
                policy2_set=set(policy2)
                union = (policy1_set | policy2_set)
                if union==policy2_set:
                    #print('IsInclusiveFlowPolicy1::True')
                    #print('policy1: %s'%(str(policy1)))
                    #print('policy2: %s'%(str(policy2)))
                    return True
                else:
                    diff = list(policy1_set.difference(policy2_set))
                    for item in diff:
                        included=False
                        # check if included in a single rule
                        for reference in list(policy2_set):
                            if self.is_included(item,reference):
                               #print('IsInclusiveFlowPolicy::True:: item: %s, reference: %s'%(item, reference))
                               included=True
                        if not included:
                            #print('IsInclusiveFlowPolicy::False:: item: %s, reference: %s'%(item, reference))
                            # check if included in a collection of rules
                            if self.is_included_in_rule_collection(item,list(policy2_set)):
                                #print('is_included_in_rule_collection::True:: item: %s, reference: %s'%(item, str(list(policy2_set))))
                                included=True
                                #return True
                            #return False
                        if not included:
                            #print('IsInclusiveFlowPolicy2::False')
                            #print('policy1: %s'%(str(policy1)))
                            #print('policy2: %s'%(str(policy2)))
                            return False

                    #print('IsInclusiveFlowPolicy3::True')
                    #print('policy1: %s'%(str(policy1)))
                    #print('policy2: %s'%(str(policy2)))
                    return True

        #print('IsInclusiveFlowPolicy4::False')
        #print('policy1: %s'%(str(policy1)))
        #print('policy2: %s'%(str(policy2)))
        return False

    def GetFlowPolicyDifference(self, policy1, policy2):
        ''' computes semantic difference of policy1 and policy2'''
        if not policy1 and not policy2: return None
        if policy1 and policy2:
            policy1_set=set(policy1)
            policy2_set=set(policy2)
            # A-B = (A v B) ^ (A ^ B)'
            union = (policy1_set | policy2_set)
            intersection=policy1_set & policy2_set


            # check length first
            if len(policy1) <= len(policy2):

                union = (policy1_set | policy2_set)
                if union==policy2_set:
                    return True

        return False

    def IsEquivalentConduitPolicy(self, conduit1_policy, conduit2_policy):
        # check for default explicit - BLOCK ALL policy match
        if (not conduit1_policy) and (not conduit2_policy): return True
        # inter-zone flow policies need to match up
        if self.IsEquivalentFlowPolicy(conduit1_policy.Flow1,
                                       conduit2_policy.Flow1):
            if self.IsEquivalentFlowPolicy(conduit1_policy.Flow2,
                                           conduit2_policy.Flow2):
                return True
        elif self.IsEquivalentFlowPolicy(conduit1_policy.Flow1,
                                         conduit2_policy.Flow2):
            if self.IsEquivalentFlowPolicy(conduit1_policy.Flow2,
                                           conduit2_policy.Flow1):
                    return True

        return  False

    def IsInclusiveConduitPolicy(self, conduit1_policy, conduit2_policy):
        '''checks if conduit_policy1 is a subset of conduit_policy2'''
        if conduit1_policy and conduit2_policy:
            # inter-zone flow policies need to be inclusive
            if self.IsInclusiveFlowPolicy(conduit1_policy.Flow1,
                                          conduit2_policy.Flow1):
                if self.IsInclusiveFlowPolicy(conduit1_policy.Flow2,
                                               conduit2_policy.Flow2):
                    return True
            elif self.IsInclusiveFlowPolicy(conduit1_policy.Flow1,
                                             conduit2_policy.Flow2):
                if self.IsInclusiveFlowPolicy(conduit1_policy.Flow2,
                                               conduit2_policy.Flow1):
                        return True

        return False

    def GetCanonicalPolicyUnion(self, policy1, policy2):
        result={}
        if policy1 and policy2:
           for protocol, policy_rules in policy1.iteritems():
                if protocol not in result:
                   result[protocol]={}

                if protocol in policy2:
                    result[protocol] = list((set(policy_rules) | set(policy2[protocol])))
                else:
                    result[protocol] = (policy_rules)

           for protocol, policy_rules in policy2.iteritems():
                if protocol not in result:
                   result[protocol]={}

                if protocol not in policy1:
                    result[protocol] = (policy_rules)

        return result

    def GetCanonicalPolicyIntersection(self, policy1, policy2):
        result={}
        if policy1 and policy2:
           for protocol, policy_rules in policy1.iteritems():
                if protocol not in result:
                   result[protocol]={}

                if protocol in policy2:
                    result[protocol] = list((set(policy_rules) & set(policy2[protocol])))

        return result

    def ExcludeCanonicalPolicy(self, policy1, policy2):
        '''Excludes policy1 from policy2'''
        result={}
        if policy1 and policy2:
            if not self.IsInclusiveFlowPolicy(policy1, policy2):
                # error
                raise AlgebraicModelHelperException(properties.resources['canonical_policy_operation_invalid'])

            for protocol, policy_rules in policy2.iteritems():
                if protocol not in result:
                   result[protocol]=[]

                for rule in policy_rules:
                    if rule not in policy1[protocol]:
                        result[protocol].append(rule)

        return result

    def GetPlotDiff(self, plot1, plot2, key, plot1_only, plot2_only):
        '''gets the semantic diff between plot1 and plot2'''
        pass

    def AddPlot(self, rule, rule_attributes, plots, use_new_key=False):

        action=self.GetAttributeValue('action=', rule_attributes)
        qos_priority=self.GetAttributeValue('priority=', rule_attributes)
        mw_siglist_alert=self.GetAttributeValue('mw_sigs_alert=', rule_attributes)
        mw_siglist_block=self.GetAttributeValue('mw_sigs_block=', rule_attributes)
        service_chain1=self.GetAttributeValue('mb1=', rule_attributes)
        service_chain2=self.GetAttributeValue('mb2=', rule_attributes)

        #TODO
        log_event=self.GetAttributeValue('log_event=', rule_attributes)
        url_category=self.GetAttributeValue('url_category=', rule_attributes)

        protocol=self.GetProtocol(rule_attributes)
        sports=self.GetSourcePorts(rule_attributes)
        dports=self.GetDestPorts(rule_attributes)
        tcp_state=self.GetTcpState(protocol, rule_attributes)

        # debug dr new new
        if use_new_key:
            key = (str(rule[0].element_set), str(rule[1].element_set), action, tcp_state, qos_priority,
                  log_event, url_category, mw_siglist_alert, mw_siglist_block, service_chain1, service_chain2)
        else:
            key = (rule[0], rule[1], action, tcp_state, qos_priority,
                   log_event, url_category, mw_siglist_alert, mw_siglist_block, service_chain1, service_chain2)

        if not key in plots:
            plots[key]=[]

        service = Service(protocol,sports,dports,tcp_state)
        if len(plots[key])>0:
            match=False
            for svc in plots[key]:
                if svc.protocol==protocol and svc.sports==sports and svc.dports==dports and svc.tcp_state==tcp_state:
                    match=True
            if not match:
               plots[key].append(service)
        else:
            plots[key].append(service)

        return plots

    def GetAttributeValue(self, key, attributes):
        value=None
        for attr in attributes:
            if key in attr:
                value=attr
        return value

    def Create2DGraph(self, plots, protocol, val):
        ## from enums import Ipv4ProtocolNumbers
        from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point

        self.line_segments[protocol]={}
        line_segment_index=0
        self.indiv_points[protocol]={}
        self.polygon_vertices_original[protocol]={}
        fig_lookup=dict()

        for key, service_list in plots.iteritems():
            fig=plt.figure()
            ax = fig.add_subplot(111)
            plt.xlabel('Source port')
            plt.ylabel('Dest port')
            points=[]
            global_coordinates=[]
            rectangles=[]

            # plot all rectangles first
            #print('PlotRectangles..')
            rect=self.PlotRectangles(key,ax,service_list,protocol)
            if rect and len(rect)>0:
                rectangles.append(rect)

            # then plot lines and individual points
            for service in service_list:
                source_ports=[]
                dest_ports=[]

                if service.sports is not None:
                    source_start=service.sports[0]
                    source_end=service.sports[1]

                if not source_ports.__contains__((source_start,source_end)):
                    source_ports.append((source_start,source_end))

                if service.dports is not None:
                    dest_start=service.dports[0]
                    dest_end=service.dports[1]

                    if not dest_ports.__contains__((dest_start,dest_end)):
                        dest_ports.append((dest_start,dest_end))

                x=None
                y=None
                from itertools import repeat
                for source_pair in source_ports:
                    for dest_pair in dest_ports:
                        #print('source_pair: %s, dest_pair: %s'%(source_pair,dest_pair))
                        is_rectangle=True
                        #print('test111')
                        if source_pair[0]!=source_pair[1]:
                            x = np.arange(source_pair[0], source_pair[1]+1)
                        else:
                            # not a rectangular plot
                            is_rectangle=False
                            x = np.array([source_pair[0]])

                        if dest_pair[0]!=dest_pair[1]:
                            y = np.arange(dest_pair[0], dest_pair[1]+1)
                        else:
                            # not a rectangular plot
                            is_rectangle=False
                            y = np.array([dest_pair[0]])

                        #print('test222')
                        if not is_rectangle:
                            # check x and y array dimensions matchup
                            if len(x)<len(y):
                                x = np.array([a for item in x for a in repeat(item, len(y))])
                            elif len(y)<len(x):
                                y = np.array([b for item in y for b in repeat(item, len(x))])

                            #print('test333')
                            # create set of coordinate points
                            coordinates=zip(x, y)
                            #print('test444: %s'%coordinates)
                            # remove those already processed
                            if len(global_coordinates)>0:
                                #print('test555: %s'%(len(coordinates)))
                                a = set(coordinates)
                                b = set(global_coordinates)
                                coordinates = list(a.difference(b))
                                coordinates = sorted(coordinates, key=lambda tup: (tup[0],tup[1]) )
                                #if len(coordinates)>0:
                                #    print('coordinates:: %s'%coordinates)
                                #coordinates=[coordinate for coordinate in coordinates if coordinate not in global_coordinates]
                                #print('test777')

                            # check whether line or point intersect with the polygons
                            omit_completely=False
                            segments={}
                            ind=0
                            buffer=[]
                            #print('for loop..start')
                            if ((key in self.polygon_vertices_original[protocol]) and self.polygon_vertices_original[protocol][key]!=None):
                                for pg, vertices in self.polygon_vertices_original[protocol][key].iteritems():
                                    polygon=Polygon(vertices)
                                    if len(coordinates)>1:
                                        if polygon.contains(LineString(coordinates)):
                                           # point/line can be completely omitted
                                           omit_completely=True
                                           break
                                        elif polygon.intersects(LineString(coordinates)):
                                           # need to consider the non-overlapping component only
                                           intersection=self.ExtractIntersection(polygon,coordinates)
                                           segments = self.ExtractLineSegments(coordinates,segments,intersection)
                                           coordinates=[x for x in coordinates if x not in intersection]
                                        else:
                                           # no overlap- consider entire point/line
                                           continue

                                    elif len(coordinates)==1:
                                        if polygon.contains(Point(coordinates)):
                                           # point/line can be completely omitted
                                           omit_completely=True
                                           break
                                        elif polygon.intersects(Point(coordinates)):
                                           # need to consider the non-overlapping component only
                                           intersection=self.ExtractIntersection(polygon,coordinates)
                                           segments = self.ExtractLineSegments(coordinates,segments,intersection)
                                           coordinates=[x for x in coordinates if x not in intersection]
                                        else:
                                           # no overlap- consider entire point/line
                                           continue

                                if not (omit_completely or len(coordinates)==0):
                                    if len(segments.values())==0:
                                        global_coordinates += coordinates
                                        if len(coordinates)>1:
                                            if key not in self.line_segments[protocol]:
                                                self.line_segments[protocol][key]={}

                                            self.line_segments[protocol][key][line_segment_index]=coordinates
                                            line_segment_index+=1

                                        elif len(coordinates)==1:
                                            if key not in self.indiv_points[protocol]:
                                                self.indiv_points[protocol][key]=[]
                                            self.indiv_points[protocol][key].append(coordinates[0])

                                    else:
                                        global_coordinates += coordinates
                                        for segment in segments.values():
                                            if key not in self.line_segments[protocol]:
                                                self.line_segments[protocol][key]={}

                                            self.line_segments[protocol][key][line_segment_index]=segment
                                            line_segment_index+=1
                            else:
                                # no polygons to intersect with
                                if len(coordinates)>1:
                                            if key not in self.line_segments[protocol]:
                                                self.line_segments[protocol][key]={}

                                            # no merge required, add as seperate
                                            self.line_segments[protocol][key][line_segment_index]=coordinates
                                            line_segment_index+=1

                                elif len(coordinates)==1:
                                            if key not in self.indiv_points[protocol]:
                                                self.indiv_points[protocol][key]=[]
                                            self.indiv_points[protocol][key].append(coordinates[0])

                            #print('for loop..end')

            #print('line_segments..')
            if len(self.line_segments)>0 and key in self.line_segments[protocol]:
                for index, segment in self.line_segments[protocol][key].iteritems():
                    # include the remaining coordinates in plot
                    x=np.array([point[0] for point in segment])
                    y=np.array([point[1] for point in segment])
                    ax.plot(x, y)
                    ax.set_xlim(0,65535)
                    ax.set_ylim(0,65535)

            # process individual point overlaps
            #print('ProcessIndividualPointOverlaps..')
            self.ProcessIndividualPointOverlaps()
            if len(self.indiv_points)>0:
                for index, point in self.indiv_points[protocol][key].iteritems():
                    # include the remaining coordinates in plot
                    x=np.array([point[0]])
                    y=np.array([point[1]])
                    ax.plot(x, y)
                    ax.set_xlim(0,65535)
                    ax.set_ylim(0,65535)

            # setup parent folder
            parent_folder="tcp_plots%s"%val
            if protocol == Ipv4ProtocolNumbers.udp:
                parent_folder="udp_plots%s"%val

            # windows enable this
            #plt.savefig("c:\\bin\\%s\\%s_%s_%s.pdf"%(parent_folder,key[0],key[1],key[2]))
            # linux enable this
            #plt.savefig("/Users/a1070571/Documents/bin/%s/%s_%s_%s.pdf"%(parent_folder,key[0],key[1],key[2]))

            # debug dr
            # fig_lookup[(key[0],key[1])]=ax
            fig_lookup[key]=ax

        return fig_lookup

    def Create1DGraph(self, plots, protocol=None):

        if protocol:
            self.indiv_points[protocol]={}
        fig_lookup=dict()

        for key, service_list in plots.iteritems():
            fig=plt.figure()
            ax = fig.add_subplot(111)
            points=[]
            global_coordinates=[]

            for service in service_list:
                #print('%s'%(type(service)))
                if not protocol:
                    protocol=service.protocol
                    self.indiv_points[protocol]={}

                if key not in self.indiv_points[protocol]:
                   self.indiv_points[protocol][key]=[]

                #if protocol==Ipv4ProtocolNumbers.icmp:
                #    if service.Type.Value not in self.indiv_points[protocol][key]:
                #        self.indiv_points[protocol][key].append((service.Type.Value,0))
                #else:
                if protocol not in self.indiv_points[protocol][key]:
                    self.indiv_points[protocol][key].append((protocol,0))

        return fig_lookup

    def ProcessIndividualPointOverlaps(self):
        processed={}
        for protocol, plots in self.indiv_points.iteritems():

            for id, points in plots.iteritems():
                processed_points=[]
                if (protocol in self.line_segments and id in self.line_segments[protocol]):
                    # check for overlaps with line segments and other points
                    processed_points=self.ProcessSegmentPointOverlaps(points, self.line_segments[protocol][id].values())
                else:
                    # check for overlaps with other points only
                    for point in points:
                        if point not in processed_points:
                            processed_points.append(point)

                if protocol not in processed:
                    processed[protocol]={}
                if id not in processed[protocol]:
                    processed[protocol][id]={}

                processed[protocol][id] = {}
                index=0
                for point in processed_points:
                    processed[protocol][id][index] = point
                    index+=1

        self.indiv_points=processed

    def ProcessSegmentPointOverlaps(self, points, segments):
        from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point

        non_overlaps=[]
        for point in points:
            overlap_found=False
            for segment in segments:
                if LineString(segment).contains(Point(point[0], point[1])):
                   overlap_found=True
                   break

            if (not overlap_found) and (point not in non_overlaps):
               non_overlaps.append(point)

        return non_overlaps

    def ProcessLineSegmentOverlaps(self, protocol, plot_id):
        processed={}

        if (protocol in self.line_segments) and (plot_id in self.line_segments[protocol]):
            if protocol not in processed:
                processed[protocol]={}

            if id not in processed[protocol]:
                processed[protocol][plot_id]={}

            if len(self.line_segments[protocol][plot_id].values()) <=1:
                # one segment or less => cannot have overlaps
                processed[protocol][plot_id] = self.line_segments[protocol][plot_id]

            else:
                # can have overlaps
                processed_segments=self.ProcessSegments(self.line_segments[protocol][plot_id].values())
                index=0
                for segment in processed_segments:
                    processed[protocol][plot_id][index] = segment
                    index+=1

        if len(processed)>0:
            self.line_segments[protocol][plot_id]=processed[protocol][plot_id]

    def ProcessSegments(self, segments):
        rem_segments=[]
        merge_found=False
        for segment in segments:
            updated_coords=[]
            updated_index=[]
            rem_segments = [x for x in segments if x!=segment]
            if self.IsLineSegmentMergeRequired(segment, rem_segments, updated_coords, updated_index):
                rem_segments = [x for x in rem_segments if rem_segments.index(x)!=updated_index[0]]
                rem_segments.append(updated_coords)
                merge_found=True
                break

        if merge_found:
            rem_segments = self.ProcessSegments(rem_segments)
        else:
            rem_segments=segments

        return rem_segments

    def ExtractCanonicalForm(self):
        from matplotlib.path import Path
        ## from enums import Ipv4ProtocolNumbers
        import matplotlib.patches as patches

        self.dissected_polygons={}
        handled=[]

        for protocol, plot in self.polygon_vertices_original.iteritems():
            self.dissected_polygons[protocol]={}
            for plot_id, polygon_list in plot.iteritems():
                if polygon_list==None: continue
                fig=plt.figure()
                ax = fig.add_subplot(111)
                self.dissected_polygons[protocol][plot_id]=[]
                handled.append((protocol,plot_id))
                #print('here1')
                for poly, vertices in polygon_list.iteritems():
                    rectangles = self.PloygonToRectangles(vertices)
                    # retain for future use
                    self.dissected_polygons[protocol][plot_id] +=rectangles
                    for rectangle in rectangles:
                        # create 2D graph plots
                        rectangle.append(((0., 0.))) # ignored

                        codes = [Path.MOVETO,Path.LINETO,Path.LINETO,Path.LINETO,Path.CLOSEPOLY]

                        path = Path(rectangle, codes)
                        patch = patches.PathPatch(path, facecolor='orange', lw=1)
                        ax.add_patch(patch)
                        ax.set_xlim(0,65535)
                        ax.set_ylim(0,65535)

                        # re-construct HL policy
                        source_dest="%s -> %s"%(plot_id[0],plot_id[1])
                        service="%s, source_port=%s-%s, dest_port=%s-%s"%(Ipv4ProtocolNumbers.tcp,rectangle[0][0],rectangle[3][0],rectangle[0][1],rectangle[1][1])

                # incorporate line segments and indiv point of the plot
                #print('here2')
                if protocol in self.line_segments:
                    if plot_id in self.line_segments[protocol]:
                        for id, segment in self.line_segments[protocol][plot_id].iteritems():
                            if len(segment)>0:
                                if isinstance(segment[0],tuple):
                                    x=np.array([point[0] for point in segment])
                                    y=np.array([point[1] for point in segment])
                                    ax.plot(x, y)
                                    ax.set_xlim(0,65535)
                                    ax.set_ylim(0,65535)
                                elif isinstance(segment[0],list):
                                    for item in segment:
                                        x=np.array([point[0] for point in item])
                                        y=np.array([point[1] for point in item])
                                        ax.plot(x, y)
                                        ax.set_xlim(0,65535)
                                        ax.set_ylim(0,65535)

                if protocol in self.indiv_points:
                    if plot_id in self.indiv_points[protocol]:
                        for point in self.indiv_points[protocol][plot_id]:
                            x=np.array([point[0]])
                            y=np.array([point[1]])
                            ax.plot(x, y)
                            ax.set_xlim(0,65535)
                            ax.set_ylim(0,65535)

                # setup parent folder
                parent_folder="tcp_plots_dissected"
                if protocol == Ipv4ProtocolNumbers.udp:
                    parent_folder="udp_plots_dissected"

                # windows enable this
                # plt.savefig("c:\\bin\\%s\\%s_%s_%s.pdf"%(parent_folder,key[0],key[1],key[2]))
                # linux enable this
                #plt.savefig("/Users/a1070571/Documents/bin/%s/%s_%s_%s.pdf"%(parent_folder,plot_id[0],plot_id[1],plot_id[2]))

        # handle plots with line segments and points only
        #print('here3')
        for protocol, plots in self.line_segments.iteritems():
            for plot_id, segments in plots.iteritems():
                if not (protocol,plot_id) in handled:
                    handled.append((protocol,plot_id))
                    fig=plt.figure()
                    ax = fig.add_subplot(111)
                    for id, segment in segments.iteritems():
                        if len(segment)>0:
                            if isinstance(segment[0],tuple):
                                x=np.array([point[0] for point in segment])
                                y=np.array([point[1] for point in segment])
                                ax.plot(x, y)
                                ax.set_xlim(0,65535)
                                ax.set_ylim(0,65535)
                            elif isinstance(segment[0],list):
                                for item in segment:
                                    x=np.array([point[0] for point in item])
                                    y=np.array([point[1] for point in item])
                                    ax.plot(x, y)
                                    ax.set_xlim(0,65535)
                                    ax.set_ylim(0,65535)

                    if protocol in self.indiv_points:
                        if plot_id in self.indiv_points[protocol]:
                            for point in self.indiv_points[protocol][plot_id].values():
                                x=np.array([point[0]])
                                y=np.array([point[1]])
                                ax.plot(x, y)
                                ax.set_xlim(0,65535)
                                ax.set_ylim(0,65535)

                    # setup parent folder
                    parent_folder="tcp_plots_dissected"
                    if protocol == Ipv4ProtocolNumbers.udp:
                        parent_folder="udp_plots_dissected"

                    # windows enable this
                    # plt.savefig("c:\\bin\\%s\\%s_%s_%s.pdf"%(parent_folder,key[0],key[1],key[2]))
                    # linux enable this
                    #plt.savefig("/Users/a1070571/Documents/bin/%s/%s_%s_%s.pdf"%(parent_folder,plot_id[0],plot_id[1],plot_id[2]))

        # handle plots with points only
        #print('here4')
        for protocol, plots in self.indiv_points.iteritems():
            for plot_id,points in plots.iteritems():
                if not (protocol,plot_id) in handled:
                    handled.append((protocol,plot_id))
                    #fig=plt.figure()
                    #ax = fig.add_subplot(111)
                    #for point in points.values():
                        #x=np.array([point[0]])
                        #y=np.array([point[1]])
                        #ax.plot(x, y)
                        #ax.set_xlim(0,65535)
                        #ax.set_ylim(0,65535)

                    # setup parent folder
                    #parent_folder="tcp_plots_dissected"
                    #if protocol == Ipv4ProtocolNumbers.udp:
                        #parent_folder="udp_plots_dissected"

                    # windows enable this
                    # plt.savefig("c:\\bin\\%s\\%s_%s_%s.pdf"%(parent_folder,key[0],key[1],key[2]))
                    # linux enable this
                    #plt.savefig("/Users/a1070571/Documents/bin/%s/%s_%s_%s.pdf"%(parent_folder,plot_id[0],plot_id[1],plot_id[2]))

        # re-construct HL policy from the various components
        self.canonical_policies={}
        # from dissected polygons
        #print('here5')
        for protocol, plot in self.dissected_polygons.iteritems():
            if protocol not in self.canonical_policies:
                self.canonical_policies[protocol]={}
            protocol_name=Ipv4ProtocolNumbers.reverse_mapping[protocol]
            for id, rectangles in plot.iteritems():
                # debug dr
                canonical_id = id #(id[0],id[1])
                actions=self.GetFlowActions(id[2])
                qos_priority=id[4]
                middlebox1=id[9]
                middlebox2=id[10]
                tcp_states=None
                if id[3] is not None:
                    tcp_states=set(list(id[3]))
                mw_sigs_alert=None
                mw_sigs_block=None
                if id[7] is not None:
                    mw_sigs_alert=self.GetMalwareSignatures('mw_sigs_alert=',id[7])
                if id[8] is not None:
                    mw_sigs_block=self.GetMalwareSignatures('mw_sigs_block=',id[8])

                if canonical_id not in self.canonical_policies[protocol]:
                    self.canonical_policies[protocol][canonical_id]=[]
                policy_rules=[]
                for rectangle in rectangles:
                    # debug dr : supporting multiple flow actions (permit/deny/log etc)
                    service="protocol=%s; %s.dest_port=%s-%s; %s.source_port=%s-%s;"%(protocol,protocol_name,int(rectangle[0][1]),int(rectangle[1][1]),protocol_name,int(rectangle[0][0]),int(rectangle[3][0]))
                    #print('service details1:: %s'%service)
                    services=[]
                    # print('protocol= %s'%protocol)
                    if protocol==Ipv4ProtocolNumbers.tcp or protocol=='6':
                        for state in tcp_states:
                            temp = service + 'TCP.state=%s'%state
                            services.append(temp)
                    else:
                        services.append(service)
                    policy_rules += self.GetPolicyRules(mw_sigs_block,mw_sigs_alert,services,qos_priority,actions,middlebox1,middlebox2,id)

                #print('policy_rules1: %s'%policy_rules)
                self.canonical_policies[protocol][canonical_id]=policy_rules

        # from line segments
        #print('here6')
        for protocol, plot in self.line_segments.iteritems():
            if protocol not in self.canonical_policies:
                self.canonical_policies[protocol]={}
            protocol_name=Ipv4ProtocolNumbers.reverse_mapping[protocol]

            for id, segments in plot.iteritems():
                # debug dr
                canonical_id = id #(id[0],id[1])
                # debug dr : supporting multiple flow actions (permit/deny/log etc)
                actions=self.GetFlowActions(id[2])
                qos_priority=id[4]
                middlebox1=id[9]
                middlebox2=id[10]
                tcp_states=None
                if id[3] is not None:
                    tcp_states=set(list(id[3]))
                mw_sigs_alert=None
                mw_sigs_block=None
                if id[7] is not None:
                    mw_sigs_alert=self.GetMalwareSignatures('mw_sigs_alert=',id[7])
                if id[8] is not None:
                    mw_sigs_block=self.GetMalwareSignatures('mw_sigs_block=',id[8])
                if id not in self.canonical_policies[protocol]:
                    self.canonical_policies[protocol][canonical_id]=[]

                policy_rules=[]

                for segment in segments.values():
                    #print('protocol: %s, segment: %s'%(protocol,segment))
                    if len(segment)>0:
                        if isinstance(segment[0],tuple):
                            if self.IsHorizontalLine(segment):
                                service="protocol=%s; %s.dest_port=%s; %s.source_port=%s-%s;"%(protocol,protocol_name,int(segment[0][1]),protocol_name,int(segment[0][0]),int(segment[len(segment)-1][0]))
                                #print('service details22:: %s'%service)
                            else:
                                service="protocol=%s; %s.dest_port=%s-%s; %s.source_port=%s;"%(protocol,protocol_name,int(segment[0][1]),int(segment[len(segment)-1][1]),protocol_name,int(segment[0][0]))
                                #print('service details23:: %s'%service)
                            services=[]
                            #print('protocol2= %s'%protocol)
                            if protocol==Ipv4ProtocolNumbers.tcp or protocol=='6':
                                for state in tcp_states:
                                    temp = service + 'TCP.state=%s'%state
                                    services.append(temp)
                            else:
                                services.append(service)

                            policy_rules += self.GetPolicyRules(mw_sigs_block,mw_sigs_alert,services,qos_priority,actions,middlebox1,middlebox2,id)

                        elif isinstance(segment[0],list):
                            for item in segment:
                                    if self.IsHorizontalLine(item):
                                        service="protocol=%s; %s.dest_port=%s; %s.source_port=%s-%s;"%(protocol,protocol_name,int(item[0][1]),protocol_name,int(item[0][0]),int(item[len(item)-1][0]))
                                    else:
                                        service="protocol=%s; %s.dest_port=%s-%s; %s.source_port=%s;"%(protocol,protocol_name,int(item[0][1]),int(item[len(item)-1][1]),protocol_name,int(item[0][0]))
                                    #print('service details3:: %s'%service)
                                    services=[]
                                    #print('protocol3= %s'%protocol)
                                    if protocol==Ipv4ProtocolNumbers.tcp or protocol=='6':
                                        for state in tcp_states:
                                            temp = service + 'TCP.state=%s'%state
                                            services.append(temp)
                                    else:
                                        services.append(service)

                                    policy_rules += self.GetPolicyRules(mw_sigs_block,mw_sigs_alert,services,qos_priority,actions,middlebox1,middlebox2,id)

                #print('policy_rules2: %s'%policy_rules)
                if self.canonical_policies[protocol][canonical_id]==None:
                    self.canonical_policies[protocol][canonical_id]=policy_rules
                else:
                    self.canonical_policies[protocol][canonical_id]+=policy_rules

        # from individual points
        #print('here7')
        for protocol, plot in self.indiv_points.iteritems():
            if protocol not in self.canonical_policies:
                self.canonical_policies[protocol]={}
            protocol_name=Ipv4ProtocolNumbers.reverse_mapping[protocol]

            for id, points in plot.iteritems():
                canonical_id = id
                actions=self.GetFlowActions(id[2])
                qos_priority=id[4]
                middlebox1=id[9]
                middlebox2=id[10]
                tcp_states=None
                if id[3] is not None:
                    tcp_states=set(list(id[3]))
                mw_sigs_alert=None
                mw_sigs_block=None
                if id[7] is not None:
                    mw_sigs_alert=self.GetMalwareSignatures('mw_sigs_alert=',id[7])
                if id[8] is not None:
                    mw_sigs_block=self.GetMalwareSignatures('mw_sigs_block=',id[8])
                if id not in self.canonical_policies[protocol]:
                    self.canonical_policies[protocol][canonical_id]=[]
                policy_rules=[]

                for point in points.values():
                    #print('protocol4= %s'%protocol)
                    if protocol==Ipv4ProtocolNumbers.tcp or protocol=='6' or protocol==Ipv4ProtocolNumbers.udp or protocol=='17':
                        service="protocol=%s; %s.dest_port=%s; %s.source_port=%s;"%(protocol,protocol_name,int(point[1]),protocol_name,int(point[0]))
                    elif protocol==Ipv4ProtocolNumbers.icmp:
                        service="protocol=%s; %s.type=%s;"%(protocol,protocol_name,point)
                    else:
                        service="protocol=%s;"%(protocol)
                    #print('service details3:: %s'%service)

                    services=[]
                    #print('protocol5= %s'%protocol)
                    if protocol==Ipv4ProtocolNumbers.tcp or protocol=='6':
                        for state in tcp_states:
                            temp = service + 'TCP.state=%s;'%state
                            services.append(temp)
                    else:
                        services.append(service)

                    policy_rules += self.GetPolicyRules(mw_sigs_block,mw_sigs_alert,services,qos_priority,actions,middlebox1,middlebox2,id)

                #print('policy_rules3: %s'%policy_rules)
                if self.canonical_policies[protocol][canonical_id]==None:
                    self.canonical_policies[protocol][canonical_id]=policy_rules
                else:
                    self.canonical_policies[protocol][canonical_id]+=policy_rules

    def GetPolicyRules1(self,mw_sigs_block,mw_sigs_alert,services,qos_priority,actions,middlebox1,middlebox2,id):
        policy_rules=[]
        if mw_sigs_block is None and mw_sigs_alert is None:
            for svc in services:
                for action in actions:
                    if qos_priority is None:
                        if middlebox1 is None and middlebox2 is None:
                            policy_rule="%s->%s : {%s; %s;}"%(id[0],id[1],svc, action)
                        elif middlebox1 is not None and middlebox2 is None:
                            policy_rule="%s->%s : {%s; %s; %s;}"%(id[0],id[1],svc, middlebox1, action)
                        elif middlebox1 is not None and middlebox2 is not None:
                            policy_rule="%s->%s : {%s; %s; %s; %s;}"%(id[0],id[1],svc, middlebox1, middlebox2, action)
                    else:
                        if middlebox1 is None and middlebox2 is None:
                            policy_rule="%s->%s : {%s; %s; %s;}"%(id[0],id[1],svc, qos_priority, action)
                        elif middlebox1 is not None and middlebox2 is None:
                            policy_rule="%s->%s : {%s; %s; %s; %s;}"%(id[0],id[1],svc, qos_priority, middlebox1, action)
                        elif middlebox1 is not None and middlebox2 is not None:
                            policy_rule="%s->%s : {%s; %s; %s; %s; %s;}"%(id[0],id[1],svc, qos_priority, middlebox1, middlebox2, action)

                    if policy_rule not in policy_rules:
                        policy_rules.append(policy_rule)
        elif mw_sigs_block is not None and mw_sigs_alert is None:
            for mw_sig in mw_sigs_block:
                for svc in services:
                    for action in actions:
                        if qos_priority is None:
                            if middlebox1 is None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s;}"%(id[0],id[1],svc, mw_sig, action)
                            elif middlebox1 is not None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s; %s;}"%(id[0],id[1],svc, mw_sig, middlebox1, action)
                            elif middlebox1 is not None and middlebox2 is not None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s; %s; %s;}"%(id[0],id[1],svc, mw_sig, middlebox1, middlebox2, action)
                        else:
                            if middlebox1 is None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s; %s;}"%(id[0],id[1],svc, mw_sig, qos_priority, action)
                            elif middlebox1 is not None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s; %s; %s;}"%(id[0],id[1],svc, mw_sig, qos_priority, middlebox1, action)
                            elif middlebox1 is not None and middlebox2 is not None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s; %s; %s; %s;}"%(id[0],id[1],svc, mw_sig, qos_priority, middlebox1, middlebox2, action)

                        if policy_rule not in policy_rules:
                            policy_rules.append(policy_rule)
        elif mw_sigs_block is None and mw_sigs_alert is not None:
            for mw_sig in mw_sigs_alert:
                for svc in services:
                    for action in actions:
                        if qos_priority is None:
                            if middlebox1 is None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s;}"%(id[0],id[1],svc, mw_sig, action)
                            elif middlebox1 is not None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s; %s;}"%(id[0],id[1],svc, mw_sig, middlebox1, action)
                            elif middlebox1 is not None and middlebox2 is not None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s; %s; %s;}"%(id[0],id[1],svc, mw_sig, middlebox1, middlebox2, action)
                        else:
                            if middlebox1 is None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s; %s;}"%(id[0],id[1],svc, mw_sig, qos_priority, action)
                            elif middlebox1 is not None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s; %s; %s;}"%(id[0],id[1],svc, mw_sig, qos_priority, middlebox1, action)
                            elif middlebox1 is not None and middlebox2 is not None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s; %s; %s; %s;}"%(id[0],id[1],svc, mw_sig, qos_priority, middlebox1, middlebox2, action)

                        if policy_rule not in policy_rules:
                            policy_rules.append(policy_rule)
        else:
            for mw_sig1 in mw_sigs_alert:
                for mw_sig2 in mw_sigs_block:
                    for svc in services:
                        for action in actions:
                            if qos_priority is None:
                                if middlebox1 is None and middlebox2 is None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s;}"%(id[0],id[1],svc, mw_sig1, mw_sig2, action)
                                elif middlebox1 is not None and middlebox2 is None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s; %s;}"%(id[0],id[1],svc, mw_sig1, mw_sig2, middlebox1, action)
                                elif middlebox1 is not None and middlebox2 is not None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s; %s; %s;}"%(id[0],id[1],svc, mw_sig1, mw_sig2, middlebox1, middlebox2, action)
                            else:
                                if middlebox1 is None and middlebox2 is None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s; %s;}"%(id[0],id[1],svc, mw_sig1, mw_sig2, qos_priority, action)
                                elif middlebox1 is not None and middlebox2 is None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s; %s; %s;}"%(id[0],id[1],svc, mw_sig1, mw_sig2, qos_priority, middlebox1, action)
                                elif middlebox1 is not None and middlebox2 is not None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s; %s; %s; %s;}"%(id[0],id[1],svc, mw_sig1, mw_sig2, qos_priority, middlebox1, middlebox2, action)

                            if policy_rule not in policy_rules:
                                policy_rules.append(policy_rule)
        return policy_rules

    def GetPolicyRules(self,mw_sigs_block,mw_sigs_alert,services,qos_priority,actions,middlebox1,middlebox2,id):
        policy_rules=[]
        if mw_sigs_block is None and mw_sigs_alert is None:
            for svc in services:
                for action in actions:
                    if qos_priority is None:
                        if middlebox1 is None and middlebox2 is None:
                            policy_rule="%s->%s : {%s; %s;}"%(str(id[0]),str(id[1]),svc, action)
                        elif middlebox1 is not None and middlebox2 is None:
                            policy_rule="%s->%s : {%s; %s; %s;}"%(str(id[0]),str(id[1]),svc, middlebox1, action)
                        elif middlebox1 is not None and middlebox2 is not None:
                            policy_rule="%s->%s : {%s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, middlebox1, middlebox2, action)
                    else:
                        if middlebox1 is None and middlebox2 is None:
                            policy_rule="%s->%s : {%s; %s; %s;}"%(str(id[0]),str(id[1]),svc, qos_priority, action)
                        elif middlebox1 is not None and middlebox2 is None:
                            policy_rule="%s->%s : {%s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, qos_priority, middlebox1, action)
                        elif middlebox1 is not None and middlebox2 is not None:
                            policy_rule="%s->%s : {%s; %s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, qos_priority, middlebox1, middlebox2, action)

                    if policy_rule not in policy_rules:
                        policy_rules.append(policy_rule)
        elif mw_sigs_block is not None and mw_sigs_alert is None:
            for mw_sig in mw_sigs_block:
                for svc in services:
                    for action in actions:
                        if qos_priority is None:
                            if middlebox1 is None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, action)
                            elif middlebox1 is not None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, middlebox1, action)
                            elif middlebox1 is not None and middlebox2 is not None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, middlebox1, middlebox2, action)
                        else:
                            if middlebox1 is None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, qos_priority, action)
                            elif middlebox1 is not None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, qos_priority, middlebox1, action)
                            elif middlebox1 is not None and middlebox2 is not None:
                                policy_rule="%s->%s : {%s; mw_sigs_block=%s; %s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, qos_priority, middlebox1, middlebox2, action)

                        if policy_rule not in policy_rules:
                            policy_rules.append(policy_rule)
        elif mw_sigs_block is None and mw_sigs_alert is not None:
            for mw_sig in mw_sigs_alert:
                for svc in services:
                    for action in actions:
                        if qos_priority is None:
                            if middlebox1 is None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, action)
                            elif middlebox1 is not None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, middlebox1, action)
                            elif middlebox1 is not None and middlebox2 is not None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, middlebox1, middlebox2, action)
                        else:
                            if middlebox1 is None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, qos_priority, action)
                            elif middlebox1 is not None and middlebox2 is None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, qos_priority, middlebox1, action)
                            elif middlebox1 is not None and middlebox2 is not None:
                                policy_rule="%s->%s : {%s; mw_sigs_alert=%s; %s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig, qos_priority, middlebox1, middlebox2, action)

                        if policy_rule not in policy_rules:
                            policy_rules.append(policy_rule)
        else:
            for mw_sig1 in mw_sigs_alert:
                for mw_sig2 in mw_sigs_block:
                    for svc in services:
                        for action in actions:
                            if qos_priority is None:
                                if middlebox1 is None and middlebox2 is None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig1, mw_sig2, action)
                                elif middlebox1 is not None and middlebox2 is None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig1, mw_sig2, middlebox1, action)
                                elif middlebox1 is not None and middlebox2 is not None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig1, mw_sig2, middlebox1, middlebox2, action)
                            else:
                                if middlebox1 is None and middlebox2 is None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig1, mw_sig2, qos_priority, action)
                                elif middlebox1 is not None and middlebox2 is None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig1, mw_sig2, qos_priority, middlebox1, action)
                                elif middlebox1 is not None and middlebox2 is not None:
                                    policy_rule="%s->%s : {%s; mw_sigs_alert=%s; mw_sigs_block=%s; %s; %s; %s; %s;}"%(str(id[0]),str(id[1]),svc, mw_sig1, mw_sig2, qos_priority, middlebox1, middlebox2, action)

                            if policy_rule not in policy_rules:
                                policy_rules.append(policy_rule)
        return policy_rules


    def GetFlowActions(self, desc):
        from enums import IpFlowAction
        desc = desc.replace('action=','')
        result=[]
        if desc==IpFlowAction.reverse_mapping[IpFlowAction.allow] or desc=='accept':
            result.append(('action=%s'%IpFlowAction.allow))
        elif desc==IpFlowAction.reverse_mapping[IpFlowAction.deny] or desc=='drop':
            result.append(('action=%s'%IpFlowAction.deny))
        elif desc==IpFlowAction.reverse_mapping[IpFlowAction.log]:
            result.append(('action=%s'%IpFlowAction.log))
        elif desc==IpFlowAction.reverse_mapping[IpFlowAction.allow_and_log]:
            result.append(('action=%s'%IpFlowAction.allow))
            result.append(('action=%s'%IpFlowAction.log))
        elif desc==IpFlowAction.reverse_mapping[IpFlowAction.deny_and_log]:
            result.append(('action=%s'%IpFlowAction.deny))
            result.append(('action=%s'%IpFlowAction.log))

        return result

    def GetMalwareSignatures(self, key, desc):
        desc = desc.replace(key,'')
        desc = desc.replace('{','')
        desc = desc.replace('}','')

        return desc.split(',')

    def GetTcpStates(self, desc):
        from enums import TcpStates
        desc = desc.replace('TCP.state=','')
        result=[]
        if desc==TcpStates.reverse_mapping[TcpStates.new]:
            result.append(('TCP.state=%s'%TcpStates.new))
        elif desc==TcpStates.reverse_mapping[TcpStates.established]:
            result.append(('TCP.state=%s'%TcpStates.established))
        elif desc==TcpStates.reverse_mapping[TcpStates.any]:
            result.append(('TCP.state=%s'%TcpStates.new))
            result.append(('TCP.state=%s'%TcpStates.established))

        return result

    def IsHorizontalLine(self, segment):
        if len(segment) > 1:
            first_coord=segment[0]
            last_coord=segment[len(segment)-1]
            # compare x coordinates
            if first_coord[0]==last_coord[0]:
                # vertical line
                return False
            # compare y coordinates
            elif first_coord[1]==last_coord[1]:
                # horizontal line
                return True
            else:
                # not horizontal/vertical
                return False
        else:
            raise ValueError("segment", properties.resources['arguments_invalid'])

    def IsLineSegmentMergeRequired(self, coordinates, existing_segments, updated_coordinates, merge_segment_index):
        '''Checks whether a partilcular line segment can be merged with existing line segments to form a single line'''
        result=False
        from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point

        if len(coordinates)>1 and len(existing_segments)>0:
                if self.IsHorizontalLine(coordinates):
                   index=0
                   for segment in existing_segments:
                       # consider only horizontal segments
                       if self.IsHorizontalLine(segment):
                           line1 = LineString(coordinates)
                           line2 = LineString(segment)
                           composite = line1.union(line2)
                           coords = composite.boundary

                           if len(coords)==2:
                               # intersecting lines, merged to one
                               updated_coordinates+=[(coords[0].x,coords[0].y),(coords[1].x,coords[0].y)]
                               merge_segment_index.append(index)
                               result=True
                               break
                           else:
                               # check if Y values are same
                               if segment[0][1]== coordinates[0][1]:
                                   # could be one or two line segments
                                   x0=segment[0][0]
                                   x1=segment[len(segment)-1][0]
                                   x2=coordinates[0][0]
                                   x3=coordinates[len(coordinates)-1][0]

                                   if x2-x1==1:
                                       # forms a single continuous line
                                       updated_coordinates+=[(x0,segment[0][1]),(x3,segment[0][1])]
                                       merge_segment_index.append(index)
                                       result=True
                                       break
                                   elif x1-x3==1:
                                       # forms a single continuous line
                                       updated_coordinates+=[(x2,segment[0][1]),(x0,segment[0][1])]
                                       merge_segment_index.append(index)
                                       result=True
                                       break
                       index+=1
                else:
                   index=0
                   for segment in existing_segments:
                       # consider only vertical segments
                       if not self.IsHorizontalLine(segment):
                           line1 = LineString(coordinates)
                           line2 = LineString(segment)
                           composite = line1.union(line2)
                           coords = composite.boundary
                           if len(coords)==2:
                               # intersecting lines, merged to one
                               updated_coordinates+=[(coords[0].x,coords[0].y),(coords[1].x,coords[1].y)]
                               merge_segment_index.append(index)
                               result=True
                               break
                           else:
                               # check if X values are same
                               if segment[0][0]== coordinates[0][0]:
                                   # could be one or two line segments
                                   y0=segment[0][1]
                                   y1=segment[len(segment)-1][1]
                                   y2=coordinates[0][1]
                                   y3=coordinates[len(coordinates)-1][1]

                                   if y2-y1==1:
                                       # forms a single continuous line
                                       updated_coordinates+=[(segment[0][0],y0),(segment[0][0],y3)]
                                       merge_segment_index.append(index)
                                       result=True
                                       break
                                   elif y1-y3==1:
                                       # forms a single continuous line
                                       updated_coordinates+=[(segment[0][0],y2),(segment[0][0],y0)]
                                       merge_segment_index.append(index)
                                       result=True
                                       break
                       index+=1

        return  result

    def PloygonToRectangles(self, poly_vertices):
        rectangles=[]
        # find p_k - lowest, leftmost vertex
        p_k = self.GetLowestLeftmostCoord(poly_vertices)
        if p_k!=None:
            # find p_l - next lowest, leftmost vertex
            updated = [v for v in poly_vertices if v!=p_k]
            p_l = self.GetLowestLeftmostCoord(updated)
            if p_l!=None:
                x_range=(p_k[0],p_l[0])
                y_range=(p_k[1]+1,65535)
                # find p_m - lowest, leftmost with y_value > y_value(p_k) and  x_value(p_k) <= x_value <= x_value (p_l)
                p_m = self.GetLowestLeftmostCoord(updated, x_range, y_range)
                if p_m is not None:
                    rectangle_to_cut=[p_k,(p_k[0],p_m[1]),(p_l[0],p_m[1]),p_l]
                    updated = self.CutRectangle(poly_vertices, rectangle_to_cut)
                    rectangles.append(rectangle_to_cut)
                    if len(updated)>0:
                        # recursive call
                        rectangles+=self.PloygonToRectangles(updated)

        return rectangles

    def CutRectangle(self, poly_vertices, rectangle_to_cut):
        if len(rectangle_to_cut)>0 and len(poly_vertices)>0:
            for vertex in rectangle_to_cut:
                if vertex in poly_vertices:
                    poly_vertices=[v for v in poly_vertices if v!=vertex]
                else:
                    poly_vertices.append(vertex)

        return poly_vertices

    def GetLowestLeftmostCoord(self, vertices, x_range=None, y_range=None):
        if len(vertices)>0:
            y_lowest = None
            for vertice in vertices:
                if y_range != None:
                    if vertice[1] >= y_range[0] and vertice[1] <= y_range[1]:
                        # vertice in required y_range
                        if y_lowest is None: y_lowest = vertice[1]
                        else:
                            if y_lowest > vertice[1]: y_lowest = vertice[1]

                else:
                    if y_lowest is None: y_lowest = vertice[1]
                    else:
                        if y_lowest > vertice[1]: y_lowest = vertice[1]

            if y_lowest!=None:
                # get all vertices with y_lowest
                eligible_points = [v for v in vertices if v[1]==y_lowest]
                # select leftmost from these
                x_lowest_leftmost = None
                for point in eligible_points:
                    if x_range!=None:
                        if point[0] >= x_range[0] and point[0] <= x_range[1]:
                            # point in required x_range
                            if x_lowest_leftmost is None: x_lowest_leftmost = point[0]
                            else:
                                if x_lowest_leftmost > point[0]: x_lowest_leftmost = point[0]

                    else:
                        if x_lowest_leftmost is None: x_lowest_leftmost = point[0]
                        else:
                            if x_lowest_leftmost > point[0]: x_lowest_leftmost = point[0]
                if x_lowest_leftmost!=None:
                    # pick lowest leftmost point
                    p_lowest_leftmost = [point for point in eligible_points if (point[0]==x_lowest_leftmost and point[1]==y_lowest)]
                    if len(p_lowest_leftmost)>1:
                        # Error
                        print ('TODO: raise error')
                    return p_lowest_leftmost[0]

        return None

    def ExtractLineSegments(self, coordinates, original_segments, intersection):
       new_segments={}
       ind=0
       buffer=[]
       if len(original_segments)==0:
           for coordinate in coordinates:
               if coordinate in intersection:
                   if len(buffer)>0:
                       new_segments[ind]=buffer
                       ind+=1
                       buffer=[]
               else:
                   buffer.append(coordinate)

           # append any end bits to a new segment
           if len(buffer)>0:
              new_segments[ind]=buffer
       else:
           for segment in original_segments.values():
               extracted=self.ExtractLineSegments(segment,{},intersection)
               for extract in extracted.values():
                   new_segments[ind]=extract
                   ind+=1

       return new_segments

    def ExtractIntersection(self, polygon, coordinates):
        from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point

        intersection=None
        geom=polygon.intersection(LineString(coordinates))
        if geom.type=="LineString":
           intersection=set(list(geom.coords))
        elif geom.type=="MultiLineString":
            line_int=[]
            for elt in geom:
                line_int += list(elt.coords)
            intersection=set(line_int)

        return intersection

    def PlotRectangles(self, id, ax, service_list, protocol):
        from shapely.geometry import Polygon, MultiPolygon, MultiLineString, LineString, Point
        rectangles=[]
        rectangle_coordinates=[]
        self.polygon_vertices_original[protocol][id]=None
        for service in service_list:
            source_ports=[]
            dest_ports=[]

            if service.sports is not None:
                source_start=service.sports[0]
                source_end=service.sports[1]

                if not source_ports.__contains__((source_start,source_end)):
                    source_ports.append((source_start,source_end))

            if service.dports is not None:
                dest_start=service.dports[0]
                dest_end=service.dports[1]

                if not dest_ports.__contains__((dest_start,dest_end)):
                    dest_ports.append((dest_start,dest_end))

            x=None
            y=None
            from itertools import repeat
            for source_pair in source_ports:
                for dest_pair in dest_ports:
                    is_rectangle=True
                    if source_pair[0]!=source_pair[1]:
                        x = np.arange(source_pair[0], source_pair[1]+1)
                    else:
                        # not a rectangular plot
                        is_rectangle=False
                        x = np.array([source_pair[0]])

                    if dest_pair[0]!=dest_pair[1]:
                        y = np.arange(dest_pair[0], dest_pair[1]+1)
                    else:
                        # not a rectangular plot
                        is_rectangle=False
                        y = np.array([dest_pair[0]])

                    if is_rectangle:

                        polygon=Polygon([
                            (x[0], y[0]), # left, bottom
                            (x[0], y[len(y)-1]), # left, top
                            (x[len(x)-1], y[len(y)-1]), # right, top
                            (x[len(x)-1], y[0]) # right, bottom
                            ])

                        rectangle_x_y_values=(x[0],x[len(x)-1],y[0],y[len(y)-1])
                        if not rectangle_coordinates.__contains__(rectangle_x_y_values):
                            rectangle_coordinates.append(rectangle_x_y_values)
                            rectangles.append(polygon)

        # construct polygons from rectangles
        if len(rectangles)>0:
            geom=rectangles[0]
            for rect in rectangles:
                if rect != geom:
                    geom=geom.union(rect)

            # get exterior coordinates of each disjoint polygon - can include non-vertices (e.g., multiple points along a polygon edge)
            polygon_coordinates=self.ExtractPolygonCoords(geom)

            # filter-out non vertices
            polygon_vertices=self.RemovePolyNonVertices(polygon_coordinates)
            # retain copy
            self.polygon_vertices_original[protocol][id]=copy.deepcopy(polygon_vertices)#dict(polygon_vertices)

            # create 2D graph plots
            from matplotlib.path import Path
            import matplotlib.patches as patches

            for polygon, vertices in polygon_vertices.iteritems():
                vertices.append(((0., 0.))) # ignored

                codes = [Path.MOVETO]
                index=0
                while (index < len(vertices)-2):
                    codes.append(Path.LINETO)
                    index +=1
                codes.append(Path.CLOSEPOLY)

                path = Path(vertices, codes)
                patch = patches.PathPatch(path, facecolor='orange', lw=1)
                ax.add_patch(patch)
                ax.set_xlim(0,65535)
                ax.set_ylim(0,65535)

            # these vertices can now be supplied to the PTR algorithm

        return rectangles

    def ExtractPolygonCoords(self, geom):
        if geom.type == 'Polygon':
            exterior_coords = {}
            exterior_coords[geom._geom] = geom.exterior.coords[:] #._geom
        elif geom.type == 'MultiPolygon':
            exterior_coords = {}
            for part in geom:
                if part.type == 'Polygon':
                    exterior_coords[part._geom] = part.exterior.coords[:] #._geom
                elif part.type == 'MultiPolygon':
                    result=self.ExtractPolygonCoords(part) # recursive call
                    for part, coords in result.iteritems():
                        exterior_coords[part._geom]=coords #._geom
        return exterior_coords

    def RemovePolyNonVertices(self, poly_coordinates):
        poly_vertices={}
        for poly,coordinates in poly_coordinates.iteritems():
            index=0
            poly_vertices[poly]=[]
            start=coordinates[index]
            # starting point is a vertice?
            poly_vertices[poly].append(start)

            while (index+2) < len(coordinates):
                middle=coordinates[index+1]
                end=coordinates[index+2]

                # check if middle coordinate is redundant
                if (start[1]==middle[1] and middle[1]==end[1]):
                    # all 3 points have same Y coordinate - on a straight line, so omit
                    index+=1
                elif (start[0]==middle[0] and middle[0]==end[0]):
                    # all 3 points have same X coordinate - on a straight line, so omit
                    index+=1
                else:
                    # the 3 points do not align, so middle point is valid
                    poly_vertices[poly].append(middle)
                    # reset starting point
                    start=middle
                    index+=1

        return poly_vertices

class Service(object):

    def __init__(self, protocol, sports, dports, tcp_state):
        self.protocol = protocol
        self.sports = sports
        self.dports = dports
        self.tcp_state=tcp_state

class MappingHolder(object):

    def __init__(self, mapping):
        self.mapping = mapping


























