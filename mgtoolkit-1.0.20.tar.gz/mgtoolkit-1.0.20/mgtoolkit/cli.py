# -*- coding: utf-8 -*-

import click


# noinspection PyUnusedLocal
@click.command()
def main(args=None):
    """Console script for mgtoolkit"""
    click.echo("Replace this message by putting your code into "
               "mgtoolkit.cli.main")
    click.echo("See click documentation at http://click.pocoo.org/")


if __name__ == "__main__":
    main()
