import unittest
from mgtoolkit.library import Metagraph, ConditionalMetagraph, Edge, MetagraphHelper, Metapath

# noinspection PyAttributeOutsideInit
class RunTests(unittest.TestCase):

    # noinspection PyPep8Naming
    def setUp(self):
        import numpy
        t = numpy.version

        self.generating_set1 = {1, 2, 3, 4, 5, 6, 7}
        self.mg1 = Metagraph(self.generating_set1)
        self.mg1.add_edges_from([Edge({1}, {2, 3}), Edge({1, 4}, {5}), Edge({3}, {6, 7})])

        self.variable_set = set(range(1, 8))
        self.propositions_set = {'p1', 'p2'}
        self.cmg1 = ConditionalMetagraph(self.variable_set, self.propositions_set)
        self.cmg1.add_edges_from([Edge({1, 2}, {3, 4}, attributes=['p1']), Edge({2}, {4, 6}, attributes=['p2']),
                                  Edge({3, 4}, {5}, attributes=['p1', 'p2']), Edge({4, 6}, {5, 7}, attributes=['p1'])])

    '''
    def test_mg_creation(self):
        self.assertEqual(len(self.mg1.edges), 3)
        self.assertEqual(len(self.mg1.nodes), 6)

    def test_mg_adjacency_matrix(self):
        adj_matrix = self.mg1.adjacency_matrix()
        row_count = adj_matrix.shape[0]
        col_count = adj_matrix.shape[1]
        row1 = adj_matrix[0, :]
        col1 = adj_matrix[:, 0]
        self.assertEqual(row_count, 7)
        self.assertEqual(col_count, 7)
        self.assertEqual(len(row1.tolist()[0]), 7)
        self.assertEqual(len(col1.tolist()), 7)
        self.assertEqual(row1.tolist()[0][1][0].coinputs, None)
        self.assertEqual(row1.tolist()[0][1][0].cooutputs, {3})
        self.assertEqual(row1.tolist()[0][1][0].edges.invertex, {1})
        self.assertEqual(row1.tolist()[0][1][0].edges.outvertex, {2, 3})

    def test_mg_incidence_matrix(self):
        incidence_m = self.mg1.incidence_matrix()
        row_count = incidence_m.shape[0]
        col_count = incidence_m.shape[1]
        row1 = incidence_m[0, :]
        col1 = incidence_m[:, 0]
        self.assertEqual(row_count, 7)
        self.assertEqual(col_count, 3)
        self.assertEqual(len(row1.tolist()[0]), 3)
        self.assertEqual(len(col1.tolist()), 7)
        self.assertEqual(row1.tolist()[0], [-1, -1, None])

    def test_mg_closure(self):
        a_star = self.mg1.get_closure()
        row_count = a_star.shape[0]
        col_count = a_star.shape[1]
        row1 = a_star[0, :]
        col1 = a_star[:, 0]
        self.assertEqual(row_count, 7)
        self.assertEqual(col_count, 7)
        self.assertEqual(len(row1.tolist()[0]), 7)
        self.assertEqual(len(col1.tolist()), 7)
        self.assertEqual(row1.tolist()[0][3], None)
        self.assertEqual(row1.tolist()[0][4][0].coinputs, {4})
        self.assertEqual(row1.tolist()[0][4][0].cooutputs, None)
        self.assertEqual(row1.tolist()[0][4][0].edges.invertex, {1, 4})
        self.assertEqual(row1.tolist()[0][4][0].edges.outvertex, {5})'''

    def test_mg_metapaths(self):
        return
        source = {1}
        target = {7}
        metapaths = self.mg1.get_all_metapaths_from(source, target)

        self.assertEqual(len(metapaths), 1)
        self.assertEqual(metapaths[0].source, {1})
        self.assertEqual(metapaths[0].target, {7})

        #self.assertEqual(metapaths[0].edge_list[0].invertex, {1})
        #self.assertEqual(metapaths[0].edge_list[0].outvertex, {2, 3})
        #self.assertEqual(metapaths[0].edge_list[1].invertex, {3})
        #self.assertEqual(metapaths[0].edge_list[1].outvertex, {6, 7})

        edge_dominant = None
        input_dominant = None
        dominant = None
        if len(metapaths) > 0:
            edge_dominant = self.mg1.is_edge_dominant_metapath(metapaths[0])
            input_dominant = self.mg1.is_input_dominant_metapath(metapaths[0])
            dominant = self.mg1.is_dominant_metapath(metapaths[0])

        self.assertEqual(edge_dominant, True)
        self.assertEqual(input_dominant, True)
        self.assertEqual(dominant, True)

        metapaths2 = self.mg1.get_all_metapaths_from({1, 3}, {7})
        metapath_dominates = metapaths[0].dominates(metapaths2[0])

        self.assertEqual(metapath_dominates, True)

    '''
    def test_edge_properties(self):
        source = {1}
        target = {7}
        metapaths = self.mg1.get_all_metapaths_from(source, target)
        redundant = self.mg1.is_redundant_edge(Edge({1}, {2, 3}), metapaths[0], source, target)
        self.assertEqual(redundant, False)

        edge_list = [Edge({1}, {2, 3})]
        is_cutset = self.mg1.is_cutset(edge_list, source, target)
        is_bridge = self.mg1.is_bridge(edge_list, source, target)
        self.assertEqual(is_cutset, True)
        self.assertEqual(is_bridge, True)

    def test_mg_projection(self):
        generating_set2 = {1, 2, 3, 4, 5, 6, 7, 8}
        mg2 = Metagraph(generating_set2)
        mg2.add_edges_from([Edge({1}, {3, 4}), Edge({3}, {6}), Edge({2}, {5}), Edge({4, 5}, {7}), Edge({6, 7}, {8})])
        generator_subset = {1, 2, 6, 7, 8}
        projection = mg2.get_projection(generator_subset)

        self.assertEqual(len(projection.edges), 4)
        self.assertEqual(len(projection.nodes), 7)

    def test_mg_inverse(self):
        generating_set2 = {1, 2, 3, 4, 5, 6, 7, 8}
        mg2 = Metagraph(generating_set2)
        mg2.add_edges_from([Edge({1, 2}, {3, 4}), Edge({3, 4, 5}, {6, 8}), Edge({1}, {5}), Edge({6, 7}, {1})])
        inverse = mg2.get_inverse()

        self.assertEqual(len(inverse.edges), 6)
        self.assertEqual(len(inverse.nodes), 6)

    def test_mg_efm(self):
        generating_set2 = {1, 2, 3, 4, 5, 6, 7, 8}
        mg2 = Metagraph(generating_set2)
        mg2.add_edges_from([Edge({1, 2}, {3, 4}), Edge({3, 4, 5}, {6, 8}), Edge({1}, {5}), Edge({6, 7}, {1})])
        generator_subset = {2, 4, 7}
        efm = mg2.get_efm(generator_subset)

        self.assertEqual(len(efm.edges), 3)
        self.assertEqual(len(efm.nodes), 3)

    def test_cmg_creation(self):
        self.assertEqual(len(self.cmg1.edges), 4)
        self.assertEqual(len(self.cmg1.nodes), 8)

    def test_cmg_context(self):
        true_props = {'p1'}
        false_props = {'p2'}
        context = self.cmg1.get_context(true_props, false_props)
        self.assertEqual(len(context.edges), 2)
        self.assertEqual(len(context.nodes), 4)

    def test_cmg_properties(self):
        source = {1, 3}
        target = {4}
        logical_expressions = ['p1 | p2']
        interpretations = [[('p1', True), ('p2', False)]]
        connected = self.cmg1.is_connected(source, target, logical_expressions, interpretations)
        fully_connected = self.cmg1.is_fully_connected(source, target, logical_expressions, interpretations)
        redundantly_connected = self.cmg1.is_redundantly_connected(source, target, logical_expressions, interpretations)
        non_redundant = self.cmg1.is_non_redundant(logical_expressions, interpretations)

        self.assertEqual(connected, False)
        self.assertEqual(fully_connected, False)
        self.assertEqual(redundantly_connected, True)
        self.assertEqual(non_redundant, True)

    def test_from_textbook(self):
        generating_set1 = {1, 2, 3, 4, 5, 6, 7, 8, 9}
        mg1 = Metagraph(generating_set1)
        mg1.add_edges_from([Edge({1}, {2, 3}), Edge({1, 4}, {5}), Edge({3}, {7}), Edge({5, 2}, {6}),
                            Edge({6, 7}, {9}), Edge({3, 4, 8}, {9}), Edge({4, 8}, {1, 5})])
        #a1=mg1.adjacency_matrix()
        #a_star1= mg1.get_closure()
        #incidence_matrix= mg1.incidence_matrix()

        metapaths1 = mg1.get_all_metapaths_from({1, 4}, {6})

        # check metapath dominance
        if len(metapaths1) > 0:
            edge_dominant = mg1.is_edge_dominant_metapath(metapaths1[0])
            input_dominant = mg1.is_input_dominant_metapath(metapaths1[0])
            dominant = mg1.is_dominant_metapath(metapaths1[0])

            self.assertEqual(edge_dominant, True)
            self.assertEqual(input_dominant, True)
            self.assertEqual(dominant, True)

        metapaths3 = mg1.get_all_metapaths_from({1, 4}, {5, 6})
        redundant1 = mg1.is_redundant_edge(Edge({1, 4}, {5}), metapaths3[0], {1, 4}, {5, 6})
        redundant2 = mg1.is_redundant_edge(Edge({4, 8}, {5, 6}), metapaths3[0], {4, 8}, {5, 6})

        self.assertEqual(redundant1, False)
        self.assertEqual(redundant2, True)

        source = {4, 8}
        target = {7}
        edge_list1 = [Edge({4, 8}, {1})]
        edge_list2 = [Edge({1}, {2, 3})]
        is_cutset = mg1.is_cutset(edge_list1, source, target)
        is_bridge = mg1.is_bridge(edge_list2, source, target)

        self.assertEqual(is_cutset, False)
        self.assertEqual(is_bridge, True)

        purpose_manage = {'purpose=create', 'purpose=view', 'purpose=edit', 'purpose=delete'}

        '''

    def test_gdpr_compliance(self):
        # construct GDPR policy MG
        data_recipients = {'data_subject_employer', 'individuals', 'hc_providers', 'third_parties'}
        personal_data = {'profile', 'medical_documents', 'other_data'}
        subject_age_group = {'subject_age<adult_age', 'subject_age>=adult_age'}
        purpose_of_proc = {'purpose=view', 'purpose=manage', 'purpose=research', 'purpose=subject_interest', 'purpose=public_interest', 'purpose=official_authority'}

        variables_set = {'data_subject', 'controller', 'processor', 'supervisory_authority', 'DPO'}.union(personal_data).union(data_recipients)
        propositions_set = {'carer_consent=true', 'subject_consent=true', 'my_data_stored=true', 'inform_purpose=true', 'retention_duration=default',
                            'request_my_data_copy=true', 'no_data_available=true', 'erase_my_data=true',
                            'subject_rights_affected=true','subject_freedom_affected=true','data_breach_notification_delay_hrs<1',
                            'data_breach_notification_delay_hrs<72'}.union(subject_age_group).union(purpose_of_proc)
        generating_set = variables_set.union(propositions_set)

        edge_list = []
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=manage','subject_age<adult_age','carer_consent=true','retention_duration=default']))
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=manage','subject_age>=adult_age','subject_consent=true','retention_duration=default']))

        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=view','subject_age<adult_age','carer_consent=true','retention_duration=default']))
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=view','subject_age>=adult_age','subject_consent=true','retention_duration=default']))

        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=research','subject_age<adult_age','carer_consent=true','retention_duration=default']))
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=research','subject_age>=adult_age','subject_consent=true','retention_duration=default']))

        edge_list.append(Edge(personal_data,{'data_subject_employer'},attributes=['purpose=subject_interest','retention_duration=default']))
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=public_interest', 'retention_duration=default']))
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=official_authority', 'retention_duration=default']))

        cmg_gdpr = ConditionalMetagraph(variables_set, propositions_set)
        cmg_gdpr.add_edges_from(edge_list)

        filepath='/Users/a1070571/Documents/ITS/cmg_gdpr.dot'
        MetagraphHelper().generate_visualisation(edge_list,filepath)

        # construct MyHR policy MG
        my_health_record = {'profile', 'medical_documents'}
        variables_set2 = {'data_subject', 'controller',  'supervisory_authority'}.union(my_health_record).union(data_recipients)
        # TODO: include data breach notification details (incl conseqs and delay limits)
        propositions_set2 = {'purpose=view', 'purpose=manage', 'purpose=research', 'purpose=subject_interest', 'purpose=public_interest', 'purpose=official_authority',
                             'carer_consent=true','retention_duration=default','subject_consent=true',
                             'my_data_stored=true', 'request_my_data_copy=true', 'no_data_available=true',
                             'subject_rights_affected=true','subject_freedom_affected=true'}.union(subject_age_group)

        edge_list2 = []
        edge_list2.append(Edge(my_health_record,{'individuals'},attributes=['purpose=manage', 'subject_age>=adult_age', 'subject_consent=true', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'individuals'},attributes=['purpose=manage', 'subject_age<adult_age', 'carer_consent=true', 'retention_duration=default']))

        edge_list2.append(Edge(my_health_record,{'hc_providers'},attributes=['purpose=view', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'hc_providers'},attributes=['purpose=subject_interest', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'hc_providers'},attributes=['purpose=public_interest', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'hc_providers'},attributes=['purpose=view', 'subject_age>=adult_age', 'subject_consent=true', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'hc_providers'},attributes=['purpose=view', 'subject_age<adult_age', 'carer_consent=true', 'retention_duration=default']))

        edge_list2.append(Edge(my_health_record,{'third_parties'},attributes=['purpose=view', 'subject_age>=adult_age', 'subject_consent=true', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'third_parties'},attributes=['purpose=manage', 'subject_age<adult_age', 'carer_consent=true', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'third_parties'},attributes=['purpose=official_authority', 'retention_duration=default']))

        cmg_myhr = ConditionalMetagraph(variables_set2, propositions_set2)
        cmg_myhr.add_edges_from(edge_list2)

        filepath='/Users/a1070571/Documents/ITS/cmg_myhr.dot'
        MetagraphHelper().generate_visualisation(edge_list2,filepath)

        # check compliance
        # node labels on both MGs are consistent (not arbitrary)
        # comparison can be done using set inclusion
        # if all metapaths in myHR mg is included by one or mps in gdpr mg
        # then we can say policy is compliant

        # E.g., Find all metapaths from my_health_record to data_recipients in cmg_myhr
        metapaths1 = []
        temp = cmg_myhr.get_all_metapaths_from(my_health_record, {'third_parties'}, include_propositions=True)

        for metapath in temp:
            if cmg_myhr.is_edge_dominant_metapath(metapath) and (not self.metapath_exists(metapath, metapaths1)):
               metapaths1.append(metapath)

        # Find all metapaths from personal_data to data_recipients in cmg_gdpr
        metapaths2 = []
        temp = cmg_gdpr.get_all_metapaths_from(personal_data, {'third_parties'}, include_propositions=True)
        for metapath in temp:
            if cmg_gdpr.is_edge_dominant_metapath(metapath) and (not self.metapath_exists(metapath, metapaths2)):
               metapaths2.append(metapath)

        # check if every metapath in 1 is included by a metapath in 2
        for mp in metapaths1:
            if not MetagraphHelper().is_metapath_included(mp, metapaths2):
                print('metapaths not included => GDPR violation')
                print('  mp=%s'%(mp.edge_list))

    def test_gdpr_compliance2(self):
        return
        # construct GDPR policy MG
        data_recipients = {'data_subject_employer', 'individuals', 'hc_providers', 'third_parties'}
        personal_data = {'profile', 'medical_documents', 'other_data'}
        subject_age_group = {'subject_age<adult_age', 'subject_age>=adult_age'}
        purpose_of_proc = {'purpose=view', 'purpose=manage', 'purpose=research', 'purpose=subject_interest', 'purpose=public_interest', 'purpose=official_authority'}

        variables_set = {'data_subject', 'controller', 'processor', 'supervisory_authority', 'DPO'}.union(personal_data).union(data_recipients)
        propositions_set = {'carer_consent=true', 'subject_consent=true', 'my_data_stored=true', 'inform_purpose=true', 'retention_duration=default',
                            'request_my_data_copy=true', 'no_data_available=true', 'erase_my_data=true',
                            'subject_rights_affected=true','subject_freedom_affected=true','data_breach_notification_delay_hrs<1',
                            'data_breach_notification_delay_hrs<72'}.union(subject_age_group).union(purpose_of_proc)
        generating_set = variables_set.union(propositions_set)

        edge_list = []
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=manage','subject_age<adult_age','carer_consent=true','retention_duration=default']))
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=manage','subject_age>=adult_age','subject_consent=true','retention_duration=default']))

        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=view','subject_age<adult_age','carer_consent=true','retention_duration=default']))
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=view','subject_age>=adult_age','subject_consent=true','retention_duration=default']))

        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=research','subject_age<adult_age','carer_consent=true','retention_duration=default']))
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=research','subject_age>=adult_age','subject_consent=true','retention_duration=default']))

        edge_list.append(Edge(personal_data,{'data_subject_employer'},attributes=['purpose=subject_interest','retention_duration=default']))
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=public_interest', 'retention_duration=default']))
        edge_list.append(Edge(personal_data,data_recipients,attributes=['purpose=official_authority', 'retention_duration=default']))

        cmg_gdpr = ConditionalMetagraph(variables_set, propositions_set)
        cmg_gdpr.add_edges_from(edge_list)

        filepath='/Users/a1070571/Documents/ITS/cmg_gdpr.dot'
        MetagraphHelper().generate_visualisation(edge_list,filepath)

        # construct MyHR policy MG
        my_health_record = {'profile', 'medical_documents'}
        variables_set2 = {'data_subject', 'controller',  'supervisory_authority'}.union(my_health_record).union(data_recipients)
        # TODO: include data breach notification details (incl conseqs and delay limits)
        propositions_set2 = {'purpose=view', 'purpose=manage', 'purpose=research', 'purpose=subject_interest', 'purpose=public_interest', 'purpose=official_authority',
                             'carer_consent=true','retention_duration=default','subject_consent=true',
                             'my_data_stored=true', 'request_my_data_copy=true', 'no_data_available=true',
                             'subject_rights_affected=true','subject_freedom_affected=true'}.union(subject_age_group)

        edge_list2 = []
        edge_list2.append(Edge(my_health_record,{'individuals'},attributes=['purpose=manage', 'subject_age>=adult_age', 'subject_consent=true', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'individuals'},attributes=['purpose=manage', 'subject_age<adult_age', 'carer_consent=true', 'retention_duration=default']))

        edge_list2.append(Edge(my_health_record,{'hc_providers'},attributes=['purpose=view', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'hc_providers'},attributes=['purpose=subject_interest', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'hc_providers'},attributes=['purpose=public_interest', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'hc_providers'},attributes=['purpose=view', 'subject_age>=adult_age', 'subject_consent=true', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'hc_providers'},attributes=['purpose=view', 'subject_age<adult_age', 'carer_consent=true', 'retention_duration=default']))

        edge_list2.append(Edge(my_health_record,{'third_parties'},attributes=['purpose=view', 'subject_age>=adult_age', 'subject_consent=true', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'third_parties'},attributes=['purpose=manage', 'subject_age<adult_age', 'carer_consent=true', 'retention_duration=default']))
        edge_list2.append(Edge(my_health_record,{'third_parties'},attributes=['purpose=official_authority', 'retention_duration=default']))

        cmg_myhr = ConditionalMetagraph(variables_set2, propositions_set2)
        cmg_myhr.add_edges_from(edge_list2)

        filepath='/Users/a1070571/Documents/ITS/cmg_myhr.dot'
        MetagraphHelper().generate_visualisation(edge_list2,filepath)

        # check compliance
        # node labels on both MGs are consistent (not arbitrary)
        # comparison can be done using set inclusion
        # if all metapaths in myHR mg is included by one or mps in gdpr mg
        # then we can say policy is compliant

        # derive all metapaths in myHR
        metapaths1 = []
        #temp = cmg_myhr.get_all_metapaths_from(my_health_record, {'individuals'}, include_propositions=True)
        # in myHR an edge can apply to a small or large set of elements

        # derive all metapaths in gdpr

        # compare

        # E.g., Find all metapaths from my_health_record to data_recipients in cmg_myhr
        metapaths1 = []
        temp = cmg_myhr.get_all_metapaths_from(my_health_record, {'third_parties'}, include_propositions=True)

        for metapath in temp:
            if cmg_myhr.is_edge_dominant_metapath(metapath) and (not self.metapath_exists(metapath, metapaths1)):
               metapaths1.append(metapath)

        # Find all metapaths from personal_data to data_recipients in cmg_gdpr
        metapaths2 = []
        temp = cmg_gdpr.get_all_metapaths_from(personal_data, {'third_parties'}, include_propositions=True)
        for metapath in temp:
            if cmg_gdpr.is_edge_dominant_metapath(metapath) and (not self.metapath_exists(metapath, metapaths2)):
               metapaths2.append(metapath)

        # check if every metapath in 1 is included by a metapath in 2
        for mp in metapaths1:
            if not MetagraphHelper().is_metapath_included(mp, metapaths2):
                print('metapaths not included => GDPR violation')
                print('  mp=%s'%(mp.edge_list))

    def metapath_exists(self, metapath, metapath_list):
        '''
        Checks if the metapath exists in a given metapath list.
        '''
        for mp in metapath_list:
            if MetagraphHelper().is_edge_list_included(metapath.edge_list,mp.edge_list):
               return True

        return False

    def test_intent_preserved(self):
        '''
         MG policy model
				1. External --> Internal\SCADA: prot=Tcp, tcp_state=est, action=allow
				2. Any --> ServerX:   prot=Tcp, tcp_port=80, action=allow
				3. External --> SCADA: app=Any, action=deny (implicit deny)
				4. Any --> ServerY: app=Any, mb1=FW, mb2=LB, action=allow

				5. External --> Internal\SCADA : app=Any, mw_sigs=Any, action=block
				6. Internal --> External : app=Any, mw_sigs=Any, action=alert

				7. Internal --> External : app=netflix, priority=low, action=allow

			. Example HL AC policy (to deploy in nw): AC_Pol
				. SCADA --> DMZ1: app=MS-SQL action=allow
				. SCADA --> Corp: app=HTTP, action=allow
				. Corp --> SCADA: app=HTTPS, action=allow
				. Corp --> ServerX: app=DNS, action=allow           // violates intent 2
				. External --> SCADA: app=HTTPS, action=allow       // violates intents 1,3
				. External --> ServerY: app=HTTP, mb1=LB, mb2=FW    // violates intents 1,4
				. Internet --> Corp : app=HTTP, mw_sigs=pa_sigs, action=alert   // violates intent 5
				. SCADA --> DMZ1 : app=SMB, mw_sigs=pa_sigs, action=block       // violates intent 6
				. Corp --> Internet : app=netflix, priority=high, action=allow  // violates intent 7

				1. all inbound traffic from the Internet must be solicited
				2. all inbound traffic to server X must be on TCP protocol 80
				3. deny all inbound traffic to SCADA from the Internet
				4. all inbound traffic to server Y must go through a FW first and then a load balancer
				5. all malicious traffic inbound from the Internet must be blocked
				6. all malcious traffic leaving any internal network must be alerted on
                7. netflix traffic must be given low priority


                intent preserved if
                    1. if canonical(implemented HL policy) <= canonical(HL policy intent)
                        note this condition may not hold
                        . wrt some flow actions (eg log_and_block)
                        . eg when HL intent does not enable mw detection but implemented policy does (would actually be a wise step, but is it still a violation of intent?)
                        . eg when HL intent does not specify a qos priority but implemented policy does (still violation of intent?)
                is what we generate really the canonical forms? WHY
                    1. AC
                        . use horizontal partition alg to generate a cover for each protocol
                        . alg generates unique partitions everytime
                    2. QoS
                        . QoS traffic priorities are (locally) unique (ie non-mutable) values (eg low, medium, high) - NO Global standard values
                        . these unique priorities associated with flows
                        . canonicalisation alg processes each (flow,priority) tuple separately
                        . hence generates (locally) unique partitions
                    3. Anti-malware
                        . malware sig lists are (vendor-specific, locally) unique values (eg pa_sigs, wildfire_sigs)
                        . malware actions are (vendor-specific, locally) unique values (eg block, alert)
                        . (sig_list,action) tuples are associated with a flow
                        . canonicalisation alg processes each (flow, (sig_list,action)) tuple separately
                        . hence generates (vendor-specific, locally) unique partitions
                    4. Service-chaining
                        . middlebox ids (ie service-chain ids) are unique (eg 1,2)
                        . middlebox values (ie service-chain values) are (locally) unique values (eg FW, LB)
                        . (mb_id,value) tuples are associated with a flow
                        . canonicalisation alg processes each (flow, (mb_id,value)) tuple separately
                        . hence generates (locally) unique partitions
                    * with the alg extensions what we have done is ensure flows are still grouped and processed together
                      as new policy criteria is added, to generate their canonical forms
                do we really need policy blacklisting? WHY
                     - NO: no bottleneck encountered yet

				'''

        return

        external = {'internet'}
        internal = {'scada', 'corp', 'dmz', 'server_x', 'server_y'}
        any = external.union(internal)

        # create intent metagraph
        var_set1=any
        prop_set1={'protocol=TCP', 'TCP.state=est', 'action=allow','TCP.dport=80', 'protocol=UDP', 'UDP.dport=53', 'prot=any', 'action=deny', 'mb1=FW', 'mb2=LB'}
        edge_list1={Edge(external,internal.difference({'scada'}),attributes=['protocol=TCP', 'TCP.state=1', 'action=allow']),
                    Edge(any.difference({'server_x'}),{'server_x'},attributes=['protocol=TCP', 'TCP.dport=80', 'action=allow']),
                    Edge(any.difference({'server_y'}),{'server_y'},attributes=['protocol=TCP', 'mb1=FW', 'mb1=LB', 'action=allow']),
                    Edge(external,internal.difference({'scada'}),attributes=['protocol=TCP', 'mw_sigs_block={wildfire_signatures,pa_signatures}', 'action=allow']),
                    Edge(internal,external,attributes=['protocol=TCP', 'mw_sigs_alert={wildfire_signatures,pa_signatures}', 'action=allow']),
                    Edge(internal,external,attributes=['protocol=TCP', 'TCP.dport=80', 'priority=2', 'action=allow']) # high=1, low=2
        }

        #edge_list1={Edge(external,internal,attributes=['protocol=TCP', 'TCP.state=1', 'action=allow'])
        #}

                    # Edge(external,{'scada'},attributes=['protocol=TCP', 'TCP.dport=80', 'action=deny'])
                    # Edge(any.difference({'server_x'}),{'server_x'},attributes=['protocol=TCP', 'TCP.dport=80', 'action=allow'])
                    # Edge(any.difference({'server_y'}),{'server_y'},attributes=['protocol=TCP', 'TCP.dport=80', 'mb1=FW', 'mb1=LB', 'action=allow']),
                    # Edge(external,internal,attributes=['protocol=TCP', 'TCP.dport=80', 'priority=1', 'action=allow']), # priority=2
                    # Edge(external,internal,attributes=['protocol=TCP', 'TCP.dport=80', 'mw_sigs_alert={wildfire_signatures}', 'action=allow']), # mw_sigs_alert
                    # Edge(external,internal,attributes=['protocol=TCP', 'TCP.dport=80', 'action=allow']), # any allow_and_log state: 0=new, 1=est 'TCP.state=1',
                    # Edge(external,{'scada'},attributes=['prot=any', 'action=deny'])}
                    # Edge(any.difference({'server_y'}),{'server_y'},attributes=['prot=any', 'mb1=FW', 'mb2=LB', 'action=allow'])}

        cmg_intent = ConditionalMetagraph(var_set1,prop_set1)
        cmg_intent.add_edges_from(edge_list1)

        filepath='/Users/a1070571/Documents/ITS/cmg_intent.dot'
        MetagraphHelper().generate_visualisation(edge_list1,filepath)

        # create policy metagraph
        var_set2=any
        prop_set2={'protocol=TCP', 'action=allow','TCP.dport=80', 'TCP.dport=443', 'protocol=UDP', 'UDP.dport=53', 'mb1=LB', 'mb2=FW'}

        edge_list2={Edge({'scada'},{'dmz'},attributes=['protocol=TCP', 'TCP.dport=1433', 'action=allow']),
                    Edge({'scada'},{'corp'},attributes=['protocol=TCP', 'TCP.dport=80', 'action=allow']),
                    Edge({'corp'},{'scada'},attributes=['protocol=TCP', 'TCP.dport=443', 'action=allow']),
                    Edge({'corp'},{'server_x'},attributes=['protocol=UDP', 'UDP.dport=53', 'action=allow']),
                    Edge(external,{'scada'},attributes=['protocol=TCP', 'TCP.dport=443', 'action=allow']),
                    Edge(external,{'server_y'},attributes=['protocol=TCP', 'TCP.dport=80', 'mb1=LB', 'mb2=FW', 'action=allow']),
                    Edge(external,{'corp'},attributes=['protocol=TCP', 'TCP.dport=80', 'mw_sigs_alert={pa_signatures}', 'action=allow']),
                    Edge({'scada'},{'dmz'},attributes=['protocol=TCP', 'TCP.dport=445', 'mw_sigs_block={pa_signatures}', 'action=allow']),
                    Edge({'corp'},external,attributes=['protocol=TCP', 'TCP.dport=80', 'priority=1', 'action=allow'])
        }
        # edge_list2={Edge(external,internal,attributes=['protocol=TCP', 'action=allow'])}

                    # Edge(external,{'server_y'},attributes=['protocol=TCP', 'TCP.dport=80', 'mb1=LB', 'mb2=FW', 'action=allow'])
                    # Edge({'corp'},{'server_x'},attributes=['protocol=TCP', 'TCP.dport=80', 'action=allow'])
                    # Edge(external,{'scada'},attributes=['protocol=TCP', 'TCP.dport=80', 'mw_sigs_block={pa_signatures}', 'action=allow'])} # mw_sigs_alert, mw_sigs_allow?
                    # Edge(external,{'scada'},attributes=['protocol=TCP', 'TCP.dport=80', 'priority=2', 'action=allow'])} # priority=1(high) 2(low)
                    # Edge(external,{'scada'},attributes=['protocol=TCP', 'TCP.dport=80', 'action=allow']), # 443
                    # Edge(external,{'server_y'},attributes=['protocol=TCP', 'TCP.dport=80', 'mb1=LB', 'mb2=FW', 'action=allow'])
                    # Edge({'corp'},{'server_x'},attributes=['protocol=UDP', 'UDP.dport=53', 'action=allow'])
                    #,
                    # Edge({'scada'},{'corp'},attributes=['prot=Tcp', 'tcp_dport=80', 'action=allow']),
                    # Edge({'corp'},{'scada'},attributes=['prot=Tcp', 'tcp_dport=443', 'action=allow']),

        '''
        HL AM policy
                5. External --> Internal : app=Any, mw_sigs=Any, action=log_and_block
                6. Internal --> Any : app=Any, mw_sigs=Any, action=log_and_block
                7. Internal --> External : app=Web, url_cats={terrorism,porn,nudity}, action=block


            Actual policy
                . External --> Internal : app=HTTP, mw_sigs=pa_sigs, action=block  // violates intent 5 (which additionally requires flow to be logged) '''

        cmg_policy = ConditionalMetagraph(var_set2,prop_set2)
        cmg_policy.add_edges_from(edge_list2)
        filepath='/Users/a1070571/Documents/ITS/cmg_policy.dot'
        MetagraphHelper().generate_visualisation(edge_list2,filepath)

        #TODO: check each policy is conflict free on its own

        # check for conflicts in combined mg (indicates intent violations)
        if False:
            # combine policies and check for conflicts in the result
            combined_cmg = cmg_intent.add_metagraph(cmg_policy)
            result = MetagraphHelper().is_policy_consistent(combined_cmg)
            print(result)

        # check implemented policy is equally or more restrictive than intent
        if True:
            from mgtoolkit.library import CanonicalPolicyHelper
            print('Create line digraph of policy1..')
            digraph_intent = MetagraphHelper().GetMultiDigraph(cmg_intent)
            cmg_intent_line_graph=MetagraphHelper().CreateLineGraph(digraph_intent)

            print('Create line digraph of policy2..')
            digraph_policy = MetagraphHelper().GetMultiDigraph(cmg_policy)
            cmg_policy_line_graph=MetagraphHelper().CreateLineGraph(digraph_policy)

            print('Generate canonical policies of policy1..')
            CanonicalPolicyHelper().GenerateCanonicalForm(digraph_intent)
            canonical_policy1 = CanonicalPolicyHelper().canonical_policies

            flow_policies1=dict()
            for key in cmg_intent_line_graph.node.keys():
                flow_policies1[key]=None
                # lookup the canonical policy of this flow
                flow1=None
                key_str='%s->%s'%(key[0],key[1])
                if key_str in canonical_policy1['final']:
                   flow1=canonical_policy1['final'][key_str]
                flow_policies1[key] = flow1

            print('Generate canonical policies of policy2..')
            CanonicalPolicyHelper().GenerateCanonicalForm(digraph_policy)
            canonical_policy2 = CanonicalPolicyHelper().canonical_policies

            flow_policies2=dict()
            for key in cmg_policy_line_graph.node.keys():
                flow_policies2[key]=None
                # lookup the canonical policy of this flow
                flow1=None
                key_str='%s->%s'%(key[0],key[1])
                if key_str in canonical_policy2['final']:
                   flow1=canonical_policy2['final'][key_str]
                flow_policies2[key] = flow1

            if CanonicalPolicyHelper().CheckPolicyInclusion(flow_policies2,flow_policies1,True):
               print('high-level policy intent is preserved')
            else:
               print('high-level policy intent is breached')

        # semantic partition based approach:
        #   . can compare policies from diff nws
        #   . allows to locate which policy edges can map to one-another
        #   . able to build plausible policy-graph mappings - each mapping must be isomorphic
        #   . eg. inclusive if at least one policy mapping (with inclusive semantics) is isomorphic

    def test_mgtk_paper(self):
        return
        variable_set = {'u1','u2','u3','u4','u5','u6','r1','r2','r3'}
        propositions_set = {'action=permit', 'action=deny'}
        cm = ConditionalMetagraph(variable_set, propositions_set)
        cm.add_edges_from([
                Edge({'u1','u2','u3'}, {'r1','r2'}, attributes=['action=permit']),
                Edge({'u3','u4','u5'}, {'r2','r3'}, attributes=['action=deny']),
                Edge({'u2','u3','u5','u6'}, {'r1','r2'}, attributes=['action=permit'])])

        all_metapaths = cm.get_all_metapaths()
        for metapath in all_metapaths:
            #if cm.has_redundancies(metapath):
            #    print('redundancy detected: %s'%repr(metapath))
            if cm.has_conflicts(metapath):
               print('conflict detected: %s'%repr(metapath.edge_list))
        return

    def test_course_pathways_paper(self):

        # create course metagraph
        import os
        import csv
        course_details_lookup=dict()
        edge_list=[]
        generator_list=[]
        generator_list2=[]
        edge_list2=[]

        return

        #folder_path= os.path.join(os.getcwd(),'test_data')
        #file_name='courses.csv'
        folder_path = "/Users/a1070571/Documents/ITS/"
        file_name='courses07.csv'

        with open(os.path.join(folder_path, file_name), 'rb') as csvfile:
            reader = csv.reader(csvfile, delimiter=',', quotechar='|')
            index=0
            for row in reader:
                if index==0:
                    # omit header
                    index+=1
                    continue
                code = row[0]
                name = row[1]
                pre_requisites= MetagraphHelper().get_pre_requisites_list(row[2])
                assumed_k = MetagraphHelper().get_pre_requisites_list(row[4])
                if code not in course_details_lookup:
                    course_details_lookup[code]=dict()
                if 'name' not in course_details_lookup[code]:
                    course_details_lookup[code]['name']= name
                if 'pre-requisites' not in course_details_lookup[code]:
                    course_details_lookup[code]['pre-requisites']= pre_requisites
                if 'assumed_k' not in course_details_lookup[code]:
                    course_details_lookup[code]['assumed_k'] = assumed_k
                index+=1

            for code, details in course_details_lookup.iteritems():
                if code not in generator_list2:
                    generator_list2.append(code)
                for assumed_k in course_details_lookup[code]['assumed_k']:
                    if isinstance(assumed_k, list):
                        edge_list2.append(Edge(set(assumed_k), set([code])))
                        for item in assumed_k:
                            if item not in generator_list2:
                                generator_list2.append(item)
                    else:
                        edge_list2.append(Edge(set([assumed_k]), set([code])))
                        if assumed_k not in generator_list2:
                           generator_list2.append(assumed_k)

            for code, details in course_details_lookup.iteritems():
                if code not in generator_list:
                    generator_list.append(code)
                for pre_requisite in course_details_lookup[code]['pre-requisites']:
                    if isinstance(pre_requisite, list):
                        edge_list.append(Edge(set(pre_requisite), set([code])))
                        for item in pre_requisite:
                            if item not in generator_list:
                                generator_list.append(item)
                    else:
                        edge_list.append(Edge(set([pre_requisite]), set([code])))
                        if pre_requisite not in generator_list:
                           generator_list.append(pre_requisite)

        # create course metagraph
        mg = Metagraph(set(generator_list))
        mg.add_edges_from(edge_list)

        #MetagraphHelper().generate_visualisation(edge_list,
        #'/Users/a1070571/Documents/ITS/mg_input.dot')

        output_folder='/Users/a1070571/Documents/ITS'
        index=1

        # 1. detect inconsistencies: eg., conflicting pre-requisites
        for node in mg.nodes:
            metapaths = mg.get_all_metapaths_from(node.element_set,node.element_set)
            if metapaths is not None and len(metapaths)>0:
                for metapath in metapaths:
                    if mg.is_edge_dominant_metapath(metapath):
                        MetagraphHelper().generate_visualisation(metapath.edge_list,
                                                    '%s/conflict_%s.dot'%(output_folder,index))
                        index +=1
            else:
                for elt in node.element_set:
                    metapaths = mg.get_all_metapaths_from(node.element_set,{elt})
                    if metapaths is not None and len(metapaths)>0:
                        for metapath in metapaths:
                            if mg.is_edge_dominant_metapath(metapath):
                                MetagraphHelper().generate_visualisation(metapath.edge_list,
                                                    '%s/conflict_%s.dot'%(output_folder,index))
                                index +=1

        all_high_school_courses={'SACE S2 Maths','a C in SACE S2 Maths', 'SACE S2 Special Maths', 'a 3 in IB Maths HL', 'a 4 in IB Maths SL'}
        # 'CS 1012', 'CS 1101', 'CS 1201', 'CS 1102', 'M 1009'
        target = {'PM 3019'}

        pathways = self.get_pathways_to(all_high_school_courses,
                   target, mg)
        index=1

        for path in pathways:
            MetagraphHelper().generate_visualisation(path.edge_list,
                                  '/Users/a1070571/Documents/ITS/pathway_pm3019_%s.dot'%(index))
            index +=1
        print('test')



        # 2. locate alteranate pathways to a course set
        if False:

            #all_high_school_courses={'a C in SACE S2 Maths', 'SACE S2 Special Maths', 'ECON 2504', 'M 1012', 'CS 1012', 'CS 1101', 'CS 1201', 'CS 1102', 'CS 1012', 'M 1015', 'M 2201', 'M 2202', 'M 2101', 'M 2102',
            #                        'a 3 in IB Maths HL'}
            all_high_school_courses={'SACE S2 Maths','a C in SACE S2 Maths', 'SACE S2 Special Maths', 'a 3 in IB Maths HL', 'a 4 in IB Maths SL','CS 1012', 'CS 1101', 'CS 1201', 'CS 1102', 'M 1009'}
            target = {'M 1010'}

            #src = set(generator_list).difference(target)
            src ={'SACE S2 Maths', 'a C in SACE S2 Maths', 'SACE S2 Special Maths',
                  'a 3 in IB Maths HL', 'a 4 in IB Maths SL', 'M 1015', 'CS 1012', 'CS 1101', 'CS 1201', 'CS 1102', 'ECON 2504', 'M 2201', 'M 2202'}

            edge_list3 = [Edge({'a 3 in IB Maths HL'},{'M 1011'}),
                          Edge({'M 1011'},{'M 1012'}),
                          Edge({'M 1012', 'ECON 2504'},{'S 2107'}),
                          Edge({'S 2107'},{'S 3005'})]

            edge_list4 = [Edge(set(['M 1013']), set(['M 1011'])),
                          Edge(set(['a 4 in IB Maths SL']), set(['M 1013'])),
                          Edge(set(['M 1011']), set(['M 1012'])),
                          Edge(set(['M 1012', 'ECON 2504']), set(['S 3005']))]

            # metapath = Metapath(src, target, edge_list4)
            # res = mg.is_metapath(metapath)
            # res2 =mg.is_edge_dominant_metapath(metapath)

            pathways = self.get_pathways_to(all_high_school_courses,
                                target, mg)
            index=1

            for path in pathways:
                MetagraphHelper().generate_visualisation(path.edge_list,
                                      '/Users/a1070571/Documents/ITS/pathway_%s.dot'%(index))
                index +=1

        # 3. identify critical pre-reqs for a course
        if True:
            all_high_school_courses ={'a C in SACE S2 Maths', 'SACE S2 Special Maths',
                             'a 3 in IB Maths HL', 'a 4 in IB Maths SL'}
            target_courses= {'AM 3022'}

            common_bridges=set()
            final_edge_set=set()
            for course in target_courses:
                bridge_list=[]
                pathways = self.get_pathways_to(all_high_school_courses, {course}, mg)
                for pathway in pathways:
                    final_edge_set = final_edge_set.union(set(pathway.edge_list))
                    for edge in pathway.edge_list:
                        if mg.is_bridge([edge], pathway.source, pathway.target): # source
                            if edge not in bridge_list:
                                print('edge: %s is a bridge from source to target= %s'%(edge, pathway.target))
                                bridge_list.append(edge)

                if len(list(common_bridges))==0:
                    common_bridges = set(bridge_list)
                else:
                    common_bridges = common_bridges.intersection(set(bridge_list))

            MetagraphHelper().generate_visualisation(list(final_edge_set),
                            '/Users/a1070571/Documents/ITS/critical10.dot')

            print('test')

        # 4. identify potentially incompatible courses
        # target MATHS 3015
        # pot. incomp course (8,9) = {'MATHS 1011', 'MATHS 1012', 'MATHS 1013'} and {'COMP SCI 1102'}
        edge_list10 = [Edge({'MATHS 1011'},{'MATHS 1012'}),
                      Edge({'MATHS 1012'},{'MATHS 3015'}),
                      Edge({'MATHS 1013'},{'MATHS 1011'}),
                      Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]

        edge_list11 = [Edge({'COMP SCI 1102'},{'MATHS 3015'})]

        all_high_school_courses={'SACE S2 Maths','a C in SACE S2 Maths', 'SACE S2 Special Maths', 'a 3 in IB Maths HL',
                                 'a 4 in IB Maths SL','CS 1012', 'CS 1101', 'CS 1201', 'CS 1102', 'M 1009'}
        target = {'M 3015'}
        pathways = self.get_pathways_to(all_high_school_courses, target, mg)

        mp2 = pathways[0]
        mp3= pathways[2]

        # L1 pre-reqs
        # all level1 subjects
        source1 = {'M 1008', 'M 1009', 'M 1010', 'M 1011', 'M 1012',
                   'M 1012', 'M 1013', 'M 1015', 'S 1000', 'S 1004',
                   'S 1005', 'S 1504', 'CS 1102'}
        mp2_level1_pre_reqs=set()
        mp3_level1_pre_reqs=set()
        for edge in mp2.edge_list:
            mp2_level1_pre_reqs = mp2_level1_pre_reqs.union(source1.intersection(edge.invertex))
            mp2_level1_pre_reqs = mp2_level1_pre_reqs.union(source1.intersection(edge.outvertex))

        for edge in mp3.edge_list:
            mp3_level1_pre_reqs = mp3_level1_pre_reqs.union(source1.intersection(edge.invertex))
            mp3_level1_pre_reqs = mp3_level1_pre_reqs.union(source1.intersection(edge.outvertex))

        # all level2 subjects
        source2 = { 'AM 2105', 'M 2100', 'M 2101', 'M 2102', 'M 2103', 'M 2104', 'M 2201', 'M 2202', 'M 2203', 'PM 2106', 'S 2107'}

        mp2_level2_pre_reqs=set()
        mp3_level2_pre_reqs=set()

        for edge in mp2.edge_list:
            mp2_level2_pre_reqs = mp2_level2_pre_reqs.union(source2.intersection(edge.invertex))
            mp2_level2_pre_reqs = mp2_level2_pre_reqs.union(source2.intersection(edge.outvertex))

        for edge in mp3.edge_list:
            mp3_level2_pre_reqs = mp3_level2_pre_reqs.union(source2.intersection(edge.invertex))
            mp3_level2_pre_reqs = mp3_level2_pre_reqs.union(source2.intersection(edge.outvertex))

        # all level3 subjects
        source3 = {'AM 3001', 'AM 3002', 'AM 3014', 'AM 3016', 'AM 3020', 'AM 3021', 'AM 3022', 'AM 3023', 'M 3012', 'M 3015', 'M 3020', 'M 3021',
                  'PM 3002', 'PM 3007', 'PM 3009', 'PM 3019' , 'PM 3022', 'PM 3023', 'S 3001', 'S 3003', 'S 3005', 'S 3006'}

        mp2_level3_pre_reqs=set()
        mp3_level3_pre_reqs=set()

        for edge in mp2.edge_list:
            mp2_level3_pre_reqs = mp2_level3_pre_reqs.union(source3.intersection(edge.invertex))
            mp2_level3_pre_reqs = mp2_level3_pre_reqs.union(source3.intersection(edge.outvertex))
            mp2_level3_pre_reqs = mp2_level3_pre_reqs.difference(target)

        for edge in mp3.edge_list:
            mp3_level3_pre_reqs = mp3_level3_pre_reqs.union(source3.intersection(edge.invertex))
            mp3_level3_pre_reqs = mp3_level3_pre_reqs.union(source3.intersection(edge.outvertex))
            mp3_level3_pre_reqs = mp3_level3_pre_reqs.difference(target)

        pot_incompatible_level1_courses_A = None
        pot_incompatible_level1_courses_B = None
        pot_incompatible_level2_courses_A = None
        pot_incompatible_level2_courses_B = None
        pot_incompatible_level3_courses_A = None
        pot_incompatible_level3_courses_B = None

        pot_incompatible_courses_A = None
        pot_incompatible_courses_B = None

        # 1,2,3 > 0
        # 1,2 >0 3=0
        # 1>0 2=0 3>0
        # 1>0 2=0 3=0
        # 1=0 2>0 3>0 x
        # 1=0 2=0 3>0 x
        # 1=0 2=0 3=0 X
        # 1=0 2>0 3=0 x

        # find pot. incompatible courses
        if (len(mp2_level1_pre_reqs)>0 and len(mp2_level2_pre_reqs)>0 and len(mp2_level3_pre_reqs)>0) and \
                (len(mp3_level1_pre_reqs)>0 and len(mp3_level2_pre_reqs)>0 and len(mp3_level3_pre_reqs)>0):
                # compare courses at each corresponding level
                level1_overlap = mp2_level1_pre_reqs.intersection(mp3_level1_pre_reqs)
                level2_overlap = mp2_level2_pre_reqs.intersection(mp3_level2_pre_reqs)
                level3_overlap = mp2_level3_pre_reqs.intersection(mp3_level3_pre_reqs)

                pot_incompatible_level1_courses_A = mp2_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level1_courses_B = mp3_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level2_courses_A = mp2_level2_pre_reqs.difference(level2_overlap)
                pot_incompatible_level2_courses_B = mp3_level2_pre_reqs.difference(level2_overlap)
                pot_incompatible_level3_courses_A = mp2_level3_pre_reqs.difference(level3_overlap)
                pot_incompatible_level3_courses_B = mp3_level3_pre_reqs.difference(level3_overlap)

        elif (len(mp2_level1_pre_reqs)>0 and len(mp2_level2_pre_reqs)>0 and len(mp2_level3_pre_reqs)==0) and \
                (len(mp3_level1_pre_reqs)>0 and len(mp3_level2_pre_reqs)>0 and len(mp3_level3_pre_reqs)==0):

                # compare courses at each corresponding level
                level1_overlap = mp2_level1_pre_reqs.intersection(mp3_level1_pre_reqs)
                level2_overlap = mp2_level2_pre_reqs.intersection(mp3_level2_pre_reqs)

                pot_incompatible_level1_courses_A = mp2_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level1_courses_B = mp3_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level2_courses_A = mp2_level2_pre_reqs.difference(level2_overlap)
                pot_incompatible_level2_courses_B = mp3_level2_pre_reqs.difference(level2_overlap)

        elif (len(mp2_level1_pre_reqs)>0 and len(mp2_level2_pre_reqs)==0 and len(mp2_level3_pre_reqs)==0) and \
                (len(mp3_level1_pre_reqs)>0 and len(mp3_level2_pre_reqs)==0 and len(mp3_level3_pre_reqs)==0):

                # compare courses at each corresponding level
                level1_overlap = mp2_level1_pre_reqs.intersection(mp3_level1_pre_reqs)

                pot_incompatible_level1_courses_A = mp2_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level1_courses_B = mp3_level1_pre_reqs.difference(level1_overlap)

        elif len(mp2_level1_pre_reqs)>0 and len(mp3_level1_pre_reqs)>0:

                # compare combined L2 and L3 lists of courses
                combined_A = mp2_level2_pre_reqs.union(mp2_level3_pre_reqs)
                combined_B = mp3_level2_pre_reqs.union(mp3_level3_pre_reqs)
                combined_overlap = combined_A.intersection(combined_B)
                pot_incompatible_courses_A = combined_A.difference(combined_overlap)
                pot_incompatible_courses_B = combined_B.difference(combined_overlap)

        elif len(mp2_level1_pre_reqs)==0:
             print('error')

        print('test')
        return

    def test_course_dependencies(self):
        import os
        import csv
        course_details_lookup=dict()
        edge_list=[]
        generator_list=[]
        generator_list2=[]
        edge_list2=[]
        institutes_list=[]
        category_lookup=dict()
        inst_course_lookup=dict()

        folder_path= os.path.join(os.getcwd(),'test_data')
        file_name='courses_edx01.csv'

        return

        #with open(os.path.join(folder_path, file_name), 'rb') as csvfile:
        if True:
            reader = csv.reader(open(os.path.join(folder_path, file_name), 'rU'), delimiter=',', quotechar='|', dialect=csv.excel_tab)
            #reader = csv.reader(csvfile, delimiter=',', quotechar='|')

            index=0
            for row in reader:
                if index==0:
                    # omit header
                    index+=1
                    continue

                #print('row: %s'%row)
                name=None
                pre_requisites=None
                category=None
                institute=None

                if len(row)>=1:
                    name = row[0]

                if len(row)>=2:
                    pre_requisites = MetagraphHelper().get_pre_requisites_list(row[1])

                if len(row)>=8:
                    category = MetagraphHelper().get_pre_requisites_list(row[7])

                if len(row)>=7:
                    institute = MetagraphHelper().get_pre_requisites_list(row[6])

                # assumed_k = MetagraphHelper().get_pre_requisites_list(row[4])

                # consider only CS courses from MS to begin with
                if category is None:
                    print('row: %s'%row)
                    continue
                if institute is None: continue

                if category[0] not in category_lookup:
                    category_lookup[category[0]] = 1
                else:
                    category_lookup[category[0]] += 1

                if pre_requisites is None or \
                   'None' in pre_requisites or \
                   'None.' in pre_requisites or \
                   'Missing' in pre_requisites or \
                   'N/A' in pre_requisites or \
                   pre_requisites==['']:
                    continue

                if True:
                    # 'Biology & Life Sciences' 'Computer Science' 'Business & Management' 'Data Analysis & Statistics'
                    # 'Education & Teacher Training' 'Economics & Finance' 'Engineering' 'History' 'Humanities' 'Math'
                    # 'Physics' 'Science' 'Social Sciences' 'Literature' 'Communication'  'Architecture' 'Art & Culture'
                    # 'Chemistry' 'Design' 'Electronics' 'Health & Safety' 'Language' 'Law' 'Medicine' 'Music'
                    #if 'Computer Science' not in category: continue
                    #if 'PurdueX' not in institute: continue # Microsoft, HarvardX, PurdueX 'MITx'

                    if name is not None and name not in course_details_lookup:
                        course_details_lookup[name]=dict()

                    if pre_requisites is not None and name is not None and 'pre-requisites' not in course_details_lookup[name]:
                        course_details_lookup[name]['pre-requisites']= pre_requisites

                    if category is not None and name is not None and 'category' not in course_details_lookup[name]:
                        course_details_lookup[name]['category']= category

                    if isinstance(institute[0],list) or institute[0]=='': continue

                    if institute is not None and name is not None and 'institute' not in course_details_lookup[name]:
                        course_details_lookup[name]['institute']= institute

                    if institute[0] not in institutes_list:
                        institutes_list.append(institute[0])

                    if institute[0] not in inst_course_lookup:
                        inst_course_lookup[institute[0]]=1
                    else:
                        inst_course_lookup[institute[0]] +=1

                    # if 'assumed_k' not in course_details_lookup[code]:
                    #    course_details_lookup[code]['assumed_k'] = assumed_k
                    index+=1

            if True:
                for name, details in course_details_lookup.iteritems():
                    if name not in generator_list:
                        generator_list.append(name)

                    if 'pre-requisites' in course_details_lookup[name]:
                        pre_reqs = course_details_lookup[name]['pre-requisites']
                        if pre_reqs is None or len(pre_reqs)==0: continue

                        for pre_requisite in pre_reqs:
                            if pre_requisite == "": continue

                            if isinstance(pre_requisite, list):
                                edge_list.append(Edge(set(pre_requisite), set([name])))
                                for item in pre_requisite:
                                    if item not in generator_list:
                                        generator_list.append(item)
                            else:
                                # ignore pre-reqs that are not course names (eg assumed K)
                                # if pre_requisite not in course_details_lookup: continue
                                if 'None' in pre_requisite or 'N/A' in pre_requisite or 'Missing' in pre_requisite:
                                    continue

                                edge_list.append(Edge(set([pre_requisite]), set([name])))
                                if pre_requisite not in generator_list:
                                   generator_list.append(pre_requisite)

        # create course metagraph
        mg = Metagraph(set(generator_list))
        mg.add_edges_from(edge_list)
        MetagraphHelper().generate_visualisation(edge_list,
                                                 '/Users/a1070571/Documents/ITS/course_struct_new.dot')
        print('done')


        # define metagraph
        generating_set = {'Maths_IB', 'Int_Econ_II', 'SMI_II',
                         'TS_III'}
        mg = Metagraph(generating_set)
        mg.add_edges_from([
         Edge({'Maths_IB'}, {'SMI_II'}),
         Edge({'SMI_II'}, {'TS_III'}),
         Edge({'Maths_IB','Int_Econ_II'}, {'TS_III'}) ])

        # compute metapaths
        source={'Maths_IB'}
        target={'TS_III'}
        metapaths = mg.get_all_metapaths_from(source, target)
        for metapath in metapaths:
          MetagraphHelper().generate_visualisation(metapath.edge_list,
            '/Users/a1070571/Documents/ITS/mp.dot')
          #print('\%s'\%(repr(metapath.edge_list)))

        gen_list5 = ['x1','x2','x3','x4']
        edge_list5 =[Edge({'x1','x2','x3'},{'x4'}),
                     Edge({'x2','x3'},{'x4'})]
        mg5 = Metagraph(set(gen_list5))
        mg5.add_edges_from(edge_list5)

        res = mg5.get_all_metapaths_from({'x1','x2','x3'},{'x4'})
        for mp in res:
            if not mg5.is_input_dominant_metapath(mp):
                print('not input dom')
        print('test')


        gen_list4 = ['x1','x2','x3','x4','x5','x6','x7']
        edge_list4 = [Edge({'x1','x2'},{'x4'}),
                      Edge({'x2','x3'},{'x5'}),
                      Edge({'x4'},{'x6'}),
                      Edge({'x5'},{'x6'}),
                      Edge({'x6'},{'x7'})]
        mg4 = Metagraph(set(gen_list4))
        mg4.add_edges_from(edge_list4)

        res = mg4.get_all_metapaths_from({'x1','x2','x3'},{'x7'})
        for mp in res:
            if not mg4.is_edge_dominant_metapath(mp):
                print('not edge dom')

        print('test')

        #MetagraphHelper().generate_visualisation(edge_list,
        #                                         '/Users/a1070571/Documents/ITS/course_struct.dot')

        # assumed knowledge
        #mg2 = Metagraph(set(generator_list2))
        #mg2.add_edges_from(edge_list2)

        # 1. how do we find flaws in the course structure
        # eg conflicting pre-requisites (eg loops)
        # eg courses that cant be reached ?
        # for node in mg.nodes:
        #    mps = mg.get_all_metapaths_from(node.element_set,node.element_set)
        #    if mps is not None and len(mps)>0:
        #        for mp in mps:
        #            print('conflicting pre-requisites found: %s'%repr(mp))

        if False:
            gen_set_new = {'M 1013', 'M 1011', 'M 1012', 'M 2101', 'M 2102', 'M 2201', 'M 2202',
                           'AM 3002', 'AM 3022', 'AM 3023', 'AM 3021'}
            edge_list_new=[Edge({'M 1013'},{'M 1011'}),
                           Edge({'M 1011'},{'M 1012'}),
                           Edge({'M 1012'},{'M 2101'}),
                           Edge({'M 1012'},{'M 2102'}),
                           Edge({'M 1012'},{'M 2201'}),
                           Edge({'M 1012'},{'M 2202'}),
                           Edge({'M 2101', 'M 2102'},{'AM 3002'}),
                           Edge({'M 2201', 'M 2202'},{'AM 3002'}),
                           Edge({'AM 3002'},{'M 2101'}),
                           Edge({'M 2101', 'M 2102'},{'AM 3022'}),
                           Edge({'M 2201', 'M 2202'},{'AM 3022'}),
                           Edge({'M 2201', 'M 2202'},{'AM 3023'}),
                           Edge({'M 2101', 'M 2102'},{'AM 3023'}),
                           Edge({'M 2201', 'M 2202'},{'AM 3021'}),
                           Edge({'M 2101', 'M 2102'},{'AM 3021'}),
                           Edge({'AM 3021'},{'M 2202'})]

            mg3 = Metagraph(gen_set_new)
            mg3.add_edges_from(edge_list_new)

            output_folder='/Users/a1070571/Documents/ITS'
            index = 1

            for node in mg3.nodes:
                metapaths = mg3.get_all_metapaths_from(node.element_set,node.element_set)
                if metapaths is not None and len(metapaths)>0:
                    for metapath in metapaths:
                        if mg3.is_edge_dominant_metapath(metapath):
                            #print('conflicting pre-requisites found: %s'%repr(mp))
                            MetagraphHelper().generate_visualisation(metapath.edge_list,
                                                        '%s/conflict_%s.dot'%(output_folder,index))
                            index +=1
                else:
                    for elt in node.element_set:
                        metapaths = mg3.get_all_metapaths_from(node.element_set,{elt})
                        if metapaths is not None and len(metapaths)>0:
                            for metapath in metapaths:
                                if mg3.is_edge_dominant_metapath(metapath):
                                    # print('conflicting pre-requisites found: %s'%repr(mp))
                                    MetagraphHelper().generate_visualisation(metapath.edge_list,
                                                        '%s/conflict_%s.dot'%(output_folder,index))
                                    index +=1


        #t = mg3.get_all_metapaths_from({'M 2101','M 2102'},{'M 2101'})
        # check for unreachable courses

        #for course in list(mg3.generating_set):
        #    source = mg3.generating_set.difference({course})
        #    target = {course}
        #    metapaths = mg3.get_all_metapaths_from(source,target)
        #    if metapaths is None or len(metapaths)==0:
        #        print('unreachable: %s'%course)
        #print('done')

        # 2. what are the pathways to course "APP MTH 3023"?
        # all level1 subjects
        high_school_courses={'SACE S2 Maths', 'a C in SACE S2 Maths', 'SACE S2 Special Maths',
                             'a 3 in IB Maths HL', 'a 4 in IB Maths SL', 'Maths L II 12 units'}

        level1_courses = {'M 1008', 'M 1009', 'M 1010', 'M 1011', 'M 1012',
                          'M 1013', 'M 1015', 'S 1000', 'S 1004',
                          'S 1005', 'S 1504', 'CS 1102', 'CS 1012', 'CS 1101',
                          'CS 1201', 'MENG 1100', 'MENG 1102', 'MENG 1103', 'MENG 1104', 'MENG 1105',
                          'CENVENG 1012'}

        #entry_level_courses = set(high_school_courses).union(set(level1_courses))
        all_high_school_courses={'a C in SACE S2 Maths', 'SACE S2 Special Maths',
                                 'a 3 in IB Maths HL'}
        if False:
            target = {'AM 3023'}
            pathways = self.get_pathways_to(all_high_school_courses, target, mg)
            output_folder='/Users/a1070571/Documents/ITS'
            index=1

            for path in pathways:
               MetagraphHelper().generate_visualisation(path.edge_list,
                                                        '%s/pathway_%s.dot'%(output_folder,index))
               index +=1

        # pathways = self.get_pathways_to({'STATS 3005'},mg)
        # print('test')
        #MetagraphHelper().generate_visualisation(mg.edges, '/Users/a1070571/Documents/ITS/course_structure.dot')

        if False:

            # 3. what are all the pre-requisites for course "APP MTH 3023"?
            pre_requisites = self.get_prerequisites(pathways)
            for course, lookup in pre_requisites.iteritems():
                for prerequisites in lookup.values():
                    if 'MATHS 2102' not in prerequisites:
                        print('%s'%(prerequisites))

            # 4. what group of courses have the same pre-requisites
            # do the same for other courses and compare
            pathways2 = self.get_pathways_to({'APP MTH 3002'},mg)
            pre_requisites2 = self.get_prerequisites(pathways2)
            identical_pre_requisites = self.compare_pre_requisites(pre_requisites,pre_requisites2)
            if identical_pre_requisites is not None:
                print('courses %s and %s have the same pre-requisites: %s'%('APP MTH 3023','APP MTH 3002',list(identical_pre_requisites)))

            # 6. can we provide alternate pathways based on career goals (eg, mechanical engineering)
            # identify courses applicable to goal
            # identify the pathways for each course
            # compose alternate pathways for course set
            mech_eng_courses = {'APP MTH 3023', 'APP MTH 3002', 'MATHS 1011', 'MATHS 1012', 'MATHS 2201' }
            all_pathways=dict()
            for course in mech_eng_courses:
                pathways = self.get_pathways_to({course},mg)
                for pathway in pathways:
                    if course not in all_pathways:
                        all_pathways[course]=[]
                    all_pathways[course].append(pathway)

            pathways=None
            for course in mech_eng_courses:
                if pathways is None:
                    pathways = all_pathways[course]
                else:
                    pathways = self.combine_pathways(pathways, all_pathways, course, mg)

            # 6. what is the effect of failing course X?
            # eg in the context of achieving a career goal
            mg2 = Metagraph(set(generator_list))
            applicable_edge_list=[]
            for metapath in pathways:
                for edge in edge_list:
                    if not MetagraphHelper().is_edge_in_list(edge, applicable_edge_list):
                        applicable_edge_list.append(edge)
            mg2.add_edges_from(applicable_edge_list)

        # 7. what subject(s) are the critical ones for most subjects
        # find a way to remove these (eg with assumed knowledge) to
        # minimise pre-reqs
        # steps
        # i)   find metapaths from a source node to the other nodes
        # ii)  identify dominant metapaths in these (optional?)
        # iii) identify bridges in these metapaths
        # iv)  locate most popular/common bridges
        # v)   the nodes connected to these bridges are the most critical nodes
        #      (ie pre-reqs that apply to most courses)

        source = {'MATHS 1009','MATHS 1011', 'MATHS 1013', 'MATHS 1015', 'STATS 1000', 'STATS 1004', 'STATS 1005', 'STATS 1504'}
        target_courses = {'AM 3022'}
        target_courses_1 = {'AM 3001','AM 3002','AM 3014','AM 3016','AM 3020','AM 3022','AM 3022','AM 3021','AM 3023',
                          'PM 2106', 'PM 3002', 'PM 3007', 'PM 3009', 'PM 3019', 'PM 3022', 'PM 3023',
                          'S 3001', 'S 3003', 'S 3005', 'S 3006',
                           'AM 2105', 'M 2100', 'M 2101', 'M 2102', 'M 2103', 'M 2104', 'M 2201', 'M 2202', 'M 2203', 'PM 2106', 'M 3015', 'M 3020', 'S 2107'}

        if True:
            common_bridges=set()
            for course in target_courses:
                bridge_list=[]
                pathways = self.get_pathways_to(high_school_courses, {course}, mg)
                for pathway in pathways:
                    for edge in pathway.edge_list:
                        if mg.is_bridge([edge], pathway.source, pathway.target): # source
                            if edge not in bridge_list:
                                print('edge: %s is a bridge from source to target= %s'%(edge, pathway.target))
                                bridge_list.append(edge)

                if len(list(common_bridges))==0:
                    common_bridges = set(bridge_list)
                else:
                    common_bridges = common_bridges.intersection(set(bridge_list))

            print('test')

        # cutset - set of edges if removed from MG removes all metapaths from source to target
        # mtd 2: find all metapaths from source to target
        #        for each metapath:
        #           remove all cutset edges in the metapath and re-check if remaining set of edges form a metapath from source  to target
        #           if no metapaths left => cutset
        # pro - no need to construct new MG (without cutset edges) and re-compute A* etc

        # target APP MTH 3023
        # pot. incomp course (2,3) = {'MATHS 2101', 'MATHS 2102'} and {'MATHS 2201', 'MATHS 2202'}
        edge_list2 = [Edge({'MATHS 2201', 'MATHS 2202'},{'APP MTH 3023'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1011'},{'Maths 1012'}),
                          Edge({'MATHS 1012'},{'MATHS 2201'}),
                          Edge({'MATHS 1012'},{'MATHS 2202'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]

        edge_list3 = [Edge({'MATHS 2101', 'MATHS 2102'},{'APP MTH 3023'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1011'},{'Maths 1012'}),
                          Edge({'MATHS 1012'},{'MATHS 2101'}),
                          Edge({'MATHS 1012'},{'MATHS 2102'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]


        # target APP MTH 3001
        # pot. incomp course (4,5) = {'MATHS 2103'} and {'MATHS 2201', 'MATHS 2202'}
        edge_list4 = [Edge({'MATHS 2103'},{'APP MTH 3001'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1012'},{'Maths 2103'}),
                          Edge({'MATHS 1011'},{'MATHS 1012'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]

        edge_list5 = [Edge({'MATHS 2201', 'MATHS 2202'},{'APP MTH 3001'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1011'},{'Maths 1012'}),
                          Edge({'MATHS 1012'},{'MATHS 2201'}),
                          Edge({'MATHS 1012'},{'MATHS 2202'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]


        # target APP MTH 3020
        # pot. incomp course (6,7) = {'MATHS 2103'} and {'APP MTH 3001'}
        edge_list6 = [Edge({'MATHS 2103'},{'APP MTH 3020'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1011'},{'Maths 1012'}),
                          Edge({'MATHS 1012'},{'MATHS 2201'}),
                          Edge({'MATHS 1012'},{'MATHS 2202'}),
                          Edge({'MATHS 1012'},{'MATHS 2103'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]

        edge_list7 = [Edge({'MATHS 2201', 'MATHS 2202'},{'APP MTH 3001'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1011'},{'Maths 1012'}),
                          Edge({'MATHS 1012'},{'MATHS 2201'}),
                          Edge({'MATHS 1012'},{'MATHS 2202'}),
                          Edge({'APP MTH 3001'},{'APP MTH 3020'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]


        # target MATHS 3012
        # pot. incomp course (8,9) = {'MATHS 1009', 'MATHS 1010'} and {'MATHS 1011', 'MATHS 1013'}
        # actual - MATHS 1010 and MATHS 1011?
        edge_list8 = [Edge({'MATHS 1009'},{'MATHS 1010'}),
                      Edge({'MATHS 1010'},{'MATHS 3012'})]

        edge_list9 = [Edge({'MATHS 1011'},{'MATHS 3012'}),
                      Edge({'MATHS 1013'},{'MATHS 1011'}),
                      Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]


        # target MATHS 3015
        # pot. incomp course (8,9) = {'MATHS 1011', 'MATHS 1012', 'MATHS 1013'} and {'COMP SCI 1102'}
        edge_list10 = [Edge({'MATHS 1011'},{'MATHS 1012'}),
                      Edge({'MATHS 1012'},{'MATHS 3015'}),
                      Edge({'MATHS 1013'},{'MATHS 1011'}),
                      Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]

        edge_list11 = [Edge({'COMP SCI 1102'},{'MATHS 3015'})]

        #MetagraphHelper().generate_visualisation(edge_list10, '/Users/a1070571/Documents/ITS/incompatible_5a.dot')
        #MetagraphHelper().generate_visualisation(edge_list11, '/Users/a1070571/Documents/ITS/incompatible_5b.dot')

        #pathways = self.get_pathways_to({'MATHS 3015'},mg)
        target={'MATHS 3015'}
        source=set(generator_list).difference(target)
        #mp = Metapath(source,target,edge_list7)
        #result = mg.is_metapath(mp)
        #print('test')
        #result = mg.is_edge_dominant_metapath(mp)
        # alternate pathways
        # can include incompatible subjects
        # TODO: locate pot. incompatible courses using alternate paths?
        # eg for 2 alternate paths, distinct courses at the same pre-req level (eg year 2) are incompatible?
        # in this ex. target course has pre-reqs at various levels
        # path1: L1 pre-reqs: M1013,M1011,M1012    L2 pre-reqs: M2201,M2202     HS pre-reqs: At least a C- in SACE Stage 2 Mathematical Studies
        # path1: L1 pre-reqs: M1013,M1011,M1012    L2 pre-reqs: M2101,M2102     HS pre-reqs: At least a C- in SACE Stage 2 Mathematical Studies
        # criteria for incompatibility: same level (eg L2), non-overlapping courses
        #                               no-pre reqs at one level (for one path), so non-ovelapping courses at different levels (eg L1, L2)- combine courses at various levels and check overlaps

        mp2 = Metapath(source,target,edge_list10)
        mp3 = Metapath(source,target,edge_list11)

        # L1 pre-reqs
        # all level1 subjects
        source1 = {'MATHS 1008', 'MATHS 1009', 'MATHS 1010', 'MATHS 1011', 'MATHS 1012',
                   'MATHS 1012', 'MATHS 1013', 'MATHS 1015', 'STATS 1000', 'STATS 1004',
                   'STATS 1005', 'STATS 1504', 'COMP SCI 1102'}
        mp2_level1_pre_reqs=set()
        mp3_level1_pre_reqs=set()
        for edge in mp2.edge_list:
            mp2_level1_pre_reqs = mp2_level1_pre_reqs.union(source1.intersection(edge.invertex))
            mp2_level1_pre_reqs = mp2_level1_pre_reqs.union(source1.intersection(edge.outvertex))

        for edge in mp3.edge_list:
            mp3_level1_pre_reqs = mp3_level1_pre_reqs.union(source1.intersection(edge.invertex))
            mp3_level1_pre_reqs = mp3_level1_pre_reqs.union(source1.intersection(edge.outvertex))

        # all level2 subjects
        source2 = { 'APP MTH 2105', 'MATHS 2100', 'MATHS 2101', 'MATHS 2102', 'MATHS 2103', 'MATHS 2104', 'MATHS 2201', 'MATHS 2202', 'MATHS 2203', 'PURE MTH 2106', 'STATS 2107'}

        mp2_level2_pre_reqs=set()
        mp3_level2_pre_reqs=set()

        for edge in mp2.edge_list:
            mp2_level2_pre_reqs = mp2_level2_pre_reqs.union(source2.intersection(edge.invertex))
            mp2_level2_pre_reqs = mp2_level2_pre_reqs.union(source2.intersection(edge.outvertex))

        for edge in mp3.edge_list:
            mp3_level2_pre_reqs = mp3_level2_pre_reqs.union(source2.intersection(edge.invertex))
            mp3_level2_pre_reqs = mp3_level2_pre_reqs.union(source2.intersection(edge.outvertex))

        # all level3 subjects
        source3 = {'APP MTH 3001', 'APP MTH 3002', 'APP MTH 3014', 'APP MTH 3016', 'APP MTH 3020', 'APP MTH 3021', 'APP MTH 3022', 'APP MTH 3023', 'MATHS 3012', 'MATHS 3015', 'MATHS 3020', 'MATHS 3021',
                  'PURE MTH 3002', 'PURE MTH 3007', 'PURE MTH 3009', 'PURE MTH 3019' , 'PURE MTH 3022', 'PURE MTH 3023', 'STATS 3001', 'STATS 3003', 'STATS 3005', 'STATS 3006'}

        mp2_level3_pre_reqs=set()
        mp3_level3_pre_reqs=set()

        for edge in mp2.edge_list:
            mp2_level3_pre_reqs = mp2_level3_pre_reqs.union(source3.intersection(edge.invertex))
            mp2_level3_pre_reqs = mp2_level3_pre_reqs.union(source3.intersection(edge.outvertex))
            mp2_level3_pre_reqs = mp2_level3_pre_reqs.difference(target)

        for edge in mp3.edge_list:
            mp3_level3_pre_reqs = mp3_level3_pre_reqs.union(source3.intersection(edge.invertex))
            mp3_level3_pre_reqs = mp3_level3_pre_reqs.union(source3.intersection(edge.outvertex))
            mp3_level3_pre_reqs = mp3_level3_pre_reqs.difference(target)

        pot_incompatible_level1_courses_A = None
        pot_incompatible_level1_courses_B = None
        pot_incompatible_level2_courses_A = None
        pot_incompatible_level2_courses_B = None
        pot_incompatible_level3_courses_A = None
        pot_incompatible_level3_courses_B = None

        pot_incompatible_courses_A = None
        pot_incompatible_courses_B = None

        # 1,2,3 > 0
        # 1,2 >0 3=0
        # 1>0 2=0 3>0
        # 1>0 2=0 3=0
        # 1=0 2>0 3>0 x
        # 1=0 2=0 3>0 x
        # 1=0 2=0 3=0 X
        # 1=0 2>0 3=0 x

        # find pot. incompatible courses
        if (len(mp2_level1_pre_reqs)>0 and len(mp2_level2_pre_reqs)>0 and len(mp2_level3_pre_reqs)>0) and \
                (len(mp3_level1_pre_reqs)>0 and len(mp3_level2_pre_reqs)>0 and len(mp3_level3_pre_reqs)>0):
                # compare courses at each corresponding level
                level1_overlap = mp2_level1_pre_reqs.intersection(mp3_level1_pre_reqs)
                level2_overlap = mp2_level2_pre_reqs.intersection(mp3_level2_pre_reqs)
                level3_overlap = mp2_level3_pre_reqs.intersection(mp3_level3_pre_reqs)

                pot_incompatible_level1_courses_A = mp2_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level1_courses_B = mp3_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level2_courses_A = mp2_level2_pre_reqs.difference(level2_overlap)
                pot_incompatible_level2_courses_B = mp3_level2_pre_reqs.difference(level2_overlap)
                pot_incompatible_level3_courses_A = mp2_level3_pre_reqs.difference(level3_overlap)
                pot_incompatible_level3_courses_B = mp3_level3_pre_reqs.difference(level3_overlap)

        elif (len(mp2_level1_pre_reqs)>0 and len(mp2_level2_pre_reqs)>0 and len(mp2_level3_pre_reqs)==0) and \
                (len(mp3_level1_pre_reqs)>0 and len(mp3_level2_pre_reqs)>0 and len(mp3_level3_pre_reqs)==0):

                # compare courses at each corresponding level
                level1_overlap = mp2_level1_pre_reqs.intersection(mp3_level1_pre_reqs)
                level2_overlap = mp2_level2_pre_reqs.intersection(mp3_level2_pre_reqs)

                pot_incompatible_level1_courses_A = mp2_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level1_courses_B = mp3_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level2_courses_A = mp2_level2_pre_reqs.difference(level2_overlap)
                pot_incompatible_level2_courses_B = mp3_level2_pre_reqs.difference(level2_overlap)

        elif (len(mp2_level1_pre_reqs)>0 and len(mp2_level2_pre_reqs)==0 and len(mp2_level3_pre_reqs)==0) and \
                (len(mp3_level1_pre_reqs)>0 and len(mp3_level2_pre_reqs)==0 and len(mp3_level3_pre_reqs)==0):

                # compare courses at each corresponding level
                level1_overlap = mp2_level1_pre_reqs.intersection(mp3_level1_pre_reqs)

                pot_incompatible_level1_courses_A = mp2_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level1_courses_B = mp3_level1_pre_reqs.difference(level1_overlap)

        elif len(mp2_level1_pre_reqs)>0 and len(mp3_level1_pre_reqs)>0:

                # compare combined L2 and L3 lists of courses
                combined_A = mp2_level2_pre_reqs.union(mp2_level3_pre_reqs)
                combined_B = mp3_level2_pre_reqs.union(mp3_level3_pre_reqs)
                combined_overlap = combined_A.intersection(combined_B)
                pot_incompatible_courses_A = combined_A.difference(combined_overlap)
                pot_incompatible_courses_B = combined_B.difference(combined_overlap)

        elif len(mp2_level1_pre_reqs)==0:
             print('error')


        print('test')

        #for course in target_courses:
            #pathways = self.get_pathways_to({course},mg)
            #print('test')
            #for pathway in pathways:
            #    for edge in pathway.edge_list:

        #print('common bridges: %s'%(list(common_bridges)))

        if False:
            #edge1 = Edge({'MATHS 1011'}, {'MATHS 1012'})

            # all stand-alone level 1 subjects
            source = {'MATHS 1009','MATHS 1011', 'MATHS 1013', 'MATHS 1015', 'STATS 1000', 'STATS 1004', 'STATS 1005', 'STATS 1504'}

            # all level1 subjects
            source1 = {'MATHS 1008', 'MATHS 1009', 'MATHS 1010', 'MATHS 1011', 'MATHS 1012',
                       'MATHS 1012', 'MATHS 1013', 'MATHS 1015', 'STATS 1000', 'STATS 1004',
                       'STATS 1005', 'STATS 1504'}

            # t = mg.is_bridge([edge1], source, {'APP MTH 3023'}) # mp.target)

            pathways = self.get_pathways_to({'APP MTH 3023'},mg)
            bridge_list1=[]
            mp = pathways[0]
            for edge in mp.edge_list:
                if mg.is_bridge([edge], source, mp.target): # mp.source
                    if edge not in bridge_list1:
                        bridge_list1.append(edge)

            pathways = self.get_pathways_to({'APP MTH 3022'},mg)
            bridge_list2=[]
            mp = pathways[0]
            for edge in mp.edge_list:
                if mg.is_bridge([edge],source,mp.target): # mp.source
                    if edge not in bridge_list2:
                        bridge_list2.append(edge)

            pathways = self.get_pathways_to({'APP MTH 3021'},mg)
            bridge_list3=[]
            mp = pathways[0]
            for edge in mp.edge_list:
                if mg.is_bridge([edge],source,mp.target): # mp.source
                    if edge not in bridge_list3:
                        bridge_list3.append(edge)

            # find most common bridge amongst the lists
            print('test')

        # 8 replacing a pre-req with assumed knowledge or vice versa
        # does it make taking the course easier/difficult?
        # Q removing a pre-requisite:: shortens the course pathway? (ie less courses to study) => easier?

        # 9. 2nd semester courses with 1st semester ones as pre-reqs
        # students begining mid year cannot take these up
        # eg MATHS 2203, MATHS 1010
        # the problem has been mitigated to some extent by offering
        # pre-req subjects in both semesters (eg Maths IA, IB)

        # 10. combining multiple courses into a single course
        # how does it simplify the structure ?
        # in some cases reduces the number of pre-requisites for a course
        #    (eg. merge maths 2201, maths 2202 reduces # pre-reqs for maths 3023)
        # can increase difficulty to studying some courses given more content to study due to merged courses
        #    (eg. merging NM II and OOR II makes it difficult to study RP III - only needs NM II as a pre-req)

        # case 4: merging subjects : does it un-necessarily increase complexity of pre-reqs?
        # (1) for each merged subject: find what they are a pre-req of?
        # (2) does each subject in (1) have all merged subjects as pre-reqs?
        # If NOT the complexity of pre-reqs for those subjects have now increased
        # subjects_to_merge ={'MATHS 2201', 'MATHS 2202'}

        subjects_to_merge ={'MATHS 2104', 'MATHS 2203'}

        # pathways1 = self.get_pathways_from(subjects_to_merge, mg)
        # generator_list = list(mg.generating_set)
        result=[]
        for course in mg.generating_set:
            metapaths = mg.get_all_metapaths_from({'MATHS 2104'}, {course}) #{course}
            if metapaths is not None:
                for mp in metapaths:
                    result.append(mp.edge_list)

        print('test')

        # 11. inserting a pre-req or course into the structure,
        # or remove course or replace it with something new
        # may be no longer a pre-req, how will it break the structure?

        # TODO: auto-gen individual metapath diags (eg using igraph, graphviz or gephi)

    def test_course_dependencies2(self):
        import os
        import csv
        course_details_lookup=dict()
        edge_list=[]
        generator_list=[]
        generator_list2=[]
        edge_list2=[]

        return

        folder_path= os.path.join(os.getcwd(),'test_data')
        file_name='courses.csv'

        with open(os.path.join(folder_path, file_name), 'rb') as csvfile:
            reader = csv.reader(csvfile, delimiter=',', quotechar='|')
            index=0
            for row in reader:
                if index==0:
                    # omit header
                    index+=1
                    continue
                code = row[0]
                name = row[1]
                pre_requisites= MetagraphHelper().get_pre_requisites_list(row[2])
                assumed_k = MetagraphHelper().get_pre_requisites_list(row[4])
                if code not in course_details_lookup:
                    course_details_lookup[code]=dict()
                if 'name' not in course_details_lookup[code]:
                    course_details_lookup[code]['name']= name
                if 'pre-requisites' not in course_details_lookup[code]:
                    course_details_lookup[code]['pre-requisites']= pre_requisites
                if 'assumed_k' not in course_details_lookup[code]:
                    course_details_lookup[code]['assumed_k'] = assumed_k
                index+=1

            for code, details in course_details_lookup.iteritems():
                if code not in generator_list2:
                    generator_list2.append(code)
                for assumed_k in course_details_lookup[code]['assumed_k']:
                    if isinstance(assumed_k, list):
                        edge_list2.append(Edge(set(assumed_k), set([code])))
                        for item in assumed_k:
                            if item not in generator_list2:
                                generator_list2.append(item)
                    else:
                        edge_list2.append(Edge(set([assumed_k]), set([code])))
                        if assumed_k not in generator_list2:
                           generator_list2.append(assumed_k)

            for code, details in course_details_lookup.iteritems():
                if code not in generator_list:
                    generator_list.append(code)
                for pre_requisite in course_details_lookup[code]['pre-requisites']:
                    if isinstance(pre_requisite, list):
                        edge_list.append(Edge(set(pre_requisite), set([code])))
                        for item in pre_requisite:
                            if item not in generator_list:
                                generator_list.append(item)
                    else:
                        edge_list.append(Edge(set([pre_requisite]), set([code])))
                        if pre_requisite not in generator_list:
                           generator_list.append(pre_requisite)

        # create course metagraph
        mg = Metagraph(set(generator_list))
        #edge_list.append(Edge({'AM 3002'},{'M 2101'}))
        mg.add_edges_from(edge_list)

        output_folder='/Users/a1070571/Documents/ITS'
        index=1

        # 1. consistency
        if False:
            for node in mg.nodes:
                    print('index=%s'%index)
                    metapaths = mg.get_all_metapaths_from(node.element_set,node.element_set)
                    if metapaths is not None and len(metapaths)>0:
                        for metapath in metapaths:
                            if mg.is_edge_dominant_metapath(metapath):
                                #print('conflicting pre-requisites found: %s'%repr(mp))
                                MetagraphHelper().generate_visualisation(metapath.edge_list,
                                                            '%s/conflict_%s.dot'%(output_folder,index))
                                index +=1
                    else:
                        for elt in node.element_set:
                            metapaths = mg.get_all_metapaths_from(node.element_set,{elt})
                            if metapaths is not None and len(metapaths)>0:
                                for metapath in metapaths:
                                    if mg.is_edge_dominant_metapath(metapath):
                                        # print('conflicting pre-requisites found: %s'%repr(mp))
                                        MetagraphHelper().generate_visualisation(metapath.edge_list,
                                                            '%s/conflict_%s.dot'%(output_folder,index))
                                        index +=1

        # 2. alternate pathways
        if False:
            all_high_school_courses={'a C in SACE S2 Maths', 'SACE S2 Special Maths',
                                    'a 3 in IB Maths HL'}
            target = {'S 3005'}
            pathways = self.get_pathways_to(all_high_school_courses,
                                target, mg)
            index=1

            for path in pathways:
                MetagraphHelper().generate_visualisation(path.edge_list,
                                      '/Users/a1070571/Documents/ITS/pathway_%s.dot'%(index))
                index +=1

        # 3. critical pre-requisites
        source_courses ={'SACE S2 Maths', 'a C in SACE S2 Maths', 'SACE S2 Special Maths',
                         'a 3 in IB Maths HL', 'a 4 in IB Maths SL', 'M 1015', 'CS 1012', 'CS 1101', 'CS 1201', 'CS 1102', 'ECON 2504', 'M 2201', 'M 2202'}
        #source_courses= set(generator_list) #{'a C in SACE S2 Maths', 'SACE S2 Special Maths', 'a 3 in IB Maths HL'}
        target_courses= {'M 3020'}

        common_bridges=set()
        final_edge_set=set()
        for course in target_courses:
            bridge_list=[]
            pathways = self.get_pathways_to(source_courses, {course}, mg)
            for pathway in pathways:
                final_edge_set = final_edge_set.union(set(pathway.edge_list))
                for edge in pathway.edge_list:
                    if mg.is_bridge([edge], pathway.source, pathway.target): # source
                        if edge not in bridge_list:
                            print('edge: %s is a bridge from source to target= %s'%(edge, pathway.target))
                            bridge_list.append(edge)

            if len(list(common_bridges))==0:
                common_bridges = set(bridge_list)
            else:
                common_bridges = common_bridges.intersection(set(bridge_list))

        MetagraphHelper().generate_visualisation(list(final_edge_set),
                        '/Users/a1070571/Documents/ITS/critical10.dot')

        res = MetagraphHelper().custom_multiply_matrices(m1,m2,edges)
        if res is not None:
            print('result valid')


        print('test')
        return



        # alternate pathways to a course
        if False:
            all_high_school_courses={'a C in SACE S2 Maths', 'SACE S2 Special Maths',
                                'a 3 in IB Maths HL'}
            target = {'AM 3001'}
            pathways = self.get_pathways_to(all_high_school_courses,
                                target, mg)
            index=1

            for path in pathways:
                MetagraphHelper().generate_visualisation(path.edge_list,
                                      '/Users/a1070571/Documents/ITS/pathway_%s.dot'%(index))
                index +=1

            print('test')

        # A. what subject(s) are the critical ones for most subjects
        # find a way to remove these (eg with assumed knowledge) to
        # minimise pre-reqs
        # steps
        # i)   find metapaths from a source node to the other nodes
        # ii)  identify dominant metapaths in these (optional?)
        # iii) identify bridges in these metapaths
        # iv)  locate most popular/common bridges
        # v)   the nodes connected to these bridges are the most critical nodes
        #      (ie pre-reqs that apply to most courses)

        source_courses ={'SACE S2 Maths', 'a C in SACE S2 Maths', 'SACE S2 Special Maths',
                             'a 3 in IB Maths HL', 'a 4 in IB Maths SL', 'M 1015', 'CS 1012', 'CS 1101', 'CS 1201', 'CS 1102', 'ECON 2504', 'M 2201', 'M 2202'}

        target_courses_1 = {'S 2107', 'M 2201', 'M 2202', 'M 2101', 'M 2102', 'M 2100', 'M 2104', 'PM 2106', 'M 2203', 'M 2103', 'AM 2105',
                          'S 3001', 'S 3003', 'S 3005', 'S 3006', 'AM 3002', 'AM 3022', 'AM 3023', 'AM 3021', 'PM 3019', 'PM 3022', 'AM 3001',
                          'PM 3002', 'PM 3009', 'M 3015', 'M 3020', 'AM 3020', 'AM 3016', 'AM 3014', 'PM 3007', 'PM 3023'}

        target_courses_2= {'PM 3002', 'PM 3009'}
        target_courses= {'M 3020'}

        if True:
            common_bridges=set()
            final_edge_set=set()
            for course in target_courses:
                bridge_list=[]
                pathways = self.get_pathways_to(source_courses, {course}, mg)
                for pathway in pathways:
                    final_edge_set = final_edge_set.union(set(pathway.edge_list))
                    for edge in pathway.edge_list:
                        if mg.is_bridge([edge], pathway.source, pathway.target): # source
                            if edge not in bridge_list:
                                print('edge: %s is a bridge from source to target= %s'%(edge, pathway.target))
                                bridge_list.append(edge)

                if len(list(common_bridges))==0:
                    common_bridges = set(bridge_list)
                else:
                    common_bridges = common_bridges.intersection(set(bridge_list))

            MetagraphHelper().generate_visualisation(list(final_edge_set),
                                                     '/Users/a1070571/Documents/ITS/critical10.dot')
            print('test')


        # B. incompatible courses
        #target_courses = {'S 3005'}
        #source_courses = {'M 1012', 'ECON 2504'}

        source = {'a 3 in IB Maths HL'}
        source_1 ={'M 1009'}
        target = {'M 3012'}

        edges = [Edge({'a 3 in IB Maths HL'},{'M 1011'}),
                 Edge({'M 1011'},{'M 3012'})]

        m1 = Metapath(source, target, edges)
        res = mg.is_metapath(m1)
        file = '/Users/a1070571/Documents/ITS/path.dot'
        MetagraphHelper().generate_visualisation(edges,file)


        if False:
            for course in target_courses:
                index=1
                pathways = self.get_pathways_to(source_courses, {course}, mg)
                for pathway in pathways:
                    file = '/Users/a1070571/Documents/ITS/path_%s_%s.dot'%(course,index)
                    MetagraphHelper().generate_visualisation(pathway.edge_list,file)
                    index+=1
            print('test')










        gen_list5 = ['x1','x2','x3','x4']
        edge_list5 =[Edge({'x1','x2','x3'},{'x4'}),
                     Edge({'x2','x3'},{'x4'})]
        mg5 = Metagraph(set(gen_list5))
        mg5.add_edges_from(edge_list5)

        res = mg5.get_all_metapaths_from({'x1','x2','x3'},{'x4'})
        for mp in res:
            if not mg5.is_input_dominant_metapath(mp):
                print('not input dom')
        print('test')


        gen_list4 = ['x1','x2','x3','x4','x5','x6','x7']
        edge_list4 = [Edge({'x1','x2'},{'x4'}),
                      Edge({'x2','x3'},{'x5'}),
                      Edge({'x4'},{'x6'}),
                      Edge({'x5'},{'x6'}),
                      Edge({'x6'},{'x7'})]
        mg4 = Metagraph(set(gen_list4))
        mg4.add_edges_from(edge_list4)

        res = mg4.get_all_metapaths_from({'x1','x2','x3'},{'x7'})
        for mp in res:
            if not mg4.is_edge_dominant_metapath(mp):
                print('not edge dom')

        print('test')

        #MetagraphHelper().generate_visualisation(edge_list,
        #                                         '/Users/a1070571/Documents/ITS/course_struct.dot')

        # assumed knowledge
        #mg2 = Metagraph(set(generator_list2))
        #mg2.add_edges_from(edge_list2)

        # 1. how do we find flaws in the course structure
        # eg conflicting pre-requisites (eg loops)
        # eg courses that cant be reached ?
        # for node in mg.nodes:
        #    mps = mg.get_all_metapaths_from(node.element_set,node.element_set)
        #    if mps is not None and len(mps)>0:
        #        for mp in mps:
        #            print('conflicting pre-requisites found: %s'%repr(mp))

        if False:
            gen_set_new = {'M 1013', 'M 1011', 'M 1012', 'M 2101', 'M 2102', 'M 2201', 'M 2202',
                           'AM 3002', 'AM 3022', 'AM 3023', 'AM 3021'}
            edge_list_new=[Edge({'M 1013'},{'M 1011'}),
                           Edge({'M 1011'},{'M 1012'}),
                           Edge({'M 1012'},{'M 2101'}),
                           Edge({'M 1012'},{'M 2102'}),
                           Edge({'M 1012'},{'M 2201'}),
                           Edge({'M 1012'},{'M 2202'}),
                           Edge({'M 2101', 'M 2102'},{'AM 3002'}),
                           Edge({'M 2201', 'M 2202'},{'AM 3002'}),
                           Edge({'AM 3002'},{'M 2101'}),
                           Edge({'M 2101', 'M 2102'},{'AM 3022'}),
                           Edge({'M 2201', 'M 2202'},{'AM 3022'}),
                           Edge({'M 2201', 'M 2202'},{'AM 3023'}),
                           Edge({'M 2101', 'M 2102'},{'AM 3023'}),
                           Edge({'M 2201', 'M 2202'},{'AM 3021'}),
                           Edge({'M 2101', 'M 2102'},{'AM 3021'}),
                           Edge({'AM 3021'},{'M 2202'})]

            mg3 = Metagraph(gen_set_new)
            mg3.add_edges_from(edge_list_new)

            output_folder='/Users/a1070571/Documents/ITS'
            index = 1

            for node in mg3.nodes:
                metapaths = mg3.get_all_metapaths_from(node.element_set,node.element_set)
                if metapaths is not None and len(metapaths)>0:
                    for metapath in metapaths:
                        if mg3.is_edge_dominant_metapath(metapath):
                            #print('conflicting pre-requisites found: %s'%repr(mp))
                            MetagraphHelper().generate_visualisation(metapath.edge_list,
                                                        '%s/conflict_%s.dot'%(output_folder,index))
                            index +=1
                else:
                    for elt in node.element_set:
                        metapaths = mg3.get_all_metapaths_from(node.element_set,{elt})
                        if metapaths is not None and len(metapaths)>0:
                            for metapath in metapaths:
                                if mg3.is_edge_dominant_metapath(metapath):
                                    # print('conflicting pre-requisites found: %s'%repr(mp))
                                    MetagraphHelper().generate_visualisation(metapath.edge_list,
                                                        '%s/conflict_%s.dot'%(output_folder,index))
                                    index +=1


        #t = mg3.get_all_metapaths_from({'M 2101','M 2102'},{'M 2101'})
        # check for unreachable courses

        #for course in list(mg3.generating_set):
        #    source = mg3.generating_set.difference({course})
        #    target = {course}
        #    metapaths = mg3.get_all_metapaths_from(source,target)
        #    if metapaths is None or len(metapaths)==0:
        #        print('unreachable: %s'%course)
        #print('done')

        # 2. what are the pathways to course "APP MTH 3023"?
        # all level1 subjects
        high_school_courses={'SACE S2 Maths', 'a C in SACE S2 Maths', 'SACE S2 Special Maths',
                             'a 3 in IB Maths HL', 'a 4 in IB Maths SL', 'Maths L II 12 units'}

        level1_courses = {'M 1008', 'M 1009', 'M 1010', 'M 1011', 'M 1012',
                          'M 1013', 'M 1015', 'S 1000', 'S 1004',
                          'S 1005', 'S 1504', 'CS 1102', 'CS 1012', 'CS 1101',
                          'CS 1201', 'MENG 1100', 'MENG 1102', 'MENG 1103', 'MENG 1104', 'MENG 1105',
                          'CENVENG 1012'}

        #entry_level_courses = set(high_school_courses).union(set(level1_courses))
        all_high_school_courses={'a C in SACE S2 Maths', 'SACE S2 Special Maths',
                                 'a 3 in IB Maths HL'}
        if False:
            target = {'AM 3023'}
            pathways = self.get_pathways_to(all_high_school_courses, target, mg)
            output_folder='/Users/a1070571/Documents/ITS'
            index=1

            for path in pathways:
               MetagraphHelper().generate_visualisation(path.edge_list,
                                                        '%s/pathway_%s.dot'%(output_folder,index))
               index +=1

        # pathways = self.get_pathways_to({'STATS 3005'},mg)
        # print('test')
        #MetagraphHelper().generate_visualisation(mg.edges, '/Users/a1070571/Documents/ITS/course_structure.dot')

        if False:

            # 3. what are all the pre-requisites for course "APP MTH 3023"?
            pre_requisites = self.get_prerequisites(pathways)
            for course, lookup in pre_requisites.iteritems():
                for prerequisites in lookup.values():
                    if 'MATHS 2102' not in prerequisites:
                        print('%s'%(prerequisites))

            # 4. what group of courses have the same pre-requisites
            # do the same for other courses and compare
            pathways2 = self.get_pathways_to({'APP MTH 3002'},mg)
            pre_requisites2 = self.get_prerequisites(pathways2)
            identical_pre_requisites = self.compare_pre_requisites(pre_requisites,pre_requisites2)
            if identical_pre_requisites is not None:
                print('courses %s and %s have the same pre-requisites: %s'%('APP MTH 3023','APP MTH 3002',list(identical_pre_requisites)))

            # 6. can we provide alternate pathways based on career goals (eg, mechanical engineering)
            # identify courses applicable to goal
            # identify the pathways for each course
            # compose alternate pathways for course set
            mech_eng_courses = {'APP MTH 3023', 'APP MTH 3002', 'MATHS 1011', 'MATHS 1012', 'MATHS 2201' }
            all_pathways=dict()
            for course in mech_eng_courses:
                pathways = self.get_pathways_to({course},mg)
                for pathway in pathways:
                    if course not in all_pathways:
                        all_pathways[course]=[]
                    all_pathways[course].append(pathway)

            pathways=None
            for course in mech_eng_courses:
                if pathways is None:
                    pathways = all_pathways[course]
                else:
                    pathways = self.combine_pathways(pathways, all_pathways, course, mg)

            # 6. what is the effect of failing course X?
            # eg in the context of achieving a career goal
            mg2 = Metagraph(set(generator_list))
            applicable_edge_list=[]
            for metapath in pathways:
                for edge in edge_list:
                    if not MetagraphHelper().is_edge_in_list(edge, applicable_edge_list):
                        applicable_edge_list.append(edge)
            mg2.add_edges_from(applicable_edge_list)

        # 7. what subject(s) are the critical ones for most subjects
        # find a way to remove these (eg with assumed knowledge) to
        # minimise pre-reqs
        # steps
        # i)   find metapaths from a source node to the other nodes
        # ii)  identify dominant metapaths in these (optional?)
        # iii) identify bridges in these metapaths
        # iv)  locate most popular/common bridges
        # v)   the nodes connected to these bridges are the most critical nodes
        #      (ie pre-reqs that apply to most courses)

        source = {'MATHS 1009','MATHS 1011', 'MATHS 1013', 'MATHS 1015', 'STATS 1000', 'STATS 1004', 'STATS 1005', 'STATS 1504'}
        target_courses = {'AM 3022'}
        target_courses_1 = {'AM 3001','AM 3002','AM 3014','AM 3016','AM 3020','AM 3022','AM 3022','AM 3021','AM 3023',
                          'PM 2106', 'PM 3002', 'PM 3007', 'PM 3009', 'PM 3019', 'PM 3022', 'PM 3023',
                          'S 3001', 'S 3003', 'S 3005', 'S 3006',
                           'AM 2105', 'M 2100', 'M 2101', 'M 2102', 'M 2103', 'M 2104', 'M 2201', 'M 2202', 'M 2203', 'PM 2106', 'M 3015', 'M 3020', 'S 2107'}

        if True:
            common_bridges=set()
            for course in target_courses:
                bridge_list=[]
                pathways = self.get_pathways_to(high_school_courses, {course}, mg)
                for pathway in pathways:
                    for edge in pathway.edge_list:
                        if mg.is_bridge([edge], pathway.source, pathway.target): # source
                            if edge not in bridge_list:
                                print('edge: %s is a bridge from source to target= %s'%(edge, pathway.target))
                                bridge_list.append(edge)

                if len(list(common_bridges))==0:
                    common_bridges = set(bridge_list)
                else:
                    common_bridges = common_bridges.intersection(set(bridge_list))

            print('test')

        # cutset - set of edges if removed from MG removes all metapaths from source to target
        # mtd 2: find all metapaths from source to target
        #        for each metapath:
        #           remove all cutset edges in the metapath and re-check if remaining set of edges form a metapath from source  to target
        #           if no metapaths left => cutset
        # pro - no need to construct new MG (without cutset edges) and re-compute A* etc

        # target APP MTH 3023
        # pot. incomp course (2,3) = {'MATHS 2101', 'MATHS 2102'} and {'MATHS 2201', 'MATHS 2202'}
        edge_list2 = [Edge({'MATHS 2201', 'MATHS 2202'},{'APP MTH 3023'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1011'},{'Maths 1012'}),
                          Edge({'MATHS 1012'},{'MATHS 2201'}),
                          Edge({'MATHS 1012'},{'MATHS 2202'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]

        edge_list3 = [Edge({'MATHS 2101', 'MATHS 2102'},{'APP MTH 3023'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1011'},{'Maths 1012'}),
                          Edge({'MATHS 1012'},{'MATHS 2101'}),
                          Edge({'MATHS 1012'},{'MATHS 2102'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]


        # target APP MTH 3001
        # pot. incomp course (4,5) = {'MATHS 2103'} and {'MATHS 2201', 'MATHS 2202'}
        edge_list4 = [Edge({'MATHS 2103'},{'APP MTH 3001'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1012'},{'Maths 2103'}),
                          Edge({'MATHS 1011'},{'MATHS 1012'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]

        edge_list5 = [Edge({'MATHS 2201', 'MATHS 2202'},{'APP MTH 3001'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1011'},{'Maths 1012'}),
                          Edge({'MATHS 1012'},{'MATHS 2201'}),
                          Edge({'MATHS 1012'},{'MATHS 2202'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]


        # target APP MTH 3020
        # pot. incomp course (6,7) = {'MATHS 2103'} and {'APP MTH 3001'}
        edge_list6 = [Edge({'MATHS 2103'},{'APP MTH 3020'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1011'},{'Maths 1012'}),
                          Edge({'MATHS 1012'},{'MATHS 2201'}),
                          Edge({'MATHS 1012'},{'MATHS 2202'}),
                          Edge({'MATHS 1012'},{'MATHS 2103'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]

        edge_list7 = [Edge({'MATHS 2201', 'MATHS 2202'},{'APP MTH 3001'}),
                          Edge({'MATHS 1013'},{'MATHS 1011'}),
                          Edge({'MATHS 1011'},{'Maths 1012'}),
                          Edge({'MATHS 1012'},{'MATHS 2201'}),
                          Edge({'MATHS 1012'},{'MATHS 2202'}),
                          Edge({'APP MTH 3001'},{'APP MTH 3020'}),
                          Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]


        # target MATHS 3012
        # pot. incomp course (8,9) = {'MATHS 1009', 'MATHS 1010'} and {'MATHS 1011', 'MATHS 1013'}
        # actual - MATHS 1010 and MATHS 1011?
        edge_list8 = [Edge({'MATHS 1009'},{'MATHS 1010'}),
                      Edge({'MATHS 1010'},{'MATHS 3012'})]

        edge_list9 = [Edge({'MATHS 1011'},{'MATHS 3012'}),
                      Edge({'MATHS 1013'},{'MATHS 1011'}),
                      Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]


        # target MATHS 3015
        # pot. incomp course (8,9) = {'MATHS 1011', 'MATHS 1012', 'MATHS 1013'} and {'COMP SCI 1102'}
        edge_list10 = [Edge({'MATHS 1011'},{'MATHS 1012'}),
                      Edge({'MATHS 1012'},{'MATHS 3015'}),
                      Edge({'MATHS 1013'},{'MATHS 1011'}),
                      Edge({'At least a C- in SACE Stage 2 Mathematical Studies'},{'MATHS 1013'})]

        edge_list11 = [Edge({'COMP SCI 1102'},{'MATHS 3015'})]

        #MetagraphHelper().generate_visualisation(edge_list10, '/Users/a1070571/Documents/ITS/incompatible_5a.dot')
        #MetagraphHelper().generate_visualisation(edge_list11, '/Users/a1070571/Documents/ITS/incompatible_5b.dot')

        #pathways = self.get_pathways_to({'MATHS 3015'},mg)
        target={'MATHS 3015'}
        source=set(generator_list).difference(target)
        #mp = Metapath(source,target,edge_list7)
        #result = mg.is_metapath(mp)
        #print('test')
        #result = mg.is_edge_dominant_metapath(mp)
        # alternate pathways
        # can include incompatible subjects
        # TODO: locate pot. incompatible courses using alternate paths?
        # eg for 2 alternate paths, distinct courses at the same pre-req level (eg year 2) are incompatible?
        # in this ex. target course has pre-reqs at various levels
        # path1: L1 pre-reqs: M1013,M1011,M1012    L2 pre-reqs: M2201,M2202     HS pre-reqs: At least a C- in SACE Stage 2 Mathematical Studies
        # path1: L1 pre-reqs: M1013,M1011,M1012    L2 pre-reqs: M2101,M2102     HS pre-reqs: At least a C- in SACE Stage 2 Mathematical Studies
        # criteria for incompatibility: same level (eg L2), non-overlapping courses
        #                               no-pre reqs at one level (for one path), so non-ovelapping courses at different levels (eg L1, L2)- combine courses at various levels and check overlaps

        mp2 = Metapath(source,target,edge_list10)
        mp3 = Metapath(source,target,edge_list11)

        # L1 pre-reqs
        # all level1 subjects
        source1 = {'MATHS 1008', 'MATHS 1009', 'MATHS 1010', 'MATHS 1011', 'MATHS 1012',
                   'MATHS 1012', 'MATHS 1013', 'MATHS 1015', 'STATS 1000', 'STATS 1004',
                   'STATS 1005', 'STATS 1504', 'COMP SCI 1102'}
        mp2_level1_pre_reqs=set()
        mp3_level1_pre_reqs=set()
        for edge in mp2.edge_list:
            mp2_level1_pre_reqs = mp2_level1_pre_reqs.union(source1.intersection(edge.invertex))
            mp2_level1_pre_reqs = mp2_level1_pre_reqs.union(source1.intersection(edge.outvertex))

        for edge in mp3.edge_list:
            mp3_level1_pre_reqs = mp3_level1_pre_reqs.union(source1.intersection(edge.invertex))
            mp3_level1_pre_reqs = mp3_level1_pre_reqs.union(source1.intersection(edge.outvertex))

        # all level2 subjects
        source2 = { 'APP MTH 2105', 'MATHS 2100', 'MATHS 2101', 'MATHS 2102', 'MATHS 2103', 'MATHS 2104', 'MATHS 2201', 'MATHS 2202', 'MATHS 2203', 'PURE MTH 2106', 'STATS 2107'}

        mp2_level2_pre_reqs=set()
        mp3_level2_pre_reqs=set()

        for edge in mp2.edge_list:
            mp2_level2_pre_reqs = mp2_level2_pre_reqs.union(source2.intersection(edge.invertex))
            mp2_level2_pre_reqs = mp2_level2_pre_reqs.union(source2.intersection(edge.outvertex))

        for edge in mp3.edge_list:
            mp3_level2_pre_reqs = mp3_level2_pre_reqs.union(source2.intersection(edge.invertex))
            mp3_level2_pre_reqs = mp3_level2_pre_reqs.union(source2.intersection(edge.outvertex))

        # all level3 subjects
        source3 = {'APP MTH 3001', 'APP MTH 3002', 'APP MTH 3014', 'APP MTH 3016', 'APP MTH 3020', 'APP MTH 3021', 'APP MTH 3022', 'APP MTH 3023', 'MATHS 3012', 'MATHS 3015', 'MATHS 3020', 'MATHS 3021',
                  'PURE MTH 3002', 'PURE MTH 3007', 'PURE MTH 3009', 'PURE MTH 3019' , 'PURE MTH 3022', 'PURE MTH 3023', 'STATS 3001', 'STATS 3003', 'STATS 3005', 'STATS 3006'}

        mp2_level3_pre_reqs=set()
        mp3_level3_pre_reqs=set()

        for edge in mp2.edge_list:
            mp2_level3_pre_reqs = mp2_level3_pre_reqs.union(source3.intersection(edge.invertex))
            mp2_level3_pre_reqs = mp2_level3_pre_reqs.union(source3.intersection(edge.outvertex))
            mp2_level3_pre_reqs = mp2_level3_pre_reqs.difference(target)

        for edge in mp3.edge_list:
            mp3_level3_pre_reqs = mp3_level3_pre_reqs.union(source3.intersection(edge.invertex))
            mp3_level3_pre_reqs = mp3_level3_pre_reqs.union(source3.intersection(edge.outvertex))
            mp3_level3_pre_reqs = mp3_level3_pre_reqs.difference(target)

        pot_incompatible_level1_courses_A = None
        pot_incompatible_level1_courses_B = None
        pot_incompatible_level2_courses_A = None
        pot_incompatible_level2_courses_B = None
        pot_incompatible_level3_courses_A = None
        pot_incompatible_level3_courses_B = None

        pot_incompatible_courses_A = None
        pot_incompatible_courses_B = None

        # 1,2,3 > 0
        # 1,2 >0 3=0
        # 1>0 2=0 3>0
        # 1>0 2=0 3=0
        # 1=0 2>0 3>0 x
        # 1=0 2=0 3>0 x
        # 1=0 2=0 3=0 X
        # 1=0 2>0 3=0 x

        # find pot. incompatible courses
        if (len(mp2_level1_pre_reqs)>0 and len(mp2_level2_pre_reqs)>0 and len(mp2_level3_pre_reqs)>0) and \
                (len(mp3_level1_pre_reqs)>0 and len(mp3_level2_pre_reqs)>0 and len(mp3_level3_pre_reqs)>0):
                # compare courses at each corresponding level
                level1_overlap = mp2_level1_pre_reqs.intersection(mp3_level1_pre_reqs)
                level2_overlap = mp2_level2_pre_reqs.intersection(mp3_level2_pre_reqs)
                level3_overlap = mp2_level3_pre_reqs.intersection(mp3_level3_pre_reqs)

                pot_incompatible_level1_courses_A = mp2_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level1_courses_B = mp3_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level2_courses_A = mp2_level2_pre_reqs.difference(level2_overlap)
                pot_incompatible_level2_courses_B = mp3_level2_pre_reqs.difference(level2_overlap)
                pot_incompatible_level3_courses_A = mp2_level3_pre_reqs.difference(level3_overlap)
                pot_incompatible_level3_courses_B = mp3_level3_pre_reqs.difference(level3_overlap)

        elif (len(mp2_level1_pre_reqs)>0 and len(mp2_level2_pre_reqs)>0 and len(mp2_level3_pre_reqs)==0) and \
                (len(mp3_level1_pre_reqs)>0 and len(mp3_level2_pre_reqs)>0 and len(mp3_level3_pre_reqs)==0):

                # compare courses at each corresponding level
                level1_overlap = mp2_level1_pre_reqs.intersection(mp3_level1_pre_reqs)
                level2_overlap = mp2_level2_pre_reqs.intersection(mp3_level2_pre_reqs)

                pot_incompatible_level1_courses_A = mp2_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level1_courses_B = mp3_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level2_courses_A = mp2_level2_pre_reqs.difference(level2_overlap)
                pot_incompatible_level2_courses_B = mp3_level2_pre_reqs.difference(level2_overlap)

        elif (len(mp2_level1_pre_reqs)>0 and len(mp2_level2_pre_reqs)==0 and len(mp2_level3_pre_reqs)==0) and \
                (len(mp3_level1_pre_reqs)>0 and len(mp3_level2_pre_reqs)==0 and len(mp3_level3_pre_reqs)==0):

                # compare courses at each corresponding level
                level1_overlap = mp2_level1_pre_reqs.intersection(mp3_level1_pre_reqs)

                pot_incompatible_level1_courses_A = mp2_level1_pre_reqs.difference(level1_overlap)
                pot_incompatible_level1_courses_B = mp3_level1_pre_reqs.difference(level1_overlap)

        elif len(mp2_level1_pre_reqs)>0 and len(mp3_level1_pre_reqs)>0:

                # compare combined L2 and L3 lists of courses
                combined_A = mp2_level2_pre_reqs.union(mp2_level3_pre_reqs)
                combined_B = mp3_level2_pre_reqs.union(mp3_level3_pre_reqs)
                combined_overlap = combined_A.intersection(combined_B)
                pot_incompatible_courses_A = combined_A.difference(combined_overlap)
                pot_incompatible_courses_B = combined_B.difference(combined_overlap)

        elif len(mp2_level1_pre_reqs)==0:
             print('error')


        print('test')

        #for course in target_courses:
            #pathways = self.get_pathways_to({course},mg)
            #print('test')
            #for pathway in pathways:
            #    for edge in pathway.edge_list:

        #print('common bridges: %s'%(list(common_bridges)))

        if False:
            #edge1 = Edge({'MATHS 1011'}, {'MATHS 1012'})

            # all stand-alone level 1 subjects
            source = {'MATHS 1009','MATHS 1011', 'MATHS 1013', 'MATHS 1015', 'STATS 1000', 'STATS 1004', 'STATS 1005', 'STATS 1504'}

            # all level1 subjects
            source1 = {'MATHS 1008', 'MATHS 1009', 'MATHS 1010', 'MATHS 1011', 'MATHS 1012',
                       'MATHS 1012', 'MATHS 1013', 'MATHS 1015', 'STATS 1000', 'STATS 1004',
                       'STATS 1005', 'STATS 1504'}

            # t = mg.is_bridge([edge1], source, {'APP MTH 3023'}) # mp.target)

            pathways = self.get_pathways_to({'APP MTH 3023'},mg)
            bridge_list1=[]
            mp = pathways[0]
            for edge in mp.edge_list:
                if mg.is_bridge([edge], source, mp.target): # mp.source
                    if edge not in bridge_list1:
                        bridge_list1.append(edge)

            pathways = self.get_pathways_to({'APP MTH 3022'},mg)
            bridge_list2=[]
            mp = pathways[0]
            for edge in mp.edge_list:
                if mg.is_bridge([edge],source,mp.target): # mp.source
                    if edge not in bridge_list2:
                        bridge_list2.append(edge)

            pathways = self.get_pathways_to({'APP MTH 3021'},mg)
            bridge_list3=[]
            mp = pathways[0]
            for edge in mp.edge_list:
                if mg.is_bridge([edge],source,mp.target): # mp.source
                    if edge not in bridge_list3:
                        bridge_list3.append(edge)

            # find most common bridge amongst the lists
            print('test')

        # 8 replacing a pre-req with assumed knowledge or vice versa
        # does it make taking the course easier/difficult?
        # Q removing a pre-requisite:: shortens the course pathway? (ie less courses to study) => easier?

        # 9. 2nd semester courses with 1st semester ones as pre-reqs
        # students begining mid year cannot take these up
        # eg MATHS 2203, MATHS 1010
        # the problem has been mitigated to some extent by offering
        # pre-req subjects in both semesters (eg Maths IA, IB)

        # 10. combining multiple courses into a single course
        # how does it simplify the structure ?
        # in some cases reduces the number of pre-requisites for a course
        #    (eg. merge maths 2201, maths 2202 reduces # pre-reqs for maths 3023)
        # can increase difficulty to studying some courses given more content to study due to merged courses
        #    (eg. merging NM II and OOR II makes it difficult to study RP III - only needs NM II as a pre-req)

        # case 4: merging subjects : does it un-necessarily increase complexity of pre-reqs?
        # (1) for each merged subject: find what they are a pre-req of?
        # (2) does each subject in (1) have all merged subjects as pre-reqs?
        # If NOT the complexity of pre-reqs for those subjects have now increased
        # subjects_to_merge ={'MATHS 2201', 'MATHS 2202'}

        subjects_to_merge ={'MATHS 2104', 'MATHS 2203'}

        # pathways1 = self.get_pathways_from(subjects_to_merge, mg)
        # generator_list = list(mg.generating_set)
        result=[]
        for course in mg.generating_set:
            metapaths = mg.get_all_metapaths_from({'MATHS 2104'}, {course}) #{course}
            if metapaths is not None:
                for mp in metapaths:
                    result.append(mp.edge_list)

        print('test')

        # 11. inserting a pre-req or course into the structure,
        # or remove course or replace it with something new
        # may be no longer a pre-req, how will it break the structure?

        # TODO: auto-gen individual metapath diags (eg using igraph, graphviz or gephi)

    def test_course_dependencies_new(self):
        import os
        import numpy as np
        import csv
        course_details_lookup=dict()
        edge_list=[]
        generator_list=[]
        props = []
        return

        if True:
            # return
            # check result
            # cves_2017 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2017.npy').item()

            import json
            filename= "/Users/a1070571/Documents/ITS/nvdcve-1.0-2005.json"
            extracted = None
            with open(filename) as json_data:
                extracted = json.load(json_data)

            count = extracted['CVE_data_numberOfCVEs']
            entries = extracted['CVE_Items']
            print('Number of CVE entries: %s'%count)
            #return
            cve_ids = dict()

            for cve in entries:
                cve_id = cve['cve']['CVE_data_meta']['ID']
                cve_ids[cve_id]=cve_id
                # if cve_id not in cve_ids:
                #    cve_ids.append(cve_id)

            np.save('/Users/a1070571/Documents/ITS/cves_2005.npy', cve_ids)
            # dict_loaded = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2017.npy').item()
            # cves_2017.npy
            return

        files = ['/Users/a1070571/Documents/ITS/course_data_maths.csv', '/Users/a1070571/Documents/ITS/course_data_pure_maths.csv']

        for file in files:
            with open(os.path.join(file), 'rb') as csvfile:
                #reader = csv.reader(csvfile, delimiter=',', quotechar='|')
                reader = self.read_file(file)
                index=0
                for row in reader:
                    if index==0:
                        # omit header
                        index+=1
                        continue

                    code = str(row[0]).strip()
                    description = row[1]
                    career = row[2]
                    units = row[3]
                    term = row[4]
                    campus = row[5]
                    contact_hrs = row[6]
                    study_abroad = row[7]
                    study_non_award = row[8]
                    pre_requisites = MetagraphHelper().get_pre_requisites_list(row[9])
                    assumed_k = MetagraphHelper().get_pre_requisites_list(row[10])
                    incompatible = row[11]
                    assessment = row[12]
                    pre_2010_band = row[13]
                    pre_2010_cost = row[14]
                    post_2010_band = row[15]
                    post_2010_cost = row[16]
                    last_add_online = row[17]
                    census_date = row[18]
                    WNF_date = row[19]
                    WF_date = row[20]
                    class_size = row[21]
                    available = row[22]
                    class_dates = row[23]
                    class_day = row[24]
                    class_time = row[25]
                    class_loc = row[26]

                    if code not in course_details_lookup:
                        course_details_lookup[code]=dict()
                    if 'description' not in course_details_lookup[code]:
                        course_details_lookup[code]['description']= description
                    if 'pre-requisites' not in course_details_lookup[code]:
                        course_details_lookup[code]['pre-requisites']= pre_requisites
                    if 'assumed_k' not in course_details_lookup[code]:
                        course_details_lookup[code]['assumed_k'] = assumed_k
                    if 'career' not in course_details_lookup[code]:
                        course_details_lookup[code]['career'] = career
                    if 'units' not in course_details_lookup[code]:
                        course_details_lookup[code]['units'] = units
                    if 'term' not in course_details_lookup[code]:
                        course_details_lookup[code]['term'] = term
                    if 'campus' not in course_details_lookup[code]:
                        course_details_lookup[code]['campus'] = campus
                    if 'contact_hrs' not in course_details_lookup[code]:
                        course_details_lookup[code]['contact_hrs'] = contact_hrs
                    if 'study_abroad' not in course_details_lookup[code]:
                        course_details_lookup[code]['study_abroad'] = study_abroad
                    if 'study_non_award' not in course_details_lookup[code]:
                        course_details_lookup[code]['study_non_award'] = study_non_award
                    if 'incompatible' not in course_details_lookup[code]:
                        course_details_lookup[code]['incompatible'] = incompatible
                    if 'assessment' not in course_details_lookup[code]:
                        course_details_lookup[code]['assessment'] = assessment
                    if 'pre_2010_band' not in course_details_lookup[code]:
                        course_details_lookup[code]['pre_2010_band'] = pre_2010_band
                    if 'pre_2010_cost' not in course_details_lookup[code]:
                        course_details_lookup[code]['pre_2010_cost'] = pre_2010_cost
                    if 'post_2010_band' not in course_details_lookup[code]:
                        course_details_lookup[code]['post_2010_band'] = post_2010_band
                    if 'post_2010_cost' not in course_details_lookup[code]:
                        course_details_lookup[code]['post_2010_cost'] = post_2010_cost
                    if 'last_add_online' not in course_details_lookup[code]:
                        course_details_lookup[code]['last_add_online'] = last_add_online
                    if 'census_date' not in course_details_lookup[code]:
                        course_details_lookup[code]['census_date'] = census_date
                    if 'WNF_date' not in course_details_lookup[code]:
                        course_details_lookup[code]['WNF_date'] = WNF_date
                    if 'WF_date' not in course_details_lookup[code]:
                        course_details_lookup[code]['WF_date'] = WF_date
                    if 'class_size' not in course_details_lookup[code]:
                        course_details_lookup[code]['class_size'] = class_size
                    if 'available' not in course_details_lookup[code]:
                        course_details_lookup[code]['available'] = available
                    if 'class_dates' not in course_details_lookup[code]:
                        course_details_lookup[code]['class_dates'] = class_dates
                    if 'class_day' not in course_details_lookup[code]:
                        course_details_lookup[code]['class_day'] = class_day
                    if 'class_time' not in course_details_lookup[code]:
                        course_details_lookup[code]['class_time'] = class_time
                    if 'class_loc' not in course_details_lookup[code]:
                        course_details_lookup[code]['class_loc'] = class_loc
                    index+=1

                for code, details in course_details_lookup.iteritems():
                    if code not in generator_list:
                        generator_list.append(code)
                    for pre_requisite in course_details_lookup[code]['pre-requisites']:
                        if isinstance(pre_requisite, list):
                            # edge attributes
                            attrs = []
                            for elt in set(pre_requisite):
                                if elt in course_details_lookup:
                                    attrs.append('career=%s'%course_details_lookup[elt]['career'])
                                    attrs.append('units=%s'%course_details_lookup[elt]['units'])
                                    attrs.append('campus=%s'%course_details_lookup[elt]['campus'])
                                    attrs.append('study_abroad=%s'%course_details_lookup[elt]['study_abroad'])
                                    attrs.append('post_2010_cost=%s'%course_details_lookup[elt]['post_2010_cost'])
                                    attrs.append('last_add_online=%s'%course_details_lookup[elt]['last_add_online'])
                                    attrs.append('wnf_date=%s'%course_details_lookup[elt]['WNF_date'])
                                    attrs.append('available=%s'%course_details_lookup[elt]['available'])
                                else:
                                    print('test')

                            # attrs are part of node
                            edge_list.append(Edge(set(pre_requisite+attrs), set([code])))
                            # edge_list.append(Edge(set(pre_requisite), set([code]), attributes=attrs))
                            props += attrs
                            for item in pre_requisite:
                                if item not in generator_list:
                                    generator_list.append(item)
                        else:
                            attrs = []
                            if pre_requisite in course_details_lookup:
                                attrs.append('career=%s'%course_details_lookup[pre_requisite]['career'])
                                attrs.append('units=%s'%course_details_lookup[pre_requisite]['units'])
                                attrs.append('campus=%s'%course_details_lookup[pre_requisite]['campus'])
                                attrs.append('study_abroad=%s'%course_details_lookup[pre_requisite]['study_abroad'])
                                attrs.append('post_2010_cost=%s'%course_details_lookup[pre_requisite]['post_2010_cost'])
                                attrs.append('last_add_online=%s'%course_details_lookup[pre_requisite]['last_add_online'])
                                attrs.append('wnf_date=%s'%course_details_lookup[pre_requisite]['WNF_date'])
                                attrs.append('available=%s'%course_details_lookup[pre_requisite]['available'])
                            else:
                                print('here')

                            # attrs are part of node
                            edge_list.append(Edge(set([pre_requisite] + attrs), set([code])))
                            # edge_list.append(Edge(set([pre_requisite]), set([code]), attributes=attrs))
                            props += attrs
                            if pre_requisite not in generator_list:
                               generator_list.append(pre_requisite)

        # create course metagraph
        mg = Metagraph(set(generator_list).union(set(props)))
        mg.add_edges_from(edge_list)
        #cmg = ConditionalMetagraph(set(generator_list), set(props))
        #cmg.add_edges_from(edge_list)


        print('test')
        return

        common_bridges=set()
        final_edge_set=set()
        source_courses = {'MATHS 1011', 'MATHS 1015'}
        target_courses = {'MATHS 3020'}

        for course in target_courses:
            bridge_list=[]
            pathways = MetagraphHelper().get_pathways_to(source_courses, {course}, cmg)
            for pathway in pathways:
                final_edge_set = final_edge_set.union(set(pathway.edge_list))
                for edge in pathway.edge_list:
                    if cmg.is_bridge([edge], pathway.source, pathway.target): # source
                        if edge not in bridge_list: #and course not in edge.outvertex
                            print('edge: %s is a bridge from source to target= %s'%(edge, pathway.target))
                            bridge_list.append(edge)

            # if len(list(common_bridges))==0:
            #    common_bridges = set(bridge_list)
            # else:
            #    common_bridges = common_bridges.intersection(set(bridge_list))

        dot_file_crit = '/Users/a1070571/Documents/ITS/critical_prereqs.dot'
        image_file_crit = '/Users/a1070571/Documents/ITS/critical_prereqs.png'

        # gen visual
        # updated_edges =  MetagraphHelper().update_edge_tags(common_bridges, lookup_table)
        MetagraphHelper().generate_visualisation(bridge_list, # list(common_bridges),
                                                 dot_file_crit,
                                                 highlight_nodes=True,
                                                 highlight_edges=True)
        #import pydot
        #(graph,) = pydot.graph_from_dot_file(dot_file_crit)
        #graph.write_png(image_file_crit)

        critical_courses = set()
        edge_attrs = set()
        for edge in bridge_list:
            inv = edge.invertex.difference(edge.attributes)
            outv = edge.outvertex
            critical_courses = critical_courses.union(inv)
            critical_courses = critical_courses.union(outv)
            edge_attrs = edge_attrs.union(edge.attributes)

        critical_courses = critical_courses.difference({'MATHS 1011', 'MATHS 3020'})
        print('critical_courses:: %s'%list(critical_courses))

        locations =  MetagraphHelper().get_edge_attributes('campus=', edge_attrs)
        study_abroad =  MetagraphHelper().get_edge_attributes('study_abroad=', edge_attrs)
        costs = MetagraphHelper().get_edge_attributes('post_2010_cost=', edge_attrs)
        last_add_online = MetagraphHelper().get_edge_attributes('last_add_online=', edge_attrs)

        print('last_add_online:: %s'%list(last_add_online))

        # can I study required (critical path)
        # at North Tce?
        if len(locations)==1 and 'campus=North Terrace' in locations:
            print('Can study critical courses at North Terrace')
        # externally?
        elif len(locations)==1 and 'campus=externally' in locations:
            print('Can study critical courses externally')
        # other
        elif len(locations)>1:
            print('Not all critical courses can be studied at North Terrace or externally')

        # can I study required (critical path) courses abroad? or as part of exchange prog?
        if len(study_abroad)==1 and 'study_abroad=Yes' in study_abroad:
            print('Can study critical courses abroad (as part of an exchange prog)')
        elif len(study_abroad)==1 and 'study_abroad=No' in study_abroad:
            print('CANNOT study critical courses abroad (as part of an exchange prog)')
        elif len(study_abroad)>1:
            print('Not all critical courses can be studied abroad (as part of an exchange prog)')

        # total cost of (critical path) courses?

        # path completion duration? (account for term offered + availability)

        # last day to enrol online? WNF?
        # makes more sense in the context of a specific  course (eg the one to study next)

        print('done')

    def test_intent_based_policies(self):
        return

        #variables = {'inside', 'outside', 'any', 'server_A', 'server_B'}
        #propositions = {'protocol=6', 'dport=0-65535', 'action=allow', 'has_exchg_history_for_srcip=True', 'application=any',
        #                'tcp_state=any', 'tcp_state=new', 'tcp_state=established' , 'load_balance=False',
        #                'load_balance=True', 'host_has_exchg_history=True', 'host_has_exchg_history=False'}

        #cmg = ConditionalMetagraph(variables,propositions)

        #edge_list1 = [Edge({'inside'},{'outside'},attributes={'application=any', 'action=allow'}),
        #             Edge({'outside'},{'inside'},attributes={'application=any', 'has_exchg_history_for_srcip=True', 'action=allow'}),
        #            ]

        #edge_list2 = [Edge({'inside'},{'outside'},attributes={'protocol=6', 'dport=0-65535', 'tcp_state=any', 'action=allow'}),
        #             Edge({'outside'},{'inside'},attributes={'protocol=6', 'dport=0-65535', 'tcp_state=established', 'action=allow'}),
        #            ]

        #edge_list = [Edge({'any'},{'server_A'},attributes={'application=any', 'load_balance=False', 'action=allow'}),
        #             Edge({'any'},{'server_A'},attributes={'application=any', 'load_balance=True', 'host_has_exchg_history=True', 'action=allow'}),
        #             Edge({'any'},{'server_B'},attributes={'application=any', 'load_balance=True', 'host_has_exchg_history=False', 'action=allow'})
        #            ]

        inside = {'mktn', 'crm_servers'}
        any = {'aarnet'}.union(inside)
        variables = any

        propositions = {'application=any', 'middlebox1=IDS1', 'middlebox2=PA1', 'middlebox3=SRX1', 'action=allow',
                        'tcp_state=established', 'protocol=6', 'dport=80', 'middlebox1=LB', 'middlebox1=RS1',
                        'application=DNS', 'host_state=normal', 'middlebox1=SRX1', 'host_state=quarantine'}

        cmg = ConditionalMetagraph(variables,propositions)

        edge_list = [Edge({'aarnet'},inside,attributes={'application=any', 'middlebox1=IDS1', 'middlebox2=PA1', 'middlebox3=SRX1', 'action=allow'}),
                     Edge({'aarnet'},inside,attributes={'application=any', 'tcp_state=established', 'action=allow'}),
                     Edge({'mktn'},{'crm_servers'},attributes={'protocol=6', 'dport=80', 'action=allow'}),
                     Edge({'mktn'},{'crm_servers'},attributes={'application=any', 'middlebox1=LB', 'action=allow'}),
                     Edge({'mktn'},{'crm_servers'},attributes={'application=DNS', 'host_state=normal', 'middlebox1=SRX1', 'action=allow'}),
                     Edge({'mktn'},{'crm_servers'},attributes={'application=DNS', 'host_state=quarantine', 'middlebox1=RS1', 'action=allow'})
        ]

        # Edge({'crm_servers'},{'mktn'},attributes={'application=DNS', 'host_state=normal', 'middlebox1=SRX1', 'action=allow'}),
        # Edge({'crm_servers'},{'mktn'},attributes={'application=DNS', 'host_state=quarantine', 'middlebox1=RS1', 'action=allow'})

        cmg.add_edges_from(edge_list)
        # if we can find a metapath which does not cause any conflicts and allows only solicited traffic from aarnet to inside => intent is preserved

        # what to verify: ie, list of intent
        # TODO: what's the clear distinction between intent and policy?
        # 1. only solicited traffic allowed from the Internet
        # 2. traffic from Internet must go through IDS before FW
        # 3. traffic to CRM servers must be on TCP port 80
        # 4. traffic to CRM servers must be load balanced
        # 5. DNS traffic from hosts with normal state must go through FW
        # 6. DNS traffic from hosts with quarantine state must go through Remediation Server

        # TODO: do we do this manually or need ways to automatically derive from intent?
        # Construct policy rules that meet each intent:
        # TODO: how do we address issues when composing (eg., as per PGA paper)?
        # Compose the rules to create a single policy metagraph:

        # Can check each intent is preserved algebraically by:
        # 1. finding dominant metapaths from src_epg to target_epg (of policy rule(s) corresponding to intent) in MG
        # 2. check there exists at least a single metapath with edges which satisfy the required propositions
        # e.g., verify intent 1 is preserved (in above list)
        # intent - only solicited traffic allowed from the Internet
        if False:
            source={'aarnet'}
            target= inside
            mps = cmg.get_all_metapaths_from(source, target)
            intent_preserved = False
            for metapath in mps:
                result=True
                for edge in metapath.edge_list:
                    if 'tcp_state=established' not in edge.attributes:
                        result=False
                        break
                if result:
                    intent_preserved=True
                    break
            if not intent_preserved:
                print('intent 1 violated')

        # e.g., verify intent 2 is preserved (in above list)
        # intent - traffic from Internet must go through IDS before FW
        if False:
            source={'aarnet'}
            target= inside
            mps = cmg.get_all_metapaths_from(source, target)
            intent_preserved = False
            for metapath in mps:
                result=True
                for edge in metapath.edge_list:
                    if ('middlebox1=IDS1' not in edge.attributes) or \
                       ('middlebox2=PA1' not in edge.attributes):
                        result=False
                        break
                if result:
                    intent_preserved=True
                    break
            if not intent_preserved:
                print('intent 2 violated')

        # e.g., verify intent 3 is preserved (in above list)
        # intent - traffic to CRM servers must be on TCP port 80
        source=any.difference({'crm_servers'})
        target= {'crm_servers'}
        mps = cmg.get_all_metapaths_from(source, target)
        intent_preserved = False
        for metapath in mps:
            result=True
            for edge in metapath.edge_list:
                if ('protocol=6' not in edge.attributes) or \
                   ('dport=80' not in edge.attributes):
                    result=False
                    break
            if result:
                intent_preserved=True
                break
        if not intent_preserved:
            print('intent 3 violated')
        print('test')

        # output_folder='/Users/a1070571/Documents/ITS'
        # MetagraphHelper().generate_visualisation(edge_list,
        #                                        '%s/composite_mg.dot'%(output_folder))
        return

    def read_file(self, file):
        import csv
        with open(file, 'r') as f:
            data = [row for row in csv.reader(f.read().splitlines())]
        return data

    def is_domain_name(self,names):
        import socket
        try:
            items = names.split(',')
            for name in items:
                # TODO: remove public addresses altogether
                socket.gethostbyname(name.strip())
            return True
        except socket.gaierror:
            pass

        return False

    def test_mud(self):
        import itertools
        gp = dict()
        gp[0]= ['t1'] # [('p1','q1')]
        gp[1]= ['t2','t3'] # [('p2','q2'), ('p3','q3')]
        gp[2]= ['t4','t5', 't6'] # [('p4','q4'), ('p5','q5'), ('p6','q6')]
        return

        updated=dict()
        from mgtoolkit.library import MappingHolder
        for key,value in gp.iteritems():
            for mapping in value:
                mh = MappingHolder(mapping)
                if key not in updated:
                    updated[key]=[]
                updated[key].append(mh)

        index=0
        intermediate=None
        # calculate final mapping set (FM)?
        while index < len(updated):
            set1=set(updated[index])
            temp=set1
            if index+1< len(updated):
                set2=set(updated[index+1])
                temp=itertools.product(set1,set2)
            if intermediate==None:
                intermediate=temp
            else:
                intermediate=itertools.product(intermediate,temp)
            index+=2

        from mgtoolkit.library import CanonicalPolicyHelper
        for tuple1 in intermediate:
            group1=[]
            group2=[]
            possible_mapping= CanonicalPolicyHelper().GetMapping(tuple1)
            print('test')

    def get_edge_list(self,acl_details,variables_set,propositions_set,convert_ipaddresses_to_numeric=False):
        edge_list=[]
        id=0
        import socket
        for direction, acls in acl_details.iteritems():
            for acl in acls:
                if direction=='from':
                    invertex = set([acl.source])
                    #outvertex = set(acl.dest)
                    if convert_ipaddresses_to_numeric:
                        dest=list(acl.dest)[0]
                        if self.is_domain_name(dest):
                           ipaddress = '%s/32'%socket.gethostbyname(dest.strip())
                           outvertex = set(MetagraphHelper().get_ipaddresses_numeric(set([ipaddress])))
                        else:
                           outvertex = set(MetagraphHelper().get_ipaddresses_numeric(set(acl.dest)))
                    else:
                        outvertex = set(acl.dest)

                elif direction=='to':
                    #invertex = set(acl.source)
                    outvertex = set([acl.dest])
                    if convert_ipaddresses_to_numeric:
                        source=list(acl.source)[0]
                        if self.is_domain_name(source):
                           ipaddress = '%s/32'%socket.gethostbyname(source.strip())
                           invertex = set(MetagraphHelper().get_ipaddresses_numeric(set([ipaddress])))
                        else:
                           invertex = set(MetagraphHelper().get_ipaddresses_numeric(set(acl.source)))
                    else:
                        invertex = set(acl.source)

                attributes = []
                attributes.append('protocol=%s'%acl.protocol)
                dports = MetagraphHelper().get_port_descriptor(acl.protocol, acl.dports, 'dport')
                sports = MetagraphHelper().get_port_descriptor(acl.protocol, acl.sports, 'sport')
                if dports is not None:
                    attributes.append(dports)
                if sports is not None:
                    attributes.append(sports)
                attributes.append('action=%s'%acl.action)
                # tag edge id
                edge_id = 'edge%s'%id
                #attributes.append('original_id=%s'%edge_id)

                if list(attributes) not in propositions_set:
                    propositions_set +=list(attributes)
                    #propositions_set = propositions_set.union(attributes)

                if invertex not in variables_set:
                    variables_set.append(invertex)
                if outvertex not in variables_set:
                    variables_set.append(outvertex)

                #variables_set = variables_set.union(invertex)
                #variables_set = variables_set.union(outvertex)
                edge = Edge(invertex,outvertex,attributes,label=edge_id)
                edge_list.append(edge)
                id+=1

        return edge_list

    def extract_ipaddresses(self, ipaddr_str):
        result = []
        if ipaddr_str is not None:
           ipaddr_str = ipaddr_str.replace('[','')
           ipaddr_str = ipaddr_str.replace(']','')
           result = ipaddr_str.split('|')

        return result

    def test_create_metagraphs(self):
        import os
        import json
        import copy
        import pydot

        return

        #import socket
        #try:
        #    socket.gethostbyname('rpsv25.video-cloud.net')
        #except BaseException,e:
        #    print('test')

        try:
            output_path= "/Users/a1070571/Documents/IOT/results/"
            folders = [x for x in os.listdir(output_path) if '.' not in x]

            for folder in folders:
                print(folder)
                full_folder_name = os.path.join(output_path,folder)
                # read in MUD file
                files = [x for x in os.listdir(full_folder_name) if '.json' in x]

                filename=os.path.join(full_folder_name,files[0])
                print(filename)
                extracted = None
                with open(filename) as json_data:
                    extracted = json.load(json_data)

                acl_details =  MetagraphHelper().get_device_acl_details(extracted)

                # create metagraphs
                variables_set=set()

                vars=[]
                props=[]
                edge_list2 = self.get_edge_list(acl_details,vars,props)
                for var in vars:
                    variables_set=variables_set.union(var)
                propositions_set=set(props)
                cmg2 = ConditionalMetagraph(variables_set,propositions_set)
                cmg2.add_edges_from(edge_list2)

                #filepath= os.path.join(full_folder_name,'cmg_mud_profile_HL.dot')
                #MetagraphHelper().generate_visualisation(edge_list2,filepath,display_attributes=False, use_temp_label=True)

                vars=[]
                props=[]
                variables_set=set()
                edge_list = self.get_edge_list(acl_details,vars,props,convert_ipaddresses_to_numeric=True)
                for var in vars:
                    variables_set=variables_set.union(var)
                propositions_set=set(props)
                cmg = ConditionalMetagraph(variables_set,propositions_set)
                cmg.add_edges_from(edge_list)

                print('mg nodes: %s, edges: %s, gen_set: %s'%(len(cmg.nodes),len(cmg.edges),len(cmg.generating_set)))

                edge_list=[]
                ip_map=dict()
                id=0
                import socket
                for direction, acls in acl_details.iteritems():
                    for acl in acls:
                        if direction=='from':
                            invertex = set([acl.source])
                            dest=list(acl.dest)[0]
                            if self.is_domain_name(dest):
                               ipaddress = '%s/32'%socket.gethostbyname(dest.strip())
                               if dest not in ip_map:
                                   ip_map[dest]=ipaddress
                               outvertex = set(MetagraphHelper().get_ipaddresses_numeric(set([ipaddress])))
                            else:
                               outvertex = set(MetagraphHelper().get_ipaddresses_numeric(set(acl.dest)))

                        elif direction=='to':
                            outvertex = set([acl.dest])
                            source=list(acl.source)[0]
                            if self.is_domain_name(source):
                               ipaddress = '%s/32'%socket.gethostbyname(source.strip())
                               if source not in ip_map:
                                   ip_map[source]=ipaddress
                               invertex = set(MetagraphHelper().get_ipaddresses_numeric(set([ipaddress])))
                            else:
                               invertex = set(MetagraphHelper().get_ipaddresses_numeric(set(acl.source)))

                        attributes = []
                        attributes.append('protocol=%s'%acl.protocol)
                        dports = MetagraphHelper().get_port_descriptor(acl.protocol, acl.dports, 'dport')
                        sports = MetagraphHelper().get_port_descriptor(acl.protocol, acl.sports, 'sport')
                        if dports is not None:
                            attributes.append(dports)
                        if sports is not None:
                            attributes.append(sports)
                        attributes.append('action=%s'%acl.action)
                        # tag edge id
                        edge_id = 'edge%s'%id
                        propositions_set = propositions_set.union(attributes)
                        variables_set = variables_set.union(invertex)
                        variables_set = variables_set.union(outvertex)
                        edge = Edge(invertex,outvertex,attributes,label=edge_id)
                        edge_list.append(edge)
                        id+=1

                variables_set=variables_set.difference({'device'})
                non_overlapping_ipaddress_ranges = MetagraphHelper().get_minimal_non_overlapping_ipaddress_ranges(list(variables_set))

                converted=[]
                for ipaddr_range in non_overlapping_ipaddress_ranges:
                    range_string = '%s-%s'%(ipaddr_range[0],ipaddr_range[1])
                    converted.append(range_string)

                variable_set = set(converted)
                new_edge_list=[]
                for edge in edge_list:
                    edge_attributes= copy.copy(edge.attributes)

                    # convert tcp port attributes to non-overlapping ranges via lookup
                    inv_device=False
                    outv_device=False
                    invertex = edge.invertex.difference(edge_attributes)
                    outvertex = edge.outvertex

                    if 'device' in invertex:
                        inv_device=True
                        invertex = invertex.difference({'device'})
                    if 'device' in outvertex:
                        outv_device=True
                        outvertex = outvertex.difference({'device'})

                    if len(invertex)>0:
                        invertex = MetagraphHelper().get_ipaddresses_canonical_form(invertex, non_overlapping_ipaddress_ranges)
                    if len(outvertex)>0:
                        outvertex = MetagraphHelper().get_ipaddresses_canonical_form(outvertex, non_overlapping_ipaddress_ranges)

                    if inv_device:
                        invertex = invertex.union({'device'})
                    if outv_device:
                        outvertex = outvertex.union({'device'})

                    temp= edge.attributes
                    new_edge= Edge(invertex, outvertex, temp, label=edge.label)
                    new_edge_list.append(new_edge)

                variable_set = variable_set.union({'device'})

                # create intermediate metagraph suitable for performing analysis
                converted_cmg= ConditionalMetagraph(variable_set, propositions_set)
                converted_cmg.add_edges_from(new_edge_list)

                # check for duplicates
                if len(new_edge_list)!= len(converted_cmg.edges):
                    MetagraphHelper().print_duplicate_edges(new_edge_list)

                #print('mg nodes: %s, edges: %s'%(len(converted_cmg.nodes),len(converted_cmg.edges)))
                #from mgtoolkit.library import CanonicalPolicyHelper
                #updated = CanonicalPolicyHelper().numeric_to_ipaddresses2(new_edge_list)

                filepath= os.path.join(full_folder_name,'cmg_mud_profile.dot')
                MetagraphHelper().generate_visualisation(new_edge_list,filepath,display_attributes=False, use_temp_label=True)

                #mg_image_file =os.path.join(full_folder_name,'cmg_mud_profile.png')
                #(graph,) = pydot.graph_from_dot_file(filepath)
                #graph.write_png(mg_image_file)

                print('generating complexity reduced, equivalent metagraph..')
                group_name_index=1
                new_edge_list=[]
                new_var_set=set()
                invertex_element_group_lookup=dict()
                outvertex_element_group_lookup=dict()

                for edge in converted_cmg.edges:
                    invertex_elts = list(edge.invertex.difference(converted_cmg.propositions_set))
                    outvertex_elts = list(edge.outvertex.difference(converted_cmg.propositions_set))

                    for elt in invertex_elts:
                        result= converted_cmg.get_associated_edges(elt)
                        edge_list_string=repr(result)
                        if edge_list_string not in invertex_element_group_lookup:
                            invertex_element_group_lookup[edge_list_string]=[]
                        if elt not in invertex_element_group_lookup[edge_list_string]:
                            invertex_element_group_lookup[edge_list_string].append(elt)

                    for elt in outvertex_elts:
                        result= converted_cmg.get_associated_edges(elt)
                        edge_list_string=repr(result)
                        if edge_list_string not in outvertex_element_group_lookup:
                            outvertex_element_group_lookup[edge_list_string]=[]
                        if elt not in outvertex_element_group_lookup[edge_list_string]:
                            outvertex_element_group_lookup[edge_list_string].append(elt)

                import json
                group_details_lookup=dict()

                for edge_list_string, elt_list in invertex_element_group_lookup.iteritems():
                    group_elts = set(elt_list)
                    if len(group_elts)>1:
                        # group
                        group_elts_string = json.dumps(list(group_elts))
                        if group_elts_string not in group_details_lookup:
                            group_name= 'group_%s'%group_name_index
                            group_details_lookup[group_elts_string]=group_name
                            group_name_index+=1

                for edge_list_string, elt_list in outvertex_element_group_lookup.iteritems():
                    group_elts = set(elt_list)
                    if len(group_elts)>1:
                        # group
                        group_elts_string = json.dumps(list(group_elts))
                        if group_elts_string not in group_details_lookup:
                            group_name= 'group_%s'%group_name_index
                            group_details_lookup[group_elts_string]=group_name
                            group_name_index+=1

                # replace original invertices with groups
                for edge in converted_cmg.edges:
                    invertex_elts = list(edge.invertex.difference(converted_cmg.propositions_set))
                    outvertex_elts = list(edge.outvertex)
                    new_invertex=set()
                    new_outvertex=set()

                    for group_elts, group_name in group_details_lookup.iteritems():
                        group_elts_list = json.loads(group_elts)
                        group_elts_list = [elt2.encode('ascii', errors='backslashreplace') for elt2 in group_elts_list]
                        if set(group_elts_list).issubset(set(invertex_elts)):
                            new_invertex = new_invertex.union({group_name})
                            invertex_elts = list(set(invertex_elts).difference(set(group_elts_list)))

                    for group_elts, group_name in group_details_lookup.iteritems():
                        group_elts_list = json.loads(group_elts)
                        group_elts_list = [elt2.encode('ascii', errors='backslashreplace') for elt2 in group_elts_list]
                        if set(group_elts_list).issubset(set(outvertex_elts)):
                            new_outvertex = new_outvertex.union({group_name})
                            outvertex_elts = list(set(outvertex_elts).difference(set(group_elts_list)))

                    new_invertex=new_invertex.union(set(invertex_elts))
                    new_outvertex=new_outvertex.union(set(outvertex_elts))
                    new_var_set = new_var_set.union(new_invertex)
                    new_var_set = new_var_set.union(new_outvertex)
                    new_edge_list.append(Edge(new_invertex, new_outvertex,
                                                      attributes=list(edge.invertex.intersection(converted_cmg.propositions_set)),
                                                      label=edge.label))

                # create complexity reduced, equivalent metagraph
                reduced_cmg= ConditionalMetagraph(new_var_set, converted_cmg.propositions_set)
                reduced_cmg.add_edges_from(new_edge_list)

                #print('mg nodes2: %s, edges2: %s'%(len(reduced_cmg.nodes),len(reduced_cmg.edges)))
                potential_conflicts = reduced_cmg.check_conflicts()
                redunancies = reduced_cmg.check_redundancies()
                #check_conflicts check_conflicts_simple check_redundancies check_conflicts

        except BaseException,e:
            print('error:: %s'%(e))

    def test_metapath(self):
        #vars = {1,2,3,4,5}
        #props = {'prot=none'}
        #edges = [Edge({1,2},{3,4}), Edge({4,5},{1,2})]
        #cmg = ConditionalMetagraph(vars,props)
        #cmg.add_edges_from(edges)
        #r = cmg.get_all_metapaths_from({1,2},{2})
        return

        v2 = {1,2,3,4,5,6,7,8,9}
        edges2 = [Edge({1,2},{3}),
                  Edge({3,4},{5}),
                  Edge({5,6},{7})]
        props2 = {'p=0'}
        cmg2 = ConditionalMetagraph(v2,props2)
        cmg2.add_edges_from(edges2)
        r = cmg2.get_all_metapaths_from(v2,{7},True)
        for mp in r:
            # warn::filtering can drop useful metapaths!
            #if not cmg2.is_edge_dominant_metapath(mp):
            #    continue
            for edge in mp.edge_list:
                int = edge.invertex.intersection({1,2})
                if int is not None and len(int)>0:
                    print('valid metapath: %s'%(str(mp.edge_list)))
        print('test')

    def test_create_mud_profiles(self):
        # read in common flows
        import os, csv
        import datetime
        import pytz
        from mgtoolkit.library import ACE, ACL
        from mgtoolkit.library import CanonicalPolicyHelper
        from mgtoolkit.library import MudPolicy
        from mako.template import Template
        return

        csv_path = "/Users/a1070571/Documents/IOT/deviceFlowRules/"
        template_path = "/Users/a1070571/Documents/IOT/"
        output_path= "/Users/a1070571/Documents/IOT/results/"

        # local gateway
        local_gateway_ipaddr = "192.168.1.1"
        manufacturers= ['lifx','samsung', 'amazon', 'august', 'awair', 'belkin', 'carematix', 'canary',
                        'google', 'dropcam', 'toytalk', 'hp', 'hue', 'phillips', 'evrythng', 'nest',
                        'netatmo', 'pix-star', 'ring', 'smartthing', 'tplink', 'invoxia', 'xbcs', 'withings']

        files = [x for x in os.listdir(csv_path)]

        for filename in files:
            if '.DS_Store' in filename:
                continue
            mud_policy=None
            print(filename)
            full_path_name = os.path.join(csv_path,filename)
            common_flows_lookup=dict()
            with open(full_path_name, 'rb') as csvfile:
                data = self.read_file(full_path_name)
                index=0
                filename_with_ext = os.path.basename(full_path_name)
                device_name, extension = os.path.splitext(filename_with_ext)

                for row in data:
                    if index==0:
                        # omit header
                        index+=1
                        continue

                    index+=1
                    source_mac = row[0]
                    dest_mac = row[1]
                    ether_type= int(row[2],16)

                    source_ipaddresses = self.extract_ipaddresses(row[3])
                    dest_ipaddresses = self.extract_ipaddresses(row[4])

                    protocol = row[5]
                    source_ports = row[6]
                    dest_ports = row[7]

                    if device_name is not None and device_name not in common_flows_lookup:
                        common_flows_lookup[device_name]=[]

                    for source_ipaddr in source_ipaddresses:
                        for dest_ipaddr in dest_ipaddresses:
                            if source_ipaddr=='*' and dest_ipaddr=='*':
                                # MAC based rules
                                #print('index= %s'%index)
                                ace = ACE(source_mac,dest_mac,protocol,dest_ports,source_ports,'accept',ethertype=ether_type)
                            else:
                                # ip based rules
                                ace = ACE(source_ipaddr,dest_ipaddr,protocol,dest_ports,source_ports,'accept',ethertype=ether_type)

                            common_flows_lookup[device_name].append(ace)

            from_acls=[]
            to_acls=[]
            acl_from1=ACL("from")
            acl_to1=ACL("to")

            for key, val in common_flows_lookup.iteritems():
                print('device: %s, #rules: %s'%(key,len(val)))

            for entry_list in common_flows_lookup.values():
                #print('len(entry_list): %s'%(len(entry_list)))
                for entry in entry_list:
                    if '*' in entry.source and '<deviceMac>' not in entry.dest:
                        dest_groups=[]
                        if local_gateway_ipaddr in entry.dest:
                            # device to local gateway
                            dest_groups.append(('controller', 'urn:ietf:params:mud:gateway'))
                        elif CanonicalPolicyHelper().is_private_ipaddress(entry.dest):
                            # device to local app
                            dest_groups.append('local-networks')
                        elif '255.255.255.255' in entry.dest:
                            # TODO handle broadcast
                            pass
                        elif self.is_domain_name(entry.dest):
                            # device to cloud..retain domain names
                            items = entry.dest.split(',')
                            for name in items:
                               is_manufacturer=False
                               for manufacturer in manufacturers:
                                  if manufacturer in entry.dest and ('manufacturer', name) not in dest_groups:
                                     dest_groups.append(('manufacturer', name))
                                     is_manufacturer=True
                               if not is_manufacturer and CanonicalPolicyHelper().is_public_ipaddress(name) and ('destination-ipv4-network', '%s/32'%(name)) not in dest_groups:
                                 dest_groups.append(('destination-ipv4-network', '%s/32'%(name)))
                               elif not is_manufacturer and ('ietf-acldns:dst-dnsname', name) not in dest_groups:
                                     dest_groups.append(('ietf-acldns:dst-dnsname', name))
                               elif not is_manufacturer:
                                   print('unhandled name1: %s'%name)
                        else:
                               print('unhandled entry.dest: %s'%entry.dest)

                        if len(dest_groups)>0:
                            ace = ACE('device',dest_groups,entry.protocol,entry.dports,entry.sports,entry.action,"from-device",ethertype=entry.ethertype)
                            acl_from1.add_ace(ace)

                    elif '*' in entry.dest and '<deviceMac>' not in entry.source:
                        source_groups=[]
                        if local_gateway_ipaddr in entry.source:
                            # local gateway to device
                            source_groups.append(('controller', 'urn:ietf:params:mud:gateway'))
                        elif CanonicalPolicyHelper().is_private_ipaddress(entry.source) :
                            # local app to device
                            source_groups.append('local-networks')
                        elif self.is_domain_name(entry.source):
                            # cloud to device..retain domain names
                            items = entry.source.split(',')
                            for name in items:
                                is_manufacturer=False
                                for manufacturer in manufacturers:
                                    if manufacturer in entry.source and ('manufacturer', name) not in source_groups:
                                        source_groups.append(('manufacturer', name))
                                        is_manufacturer=True
                                if not is_manufacturer and CanonicalPolicyHelper().is_public_ipaddress(name) and ('source-ipv4-network', '%s/32'%(name)) not in source_groups:
                                    source_groups.append(('source-ipv4-network', '%s/32'%(name)))
                                elif not is_manufacturer and ('ietf-acldns:src-dnsname', name) not in source_groups:
                                    source_groups.append(('ietf-acldns:src-dnsname', name))
                                elif not is_manufacturer:
                                   print('unhandled name2: %s'%name)
                        else:
                               print('unhandled entry.source: %s'%entry.source)

                        if len(source_groups)>0:
                            ace = ACE(source_groups,'device',entry.protocol,entry.dports,entry.sports,entry.action,"to-device",ethertype=entry.ethertype)
                            acl_to1.add_ace(ace)

                    elif '<deviceMac>' in entry.source:
                        dest_groups=[]
                        if '*' in entry.dest:
                            # device to local app
                            dest_groups.append('local-networks')
                        elif '<gatewayMac>' in entry.dest:
                            # device to local gateway
                            dest_groups.append(('controller', 'urn:ietf:params:mud:gateway'))
                        elif 'ff:ff:ff:ff:ff:ff' in entry.dest:
                            # TODO: handle L2 broadcast from device
                            pass
                        else:
                            print('unh: entry.dest: src= %s, dst= %s, prot: %s, dports: %s, sports: %s, ethertype: %s'%(entry.source, entry.dest, entry.protocol,entry.dports,entry.sports,entry.ethertype))

                        if len(dest_groups)>0:
                            ace = ACE('device',dest_groups,entry.protocol,entry.dports,entry.sports,entry.action,"from-device",ethertype=entry.ethertype)
                            acl_from1.add_ace(ace)

                    elif '<deviceMac>' in entry.dest:
                        source_groups=[]
                        if '*' in entry.source:
                            # local app to device
                            source_groups.append('local-networks')
                        elif '<gatewayMac>' in entry.source:
                            # local gateway to device
                            source_groups.append(('controller', 'urn:ietf:params:mud:gateway'))
                        elif 'ff:ff:ff:ff:ff:ff' in entry.source:
                            # TODO: handle L2 broadcast from device
                            pass
                        else:
                            print('unh: entry.source: src= %s, dst= %s, prot: %s, dports: %s, sports: %s, ethertype: %s'%(entry.source, entry.dest, entry.protocol,entry.dports,entry.sports,entry.ethertype))

                        if len(source_groups)>0:
                            ace = ACE(source_groups,'device',entry.protocol,entry.dports,entry.sports,entry.action,"to-device",ethertype=entry.ethertype)
                            acl_to1.add_ace(ace)

                    else:
                        print('unh: entry: %s'% entry)


            from_acls.append(acl_from1)
            to_acls.append(acl_to1)

            #rule_count = len(acl_from1.aces) + len(acl_to1.aces)
            #print('rule_count: %s'%rule_count)
            #print('from device svc count: %s'%(len(acl_from1.aces)))
            #print('to device svc count: %s'%(len(acl_to1.aces)))

            #mud_policy = MudPolicy('belkingcamera2000','belkin camera',from_acls,to_acls)
            #mud_policy = MudPolicy('samsungcamera1000','samsung camera',from_acls,to_acls)
            #mud_policy = MudPolicy('amazonecho1000','amazon echo speaker',from_acls,to_acls)
            # TODO: check if time is UTC etc
            create_datetime = datetime.datetime.now(pytz.utc).isoformat()
            #desc = '{0:%Y}-{0:%m}-{0:%d}T{0:%H}:{0:%M}:{0:%S}+{0:%m}:{0:%d}'.format(d)
            # TODO: pass desc in csv (currently using filename as desc
            desc=device_name.replace('rule','').lower()
            mud_policy = MudPolicy(create_datetime,desc,desc,from_acls,to_acls)
            # 'lifxsmartbulb','lifx smart bulb'
            # 'amazonecho','amazon echo smart speaker'
            # 'augustdoorbellcam','august door bell camera'

            # construct MUD file
            mud_template = Template(filename=template_path+"/mud_profile_template.mako")
            mud_policy_text = mud_template.render(policy=mud_policy)

            # create new folder
            subfolder= device_name.replace('rule','')
            target_folder = os.path.join(output_path,subfolder)
            if not os.path.exists(target_folder):
               os.makedirs(target_folder)

            # write to file
            policy_file=open(os.path.join(target_folder,'device_mud_profile.json'),'w') #
            policy_file.write(mud_policy_text)
            policy_file.close()

        return

        # read in MUD file
        file = '/Users/a1070571/Documents/IOT/augustdoorbell.json' # bkcamera.json samsungcamexpected samsungcam.json amazonecho.json lifxbulb.json samsungcamexpected

        extracted = None
        with open(file) as json_data:
            extracted = json.load(json_data)
            # extracted = simplejson.load(json_data)
            #print(extracted)

        #print('1: %s'%extracted['ietf-mud:mud'])
        #print('2: %s'%extracted['ietf-mud:mud']['from-device-policy'])

        #print(extracted['ietf-mud:mud']['from-device-policy']['access-lists']['access-list'][0]['acl-name'])
        #print(extracted['ietf-access-control-list:access-lists']['acl'][0]['access-list-entries']['ace'][0]['matches']['ipv6-acl']['ietf-acldns:src-dnsname'])

        # TODO: check all services included for belkin camera
        acl_details =  MetagraphHelper().get_device_acl_details(extracted)

        # create metagraphs
        variables_set=set()

        vars=[]
        props=[]
        edge_list2 = self.get_edge_list(acl_details,vars,props)
        for var in vars:
            variables_set=variables_set.union(var)
        propositions_set=set(props)
        cmg2 = ConditionalMetagraph(variables_set,propositions_set)
        cmg2.add_edges_from(edge_list2)

        e2 = self.get_edge_list(acl_details,propositions_set)
        cm3 = ConditionalMetagraph(variable_set,props)
        cm3.add_edges_from(e2)
        src={}
        target={}
        cm3.get_all_metapaths_from(src,target)

        vars=[]
        props=[]
        variables_set=set()

        edge_list = self.get_edge_list(acl_details,vars,props,convert_ipaddresses_to_numeric=True)
        for var in vars:
            variables_set=variables_set.union(var)
        propositions_set=set(props)
        cmg = ConditionalMetagraph(variables_set,propositions_set)
        cmg.add_edges_from(edge_list)

        if True:
            edge_list=[]
            id=0
            import socket
            for direction, acls in acl_details.iteritems():
                for acl in acls:
                    if direction=='from':
                        invertex = set([acl.source])
                        #outvertex = set(acl.dest)
                        dest=list(acl.dest)[0]
                        if self.is_domain_name(dest):
                           ipaddress = '%s/32'%socket.gethostbyname(dest.strip())
                           outvertex = set(MetagraphHelper().get_ipaddresses_numeric(set([ipaddress])))
                        else:
                           outvertex = set(MetagraphHelper().get_ipaddresses_numeric(set(acl.dest)))

                    elif direction=='to':
                        #invertex = set(acl.source)
                        outvertex = set([acl.dest])
                        #invertex = set(MetagraphHelper().get_ipaddresses_numeric(set(acl.source)))
                        source=list(acl.source)[0]
                        if self.is_domain_name(source):
                           ipaddress = '%s/32'%socket.gethostbyname(source.strip())
                           invertex = set(MetagraphHelper().get_ipaddresses_numeric(set([ipaddress])))
                        else:
                           invertex = set(MetagraphHelper().get_ipaddresses_numeric(set(acl.source)))

                    attributes = []
                    attributes.append('protocol=%s'%acl.protocol)
                    dports = MetagraphHelper().get_port_descriptor(acl.protocol, acl.dports, 'dport')
                    sports = MetagraphHelper().get_port_descriptor(acl.protocol, acl.sports, 'sport')
                    if dports is not None:
                        attributes.append(dports)
                    if sports is not None:
                        attributes.append(sports)
                    attributes.append('action=%s'%acl.action)
                    # tag edge id
                    edge_id = 'edge%s'%id
                    #attributes.append('original_id=%s'%edge_id)
                    propositions_set = propositions_set.union(attributes)
                    variables_set = variables_set.union(invertex)
                    variables_set = variables_set.union(outvertex)
                    edge = Edge(invertex,outvertex,attributes,label=edge_id)
                    edge_list.append(edge)
                    id+=1

        #cmg = ConditionalMetagraph(variables_set,propositions_set)
        #cmg.add_edges_from(edge_list)

        #filepath='/Users/a1070571/Documents/IOT/cmg_mud_profile.dot'
        #MetagraphHelper().generate_visualisation(edge_list,filepath,display_attributes=False, use_temp_label=True)

        if True:
            variables_set=variables_set.difference({'device'})
            non_overlapping_ipaddress_ranges = MetagraphHelper().get_minimal_non_overlapping_ipaddress_ranges(list(variables_set))

            converted=[]
            for ipaddr_range in non_overlapping_ipaddress_ranges:
                range_string = '%s-%s'%(ipaddr_range[0],ipaddr_range[1])
                converted.append(range_string)

            variable_set = set(converted)
            new_edge_list=[]
            import copy
            for edge in edge_list:
                edge_attributes= copy.copy(edge.attributes)

                # convert tcp port attributes to non-overlapping ranges via lookup
                inv_device=False
                outv_device=False
                invertex = edge.invertex.difference(edge_attributes)
                outvertex = edge.outvertex

                if 'device' in invertex:
                    inv_device=True
                    invertex = invertex.difference({'device'})
                if 'device' in outvertex:
                    outv_device=True
                    outvertex = outvertex.difference({'device'})

                if len(invertex)>0:
                    invertex = MetagraphHelper().get_ipaddresses_canonical_form(invertex, non_overlapping_ipaddress_ranges)
                if len(outvertex)>0:
                    outvertex = MetagraphHelper().get_ipaddresses_canonical_form(outvertex, non_overlapping_ipaddress_ranges)

                if inv_device:
                    invertex = invertex.union({'device'})
                if outv_device:
                    outvertex = outvertex.union({'device'})

                temp= edge.attributes
                # TCP
                #edge_tcp_attr= MetagraphHelper().filter_port_attributes("TCP", edge_attributes)
                #if len(edge_tcp_attr)>0:
                #    canonical_tcp_attr= MetagraphHelper().get_ports_canonical_form('TCP.dport=', edge_tcp_attr[0], non_overlapping_tcp_port_ranges)
                # UDP
                #edge_udp_attr= MetagraphHelper().filter_port_attributes("UDP", edge_attributes)
                #if len(edge_udp_attr)>0:
                #    canonical_udp_attr= MetagraphHelper().get_ports_canonical_form('UDP.dport=', edge_udp_attr[0], non_overlapping_udp_port_ranges)

                # update temp and propositions_set
                # TCP
                #if len(edge_tcp_attr)>0:
                #    if edge_tcp_attr[0] in temp: temp.remove(edge_tcp_attr[0])
                #    if edge_tcp_attr[0] in propositions_set: propositions_set.remove(edge_tcp_attr[0])
                #    for canonical_attr in canonical_tcp_attr:
                #        if canonical_attr not in temp:
                #            temp.append(canonical_attr)
                #        if canonical_attr not in propositions_set:
                #            propositions_set= propositions_set.union({canonical_attr})
                # UDP
                #if len(edge_udp_attr)>0:
                #    if edge_udp_attr[0] in temp: temp.remove(edge_udp_attr[0])
                #    if edge_udp_attr[0] in propositions_set: propositions_set.remove(edge_udp_attr[0])
                #    for canonical_attr in canonical_udp_attr:
                #        if canonical_attr not in temp:
                #            temp.append(canonical_attr)
                #        if canonical_attr not in propositions_set:
                #            propositions_set= propositions_set.union({canonical_attr})


                new_edge= Edge(invertex, outvertex, temp, label=edge.label)
                new_edge_list.append(new_edge)

            variable_set = variable_set.union({'device'})

            # create intermediate metagraph suitable for performing analysis
            converted_cmg= ConditionalMetagraph(variable_set, propositions_set)
            converted_cmg.add_edges_from(new_edge_list)

            filepath='/Users/a1070571/Documents/IOT/cmg_mud_profile.dot'
            MetagraphHelper().generate_visualisation(new_edge_list,filepath,display_attributes=False, use_temp_label=True)


            return

            print('generating complexity reduced, equivalent metagraph..')
            group_name_index=1
            new_edge_list=[]
            new_var_set=set()
            invertex_element_group_lookup=dict()
            outvertex_element_group_lookup=dict()

            for edge in converted_cmg.edges:
                invertex_elts = list(edge.invertex.difference(converted_cmg.propositions_set))
                outvertex_elts = list(edge.outvertex.difference(converted_cmg.propositions_set))

                for elt in invertex_elts:
                    result= converted_cmg.get_associated_edges(elt)
                    edge_list_string=repr(result)
                    if edge_list_string not in invertex_element_group_lookup:
                        invertex_element_group_lookup[edge_list_string]=[]
                    if elt not in invertex_element_group_lookup[edge_list_string]:
                        invertex_element_group_lookup[edge_list_string].append(elt)

                for elt in outvertex_elts:
                    result= converted_cmg.get_associated_edges(elt)
                    edge_list_string=repr(result)
                    if edge_list_string not in outvertex_element_group_lookup:
                        outvertex_element_group_lookup[edge_list_string]=[]
                    if elt not in outvertex_element_group_lookup[edge_list_string]:
                        outvertex_element_group_lookup[edge_list_string].append(elt)

            import json
            group_details_lookup=dict()

            for edge_list_string, elt_list in invertex_element_group_lookup.iteritems():
                group_elts = set(elt_list)
                if len(group_elts)>1:
                    # group
                    group_elts_string = json.dumps(list(group_elts))
                    if group_elts_string not in group_details_lookup:
                        group_name= 'group_%s'%group_name_index
                        group_details_lookup[group_elts_string]=group_name
                        group_name_index+=1

            for edge_list_string, elt_list in outvertex_element_group_lookup.iteritems():
                group_elts = set(elt_list)
                if len(group_elts)>1:
                    # group
                    group_elts_string = json.dumps(list(group_elts))
                    if group_elts_string not in group_details_lookup:
                        group_name= 'group_%s'%group_name_index
                        group_details_lookup[group_elts_string]=group_name
                        group_name_index+=1

            # replace original invertices with groups
            for edge in converted_cmg.edges:
                invertex_elts = list(edge.invertex.difference(converted_cmg.propositions_set))
                outvertex_elts = list(edge.outvertex)
                new_invertex=set()
                new_outvertex=set()

                for group_elts, group_name in group_details_lookup.iteritems():
                    group_elts_list = json.loads(group_elts)
                    group_elts_list = [elt2.encode('ascii', errors='backslashreplace') for elt2 in group_elts_list]
                    if set(group_elts_list).issubset(set(invertex_elts)):
                        new_invertex = new_invertex.union({group_name})
                        invertex_elts = list(set(invertex_elts).difference(set(group_elts_list)))

                for group_elts, group_name in group_details_lookup.iteritems():
                    group_elts_list = json.loads(group_elts)
                    group_elts_list = [elt2.encode('ascii', errors='backslashreplace') for elt2 in group_elts_list]
                    if set(group_elts_list).issubset(set(outvertex_elts)):
                        new_outvertex = new_outvertex.union({group_name})
                        outvertex_elts = list(set(outvertex_elts).difference(set(group_elts_list)))

                new_invertex=new_invertex.union(set(invertex_elts))
                new_outvertex=new_outvertex.union(set(outvertex_elts))
                new_var_set = new_var_set.union(new_invertex)
                new_var_set = new_var_set.union(new_outvertex)
                new_edge_list.append(Edge(new_invertex, new_outvertex,
                                                  attributes=list(edge.invertex.intersection(converted_cmg.propositions_set)),
                                                  label=edge.label))

            # create complexity reduced, equivalent metagraph
            reduced_cmg= ConditionalMetagraph(new_var_set, converted_cmg.propositions_set)
            reduced_cmg.add_edges_from(new_edge_list)

            potential_conflicts = reduced_cmg.check_conflicts() #check_conflicts check_conflicts_simple


        # example bp/compancy policy
        variables_set2={'corporate_zone','scada_zone','abstract_zone','internet_zone','management_zone', 'carrier_zone', 'firewall_zone', 'dmz'}

        edge_list2=[]
        #edge_list2.append(Edge({'corporate_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
        #edge_list2.append(Edge({'corporate_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))

        edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=53', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=123', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=1', 'action=accept']))

        edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
        edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
        edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=53', 'action=accept']))
        edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=123', 'action=accept']))
        edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'action=accept']))
        edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=1', 'action=accept']))

        if True:
            # telnet secure
            edge_list2.append(Edge({'corporate_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            # kerberos
            edge_list2.append(Edge({'corporate_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            # ldaps
            edge_list2.append(Edge({'corporate_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'scada_zone'},attributes=['protocol=17', 'UDP.dport=636', 'action=accept']))
            # ping
            edge_list2.append(Edge({'corporate_zone'},{'scada_zone'},attributes=['protocol=1', 'action=accept']))


        if False:
            edge_list2.append(Edge({'abstract_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'abstract_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'abstract_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'abstract_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'abstract_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'abstract_zone'},{'scada_zone'},attributes=['protocol=17', 'UDP.dport=636', 'action=accept']))
            # modbus
            edge_list2.append(Edge({'abstract_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=502', 'action=accept']))
            # dcom
            edge_list2.append(Edge({'abstract_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'abstract_zone'},{'scada_zone'},attributes=['protocol=1', 'action=accept']))


            edge_list2.append(Edge({'management_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'management_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'management_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'management_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'management_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'management_zone'},{'scada_zone'},attributes=['protocol=17', 'UDP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'management_zone'},{'scada_zone'},attributes=['protocol=1', 'action=accept']))

        #edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
        #edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
        #edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))

        if True:
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=17', 'UDP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=502', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=1', 'action=accept']))

        if False:
            edge_list2.append(Edge({'firewall_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'scada_zone'},attributes=['protocol=17', 'UDP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'scada_zone'},attributes=['protocol=1', 'action=accept']))


        #edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
        #edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
        #edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
        #edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))

        if True:
            edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=636', 'action=accept']))
            # telnet
            edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            # ftp
            edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            # smtp
            edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'corporate_zone'},attributes=['protocol=1', 'action=accept']))

        if False:
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=17', 'UDP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=502', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'abstract_zone'},attributes=['protocol=1', 'action=accept']))

        if False:
            edge_list2.append(Edge({'scada_zone'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'firewall_zone'},attributes=['protocol=89', 'action=accept']))


        if False:
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=17', 'UDP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'management_zone'},attributes=['protocol=1', 'action=accept']))

        #edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
        #edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))

        if True:
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=502', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=1', 'action=accept']))

        if False:
            # corp -> internet
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            # chargen
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=19', 'action=accept']))
            # gopher
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=70', 'action=accept']))
            # finger
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=79', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=88', 'action=accept']))

        if False:
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=109', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=110', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=115', 'action=accept']))

            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))

        if False:
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=138', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=139', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=156', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=162', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=179', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=194', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=201', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=389', 'action=accept']))

            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=445', 'action=accept']))

        if False:
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=989', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=990', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=3268', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=3389', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=5631', 'action=accept']))


        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=tcp', 'TCP.dport=445', 'action=accept']))
        #edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=138', 'action=accept']))
        #edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=139', 'action=accept']))
        #edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=6', 'TCP.dport=156', 'action=accept']))

        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=tcp', 'TCP.dport=135', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=tcp', 'TCP.dport=80', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=tcp', 'TCP.dport=443', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=tcp', 'TCP.dport=21', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=tcp', 'TCP.dport=20', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=tcp', 'TCP.dport=25', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=tcp', 'TCP.dport=23', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=tcp', 'TCP.dport=22', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=tcp', 'TCP.dport=1024-65535', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=123', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=53', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'action=accept']))
        edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=1', 'action=accept']))


        edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
        edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
        edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
        edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
        edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'action=accept']))


        if False:
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=520', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=521', 'action=accept']))

            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=53', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=67', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=68', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=123', 'action=accept']))

        if False:
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=19', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=156', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=194', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=201', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=3268', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=5632', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=89', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=88', 'action=accept']))

        if False:
            # internet -> corp
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            # chargen
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=6', 'TCP.dport=19', 'action=accept']))
            # gopher
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone','dmz'},attributes=['protocol=6', 'TCP.dport=70', 'action=accept']))
            # finger
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=79', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=109', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=110', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=115', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))

        if False:
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=138', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=139', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=156', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=162', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=179', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=194', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=201', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=389', 'action=accept']))

            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=445', 'action=accept']))

        if False:
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=989', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=990', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            #edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=3268', 'action=accept']))
            #edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=3389', 'action=accept']))
            #edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=5631', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=520', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=521', 'action=accept']))

            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=53', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=67', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=68', 'action=accept']))

        if False:
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=53', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=67', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=68', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.dport=123', 'action=accept']))

            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=19', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=123', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=137', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=138', 'action=accept']))

        if False:
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=162', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=139', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=156', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=194', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=201', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=992', 'action=accept']))
            #edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=3268', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=135', 'action=accept']))

            #edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=5632', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=89', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=88', 'action=accept']))
            edge_list2.append(Edge({'internet_zone','dmz'},{'corporate_zone'},attributes=['protocol=1', 'action=accept']))

        if False:
            edge_list2.append(Edge({'corporate_zone'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'firewall_zone'},attributes=['protocol=89', 'action=accept']))

            edge_list2.append(Edge({'firewall_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'corporate_zone'},attributes=['protocol=89', 'action=accept']))

            edge_list2.append(Edge({'management_zone','abstract_zone'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'management_zone','abstract_zone'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'management_zone','abstract_zone'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'management_zone','abstract_zone'},{'firewall_zone'},attributes=['protocol=89', 'action=accept']))

            edge_list2.append(Edge({'firewall_zone'},{'management_zone','abstract_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'management_zone','abstract_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'management_zone','abstract_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'management_zone','abstract_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'management_zone','abstract_zone'},attributes=['protocol=89', 'action=accept']))

        if False:
            edge_list2.append(Edge({'firewall_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'firewall_zone'},{'dmz'},attributes=['protocol=89', 'action=accept']))

            edge_list2.append(Edge({'dmz'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'firewall_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'firewall_zone'},attributes=['protocol=89', 'action=accept']))

        # TODO
        # policy_rule dmz_internet { internet_zone <-> dmz : iana_services.common_services}

        # policy_rule management_dmz { management_zone <-> dmz : iana_services.common_services}
        # policy_rule corp_management { corporate_zone <-> management_zone : iana_services.common_services}
        # policy_rule management_abstract_zone { management_zone <-> abstract_zone : iana_services.common_services}
        # policy_rule corp_abstract_zone { corporate_zone <-> abstract_zone : iana_services.common_services}
        # policy_rule dmz_abstract { dmz <-> abstract_zone : iana_services.common_services}
        # policy_rule abstract_zone_internet { abstract_zone <-> internet_zone : iana_services.common_services}

        propositions_set2=set()
        for edge in edge_list2:
            propositions_set2 = propositions_set2.union(set(edge.attributes))

        cmg_bp_policy = ConditionalMetagraph(variables_set2,propositions_set2)
        cmg_bp_policy.add_edges_from(edge_list2)

        #filepath='/Users/a1070571/Documents/IOT/cmg_bp_policy.dot'
        #MetagraphHelper().generate_visualisation(edge_list2,filepath,display_attributes=False, use_temp_label=True)

        # check implemented policy is equally or m ore restrictive than intent
        print('Create line digraph of policy1..')
        digraph_original = MetagraphHelper().GetMultiDigraph(cmg)
        cmg_original_line_graph=MetagraphHelper().CreateLineGraph(digraph_original)


        print('Create line digraph of policy2..')
        digraph_bp_policy = MetagraphHelper().GetMultiDigraph(cmg_bp_policy)
        bp_policy_line_graph=MetagraphHelper().CreateLineGraph(digraph_bp_policy)

        #for node, attributes in cmg_original_line_graph.node.iteritems():
        #    print('node: %s, attr: %s'%(node,attributes))

        if True:
            print('Generate canonical policies of policy1..')
            CanonicalPolicyHelper().GenerateCanonicalForm(digraph_original)
            canonical_policy1 = CanonicalPolicyHelper().canonical_policies

            flow_policies1=dict()
            for key in cmg_original_line_graph.node.keys():
                flow_policies1[key]=None
                # lookup the canonical policy of this flow
                flow1=None
                key_str='%s->%s'%(key[0],key[1])
                if key_str in canonical_policy1['final']:
                   flow1=canonical_policy1['final'][key_str]
                flow_policies1[key] = flow1

        print('Generate canonical policies of policy2..')
        CanonicalPolicyHelper().GenerateCanonicalForm(digraph_bp_policy)
        canonical_policy2 = CanonicalPolicyHelper().canonical_policies

        flow_policies2=dict()
        for key in bp_policy_line_graph.node.keys():
            flow_policies2[key]=None
            # lookup the canonical policy of this flow
            flow1=None
            key_str='%s->%s'%(key[0],key[1])
            if key_str in canonical_policy2['final']:
               flow1=canonical_policy2['final'][key_str]
            flow_policies2[key] = flow1
            #print('flow_policies2::key: %s, value: %s'%(key,flow1))

        print('CheckPolicyInclusion....')
        CanonicalPolicyHelper().CheckPolicyInclusion(flow_policies1,flow_policies2,cmg_original_line_graph,bp_policy_line_graph, #
                                                        digraph_original,digraph_bp_policy,"specified_policy","bp_policy", cmg, cmg2, False)

        #if CanonicalPolicyHelper().CheckPolicyInclusion(flow_policies2,flow_policies1,cmg_original_line_graph,bp_policy_line_graph,
        #                                                digraph_original,digraph_bp_policy,"specified_policy","bp_policy",False):
           #print('high-level policy intent is preserved')
        #else:
           #print('high-level policy intent is breached')

        # convert original metagraph to an intermediate metagraph that can be analysed
        # reformat attributes
        # TCP
        #tcp_port_attributes = MetagraphHelper().filter_port_attributes("TCP", original_cmg.propositions_set)
        #non_overlapping_tcp_port_ranges = MetagraphHelper().get_minimal_non_overlapping_port_ranges('TCP','dport',tcp_port_attributes)
        # UDP
        #udp_port_attributes = MetagraphHelper().filter_port_attributes("UDP", original_cmg.propositions_set)
        #non_overlapping_udp_port_ranges = MetagraphHelper().get_minimal_non_overlapping_port_ranges('UDP','dport',udp_port_attributes)

        print('test')

    def test_check_bp_compliance(self):
        import json
        import os, csv
        import datetime
        import pytz
        from mgtoolkit.library import ACE, ACL
        from mgtoolkit.library import CanonicalPolicyHelper
        from mgtoolkit.library import MudPolicy
        from mako.template import Template
        return

        # read in MUD file
        file = '/Users/a1070571/Documents/IOT/results/augustDoorBellCam/device_mud_profile.json' #pixstarPhotoFrame tribyspeaker amazonEcho blipcareBpmeter lifxBulb

        extracted = None
        with open(file) as json_data:
            extracted = json.load(json_data)

        acl_details =  MetagraphHelper().get_device_acl_details(extracted,True)

        # create metagraphs
        vars=[]
        props=[]
        variables_set=set()

        edge_list = self.get_edge_list(acl_details,vars,props,convert_ipaddresses_to_numeric=True)
        for var in vars:
            variables_set=variables_set.union(var)
        propositions_set=set(props)
        cmg = ConditionalMetagraph(variables_set,propositions_set)
        cmg.add_edges_from(edge_list)

        #vars02=[]
        #props02=[]
        #variables_set02=set()
        #edge_list02 = self.get_edge_list(acl_details,vars02,props02,convert_ipaddresses_to_numeric=False)
        #for var in vars02:
        #    variables_set02=variables_set02.union(var)
        #propositions_set02=set(props02)
        #cmg02 = ConditionalMetagraph(variables_set02,propositions_set02)
        #cmg02.add_edges_from(edge_list02)

        # example bp/compancy policy
        variables_set2={'corporate_zone','scada_zone','abstract_zone','internet_zone','management_zone', 'carrier_zone', 'firewall_zone', 'dmz'}
        edge_list2=[]

        #edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=137', 'UDP.sport=1024-65535', 'action=accept']))
        #edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
        #edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
        #edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=53', 'action=accept']))
        #edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))

        if True:

            #new
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))

            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=67', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=68', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=636', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=520', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=521', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=53', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=123', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=161', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=137', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))

            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=1024-65535','UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=1', 'action=accept']))
            #new new
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=554', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=444', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=139', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=445', 'action=accept']))

            # return responses
            #edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.sport=1024-65535', 'action=accept']))

            #new
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=53', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=123', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=1', 'action=accept']))

            #edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            #edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=1024-65535','action=accept']))

            # return responses
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=67', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=68', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=636', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=520', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=521', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=161', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=137', 'action=accept']))
            #edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'UDP.dport=1024-65535', 'action=accept']))
            # newr
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept'])) #3179

            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=636', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=502', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=1', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=636', 'action=accept']))

            #new
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=17', 'UDP.dport=636', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=1', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=17', 'UDP.sport=636', 'action=accept']))

            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=445', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=123', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=53', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=161', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=1', 'action=accept']))

            # return response
            #edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept']))
            ##edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.sport=1024-65535', 'action=accept']))
            ##edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            ##edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
            ##edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept']))

            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            #edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            #edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=161', 'action=accept']))
            ##edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept']))
            ##edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.sport=1024-65535', 'action=accept']))


            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=445', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=123', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=53', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=161', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=1', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=161', 'action=accept']))
            #edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept']))
            # new new
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=465', 'action=accept']))

            ##edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.sport=1024-65535', 'action=accept']))
            #edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            #edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept']))

            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=445', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=123', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=53', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=161', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=1', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=161', 'action=accept']))

        # TODO
        # policy_rule dmz_internet { internet_zone <-> dmz : iana_services.common_services}

        # policy_rule management_dmz { management_zone <-> dmz : iana_services.common_services}
        # policy_rule corp_management { corporate_zone <-> management_zone : iana_services.common_services}
        # policy_rule management_abstract_zone { management_zone <-> abstract_zone : iana_services.common_services}
        # policy_rule corp_abstract_zone { corporate_zone <-> abstract_zone : iana_services.common_services}
        # policy_rule dmz_abstract { dmz <-> abstract_zone : iana_services.common_services}
        # policy_rule abstract_zone_internet { abstract_zone <-> internet_zone : iana_services.common_services}

        propositions_set2=set()
        for edge in edge_list2:
            propositions_set2 = propositions_set2.union(set(edge.attributes))

        cmg_bp_policy = ConditionalMetagraph(variables_set2,propositions_set2)
        cmg_bp_policy.add_edges_from(edge_list2)

        #filepath='/Users/a1070571/Documents/IOT/cmg_bp_policy.dot'
        #MetagraphHelper().generate_visualisation(edge_list2,filepath,display_attributes=False, use_temp_label=True)

        # check implemented policy is equally or m ore restrictive than intent
        print('Create line digraph of policy1..')
        digraph_original = MetagraphHelper().GetMultiDigraph(cmg)
        cmg_original_line_graph=MetagraphHelper().CreateLineGraph(digraph_original)

        print('Create line digraph of policy2..')
        digraph_bp_policy = MetagraphHelper().GetMultiDigraph(cmg_bp_policy)
        bp_policy_line_graph=MetagraphHelper().CreateLineGraph(digraph_bp_policy)

        if True:
            print('Generate canonical policies of policy1..')
            CanonicalPolicyHelper().GenerateCanonicalForm(digraph_original)
            canonical_policy1 = CanonicalPolicyHelper().canonical_policies

            flow_policies1=dict()
            for key in cmg_original_line_graph.node.keys():
                flow_policies1[key]=None
                # lookup the canonical policy of this flow
                flow1=None
                key_str='%s->%s'%(key[0],key[1])
                if key_str in canonical_policy1['final']:
                   flow1=canonical_policy1['final'][key_str]
                flow_policies1[key] = flow1

        print('Generate canonical policies of policy2..')
        CanonicalPolicyHelper().GenerateCanonicalForm(digraph_bp_policy)
        canonical_policy2 = CanonicalPolicyHelper().canonical_policies

        flow_policies2=dict()
        for key in bp_policy_line_graph.node.keys():
            flow_policies2[key]=None
            # lookup the canonical policy of this flow
            flow1=None
            key_str='%s->%s'%(key[0],key[1])
            if key_str in canonical_policy2['final']:
               flow1=canonical_policy2['final'][key_str]
            flow_policies2[key] = flow1
            #print('flow_policies2::key: %s, value: %s'%(key,flow1))

        #print('CheckPolicyInclusion....')
        CanonicalPolicyHelper().CheckPolicyInclusion(flow_policies1,flow_policies2,cmg_original_line_graph,bp_policy_line_graph, #
                                                     digraph_original,digraph_bp_policy,"specified_policy","bp_policy", False)

    def test_check_sd(self):
        import json
        import os, csv
        import datetime
        import pytz
        from mgtoolkit.library import ACE, ACL
        from mgtoolkit.library import CanonicalPolicyHelper
        from mgtoolkit.library import MudPolicy
        from mako.template import Template
        return

        # nestsmokesensor(dmz,corp) lifxBulb(corp,dmz)
        # read in MUD file
        file = '/Users/a1070571/Documents/IOT/results/augustDoorBellCam/device_mud_profile.json'
        target_zone = 'dmz' # scada_zone corporate_zone dmz

        extracted = None
        with open(file) as json_data:
            extracted = json.load(json_data)

        acl_details =  MetagraphHelper().get_device_acl_details(extracted,True)

        # create metagraphs
        vars02=[]
        props02=[]
        variables_set02=set()
        edge_list02 = self.get_edge_list(acl_details,vars02,props02,convert_ipaddresses_to_numeric=False)
        for var in vars02:
            variables_set02=variables_set02.union(var)
        propositions_set02=set(props02)
        cmg02 = ConditionalMetagraph(variables_set02,propositions_set02)
        cmg02.add_edges_from(edge_list02)

        # example bp/compancy policy
        variables_set2={'corporate_zone','scada_zone','abstract_zone','internet_zone','management_zone', 'carrier_zone', 'firewall_zone', 'dmz'}
        edge_list2=[]

        if True:

            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            #new new
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=554', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=444', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=139', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=445', 'action=accept']))

            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=67', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=68', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=636', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=520', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=521', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=53', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=123', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=161', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=137', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))

            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=1024-65535','UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=1', 'action=accept']))

            # return responses
            #edge_list2.append(Edge({'corporate_zone'},{'dmz'},attributes=['protocol=6', 'TCP.sport=1024-65535', 'action=accept']))

            #new
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=53', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=123', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=1', 'action=accept']))

            #edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            #edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=1024-65535','action=accept']))

            # return responses
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=67', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=68', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=636', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=520', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=521', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=161', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=137', 'action=accept']))
            #edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'UDP.dport=1024-65535', 'action=accept']))
            # newr
            edge_list2.append(Edge({'dmz'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept'])) #3179


            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=636', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=502', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=1', 'action=accept']))
            edge_list2.append(Edge({'scada_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=636', 'action=accept']))

            #new
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=992', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=88', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=6', 'TCP.dport=636', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=17', 'UDP.dport=636', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=1', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'scada_zone'},attributes=['protocol=17', 'UDP.sport=636', 'action=accept']))

            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=445', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=123', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=53', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=161', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=1', 'action=accept']))

            # return response
            #edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept']))
            ##edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=6', 'TCP.sport=1024-65535', 'action=accept']))
            ##edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            ##edge_list2.append(Edge({'corporate_zone'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
            ##edge_list2.append(Edge({'corporate_zone'},{'internet_zone','dmz'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept']))

            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            #edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            #edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=161', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept']))
            ##edge_list2.append(Edge({'internet_zone'},{'corporate_zone'},attributes=['protocol=6', 'TCP.sport=1024-65535', 'action=accept']))


            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=445', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=123', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=53', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=161', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=1', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=161', 'action=accept']))
            #edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept']))
            #new new
            edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.dport=465', 'action=accept']))

            ##edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=6', 'TCP.sport=1024-65535', 'action=accept']))
            #edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            #edge_list2.append(Edge({'dmz'},{'internet_zone'},attributes=['protocol=17', 'UDP.sport=1024-65535', 'action=accept']))

            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=445', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=135', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=80', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=443', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=631', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=21', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=20', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=25', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=23', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=22', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=123', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=53', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=161', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=6', 'TCP.dport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.dport=1024-65535', 'UDP.sport=1024-65535', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=1', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=123', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=53', 'action=accept']))
            edge_list2.append(Edge({'internet_zone'},{'dmz'},attributes=['protocol=17', 'UDP.sport=161', 'action=accept']))

        # TODO
        # policy_rule dmz_internet { internet_zone <-> dmz : iana_services.common_services}

        # policy_rule management_dmz { management_zone <-> dmz : iana_services.common_services}
        # policy_rule corp_management { corporate_zone <-> management_zone : iana_services.common_services}
        # policy_rule management_abstract_zone { management_zone <-> abstract_zone : iana_services.common_services}
        # policy_rule corp_abstract_zone { corporate_zone <-> abstract_zone : iana_services.common_services}
        # policy_rule dmz_abstract { dmz <-> abstract_zone : iana_services.common_services}
        # policy_rule abstract_zone_internet { abstract_zone <-> internet_zone : iana_services.common_services}

        propositions_set2=set()
        for edge in edge_list2:
            propositions_set2 = propositions_set2.union(set(edge.attributes))

        cmg_bp_policy = ConditionalMetagraph(variables_set2,propositions_set2)
        cmg_bp_policy.add_edges_from(edge_list2)

        #filepath='/Users/a1070571/Documents/IOT/cmg_bp_policy.dot'
        #MetagraphHelper().generate_visualisation(edge_list2,filepath,display_attributes=False, use_temp_label=True)

        # check implemented policy is equally or m ore restrictive than intent
        # print('Create line digraph of policy2..')
        digraph_bp_policy = MetagraphHelper().GetMultiDigraph(cmg_bp_policy)

        lookup_map = dict()
        cmg02 = self.update_edges(cmg02,target_zone,lookup_map)
        digraph_original02 = MetagraphHelper().GetMultiDigraph(cmg02)
        self.PrintSemanticDifference(digraph_original02,digraph_bp_policy,"specified_policy","bp_policy",True,'Policy violations',cmg02,lookup_map)
        print('test')

    def update_edges(self, cmg02, target_zone,lookup_map):
        from mgtoolkit.library import CanonicalPolicyHelper
        from mgtoolkit.exception import InvalidTargetZoneException
        from mgtoolkit.properties import resources
        vars = []
        props = []
        new_edges = []
        for edge in cmg02.edges:
            inv = set()
            outv = set()
            props += list(edge.attributes)
            invertex = edge.invertex.difference(edge.attributes)
            outvertex = edge.outvertex
            for elt in list(invertex):
                if elt=='device':
                   inv = inv.union({target_zone})
                   lookup_map[target_zone]=['device']
                elif CanonicalPolicyHelper().is_private_ipaddress(elt):
                    if target_zone=='dmz':
                        # pick next least secure internal zone relative to dmz
                        inv = inv.union({'corporate_zone'})
                        if 'corporate_zone' not in lookup_map:
                            lookup_map['corporate_zone']=[]
                        if elt not in lookup_map['corporate_zone']:
                            lookup_map['corporate_zone'].append(elt)
                    else:
                        # least secure internal zone
                        inv = inv.union({'dmz'})
                        if 'dmz' not in lookup_map:
                            lookup_map['dmz']=[]
                        if elt not in lookup_map['dmz']:
                            lookup_map['dmz'].append(elt)
                else:
                   if target_zone=='internet_zone':
                       # error
                       raise InvalidTargetZoneException(resources['specified_target_zone_invalid'])
                   else:
                       inv = inv.union({'internet_zone'})
                       if 'internet_zone' not in lookup_map:
                            lookup_map['internet_zone']=[]
                       if elt not in lookup_map['internet_zone']:
                            lookup_map['internet_zone'].append(elt)

            for elt in list(outvertex):
                if elt=='device':
                   outv = outv.union({target_zone})
                   lookup_map[target_zone] = ['device']

                elif CanonicalPolicyHelper().is_private_ipaddress(elt):
                   if target_zone=='dmz':
                      # pick next least secure internal zone relative to dmz
                      outv = outv.union({'corporate_zone'})
                      if 'corporate_zone' not in lookup_map:
                          lookup_map['corporate_zone']=[]
                      if elt not in lookup_map['corporate_zone']:
                          lookup_map['corporate_zone'].append(elt)
                   else:
                      # least secure internal zone
                      outv = outv.union({'dmz'})
                      if 'dmz' not in lookup_map:
                          lookup_map['dmz']=[]
                      if elt not in lookup_map['dmz']:
                          lookup_map['dmz'].append(elt)
                else:
                   outv = outv.union({'internet_zone'})
                   if 'internet_zone' not in lookup_map:
                      lookup_map['internet_zone']=[]
                   if elt not in lookup_map['internet_zone']:
                      lookup_map['internet_zone'].append(elt)

            vars += list(inv)
            vars += list(outv)
            new_edges.append(Edge(inv,outv, attributes=edge.attributes, label=edge.label))

        cmg = ConditionalMetagraph(set(vars),set(props))
        cmg.add_edges_from(new_edges)
        return cmg

    def PrintSemanticDifference(self, policy1, policy2, policy1_name,policy2_name,display_policy1_only,msg='policy differences::',original_policy1=None,lookup_map=None):
        from mgtoolkit.library import CanonicalPolicyHelper
        print('Get policy semantic difference..')
        if policy1 and policy2:
            diff_lookup= CanonicalPolicyHelper().GetSemanticDifference(policy1,policy2)
            print(msg)
            print('%s'%policy1_name)
            if '1' in diff_lookup and diff_lookup['1'] and len(diff_lookup['1'])>0:
                for protocol, flows in diff_lookup['1'].iteritems():
                    for key, rules in flows.iteritems():
                        for rule in rules:
                            # get original rule TODO get this working
                            original = None # self.get_original_rule(rule, original_policy1, lookup_map)
                            if original is not None:
                                print(original)
                            else:
                                print(rule)
            print('-----------------')
            if True: #not display_policy1_only:
                print('%s'%policy2_name)
                if '2' in diff_lookup and diff_lookup['2'] and len(diff_lookup['2'])>0:
                    for protocol, flows in diff_lookup['2'].iteritems():
                        for key, rules in flows.iteritems():
                            for rule in rules:
                                #print(rule)
                                pass
                print('-----------------')

    def get_original_rule(self, rule, original_policy, lookup_map):
        replaced=[]
        # use lookup map to replace elts
        part1 = rule.split(':')[0]
        part2 = rule.split(':')[1]
        src = part1.split('->')[0]
        dst = part1.split('->')[1]
        part2 = part2.replace('{','')
        part2 = part2.replace('}','')
        part2 = part2.split(';')
        attributes = []
        for elt in part2:
            elt=elt.replace(' ','')
            if elt is not None and elt!='':
                attributes.append(elt)

        src = src.replace('Node(set([','')
        src = src.replace(']))','')
        src = src.replace("\\", '')
        src = src.replace("\"",'')
        src = src.split(',')

        dst = dst.replace('Node(set([','')
        dst = dst.replace(']))','')
        dst = dst.replace("\\", '')
        dst = dst.replace("\"",'')
        dst = dst.split(',')

        all_sources=[]
        for source in src:
            source = '%s'%source
            if source is not None and source in lookup_map:
                all_sources += lookup_map[source]
            else:
                all_sources.append(source)

        all_dests=[]
        for dest in dst:
            dest='%s'%dest
            if dest is not None and dest in lookup_map:
                all_dests += lookup_map[dest]
            else:
                all_dests.append(dest)

        all_edges=[]
        for source in all_sources:
            for dest in all_dests:
                all_edges.append(Edge(set(source),set(dest),attributes))

        for edge in original_policy.edges:
            inv = edge.invertex.difference(edge.attributes)
            outv = edge.outvertex
            if inv.issubset(set(all_sources)) and outv.issubset(set(all_dests)) and edge.attributes==attributes:
                # applicable edge
                replaced.append(edge)

        return replaced

    def test_mud_profile1(self):
        # read in common flows
        return

        import os, csv
        from mgtoolkit.library import ACE, ACL
        folder_path = "/Users/a1070571/Documents/IOT/"
        file_name = 'samsungRules.csv' #'observedFlows.csv'
        full_path_name = os.path.join(folder_path, file_name)
        common_flows_lookup=dict()

        with open(full_path_name, 'rb') as csvfile:
            data = self.read_file(full_path_name)
            index=0
            device_name = None
            device_mac = None
            for row in data:
                # print(row)
                if index==0:
                    # omit header
                    index+=1
                    continue

                if row[0] is not None and row[0]!='':
                    device_name = row[0]

                if row[1] is not None and row[1]!='':
                    device_mac = row[1]

                source_mac = row[2]
                dest_mac = row[3]
                protocol = row[4]
                source_ports = row[5]
                dest_ports = row[6]

                if device_name is not None and device_name not in common_flows_lookup:
                    common_flows_lookup[device_name]=[]

                ace = ACE(source_mac,dest_mac,protocol,dest_ports,source_ports,'accept') #drop
                common_flows_lookup[device_name].append(ace)

        from mgtoolkit.library import MudPolicy

        from_acls=[]
        to_acls=[]

        controllers = ['*', '14:cc:20:51:33:ea']
        local_networks = ['*']
        manufacturers = ['*']
        models = ['*']

        # for comms specific to controller
        acl_from1=ACL("from_1")
        acl_to1=ACL("to_1")
        # for all other comms
        acl_from2=ACL("from_2")
        acl_to2=ACL("to_2")

        for entry_list in common_flows_lookup.values():
            for entry in entry_list:
                if device_mac in entry.source:
                    dest_groups=[]
                    if entry.dest in controllers:
                        dest_groups.append('controller')
                    elif entry.dest in local_networks:
                        dest_groups.append('local-networks')
                    elif entry.dest in manufacturers:
                        dest_groups.append('manufacturer')
                    elif entry.dest in models:
                        dest_groups.append('model')

                    ace = ACE('device',dest_groups,entry.protocol,entry.dports,entry.sports,entry.action,"from-device")
                    if entry.dest=='14:cc:20:51:33:ea':
                        # controller specific
                        acl_from1.add_ace(ace)
                    else:
                        acl_from2.add_ace(ace)

                elif device_mac in entry.dest:
                    source_groups=[]
                    if entry.source in controllers:
                        source_groups.append('controller')
                    elif entry.source in local_networks:
                        source_groups.append('local-networks')
                    elif entry.source in manufacturers:
                        source_groups.append('manufacturer')
                    elif entry.source in models:
                        source_groups.append('model')

                    ace = ACE(source_groups,'device',entry.protocol,entry.dports,entry.sports,entry.action,"to-device")
                    if entry.source=='14:cc:20:51:33:ea':
                        # controller specific
                        acl_to1.add_ace(ace)
                    else:
                        acl_to2.add_ace(ace)

        from_acls.append(acl_from1)
        from_acls.append(acl_from2)

        to_acls.append(acl_to1)
        to_acls.append(acl_to2)

        mud_policy = MudPolicy('belkingcamera2000','belkin camera',from_acls,to_acls)

        # construct MUD file
        from mako.template import Template
        mud_template = Template(filename=folder_path+"/mud_profile_template.mako")
        mud_policy_text = mud_template.render(policy=mud_policy)
        # write to file
        policy_file=open(os.path.join(folder_path,'device_mud_profile.json'),'w') #
        policy_file.write(mud_policy_text)
        policy_file.close()

        # read in MUD file
        import json, simplejson
        file = '/Users/a1070571/Documents/IOT/samsungcam.json' # bkcamera.json

        extracted = None
        with open(file) as json_data:
            extracted = json.load(json_data)
            # extracted = simplejson.load(json_data)
            #print(extracted)

        #print('1: %s'%extracted['ietf-mud:mud'])
        #print('2: %s'%extracted['ietf-mud:mud']['from-device-policy'])

        #print(extracted['ietf-mud:mud']['from-device-policy']['access-lists']['access-list'][0]['acl-name'])
        #print(extracted['ietf-access-control-list:access-lists']['acl'][0]['access-list-entries']['ace'][0]['matches']['ipv6-acl']['ietf-acldns:src-dnsname'])

        # TODO: check all services included for belkin camera
        acl_details =  MetagraphHelper().get_device_acl_details(extracted)

        # create metagraph

        variables_set=set()
        propositions_set=set()

        edge_list=[]
        for direction, acls in acl_details.iteritems():
            for acl in acls:
                if direction=='from':
                    invertex = set([acl.source])
                    #outvertex = set(acl.dest)
                    outvertex = set(MetagraphHelper().get_ipaddresses_numeric(set(acl.dest)))

                elif direction=='to':
                    #invertex = set(acl.source)
                    outvertex = set([acl.dest])
                    invertex = set(MetagraphHelper().get_ipaddresses_numeric(set(acl.source)))

                attributes = []
                attributes.append('protocol=%s'%acl.protocol)
                dports = MetagraphHelper().get_port_descriptor(acl.protocol, acl.dports, 'dport')
                sports = MetagraphHelper().get_port_descriptor(acl.protocol, acl.sports, 'sport')
                if dports is not None:
                    attributes.append(dports)
                if sports is not None:
                    attributes.append(sports)
                attributes.append('action=%s'%acl.action)
                propositions_set = propositions_set.union(attributes)
                variables_set = variables_set.union(invertex)
                variables_set = variables_set.union(outvertex)
                edge = Edge(invertex,outvertex,attributes)
                edge_list.append(edge)

        #cmg = ConditionalMetagraph(variables_set,propositions_set)
        #cmg.add_edges_from(edge_list)

        #filepath='/Users/a1070571/Documents/IOT/cmg_mud_profile.dot'
        #MetagraphHelper().generate_visualisation(edge_list,filepath,display_attributes=False, use_temp_label=True)


        if True:
            variables_set=variables_set.difference({'device'})
            non_overlapping_ipaddress_ranges = MetagraphHelper().get_minimal_non_overlapping_ipaddress_ranges(list(variables_set))

            converted=[]
            for ipaddr_range in non_overlapping_ipaddress_ranges:
                range_string = '%s-%s'%(ipaddr_range[0],ipaddr_range[1])
                converted.append(range_string)

            variable_set = set(converted)
            new_edge_list=[]
            import copy
            for edge in edge_list:
                edge_attributes= copy.copy(edge.attributes)

                # convert tcp port attributes to non-overlapping ranges via lookup
                inv_device=False
                outv_device=False
                invertex = edge.invertex.difference(edge_attributes)
                outvertex = edge.outvertex

                if 'device' in invertex:
                    inv_device=True
                    invertex = invertex.difference({'device'})
                if 'device' in outvertex:
                    outv_device=True
                    outvertex = outvertex.difference({'device'})

                if len(invertex)>0:
                    invertex = MetagraphHelper().get_ipaddresses_canonical_form(invertex, non_overlapping_ipaddress_ranges)
                if len(outvertex)>0:
                    outvertex = MetagraphHelper().get_ipaddresses_canonical_form(outvertex, non_overlapping_ipaddress_ranges)

                if inv_device:
                    invertex = invertex.union({'device'})
                if outv_device:
                    outvertex = outvertex.union({'device'})

                temp= edge.attributes
                # TCP
                #edge_tcp_attr= MetagraphHelper().filter_port_attributes("TCP", edge_attributes)
                #if len(edge_tcp_attr)>0:
                #    canonical_tcp_attr= MetagraphHelper().get_ports_canonical_form('TCP.dport=', edge_tcp_attr[0], non_overlapping_tcp_port_ranges)
                # UDP
                #edge_udp_attr= MetagraphHelper().filter_port_attributes("UDP", edge_attributes)
                #if len(edge_udp_attr)>0:
                #    canonical_udp_attr= MetagraphHelper().get_ports_canonical_form('UDP.dport=', edge_udp_attr[0], non_overlapping_udp_port_ranges)

                # update temp and propositions_set
                # TCP
                #if len(edge_tcp_attr)>0:
                #    if edge_tcp_attr[0] in temp: temp.remove(edge_tcp_attr[0])
                #    if edge_tcp_attr[0] in propositions_set: propositions_set.remove(edge_tcp_attr[0])
                #    for canonical_attr in canonical_tcp_attr:
                #        if canonical_attr not in temp:
                #            temp.append(canonical_attr)
                #        if canonical_attr not in propositions_set:
                #            propositions_set= propositions_set.union({canonical_attr})
                # UDP
                #if len(edge_udp_attr)>0:
                #    if edge_udp_attr[0] in temp: temp.remove(edge_udp_attr[0])
                #    if edge_udp_attr[0] in propositions_set: propositions_set.remove(edge_udp_attr[0])
                #    for canonical_attr in canonical_udp_attr:
                #        if canonical_attr not in temp:
                #            temp.append(canonical_attr)
                #        if canonical_attr not in propositions_set:
                #            propositions_set= propositions_set.union({canonical_attr})


                new_edge= Edge(invertex, outvertex, temp, label=edge.label)
                new_edge_list.append(new_edge)

            variable_set = variable_set.union({'device'})

            # create intermediate metagraph suitable for performing analysis
            converted_cmg= ConditionalMetagraph(variable_set, propositions_set)
            converted_cmg.add_edges_from(new_edge_list)

            filepath='/Users/a1070571/Documents/IOT/cmg_mud_profile.dot'
            MetagraphHelper().generate_visualisation(new_edge_list,filepath,display_attributes=False, use_temp_label=True)




        # convert original metagraph to an intermediate metagraph that can be analysed
        # reformat attributes
        # TCP
        #tcp_port_attributes = MetagraphHelper().filter_port_attributes("TCP", original_cmg.propositions_set)
        #non_overlapping_tcp_port_ranges = MetagraphHelper().get_minimal_non_overlapping_port_ranges('TCP','dport',tcp_port_attributes)
        # UDP
        #udp_port_attributes = MetagraphHelper().filter_port_attributes("UDP", original_cmg.propositions_set)
        #non_overlapping_udp_port_ranges = MetagraphHelper().get_minimal_non_overlapping_port_ranges('UDP','dport',udp_port_attributes)

        print('test')

    def combine_pathways(self, pathways1, all_pathways, course_id, metagraph):
        result=[]

        for pathway1 in pathways1:
            pre_requisites= self.get_prerequisites([pathway1]).values()[0].values()[0]
            if course_id in pre_requisites:
                # already a pre-req
                if pathway1 not in result:
                    result.append(pathway1)
                continue

            pathways2 = all_pathways[course_id]
            for pathway2 in pathways2:
                # combine the two metapaths
                temp = set(pathway1.edge_list).union(set(pathway2.edge_list))
                source = pathway1.source.union(pathway2.source)
                target = pathway1.target.union(pathway2.target)
                mp = Metapath(source, target, list(temp))
                response = metagraph.is_metapath(mp)
                if not response: print('NOT a metapath: %s'%repr(mp))
                if mp not in result:
                    result.append(mp)

        return result

    def get_pathways_to(self, source, target, metagraph):
        # compute all metapaths
        metapaths = metagraph.get_all_metapaths_from(source,target)

        # extract dominant metapaths
        extracted=[]
        if metapaths is not None and len(metapaths)>0:
            for mp in metapaths:
                if metagraph.is_edge_dominant_metapath(mp):
                    extracted.append(mp)
                #elif(len(mp.edge_list)==4):
                #    print('non edge dom mp: %s'%mp.edge_list)

        # comment this out - we can add this later
        '''
        filtered=[]
        if extracted is not None:
            # remove duplicates
            for mp1 in extracted:
                included=False
                for mp2 in extracted:
                    if mp1!=mp2:
                       if MetagraphHelper().is_edge_list_included(mp1.edge_list,mp2.edge_list):
                          if len(mp1.edge_list)!=len(mp2.edge_list):
                             included=True
                             break
                if not included:
                   filtered.append(mp1)'''

        return extracted #filtered

    def get_pathways_from(self, source, metagraph):
        generator_set = list(metagraph.generating_set)
        target = set(generator_set).difference(source)
        metapaths = metagraph.get_all_metapaths_from(source,target)

        filtered=[]
        if metapaths is not None:
            # remove duplicates
            for mp1 in metapaths:
                included=False
                for mp2 in metapaths:
                    if mp1!=mp2:
                       if MetagraphHelper().is_edge_list_included(mp1.edge_list,mp2.edge_list):
                          if len(mp1.edge_list)!=len(mp2.edge_list):
                             included=True
                             break
                if not included:
                   filtered.append(mp1)

        return filtered

    def get_prerequisites(self, pathways):
        pre_requisites_lookup=dict()
        index=1
        for metapath in pathways:
            target=list(metapath.target)[0]
            if target not in pre_requisites_lookup:
                pre_requisites_lookup[target] = dict()

            pre_requisites=set()
            for edge in metapath.edge_list:
                pre_requisites = pre_requisites.union(edge.invertex)

            pre_requisites_lookup[target][index] =pre_requisites
            index+=1

        return pre_requisites_lookup

    def compare_pre_requisites(self, pre_requisites1, pre_requisites2):
        for course1, lookup1 in pre_requisites1.iteritems():
            for requisites1 in lookup1.values():
                for course2, lookup2 in pre_requisites2.iteritems():
                    for requisites2 in lookup2.values():
                        if requisites1==requisites2:
                            return requisites1
        return None

    def test_cve_data(self):
        from mgtoolkit.library import CVE
        import json
        return
        filename= "/Users/a1070571/Documents/ITS/nvdcve-1.0-2018.json"
        extracted = None
        with open(filename) as json_data:
            extracted = json.load(json_data)

        count = extracted['CVE_data_numberOfCVEs']
        entries = extracted['CVE_Items']
        print('Number of CVE entries: %s'%count)
        extracted_cves = []

        for cve in entries:
            cve_id = cve['cve']['CVE_data_meta']['ID']
            lastmodified = cve['lastModifiedDate']
            published = cve['publishedDate']
            vendor_prod_versions=[]
            if 'cve' in cve and \
               'affects' in cve['cve'] and \
               'vendor' in  cve['cve']['affects'] and \
               'vendor_data' in cve['cve']['affects']['vendor']:
                for item in cve['cve']['affects']['vendor']['vendor_data']:
                    vendor = item['vendor_name']
                    products = item['product']['product_data']
                    for prod in products:
                        prod_name = prod['product_name']
                        versions = prod['version']['version_data']
                        prod_versions=[]
                        for version in versions:
                            v = str(version['version_value'])
                            if v not in prod_versions:
                                prod_versions.append("%s_%s_v%s"%(vendor,prod_name,v))
                        vendor_prod_versions += list(set(prod_versions))

            # create cve object
            # if len(vendor_prod_versions)==0:
            #    print('here')
            cve_entry = CVE(cve_id, vendor_prod_versions, lastmodified, published)

            if 'impact' in cve and \
               'baseMetricV3' in cve['impact']:
                cve_entry.exp_score = cve['impact']['baseMetricV3']['exploitabilityScore']
                cve_entry.impact_score = cve['impact']['baseMetricV3']['impactScore']
                cvss_v3 = cve['impact']['baseMetricV3']['cvssV3']
                cve_entry.attack_complexity = cvss_v3['attackComplexity']
                cve_entry.attack_vector = cvss_v3['attackVector']
                cve_entry.priv_required = cvss_v3['privilegesRequired']
                cve_entry.scope = cvss_v3['scope'] #whats this?
                cve_entry.user_interaction = cvss_v3['userInteraction']
                cve_entry.avail_impact = cvss_v3['availabilityImpact']
                cve_entry.confidentiality_impact = cvss_v3['confidentialityImpact']
                cve_entry.integrity_impact = cvss_v3['integrityImpact']
                cve_entry.base_score = cvss_v3['baseScore']
                cve_entry.base_severity = cvss_v3['baseSeverity']
            extracted_cves.append(cve_entry)

        vars=set()
        props=set()
        edge_list=[]
        count=1
        for cve in extracted_cves:
            invertex = set()
            if cve.vendor_product_data is None or len(cve.vendor_product_data)==0:
                continue

            #count+=1
            #if count>50: break

            invertex = invertex.union(set(cve.vendor_product_data))
            edge = Edge(invertex,
                        {"CI_%s"%cve.confidentiality_impact,
                         "AI_%s"%cve.avail_impact,
                         "II_%s"%cve.integrity_impact},
                        attributes=["attack_complexity=%s"%cve.attack_complexity,
                                    "attack_vector=%s"%cve.attack_vector,
                                    "priv_required=%s"%cve.priv_required,
                                    "user_interaction=%s"%cve.user_interaction],
                        label=cve.id)
            edge_list.append(edge)
            vars = vars.union(set(cve.vendor_product_data))
            vars = vars.union({"CI_%s"%cve.confidentiality_impact})
            vars = vars.union({"AI_%s"%cve.avail_impact})
            vars = vars.union({"II_%s"%cve.integrity_impact})
            props = props.union({"attack_complexity=%s"%cve.attack_complexity})
            props = props.union({"attack_vector=%s"%cve.attack_vector})
            props = props.union({"priv_required=%s"%cve.priv_required})
            props = props.union({"user_interaction=%s"%cve.user_interaction})

        cmg = ConditionalMetagraph(vars,props)
        cmg.add_edges_from(edge_list)
        source = {"juniper_junos_v14.1x53", "juniper_junos_v15.1", "juniper_junos_v15.1x53", "juniper_junos_v16.1",
                  "juniper_junos_v15.1x49", "juniper_junos_v12.3x48", "juniper_junos_v14.1", "juniper_junos_v14.2",
                  "juniper_junos_v12.1x46", "juniper_appformix_v2.7.3", "juniper_screenos_v6.3.0r23"}
        target = {"CI_HIGH", "AI_HIGH", "II_HIGH"}
        print('get metapaths..')
        mps = cmg.get_all_metapaths_from(source, target,include_propositions=True)
        for mp in mps:
            if cmg.is_edge_dominant_metapath(mp):
                print('metapath:')
                for edge in mp.edge_list:
                    print('CVE: %s'%edge.label)

        # above code finds 'similar' CVEs
        # how do we find 'dependent' CVEs?
                    # ie one must be exploited in order to exploit the other?
                    # meaning pre-conds for a CVE can be satisfied by the postconditions of another CVE

        # build CMG of cves
        # lookup related CVEs for a fresh one (eg use exploitability metrics, vendor, product details and impact metrics)
        # for each related CVE found look at the CVE life cycle/state MG and find applicable time values (eg for patch release, poc exploit etc)
        # compute potential time values for fresh CVE based on these findings (eg using average etc)

    def test_cve_data2(self):
        from mgtoolkit.library import CVE
        import json
        import numpy as np
        import collections
        return

        if False:
            # Load
            delay_2018 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2018.npy').item()
            delay_2017 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2017.npy').item()
            delay_2016 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2016.npy').item()
            delay_2015 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2015.npy').item()
            delay_2014 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2014.npy').item()
            delay_2013 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2013.npy').item()
            delay_2012 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2012.npy').item()
            delay_2011 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2011.npy').item()
            delay_2010 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2010.npy').item()
            # TODO: extend to 2010 (check cvss populated ok - either cvss2/3)

            from collections import Counter
            import matplotlib.pyplot as plt
            combined = dict(Counter(delay_2018)+Counter(delay_2017)+Counter(delay_2016)+Counter(delay_2015)+Counter(delay_2014)+Counter(delay_2013)+Counter(delay_2012)+Counter(delay_2011)+Counter(delay_2010))

            # find total entries
            total=0
            for key, val in combined.iteritems():
                total = total+val

            print('total=%s'%total)
            major_ticks = np.arange(0, 3000, 100) # 500,20
            fig = plt.figure()
            ax = fig.add_subplot(1, 1, 1)
            ax.set_xticks(major_ticks)

            plt.plot(combined.keys(), combined.values())
            # plt.axis([0, 100, 0, 150])  # 2018
            # plt.axis([0, 500, 0, 800])  # 2017
            # plt.axis([0, 800, 0, 400])  # 2016
            # plt.axis([0, 1200, 0, 600]) # 2015
            # plt.axis([0, 1600, 0, 1100])  # 2014
            # plt.axis([0, 3000, 0, 200])   # 2010
            # plt.axis([0, 2600, 0, 200])   # 2011
            # plt.axis([0, 2300, 0, 150])   # 2012
            # plt.axis([0, 2300, 0, 250])   # 2013
            plt.axis([0, 3000, 0, 2200])    # combined
            plt.show()
            print('test')

        # return

        filename= "/Users/a1070571/Documents/ITS/nvdcve-1.0-2018.json"
        extracted = None
        with open(filename) as json_data:
            extracted = json.load(json_data)

        # import vulners
        # db = vulners.Vulners()
        # cve=db.document('CVE-2016-2036')
        # print('tests')

        count = extracted['CVE_data_numberOfCVEs']
        entries = extracted['CVE_Items']
        print('Number of CVE entries: %s'%count)
        extracted_cves = []

        for cve in entries:
            cve_id = cve['cve']['CVE_data_meta']['ID']
            #if str(cve_id) == "CVE-2017-11496":
            #    print('here')
            #    break;
            lastmodified = cve['lastModifiedDate']
            published = cve['publishedDate']
            vendor_prod_versions=[]
            if 'cve' in cve and \
               'affects' in cve['cve'] and \
               'vendor' in  cve['cve']['affects'] and \
               'vendor_data' in cve['cve']['affects']['vendor']:
                for item in cve['cve']['affects']['vendor']['vendor_data']:
                    vendor = str(item['vendor_name'])
                    products = item['product']['product_data']
                    for prod in products:
                        prod_name = str(prod['product_name'])
                        versions = prod['version']['version_data']
                        prod_versions=[]
                        for version in versions:
                            v = str(version['version_value'])
                            if v not in prod_versions:
                                prod_versions.append("%s_%s_v%s"%(vendor,prod_name,v))
                        #tup = (vendor, prod_name, set(prod_versions))
                        #if tup not in vendor_prod_versions:
                        #    vendor_prod_versions.append(tup)
                        vendor_prod_versions += list(set(prod_versions))

            description = None
            if 'cve' in cve and \
               'description' in cve['cve'] and \
               'description_data' in cve['cve']['description'] and \
                len(cve['cve']['description']['description_data'])>0:
                  description = cve['cve']['description']['description_data'][0]['value']

            references = None
            if 'cve' in cve and \
               'references' in cve['cve'] and \
               'reference_data' in cve['cve']['references'] and \
                len(cve['cve']['references']['reference_data'])>0:
                   references = cve['cve']['references']['reference_data']

            # extract problemtype?
            # creae cve object
            cve_entry = CVE(cve_id, vendor_prod_versions, lastmodified, published, description, references)

            if 'impact' in cve and \
               'baseMetricV3' in cve['impact']:
                cve_entry.exp_score = cve['impact']['baseMetricV3']['exploitabilityScore']
                cve_entry.impact_score = cve['impact']['baseMetricV3']['impactScore']
                cvss_v3 = cve['impact']['baseMetricV3']['cvssV3']
                cve_entry.attack_complexity = str(cvss_v3['attackComplexity'])
                cve_entry.attack_vector = str(cvss_v3['attackVector'])
                cve_entry.priv_required = str(cvss_v3['privilegesRequired'])
                cve_entry.scope = str(cvss_v3['scope']) #whats this?
                cve_entry.user_interaction = str(cvss_v3['userInteraction'])
                cve_entry.avail_impact = str(cvss_v3['availabilityImpact'])
                cve_entry.confidentiality_impact = str(cvss_v3['confidentialityImpact'])
                cve_entry.integrity_impact = str(cvss_v3['integrityImpact'])
                cve_entry.base_score = cvss_v3['baseScore']
                cve_entry.base_severity = cvss_v3['baseSeverity']
                cve_entry.cvss3=True

            elif 'impact' in cve and \
               'baseMetricV2' in cve['impact']:
                cve_entry.cvss2=True
            extracted_cves.append(cve_entry)

        vars=set()
        props=set()
        edge_list=[]
        count=1
        index=1
        temp=1
        rejects=0
        check=[]
        vendor_prod_keywords = ['cisco', 'microsoft', 'juniper', 'junos', 'remctl', 'WP Retina', 'line for ios', 'Cybozu Garoon',' Tor ',
                                'Johnathan Nightingale beep through', 'ArsenoL', 'QQQ SYSTEMS', 'ViX',
                                'Tiny FTP Daemon', 'LXR', 'WP All Import', 'PhishWall Client', 'iRemoconWiFi',
                                'Buffalo WZR-1750DHP2', 'Hatena Bookmark App', 'SoundEngine Free',
                                'OpenSSL', 'Internet Explorer', 'Windows 7', 'Windows 8', 'Windows 10', 'Windows Server',
                                'Video Downloader professional', 'Knot Resolver', 'ovirt-hosted-engine-setup',
                                'GmbH Electrum Bitcoin Wallet', 'Jerome Gamez Firebase Admin SDK',
                                'Security Onion Solutions Squert', 'NASA Pyblock', 'fmtlib', 'Sensu Core',
                                'Pym.js', 'Doorkeeper', 'django-anymail', 'tiny-json-http', 'FFmpeg', 'iScripts eSwap',
                                'Jungo DriverWizard WinDriver', 'WordPress', 'D-Link DIR-815', 'GEGL',
                                'XYHCMS', 'PbootCMS', 'iScripts UberforX', 'Moodle', 'Dell EMC Isilon', 'Dell EMC iDRAC7',
                                'EMC RSA Archer', 'RSA Authentication Agent', 'Spring Framework', 'NetIQ Identity Manager driver',
                                'IBM GSKit', 'SAP Disclosure Management', 'Oracle Support Tools', 'Sun ZFS Storage Appliance Kit',
                                'Intel Remote Keyboard', 'In Android', 'Qualcomm', # 'Qualcomm Snapdragon', 'Qualcomm Android for MSM', 'Qualcomm Small Cell'
                                'TeleControl Server Basic', 'iOS before', 'macOS before', 'Safari before',
                                'Philips IntelliSpace Portal', 'F5 BIG-IP', 'Extreme Networks ExtremeWireless WiNG',
                                'idreamsoft iCMS', 'Gxlcms QY', 'Exiv2', 'Wireshark', 'Crea8social', 'v20180320',
                                'zzcms', 'Ryzen', 'Ruby', 'NetIQ Identity Manager', 'FreeBSD', 'VMware vRealize Automation',
                                'Icinga','NVIDIA', 'Mediawiki', 'Linux foundation ONOS', 'Product: Android', 'Micrologix' ,
                                'IKARUS', 'Huawei', 'Norton', 'Apache Qpid Broker-J', 'K7', 'Netgain Enterprise Manager',
                                'Synology', 'IBM', 'Bastet', 'VCM5010', 'VMware AirWatch', 'Drupal', 'HedEx', 'Mitsubishi',
                                'Amazon', 'Siemens', 'Dolibarr', 'HPE', 'P10', 'CCN-lite', 'Inedo BuildMaster', 'Bitdefender',
                                'QPDF', 'Phone Finder', 'P9', 'Sandstorm', 'Symantec', 'Phoenix Contact ILC PLCs', 'Skybox',
                                'DragonByte Technologies'] # 'windows', 'ios'

        prod_lookup=dict()
        cvss_population_delays = dict()
        for cve in extracted_cves:
            invertex = set()
            if (cve.vendor_product_data is None or len(cve.vendor_product_data)==0): # and ('** REJECT' not in cve.description):
                #or len(cve.vendor_product_data[0])<3:
                #print('%s. cve_id: %s: vendor_product_data: %s'%(count, cve.id, cve.vendor_product_data))
                print('cve_id: %s'%(cve.id))
                desc = cve.description.lower()
                if '** reject' in desc or '** disputed' in desc:
                    rejects +=1
                    continue

                #print('CVE created= %s, updated= %s'%(cve.published,cve.lastmodified))

                #if 'android' in desc:
                #    print('%s. cve_id: %s'%(count,cve.id))
                #absent=True
                #for keyword in vendor_prod_keywords:
                #    if keyword.lower() in desc:
                        #print('%s. desc=%s'%(count,cve.description))
                #        absent= False
                #        if keyword.lower() not in prod_lookup:
                #            prod_lookup[keyword.lower()]=1
                #        else:
                #            prod_lookup[keyword.lower()] +=1
                #        break
                        #count+=1
                #if absent:
                #    print('%s. desc=%s'%(count,cve.description))
                    #print('%s. date=%s'%(count,cve.published))
                    #print('%s. id=%s'%(count,cve.id))
                #    count+=1

                #if count<500:
                #    check.append(cve)
                continue

            #print('%s. date=%s'%(index,cve.published))
            #index+=1
            #print('cve_id: %s: desc: %s'%(cve.id, cve.description))
            #print('cve_id: %s:, cvss2: %s, cvss3: %s'%(cve.id, cve.cvss2, cve.cvss3))
            #print('cve_id= %s, published= %s, lastmod= %s'%(cve.id, cve.published, cve.lastmodified))

            #count+=1
            #if count>100: break

            #invertex = invertex.union({cve.vendor_product_data[0][0]})
            #invertex = invertex.union({cve.vendor_product_data[0][1]})
            #invertex = invertex.union(cve.vendor_product_data[0][2])
            #print('CVE id= %s, created= %s, updated= %s'%(cve.id, cve.published, cve.lastmodified))

            #if (not cve.cvss2) and (not cve.cvss3):
            #   print('cve= %s, No CVSS data'%cve.id)

            disclosed = self.get_date_time(cve.published)
            cvss_populated = self.get_date_time(cve.lastmodified) # replace with initial analysis datetime
            delay = (cvss_populated - disclosed).days

            #if delay>200 and delay<400:
            #    print('cve(delay>2000):%s'%(cve.id))

            # TODO : check why a few negative entries exist
            if delay >0:
                if delay not in cvss_population_delays:
                    cvss_population_delays[delay] = 0
                cvss_population_delays[delay] +=1

            # 2018-03-09T11:29:00
            invertex = invertex.union(set(cve.vendor_product_data))
            edge = Edge(invertex,
                        {"CI_%s"%cve.confidentiality_impact, # conf_impact=
                         "AI_%s"%cve.avail_impact, # avail_impact=
                         "II_%s"%cve.integrity_impact}, # int_impact=
                        attributes=["attack_complexity=%s"%cve.attack_complexity,
                                   "attack_vector=%s"%cve.attack_vector,
                                   "priv_required=%s"%cve.priv_required,
                                   "user_interaction=%s"%cve.user_interaction],
                        label=cve.id)

            #if temp<5:
            #    print('id=%s, cve.vendor=%s'%(cve.id,cve.vendor_product_data))
            #    temp+=1
            edge_list.append(edge)
            #vars = vars.union({cve.vendor_product_data[0][0]})
            #vars = vars.union({cve.vendor_product_data[0][1]})
            #vars = vars.union(cve.vendor_product_data[0][2])
            vars = vars.union(set(cve.vendor_product_data))
            vars = vars.union({"CI_%s"%cve.confidentiality_impact})
            vars = vars.union({"AI_%s"%cve.avail_impact})
            vars = vars.union({"II_%s"%cve.integrity_impact})

            props = props.union({"attack_complexity=%s"%cve.attack_complexity})
            props = props.union({"attack_vector=%s"%cve.attack_vector})
            props = props.union({"priv_required=%s"%cve.priv_required})
            props = props.union({"user_interaction=%s"%cve.user_interaction})

        # print('rejects: %s'%rejects)
        # for key, val in prod_lookup.iteritems():
        #   print('%s:%s'%(key,val))
        #print('#vars: %s, #props: %s, #edges: %s'%(len(vars),len(props),len(edge_list)))

        #edge_list = edge_list[0:20]
        #vars=set()
        #for edge in edge_list:
        #    vars=vars.union(edge.invertex)
        #    vars=vars.union(edge.outvertex)

        #for key, value in cvss_population_delays.iteritems():
        #    print('delay(days)= %s, count=%s'%(key,value))

        # sort and save
        #cvss_population_delays_ord = collections.OrderedDict(sorted(cvss_population_delays.items()))
        #print('saving')
        #np.save('/Users/a1070571/Documents/ITS/cvss_pop_delay_2014.npy', cvss_population_delays_ord)

        #props=set()
        #print('#vars1= %s, #props1= %s, #edges1= %s'%(len(vars),len(props),len(edge_list)))

        #for edge in edge_list:
        #    print('inv= %s, outv= %s, label= %s'%(edge.invertex,edge.outvertex,edge.label))

        if False:
            cmg = ConditionalMetagraph(vars,props)
            cmg.add_edges_from(edge_list)
            #source = {"juniper_junos_v14.1x53", "juniper_junos_v15.1", "juniper_junos_v15.1x53", "juniper_junos_v16.1",
            #          "juniper_junos_v15.1x49", "juniper_junos_v12.3x48", "juniper_junos_v14.1", "juniper_junos_v14.2",
            #          "juniper_junos_v12.1x46", "juniper_appformix_v2.7.3", "juniper_screenos_v6.3.0r23"}
            #source = {"microsoft_windows_7_v-", "microsoft_windows_server_2008_vr2", "microsoft_windows_server_2008_v-", "microsoft_windows_vista_v-"}
            #target = {"CI_NONE", "AI_HIGH", "II_NONE"}
            source = {'juniper_junos_v15.1', 'juniper_junos_v14.1x53', 'juniper_junos_v15.1x53'}
            target = {'CI_HIGH', 'AI_HIGH', 'II_HIGH'}
            print('get metapaths..')
            mps = cmg.get_all_metapaths_from(source, target,include_propositions=False)
            for mp in mps:
                #if cmg.is_edge_dominant_metapath(mp):
                    print('metapath:')
                    for edge in mp.edge_list:
                        print('CVE: %s'%edge.label)

        #return

        #generate complexity reduced, equiv metagraph
        group_name_index=1
        new_edge_list=[]
        new_var_set=set()
        invertex_element_group_lookup=dict()
        outvertex_element_group_lookup=dict()
        propositions_set = props

        #print('step1')
        for edge in edge_list:
            inv = list(edge.invertex.difference(propositions_set))
            outv = list(edge.outvertex.difference(propositions_set))
            for elt in inv:
                if elt not in invertex_element_group_lookup:
                    invertex_element_group_lookup[elt] = set()
                invertex_element_group_lookup[elt] = invertex_element_group_lookup[elt].union({edge.label})

            for elt in outv:
                if elt not in outvertex_element_group_lookup:
                    outvertex_element_group_lookup[elt] = set()
                outvertex_element_group_lookup[elt] = outvertex_element_group_lookup[elt].union({edge.label})

        #print('step1.1')
        groups_inv=dict()
        groups_outv=dict()
        group_details_lookup=dict()

        for elt, edges in invertex_element_group_lookup.iteritems():
            edge_list_string = json.dumps(list(edges))
            if edge_list_string not in groups_inv:
                groups_inv[edge_list_string]=set()
            groups_inv[edge_list_string] = groups_inv[edge_list_string].union({elt})

        for elt, edges in outvertex_element_group_lookup.iteritems():
            edge_list_string = json.dumps(list(edges))
            if edge_list_string not in groups_outv:
                groups_outv[edge_list_string]=set()
            groups_outv[edge_list_string] = groups_outv[edge_list_string].union({elt})

        print('step1.2')
        for edge_list_string, elt_list in groups_inv.iteritems():
            group_elts = set(elt_list)
            if len(group_elts)>1:
                group_elts = set(elt_list)
                if len(group_elts)>1:
                    # group
                    group_elts_string = json.dumps(list(group_elts))
                    if group_elts_string not in group_details_lookup:
                        group_name= 'group_%s'%group_name_index
                        group_details_lookup[group_elts_string]=group_name
                        group_name_index+=1

        for edge_list_string, elt_list in groups_outv.iteritems():
            group_elts = set(elt_list)
            if len(group_elts)>1:
                # group
                group_elts_string = json.dumps(list(group_elts))
                if group_elts_string not in group_details_lookup:
                    group_name= 'group_%s'%group_name_index
                    group_details_lookup[group_elts_string]=group_name
                    group_name_index+=1

        #print('step1.3')

        if False:
            for edge in edge_list:
                invertex_elts = list(edge.invertex.difference(propositions_set))
                outvertex_elts = list(edge.outvertex.difference(propositions_set))

                for elt in invertex_elts:
                    result= MetagraphHelper().get_associated_edges(elt, edge_list)
                    edge_list_string=repr(result)
                    print('edge_list_string= %s'%edge_list_string)
                    if edge_list_string not in invertex_element_group_lookup:
                        invertex_element_group_lookup[edge_list_string]=[]
                    if elt not in invertex_element_group_lookup[edge_list_string]:
                        invertex_element_group_lookup[edge_list_string].append(elt)

                for elt in outvertex_elts:
                    result= MetagraphHelper().get_associated_edges(elt, edge_list)
                    edge_list_string=repr(result)
                    if edge_list_string not in outvertex_element_group_lookup:
                        outvertex_element_group_lookup[edge_list_string]=[]
                    if elt not in outvertex_element_group_lookup[edge_list_string]:
                        outvertex_element_group_lookup[edge_list_string].append(elt)

            #print('step2')
            import json
            group_details_lookup=dict()

            for edge_list_string, elt_list in invertex_element_group_lookup.iteritems():
                group_elts = set(elt_list)
                if len(group_elts)>1:
                    # group
                    group_elts_string = json.dumps(list(group_elts))
                    if group_elts_string not in group_details_lookup:
                        group_name= 'group_%s'%group_name_index
                        group_details_lookup[group_elts_string]=group_name
                        group_name_index+=1

            #print('step3')
            for edge_list_string, elt_list in outvertex_element_group_lookup.iteritems():
                group_elts = set(elt_list)
                if len(group_elts)>1:
                    # group
                    group_elts_string = json.dumps(list(group_elts))
                    if group_elts_string not in group_details_lookup:
                        group_name= 'group_%s'%group_name_index
                        group_details_lookup[group_elts_string]=group_name
                        group_name_index+=1

        #print('step4')
        #print('edge count: %s'%len(edge_list))
        #print('GD lookup: %s'%len(group_details_lookup.keys()))

        # replace original invertices with groups
        counter=1
        for edge in edge_list:
            invertex_elts = list(edge.invertex.difference(propositions_set))
            outvertex_elts = list(edge.outvertex)
            new_invertex=set()
            new_outvertex=set()

            for group_elts, group_name in group_details_lookup.iteritems():
                group_elts_list = json.loads(group_elts)
                group_elts_list = [elt2.encode('ascii', errors='backslashreplace') for elt2 in group_elts_list]
                if set(group_elts_list).issubset(set(invertex_elts)):
                    new_invertex = new_invertex.union({group_name})
                    invertex_elts = list(set(invertex_elts).difference(set(group_elts_list)))

                #for group_elts, group_name in group_details_lookup.iteritems():
                #    group_elts_list = json.loads(group_elts)
                #    group_elts_list = [elt2.encode('ascii', errors='backslashreplace') for elt2 in group_elts_list]
                if set(group_elts_list).issubset(set(outvertex_elts)):
                    new_outvertex = new_outvertex.union({group_name})
                    outvertex_elts = list(set(outvertex_elts).difference(set(group_elts_list)))

            new_invertex=new_invertex.union(set(invertex_elts))
            new_outvertex=new_outvertex.union(set(outvertex_elts))
            new_var_set = new_var_set.union(new_invertex)
            new_var_set = new_var_set.union(new_outvertex)
            new_edge_list.append(Edge(new_invertex, new_outvertex,
                                              attributes=list(edge.invertex.intersection(propositions_set)),
                                              label=edge.label))

            #print('counter=%s'%counter)
            #counter +=1

        # create complexity reduced, equivalent metagraph
        print('#vars2= %s, #props2= %s, #edges2= %s'%(len(new_var_set),len(propositions_set),len(new_edge_list)))
        reduced_cmg= ConditionalMetagraph(new_var_set, propositions_set)
        reduced_cmg.add_edges_from(new_edge_list)

        #for edge in new_edge_list:
        #    print('inv= %s, outv= %s, label= %s'%(edge.invertex,edge.outvertex,edge.label))

        #for elt in new_var_set:
        #    print('var- %s'%elt)
        #for elt in propositions_set:
        #    print('prop- %s'%elt)
        #for key, val in group_details_lookup.iteritems():
        #    print('key=%s, val=%s'%(key,val))

        source = {"juniper_junos_v14.1x53", "juniper_junos_v15.1", "juniper_junos_v15.1x53", "juniper_junos_v16.1",
                  "juniper_junos_v15.1x49", "juniper_junos_v12.3x48", "juniper_junos_v14.1", "juniper_junos_v14.2",
                  "juniper_junos_v12.1x46", "juniper_appformix_v2.7.3", "juniper_screenos_v6.3.0r23"}
        #source = {"microsoft_windows_7_v-", "microsoft_windows_server_2008_vr2", "microsoft_windows_server_2008_v-", "microsoft_windows_vista_v-"}
        #target = {"CI_NONE", "AI_HIGH", "II_NONE"}
        target = {'CI_HIGH', 'AI_HIGH', 'II_HIGH'}

        src_groups=set()
        target_groups=set()
        for elt in source:
            for key,val in group_details_lookup.iteritems():
                if elt in key:
                    src_groups = src_groups.union({val})

        for elt in target:
            for key,val in group_details_lookup.iteritems():
                if elt in key:
                    target_groups = target_groups.union({val})

        modified_source = src_groups
        modified_target = target_groups
        # print('modified_source= %s, modified_target= %s'%(modified_source, target))
        # src = {'juniper_junos_v12.3', 'juniper_junos_v15.1', 'group_94', 'group_216', 'group_43'} # CVE-2018-0001
        # src = {'group_3', 'juniper_junos_v15.1', 'group_6', 'group_5', 'juniper_junos_v12.3'}
        #src = set(['group_119', 'juniper_junos_v12.3', 'juniper_junos_v15.1', 'group_203', 'group_82'])
        src = {'oracle_mysql_v5.5.54', 'group_1386', 'group_1449'} #{'oracle_solaris_v11.3'} # {'oracle_mysql_v5.5.54', 'group_1386', 'group_1449'}
        target = {'II_NONE', 'AI_HIGH', 'CI_NONE'} #{'AI_NONE', 'CI_NONE', 'II_LOW'} # 'II_NONE', 'AI_HIGH', 'CI_NONE'

        print('get metapaths..')
        #mps = reduced_cmg.get_all_metapaths_from(src, target,include_propositions=True) #modified_source
        #for mp in mps:
        #    if reduced_cmg.is_edge_dominant_metapath(mp): #is_edge_dominant_metapath
        #        print('metapath:')
        #        for edge in mp.edge_list:
        #            print('CVE: %s'%edge.label)

        #print('done')
        # build CMG of cves
        # lookup related CVEs for a fresh one (eg use exploitability metrics, vendor, product details and impact metrics)
        # for each related CVE found look at the CVE life cycle/state MG and find applicable time values (eg for patch release, poc exploit etc)
        # compute potential time values for fresh CVE based on these findings (eg using average etc)

    def test_cve_data3(self):
        from mgtoolkit.library import CVE
        import json
        import numpy as np
        import collections
        from datetime import datetime
        from collections import Counter
        import matplotlib.pyplot as plt
        import xmltodict
        return

        #cve_initial_analysis_lookup6 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2015.npy').item()
        # cve_initial_analysis_lookup7 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2017.npy').item()
        #print('test')

        if False:
            # Load
            delay_2018 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2018.npy').item()
            delay_2017 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2017.npy').item()
            delay_2016 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2016.npy').item()
            delay_2015 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2015.npy').item()
            delay_2014 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2014.npy').item()
            delay_2013 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2013.npy').item()
            delay_2012 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2012.npy').item()
            delay_2011 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2011.npy').item()
            delay_2010 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2010.npy').item()
            # TODO: extend to 2010 (check cvss populated ok - either cvss2/3)

            from collections import Counter
            import matplotlib.pyplot as plt
            combined = dict(Counter(delay_2018)+Counter(delay_2017)+Counter(delay_2016)+Counter(delay_2015)+Counter(delay_2014)+Counter(delay_2013)+Counter(delay_2012)+Counter(delay_2011)+Counter(delay_2010))

            # find total entries
            total=0
            for key, val in combined.iteritems():
                total = total+val

            print('total=%s'%total)
            major_ticks = np.arange(0, 3000, 100) # 500,20
            fig = plt.figure()
            ax = fig.add_subplot(1, 1, 1)
            ax.set_xticks(major_ticks)

            plt.plot(combined.keys(), combined.values())
            # plt.axis([0, 100, 0, 150])  # 2018
            # plt.axis([0, 500, 0, 800])  # 2017
            # plt.axis([0, 800, 0, 400])  # 2016
            # plt.axis([0, 1200, 0, 600]) # 2015
            # plt.axis([0, 1600, 0, 1100])  # 2014
            # plt.axis([0, 3000, 0, 200])   # 2010
            # plt.axis([0, 2600, 0, 200])   # 2011
            # plt.axis([0, 2300, 0, 150])   # 2012
            # plt.axis([0, 2300, 0, 250])   # 2013
            plt.axis([0, 3000, 0, 2200])    # combined
            plt.show()
            print('test')

        # return
        folder = "/Users/a1070571/Documents/ITS/cve"

        import os
        root, dirs, files = next(os.walk(folder))
        processed=[]
        extracted_cves = []
        index1 =1
        priv_req_none = 0
        priv_req_low = 0
        priv_req_high = 0

        user_int_none = 0
        user_int_req = 0

        ci_none = 0
        ci_low = 0
        ci_high = 0

        for file in files:
            #if (file != 'nvdcve-1.0-2010.json') and \
            #   (file != 'nvdcve-1.0-2011.json') and \
            #   (file != 'nvdcve-1.0-2012.json') and \
            #   (file != 'nvdcve-1.0-2013.json') and \
            #   (file != 'nvdcve-1.0-2017.json'):
            if (file == 'nvdcve-1.0-2017.json' or file == 'nvdcve-1.0-2018.json'):
                continue
            if file == '.DS_Store': continue
            print('processing file: %s'%file)
            extracted = None
            filename = "/Users/a1070571/Documents/ITS/%s"%file
            with open(filename) as json_data:
                extracted = json.load(json_data)
                count = extracted['CVE_data_numberOfCVEs']
                entries = extracted['CVE_Items']
                print('Number of CVE entries: %s'%count)
                for cve in entries:
                    cve_id = cve['cve']['CVE_data_meta']['ID']
                    #if cve_id in processed:
                    #    print('cve-id(1)=%s'%cve_id)
                    processed.append(cve_id)
                    lastmodified = cve['lastModifiedDate']
                    published = cve['publishedDate']
                    #print('cve id: %s, published: %s'%(cve_id, published))
                    vendor_prod_versions=[]
                    if 'cve' in cve and \
                       'affects' in cve['cve'] and \
                       'vendor' in  cve['cve']['affects'] and \
                       'vendor_data' in cve['cve']['affects']['vendor']:
                        for item in cve['cve']['affects']['vendor']['vendor_data']:
                            vendor = str(item['vendor_name'])
                            products = item['product']['product_data']
                            for prod in products:
                                prod_name = str(prod['product_name'])
                                versions = prod['version']['version_data']
                                prod_versions=[]
                                for version in versions:
                                    v = str(version['version_value'])
                                    if v not in prod_versions:
                                        prod_versions.append("%s_%s_v%s"%(vendor,prod_name,v))
                                vendor_prod_versions += list(set(prod_versions))

                    description = None
                    if 'cve' in cve and \
                       'description' in cve['cve'] and \
                       'description_data' in cve['cve']['description'] and \
                        len(cve['cve']['description']['description_data'])>0:
                          description = cve['cve']['description']['description_data'][0]['value']

                    references = None
                    if 'cve' in cve and \
                       'references' in cve['cve'] and \
                       'reference_data' in cve['cve']['references'] and \
                        len(cve['cve']['references']['reference_data'])>0:
                           references = cve['cve']['references']['reference_data']

                    cve_entry = CVE(cve_id, vendor_prod_versions, lastmodified, published, description, references)

                    if 'impact' in cve and \
                       'baseMetricV3' in cve['impact']:
                        cve_entry.exp_score = cve['impact']['baseMetricV3']['exploitabilityScore']
                        cve_entry.impact_score = cve['impact']['baseMetricV3']['impactScore']
                        cvss_v3 = cve['impact']['baseMetricV3']['cvssV3']
                        cve_entry.attack_complexity = str(cvss_v3['attackComplexity'])
                        cve_entry.attack_vector = str(cvss_v3['attackVector'])
                        cve_entry.priv_required = str(cvss_v3['privilegesRequired'])
                        cve_entry.scope = str(cvss_v3['scope']) #whats this?
                        cve_entry.user_interaction = str(cvss_v3['userInteraction'])
                        cve_entry.avail_impact = str(cvss_v3['availabilityImpact'])
                        cve_entry.confidentiality_impact = str(cvss_v3['confidentialityImpact'])
                        cve_entry.integrity_impact = str(cvss_v3['integrityImpact'])
                        cve_entry.base_score = cvss_v3['baseScore']
                        cve_entry.base_severity = cvss_v3['baseSeverity']
                        cve_entry.cvss3=True
                        #print('cve_entry.priv_required: %s'%cve_entry.priv_required)
                        '''
                        if 'NONE' in cve_entry.priv_required:
                            priv_req_none +=1
                        if 'LOW' in cve_entry.priv_required:
                            priv_req_low +=1
                        if 'HIGH' in cve_entry.priv_required:
                            priv_req_high +=1
                        if 'NONE' in cve_entry.user_interaction:
                            user_int_none +=1
                        if 'REQUIRED' in cve_entry.user_interaction:
                            user_int_req +=1
                        if 'NONE' in cve_entry.confidentiality_impact:
                            ci_none +=1
                        if 'LOW' in cve_entry.confidentiality_impact:
                            ci_low  +=1
                        if 'HIGH' in cve_entry.confidentiality_impact:
                            ci_high  +=1'''

                    elif 'impact' in cve and \
                       'baseMetricV2' in cve['impact']:
                        cve_entry.cvss2=True
                        self.populate_cvss3_data(cve,cve_entry)
                        #print('cve_entry.priv_required: %s'%cve_entry.priv_required)
                        '''
                        if 'NONE' in cve_entry.priv_required:
                            priv_req_none +=1
                        if 'LOW' in cve_entry.priv_required:
                            priv_req_low +=1
                        if 'HIGH' in cve_entry.priv_required:
                            priv_req_high +=1
                        if 'NONE' in cve_entry.user_interaction:
                            user_int_none +=1
                        if 'REQUIRED' in cve_entry.user_interaction:
                            user_int_req +=1
                        if 'NONE' in cve_entry.confidentiality_impact:
                            ci_none +=1
                        if 'LOW' in cve_entry.confidentiality_impact:
                            ci_low  +=1
                        if 'HIGH' in cve_entry.confidentiality_impact:
                            ci_high  +=1'''

                    extracted_cves.append(cve_entry)

        #print('priv req none: %s'%(priv_req_none))
        #print('priv req low: %s'%priv_req_low)
        #print('priv req high: %s'%priv_req_high)

        #print('user int none: %s'%(user_int_none))
        #print('user int req: %s'%user_int_req)

        #print('CI none: %s'%(ci_none))
        #print('CI low: %s'%ci_low)
        #print('CI high: %s'%ci_high)
        #return
        print('len(extracted_cves): %s'%len(extracted_cves))
        cve_initial_analysis_lookup = dict()

        # load latest data set
        cve_initial_analysis_lookup1 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2005.npy').item()
        cve_initial_analysis_lookup2 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2006.npy').item()
        cve_initial_analysis_lookup3 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2007.npy').item()
        cve_initial_analysis_lookup4 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2008.npy').item()
        cve_initial_analysis_lookup5 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2009.npy').item()
        cve_initial_analysis_lookup6 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2010.npy').item()
        cve_initial_analysis_lookup7 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2011.npy').item()
        cve_initial_analysis_lookup8 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2012.npy').item()
        cve_initial_analysis_lookup9 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2013.npy').item()
        cve_initial_analysis_lookup10 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2014.npy').item()
        cve_initial_analysis_lookup11 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2015.npy').item()
        cve_initial_analysis_lookup12 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2016.npy').item()
        #cve_initial_analysis_lookup13 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2017.npy').item()
        #cve_initial_analysis_lookup14 = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2018.npy').item()

        cve_initial_analysis_lookup = cve_initial_analysis_lookup1.copy()
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup2)
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup3)
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup4)
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup5)
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup6)
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup7)
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup8)
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup9)
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup10)
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup11)
        cve_initial_analysis_lookup.update(cve_initial_analysis_lookup12)
        #cve_initial_analysis_lookup.update(cve_initial_analysis_lookup13)
        #cve_initial_analysis_lookup.update(cve_initial_analysis_lookup14)

        # cve_initial_analysis_lookup = np.load('/Users/a1070571/Documents/ITS/cvss_pop_delay_2012.npy').item()
        # print('len(cve_initial_analysis_lookup): %s'%(len(cve_initial_analysis_lookup.keys())))
        # print('len(extracted_cves): %s'%(len(extracted_cves)))

        vars=set()
        props=set()
        edge_list=[]
        count=1
        index=1
        temp=1
        rejects=0
        check=[]
        processed=[]
        vendor_prod_keywords = ['cisco', 'microsoft', 'juniper', 'junos', 'remctl', 'WP Retina', 'line for ios', 'Cybozu Garoon',' Tor ',
                                'Johnathan Nightingale beep through', 'ArsenoL', 'QQQ SYSTEMS', 'ViX',
                                'Tiny FTP Daemon', 'LXR', 'WP All Import', 'PhishWall Client', 'iRemoconWiFi',
                                'Buffalo WZR-1750DHP2', 'Hatena Bookmark App', 'SoundEngine Free',
                                'OpenSSL', 'Internet Explorer', 'Windows 7', 'Windows 8', 'Windows 10', 'Windows Server',
                                'Video Downloader professional', 'Knot Resolver', 'ovirt-hosted-engine-setup',
                                'GmbH Electrum Bitcoin Wallet', 'Jerome Gamez Firebase Admin SDK',
                                'Security Onion Solutions Squert', 'NASA Pyblock', 'fmtlib', 'Sensu Core',
                                'Pym.js', 'Doorkeeper', 'django-anymail', 'tiny-json-http', 'FFmpeg', 'iScripts eSwap',
                                'Jungo DriverWizard WinDriver', 'WordPress', 'D-Link DIR-815', 'GEGL',
                                'XYHCMS', 'PbootCMS', 'iScripts UberforX', 'Moodle', 'Dell EMC Isilon', 'Dell EMC iDRAC7',
                                'EMC RSA Archer', 'RSA Authentication Agent', 'Spring Framework', 'NetIQ Identity Manager driver',
                                'IBM GSKit', 'SAP Disclosure Management', 'Oracle Support Tools', 'Sun ZFS Storage Appliance Kit',
                                'Intel Remote Keyboard', 'In Android', 'Qualcomm', # 'Qualcomm Snapdragon', 'Qualcomm Android for MSM', 'Qualcomm Small Cell'
                                'TeleControl Server Basic', 'iOS before', 'macOS before', 'Safari before',
                                'Philips IntelliSpace Portal', 'F5 BIG-IP', 'Extreme Networks ExtremeWireless WiNG',
                                'idreamsoft iCMS', 'Gxlcms QY', 'Exiv2', 'Wireshark', 'Crea8social', 'v20180320',
                                'zzcms', 'Ryzen', 'Ruby', 'NetIQ Identity Manager', 'FreeBSD', 'VMware vRealize Automation',
                                'Icinga','NVIDIA', 'Mediawiki', 'Linux foundation ONOS', 'Product: Android', 'Micrologix' ,
                                'IKARUS', 'Huawei', 'Norton', 'Apache Qpid Broker-J', 'K7', 'Netgain Enterprise Manager',
                                'Synology', 'IBM', 'Bastet', 'VCM5010', 'VMware AirWatch', 'Drupal', 'HedEx', 'Mitsubishi',
                                'Amazon', 'Siemens', 'Dolibarr', 'HPE', 'P10', 'CCN-lite', 'Inedo BuildMaster', 'Bitdefender',
                                'QPDF', 'Phone Finder', 'P9', 'Sandstorm', 'Symantec', 'Phoenix Contact ILC PLCs', 'Skybox',
                                'DragonByte Technologies'] # 'windows', 'ios'

        prod_lookup=dict()
        cvss_population_delays = dict()
        for cve in extracted_cves:
            invertex = set()
            if (cve.vendor_product_data is None or len(cve.vendor_product_data)==0): # and ('** REJECT' not in cve.description):
                #or len(cve.vendor_product_data[0])<3:
                #print('%s. cve_id: %s: vendor_product_data: %s'%(count, cve.id, cve.vendor_product_data))
                if cve.id in processed:
                    print('cve_id(2): %s'%(cve.id))
                desc = cve.description.lower()
                if '** reject' in desc or '** disputed' in desc:
                    rejects +=1
                    continue

                #print('CVE created= %s, updated= %s'%(cve.published,cve.lastmodified))

                #if 'android' in desc:
                #    print('%s. cve_id: %s'%(count,cve.id))
                #absent=True
                #for keyword in vendor_prod_keywords:
                #    if keyword.lower() in desc:
                        #print('%s. desc=%s'%(count,cve.description))
                #        absent= False
                #        if keyword.lower() not in prod_lookup:
                #            prod_lookup[keyword.lower()]=1
                #        else:
                #            prod_lookup[keyword.lower()] +=1
                #        break
                        #count+=1
                #if absent:
                #    print('%s. desc=%s'%(count,cve.description))
                    #print('%s. date=%s'%(count,cve.published))
                    #print('%s. id=%s'%(count,cve.id))
                #    count+=1

                #if count<500:
                #    check.append(cve)
                continue

            #print('%s. date=%s'%(index,cve.published))
            #index+=1
            #print('cve_id: %s: desc: %s'%(cve.id, cve.description))
            #print('cve_id: %s:, cvss2: %s, cvss3: %s'%(cve.id, cve.cvss2, cve.cvss3))
            #print('cve_id= %s, published= %s, lastmod= %s'%(cve.id, cve.published, cve.lastmodified))

            #count+=1
            #if count>100: break

            #invertex = invertex.union({cve.vendor_product_data[0][0]})
            #invertex = invertex.union({cve.vendor_product_data[0][1]})
            #invertex = invertex.union(cve.vendor_product_data[0][2])
            #print('CVE id= %s, created= %s, updated= %s'%(cve.id, cve.published, cve.lastmodified))

            #if (not cve.cvss2) and (not cve.cvss3):
            #   print('cve= %s, No CVSS data'%cve.id)

            disclosed = self.get_date_time(cve.published)
            if cve.id in cve_initial_analysis_lookup and cve_initial_analysis_lookup[cve.id] is not None:
                cvss_populated = self.get_date_time2(cve_initial_analysis_lookup[cve.id])
            else:
                cvss_populated = self.get_date_time(cve.lastmodified) # replace with initial analysis datetime
                index1 +=1
                #print('cant find cvss pop: %s'%cve.id)
                # continue
            delay = (cvss_populated - disclosed).days
            processed.append(cve.id)

            # TODO : check why a few negative entries exist
            #if delay<(-1):
            #    print('cve-id: %s, cvss_pop: %s, discl: %s'%(cve.id,cvss_populated,disclosed))
            if delay >10:
                print('cve-id: %s, cvss_pop: %s, discl: %s'%(cve.id,cvss_populated,disclosed))

            # if delay >=0 and delay<120:
            if delay not in cvss_population_delays:
                cvss_population_delays[delay] = 0
            cvss_population_delays[delay] +=1
            # else:
            #   cvss_population_delays[delay] =0

        if False:
            import plotly.plotly as py
            import plotly.graph_objs as go
            import numpy as np

            # x = np.random.randn(500)
            names = ['id','data']
            formats = ['f8','f8']
            dtype = dict(names = names, formats=formats)
            x = np.array(list(cvss_population_delays.items()), dtype=dtype)
            # print('data: %s'%type(x))
            data = [go.Histogram(x=x,
                                 cumulative=dict(enabled=True))]
            py.iplot(data, filename='cumulative histogram', auto_open=True)

        if True:
            #print('cant get CVSS pop datetime: %s'%index1)
            cvss_population_delays_ord = collections.OrderedDict(sorted(cvss_population_delays.items()))
            # delay_counters, avg_delay_to_exploit, med=7, percentiles: 0.6=12.0.8=53,.95=390

            # CDF
            delay_cdf=dict()
            prev_key=None
            total=0
            count=0
            for key, val in cvss_population_delays_ord.iteritems():
                if key>0:
                    delay_cdf[key]= delay_cdf[prev_key]+val
                    total += key*val
                    count += val
                else:
                    delay_cdf[key]=val
                prev_key=key

            mean = float(total)/count
            print('mean= %s'%mean)

            delay_cdf_ord = collections.OrderedDict(sorted(delay_cdf.items())) # delay_counters, avg_delay_to_exploit

            keys = delay_cdf_ord.keys()
            last_key_index = len(keys)-1
            total = delay_cdf_ord[keys[last_key_index]]

            delay_cdf2 = dict()
            for key, val in delay_cdf_ord.iteritems():
                delay_cdf2[key] = float(val)/total
                #print('key: %s, val: %s'%(key, delay_cdf2[key]))

            delay_cdf_ord2 = collections.OrderedDict(sorted(delay_cdf2.items())) # delay_counters, avg_delay_to_exploit

            # save lookup table
            np.save('/Users/a1070571/Documents/ITS/cvss_population_delays_ord_2005_2016.npy', cvss_population_delays_ord)

            major_ticks = np.arange(0, 1000, 50) # generic delay
            fig = plt.figure()
            ax = fig.add_subplot(1, 1, 1)
            ax.set_xticks(major_ticks)

            # Fit power law dist
            #import powerlaw
            #names = ['delay','count']
            #formats = ['f8','f8']
            #dtype = dict(names = names, formats=formats)
            #data = np.array(list(cvss_population_delays.items()), dtype=dtype)
            ##data = array([1.7, 3.2 ...]) # data can be list or numpy array
            #results = powerlaw.Fit(data)
            #print('power_law.alpha: %s'%results.power_law.alpha)
            #print('power_law.xmin: %s'%results.power_law.xmin)

            #curve_fit(func_powerlaw, x, y, p0 = np.asarray([-1,10**5,0]))

            ax.set_ylabel('Probability')
            ax.set_xlabel('Time (days)')
            #ax.set_title('CDF for distribution of time to populate CVSS data')

            plt.plot(delay_cdf_ord2.keys(), delay_cdf_ord2.values()) #cvss_population_delays_ord delay_cdf_ord
            plt.axis([0, 1000, 0, 1]) # generic delay
            plt.show()

    def test_cve_data4(self):
        from mgtoolkit.library import CVE
        import json
        import numpy as np
        import collections
        from datetime import datetime
        from collections import Counter
        import matplotlib.pyplot as plt
        import xmltodict

        return
        folder = "/Users/a1070571/Documents/ITS/cve"

        import os
        root, dirs, files = next(os.walk(folder))
        processed=[]
        extracted_cves = []

        for file in files:
            if file != 'nvdcve-1.0-20158.json': continue
            if file == '.DS_Store': continue
            print('processing file: %s'%file)
            extracted = None
            filename = "/Users/a1070571/Documents/ITS/%s"%file
            with open(filename) as json_data:
                extracted = json.load(json_data)
                count = extracted['CVE_data_numberOfCVEs']
                entries = extracted['CVE_Items']
                print('Number of CVE entries: %s'%count)
                for cve in entries:
                    cve_id = cve['cve']['CVE_data_meta']['ID']
                    if cve_id in processed:
                        print('cve-id(1)=%s'%cve_id)
                    processed.append(cve_id)
                    lastmodified = cve['lastModifiedDate']
                    published = cve['publishedDate']
                    vendor_prod_versions=[]
                    if 'cve' in cve and \
                       'affects' in cve['cve'] and \
                       'vendor' in  cve['cve']['affects'] and \
                       'vendor_data' in cve['cve']['affects']['vendor']:
                        for item in cve['cve']['affects']['vendor']['vendor_data']:
                            vendor = str(item['vendor_name'])
                            products = item['product']['product_data']
                            for prod in products:
                                prod_name = str(prod['product_name'])
                                versions = prod['version']['version_data']
                                prod_versions=[]
                                for version in versions:
                                    v = str(version['version_value'])
                                    if v not in prod_versions:
                                        prod_versions.append("%s_%s_v%s"%(vendor,prod_name,v))
                                vendor_prod_versions += list(set(prod_versions))

                    description = None
                    if 'cve' in cve and \
                       'description' in cve['cve'] and \
                       'description_data' in cve['cve']['description'] and \
                        len(cve['cve']['description']['description_data'])>0:
                          description = cve['cve']['description']['description_data'][0]['value']

                    references = None
                    if 'cve' in cve and \
                       'references' in cve['cve'] and \
                       'reference_data' in cve['cve']['references'] and \
                        len(cve['cve']['references']['reference_data'])>0:
                           references = cve['cve']['references']['reference_data']

                    cve_entry = CVE(cve_id, vendor_prod_versions, lastmodified, published, description, references)

                    if 'impact' in cve and \
                       'baseMetricV3' in cve['impact']:
                        cve_entry.exp_score = cve['impact']['baseMetricV3']['exploitabilityScore']
                        cve_entry.impact_score = cve['impact']['baseMetricV3']['impactScore']
                        cvss_v3 = cve['impact']['baseMetricV3']['cvssV3']
                        cve_entry.attack_complexity = str(cvss_v3['attackComplexity'])
                        cve_entry.attack_vector = str(cvss_v3['attackVector'])
                        cve_entry.priv_required = str(cvss_v3['privilegesRequired'])
                        cve_entry.scope = str(cvss_v3['scope']) #whats this?
                        cve_entry.user_interaction = str(cvss_v3['userInteraction'])
                        cve_entry.avail_impact = str(cvss_v3['availabilityImpact'])
                        cve_entry.confidentiality_impact = str(cvss_v3['confidentialityImpact'])
                        cve_entry.integrity_impact = str(cvss_v3['integrityImpact'])
                        cve_entry.base_score = cvss_v3['baseScore']
                        cve_entry.base_severity = cvss_v3['baseSeverity']
                        cve_entry.cvss3=True

                    elif 'impact' in cve and \
                       'baseMetricV2' in cve['impact']:
                        cve_entry.cvss2=True
                    extracted_cves.append(cve_entry)


        vars=set()
        props=set()
        edge_list=[]
        count=1
        index=1
        temp=1
        rejects=0
        check=[]
        processed=[]
        vendor_prod_keywords = ['cisco', 'microsoft', 'juniper', 'junos', 'remctl', 'WP Retina', 'line for ios', 'Cybozu Garoon',' Tor ',
                                'Johnathan Nightingale beep through', 'ArsenoL', 'QQQ SYSTEMS', 'ViX',
                                'Tiny FTP Daemon', 'LXR', 'WP All Import', 'PhishWall Client', 'iRemoconWiFi',
                                'Buffalo WZR-1750DHP2', 'Hatena Bookmark App', 'SoundEngine Free',
                                'OpenSSL', 'Internet Explorer', 'Windows 7', 'Windows 8', 'Windows 10', 'Windows Server',
                                'Video Downloader professional', 'Knot Resolver', 'ovirt-hosted-engine-setup',
                                'GmbH Electrum Bitcoin Wallet', 'Jerome Gamez Firebase Admin SDK',
                                'Security Onion Solutions Squert', 'NASA Pyblock', 'fmtlib', 'Sensu Core',
                                'Pym.js', 'Doorkeeper', 'django-anymail', 'tiny-json-http', 'FFmpeg', 'iScripts eSwap',
                                'Jungo DriverWizard WinDriver', 'WordPress', 'D-Link DIR-815', 'GEGL',
                                'XYHCMS', 'PbootCMS', 'iScripts UberforX', 'Moodle', 'Dell EMC Isilon', 'Dell EMC iDRAC7',
                                'EMC RSA Archer', 'RSA Authentication Agent', 'Spring Framework', 'NetIQ Identity Manager driver',
                                'IBM GSKit', 'SAP Disclosure Management', 'Oracle Support Tools', 'Sun ZFS Storage Appliance Kit',
                                'Intel Remote Keyboard', 'In Android', 'Qualcomm', # 'Qualcomm Snapdragon', 'Qualcomm Android for MSM', 'Qualcomm Small Cell'
                                'TeleControl Server Basic', 'iOS before', 'macOS before', 'Safari before',
                                'Philips IntelliSpace Portal', 'F5 BIG-IP', 'Extreme Networks ExtremeWireless WiNG',
                                'idreamsoft iCMS', 'Gxlcms QY', 'Exiv2', 'Wireshark', 'Crea8social', 'v20180320',
                                'zzcms', 'Ryzen', 'Ruby', 'NetIQ Identity Manager', 'FreeBSD', 'VMware vRealize Automation',
                                'Icinga','NVIDIA', 'Mediawiki', 'Linux foundation ONOS', 'Product: Android', 'Micrologix' ,
                                'IKARUS', 'Huawei', 'Norton', 'Apache Qpid Broker-J', 'K7', 'Netgain Enterprise Manager',
                                'Synology', 'IBM', 'Bastet', 'VCM5010', 'VMware AirWatch', 'Drupal', 'HedEx', 'Mitsubishi',
                                'Amazon', 'Siemens', 'Dolibarr', 'HPE', 'P10', 'CCN-lite', 'Inedo BuildMaster', 'Bitdefender',
                                'QPDF', 'Phone Finder', 'P9', 'Sandstorm', 'Symantec', 'Phoenix Contact ILC PLCs', 'Skybox',
                                'DragonByte Technologies'] # 'windows', 'ios'

        prod_lookup=dict()
        cvss_population_delays = dict()
        for cve in extracted_cves:
            invertex = set()
            if (cve.vendor_product_data is None or len(cve.vendor_product_data)==0): # and ('** REJECT' not in cve.description):
                if cve.id in processed:
                    print('cve_id(2): %s'%(cve.id))
                desc = cve.description.lower()
                if '** reject' in desc or '** disputed' in desc:
                    rejects +=1
                    continue
                continue

            processed.append(cve.id)

            # 2018-03-09T11:29:00
            invertex = invertex.union(set(cve.vendor_product_data))
            edge = Edge(invertex,
                        {"CI_%s"%cve.confidentiality_impact,  # conf_impact =
                         "AI_%s"%cve.avail_impact,            # avail_impact =
                         "II_%s"%cve.integrity_impact},       # int_impact =
                        attributes=["attack_complexity=%s"%cve.attack_complexity,
                                   "attack_vector=%s"%cve.attack_vector,
                                   "priv_required=%s"%cve.priv_required,
                                   "user_interaction=%s"%cve.user_interaction],
                        label=cve.id)

            edge_list.append(edge)
            vars = vars.union(set(cve.vendor_product_data))
            vars = vars.union({"CI_%s"%cve.confidentiality_impact})
            vars = vars.union({"AI_%s"%cve.avail_impact})
            vars = vars.union({"II_%s"%cve.integrity_impact})

            props = props.union({"attack_complexity=%s"%cve.attack_complexity})
            props = props.union({"attack_vector=%s"%cve.attack_vector})
            props = props.union({"priv_required=%s"%cve.priv_required})
            props = props.union({"user_interaction=%s"%cve.user_interaction})

        print('#vars1= %s, #props1= %s, #edges1= %s'%(len(vars),len(props),len(edge_list)))
        #generate complexity reduced, equiv metagraph
        print('generate compl reduced mg')
        group_name_index=1
        new_edge_list=[]
        new_var_set=set()
        invertex_element_group_lookup=dict()
        outvertex_element_group_lookup=dict()
        propositions_set = props

        for edge in edge_list:
            inv = list(edge.invertex.difference(propositions_set))
            outv = list(edge.outvertex.difference(propositions_set))
            for elt in inv:
                if elt not in invertex_element_group_lookup:
                    invertex_element_group_lookup[elt] = set()
                invertex_element_group_lookup[elt] = invertex_element_group_lookup[elt].union({edge.label})

            for elt in outv:
                if elt not in outvertex_element_group_lookup:
                    outvertex_element_group_lookup[elt] = set()
                outvertex_element_group_lookup[elt] = outvertex_element_group_lookup[elt].union({edge.label})

        print('step 10')

        groups_inv=dict()
        groups_outv=dict()
        group_details_lookup=dict()

        for elt, edges in invertex_element_group_lookup.iteritems():
            edge_list_string = json.dumps(list(edges))
            if edge_list_string not in groups_inv:
                groups_inv[edge_list_string]=set()
            groups_inv[edge_list_string] = groups_inv[edge_list_string].union({elt})

        for elt, edges in outvertex_element_group_lookup.iteritems():
            edge_list_string = json.dumps(list(edges))
            if edge_list_string not in groups_outv:
                groups_outv[edge_list_string]=set()
            groups_outv[edge_list_string] = groups_outv[edge_list_string].union({elt})

        print('step 11')

        for edge_list_string, elt_list in groups_inv.iteritems():
            group_elts = set(elt_list)
            if len(group_elts)>1:
                group_elts = set(elt_list)
                if len(group_elts)>1:
                    # group
                    group_elts_string = str(json.dumps(list(group_elts)))
                    #print('group_elts_string=%s'%group_elts_string)
                    if group_elts_string not in group_details_lookup:
                        group_name= 'group_%s'%group_name_index
                        group_details_lookup[group_elts_string]=group_name
                        group_name_index+=1

        for edge_list_string, elt_list in groups_outv.iteritems():
            group_elts = set(elt_list)
            if len(group_elts)>1:
                # group
                group_elts_string = str(json.dumps(list(group_elts)))
                #print('group_elts_string=%s'%group_elts_string)
                if group_elts_string not in group_details_lookup:
                    group_name= 'group_%s'%group_name_index
                    group_details_lookup[group_elts_string]=group_name
                    group_name_index+=1

        print('step 12')

        if False:
            for edge in edge_list:
                invertex_elts = list(edge.invertex.difference(propositions_set))
                outvertex_elts = list(edge.outvertex.difference(propositions_set))

                for elt in invertex_elts:
                    result= MetagraphHelper().get_associated_edges(elt, edge_list)
                    edge_list_string=repr(result)
                    print('edge_list_string= %s'%edge_list_string)
                    if edge_list_string not in invertex_element_group_lookup:
                        invertex_element_group_lookup[edge_list_string]=[]
                    if elt not in invertex_element_group_lookup[edge_list_string]:
                        invertex_element_group_lookup[edge_list_string].append(elt)

                for elt in outvertex_elts:
                    result= MetagraphHelper().get_associated_edges(elt, edge_list)
                    edge_list_string=repr(result)
                    if edge_list_string not in outvertex_element_group_lookup:
                        outvertex_element_group_lookup[edge_list_string]=[]
                    if elt not in outvertex_element_group_lookup[edge_list_string]:
                        outvertex_element_group_lookup[edge_list_string].append(elt)

            import json
            group_details_lookup=dict()

            for edge_list_string, elt_list in invertex_element_group_lookup.iteritems():
                group_elts = set(elt_list)
                if len(group_elts)>1:
                    # group
                    group_elts_string = str(json.dumps(list(group_elts)))
                    print('group_elts_string=%s'%group_elts_string)
                    if group_elts_string not in group_details_lookup:
                        group_name= 'group_%s'%group_name_index
                        group_details_lookup[group_elts_string]=group_name
                        group_name_index+=1

            for edge_list_string, elt_list in outvertex_element_group_lookup.iteritems():
                group_elts = set(elt_list)
                if len(group_elts)>1:
                    # group
                    group_elts_string = str(json.dumps(list(group_elts)))
                    print('group_elts_string=%s'%group_elts_string)
                    if group_elts_string not in group_details_lookup:
                        group_name= 'group_%s'%group_name_index
                        group_details_lookup[group_elts_string]=group_name
                        group_name_index+=1

        print('step 14')
        print('len(group_details_lookup)=%s'%(len(group_details_lookup.keys())))

        # save lookup table
        np.save('/Users/a1070571/Documents/ITS/cve_group_details_lookup.npy', group_details_lookup)
        return

        # replace original invertices with groups
        counter=1
        for edge in edge_list:
            invertex_elts = list(edge.invertex.difference(propositions_set))
            outvertex_elts = list(edge.outvertex)
            new_invertex = set()
            new_outvertex = set()

            for group_elts, group_name in group_details_lookup.iteritems():
                group_elts_list = json.loads(group_elts)
                # print('group_elts_list=%s'%group_elts_list)
                # group_elts_list = [elt2.encode('ascii', errors='backslashreplace') for elt2 in group_elts_list]
                if set(group_elts_list).issubset(set(invertex_elts)):
                    new_invertex = new_invertex.union({group_name})
                    invertex_elts = list(set(invertex_elts).difference(set(group_elts_list)))

                if set(group_elts_list).issubset(set(outvertex_elts)):
                    new_outvertex = new_outvertex.union({group_name})
                    outvertex_elts = list(set(outvertex_elts).difference(set(group_elts_list)))

                if len(invertex_elts)==0 and len(outvertex_elts)==0:
                    break

            new_invertex = new_invertex.union(set(invertex_elts))
            new_outvertex = new_outvertex.union(set(outvertex_elts))
            new_var_set = new_var_set.union(new_invertex)
            new_var_set = new_var_set.union(new_outvertex)
            new_edge_list.append(Edge(new_invertex, new_outvertex,
                                 attributes=list(edge.invertex.intersection(propositions_set)),
                                 label=edge.label))

        # create complexity reduced, equivalent metagraph
        print('#vars2= %s, #props2= %s, #edges2= %s'%(len(new_var_set),len(propositions_set),len(new_edge_list)))
        reduced_cmg= ConditionalMetagraph(new_var_set, propositions_set)
        reduced_cmg.add_edges_from(new_edge_list)

        # save mg in file (for later use)
        metagraph = dict()
        metagraph['vars'] = new_var_set
        metagraph['props'] = propositions_set
        metagraph['edges'] = new_edge_list
        # save overall metagraph for later use
        np.save('/Users/a1070571/Documents/ITS/cve_metagraph_all.npy', metagraph)
        # load metagraph
        #mg_loaded = np.load('/Users/a1070571/Documents/ITS/cve_metagraph_all.npy').item()

        source = {"juniper_junos_v14.1x53", "juniper_junos_v15.1", "juniper_junos_v15.1x53", "juniper_junos_v16.1",
                  "juniper_junos_v15.1x49", "juniper_junos_v12.3x48", "juniper_junos_v14.1", "juniper_junos_v14.2",
                  "juniper_junos_v12.1x46", "juniper_appformix_v2.7.3", "juniper_screenos_v6.3.0r23"}
        #source = {"microsoft_windows_7_v-", "microsoft_windows_server_2008_vr2", "microsoft_windows_server_2008_v-", "microsoft_windows_vista_v-"}
        #target = {"CI_NONE", "AI_HIGH", "II_NONE"}
        target = {'CI_HIGH', 'AI_HIGH', 'II_HIGH'}

        src_groups=set()
        target_groups=set()
        for elt in source:
            for key,val in group_details_lookup.iteritems():
                if elt in key:
                    src_groups = src_groups.union({val})

        for elt in target:
            for key,val in group_details_lookup.iteritems():
                if elt in key:
                    target_groups = target_groups.union({val})

        modified_source = src_groups
        modified_target = target_groups
        # print('modified_source= %s, modified_target= %s'%(modified_source, target))
        # src = {'juniper_junos_v12.3', 'juniper_junos_v15.1', 'group_94', 'group_216', 'group_43'} # CVE-2018-0001
        # src = {'group_3', 'juniper_junos_v15.1', 'group_6', 'group_5', 'juniper_junos_v12.3'}
        #src = set(['group_119', 'juniper_junos_v12.3', 'juniper_junos_v15.1', 'group_203', 'group_82'])
        src = {'oracle_mysql_v5.5.54', 'group_1386', 'group_1449'} #{'oracle_solaris_v11.3'} # {'oracle_mysql_v5.5.54', 'group_1386', 'group_1449'}
        target = {'II_NONE', 'AI_HIGH', 'CI_NONE'} #{'AI_NONE', 'CI_NONE', 'II_LOW'} # 'II_NONE', 'AI_HIGH', 'CI_NONE'

        print('get metapaths..')
        #mps = reduced_cmg.get_all_metapaths_from(src, target,include_propositions=True) #modified_source
        #for mp in mps:
        #    if reduced_cmg.is_edge_dominant_metapath(mp): #is_edge_dominant_metapath
        #        print('metapath:')
        #        for edge in mp.edge_list:
        #            print('CVE: %s'%edge.label)

        #print('done')
        # build CMG of cves
        # lookup related CVEs for a fresh one (eg use exploitability metrics, vendor, product details and impact metrics)
        # for each related CVE found look at the CVE life cycle/state MG and find applicable time values (eg for patch release, poc exploit etc)
        # compute potential time values for fresh CVE based on these findings (eg using average etc)
        print('test')

    def test_cve_data5(self):
        import numpy as np
        return

        # load metagraph
        mg_loaded = np.load('/Users/a1070571/Documents/ITS/cve_metagraph_all.npy').item()
        propositions = mg_loaded['props']
        vars = mg_loaded['vars']
        edge_list = mg_loaded['edges']

        print('here1')
        cmg = ConditionalMetagraph(vars,propositions)
        print('here2')
        cmg.add_edges_from(edge_list[0:10])
        print('here3')

        #source = {"juniper_junos_v14.1x53", "juniper_junos_v15.1", "juniper_junos_v15.1x53", "juniper_junos_v16.1",
        #          "juniper_junos_v15.1x49", "juniper_junos_v12.3x48", "juniper_junos_v14.1", "juniper_junos_v14.2",
        #          "juniper_junos_v12.1x46", "juniper_appformix_v2.7.3", "juniper_screenos_v6.3.0r23"}
        # target = {"CI_NONE", "AI_HIGH", "II_NONE"}
        # target = {'CI_HIGH', 'AI_HIGH', 'II_HIGH'}

        source = {'adium_adium_v1.3.8', 'pidgin_pidgin_v2.6.4'}
        target = {'group_11828'}
        src_groups=set()
        target_groups=set()

        '''
        for elt in source:
            for key,val in group_details_lookup.iteritems():
                if elt in key:
                    src_groups = src_groups.union({val})

        for elt in target:
            for key,val in group_details_lookup.iteritems():
                if elt in key:
                    target_groups = target_groups.union({val})'''

        #modified_source = src_groups
        #modified_target = target_groups
        # print('modified_source= %s, modified_target= %s'%(modified_source, target))
        # src = {'juniper_junos_v12.3', 'juniper_junos_v15.1', 'group_94', 'group_216', 'group_43'} # CVE-2018-0001
        # src = {'group_3', 'juniper_junos_v15.1', 'group_6', 'group_5', 'juniper_junos_v12.3'}
        #src = set(['group_119', 'juniper_junos_v12.3', 'juniper_junos_v15.1', 'group_203', 'group_82'])
        #src = {'oracle_mysql_v5.5.54', 'group_1386', 'group_1449'} #{'oracle_solaris_v11.3'} # {'oracle_mysql_v5.5.54', 'group_1386', 'group_1449'}
        #target = {'II_NONE', 'AI_HIGH', 'CI_NONE'} #{'AI_NONE', 'CI_NONE', 'II_LOW'} # 'II_NONE', 'AI_HIGH', 'CI_NONE'

        print('get metapaths..')
        mps = cmg.get_all_metapaths_from(source, target,include_propositions=True)
        print('here2')

    def test_exploit_db(self):
        import json
        from datetime import datetime
        from collections import Counter
        from mgtoolkit.library import CVE
        import matplotlib.pyplot as plt
        import numpy as np
        import collections
        import xmltodict
        return

        json_file = "/Users/a1070571/Documents/ITS/cvrf.json"
        xml_file = "/Users/a1070571/Documents/ITS/cvrf.xml"

        if False:
            # xml to json

            print('s1')
            with open(xml_file, 'r') as f:
                xmlString = f.read()

            print('s2')
            jsonString = json.dumps(xmltodict.parse(xmlString), indent=4)

            print('s3')
            with open(json_file, 'w') as f:
                f.write(jsonString)

            print('test')

        #return
        cve_expolit_lookup=dict()
        filename= "/Users/a1070571/Documents/ITS/exploit_db.json"
        extracted = None
        with open(filename) as json_data:
            extracted = json.load(json_data)

        for exploit in extracted:
            cve_id = exploit['cve']
            exploit_date = datetime.fromtimestamp(int(exploit['exploit_published_date']))
            if cve_id not in cve_expolit_lookup:
                cve_expolit_lookup[cve_id] = exploit_date
            else:
                # retain the oldest date (ie first exploit date)
                if exploit_date<cve_expolit_lookup[cve_id]:
                    cve_expolit_lookup[cve_id] = exploit_date

        #extracted1 = None
        #with open(json_file) as json_data:
        #    extracted1 = json.load(json_data)
        #extracted1['cvrfdoc']['Vulnerability'][100]

        folder = "/Users/a1070571/Documents/ITS/cve"
        #filename2= "/Users/a1070571/Documents/ITS/nvdcve-1.0-2017.json"

        import os
        root, dirs, files = next(os.walk(folder))
        cve_lookup = dict()
        days_to_exploit = dict()
        delay_counters = dict()
        delay_counters2 = dict()
        delay_counters3 = dict()
        avg_delay_to_exploit = dict()
        processed=[]
        user_int_none=0

        for file in files:
            #if file != 'nvdcve-1.0-2017.json': continue
            print('processing file: %s'%file)
            extracted2 = None
            filename2 = "/Users/a1070571/Documents/ITS/%s"%file
            with open(filename2) as json_data:
                extracted2 = json.load(json_data)

            entries = extracted2['CVE_Items']
            for cve in entries:
                cve_id = cve['cve']['CVE_data_meta']['ID']
                published_date = self.get_date_time(cve['publishedDate'])
                lastmod_date = self.get_date_time(cve['lastModifiedDate'])
                cve_entry = CVE(cve_id, None, lastmod_date, published_date, None, None)

                # CVSS metrics: AC, AV, CI, II, AI
                if 'impact' in cve and \
                   'baseMetricV3' in cve['impact']:
                    cve_entry.exp_score = cve['impact']['baseMetricV3']['exploitabilityScore']
                    cve_entry.impact_score = cve['impact']['baseMetricV3']['impactScore']
                    cvss_v3 = cve['impact']['baseMetricV3']['cvssV3']
                    cve_entry.attack_complexity = str(cvss_v3['attackComplexity'])
                    cve_entry.attack_vector = str(cvss_v3['attackVector'])
                    cve_entry.priv_required = str(cvss_v3['privilegesRequired'])
                    cve_entry.scope = str(cvss_v3['scope']) #whats this?
                    cve_entry.user_interaction = str(cvss_v3['userInteraction'])
                    cve_entry.avail_impact = str(cvss_v3['availabilityImpact'])
                    cve_entry.confidentiality_impact = str(cvss_v3['confidentialityImpact'])
                    cve_entry.integrity_impact = str(cvss_v3['integrityImpact'])
                    cve_entry.base_score = float(cvss_v3['baseScore'])
                    cve_entry.base_severity = cvss_v3['baseSeverity']

                elif 'impact' in cve and \
                   'baseMetricV2' in cve['impact'] and \
                    'cvssV2' in cve['impact']['baseMetricV2']:
                    self.populate_cvss3_data(cve, cve_entry)
                    #continue

                cve_lookup[cve_id] = cve_entry #published_date

            # generic exploit delay (for all cves)
            #for cve_id, entry in cve_lookup.iteritems():
            #    if cve_id in cve_expolit_lookup:
            #        exploited = cve_expolit_lookup[cve_id]
            #        delay = (exploited - entry.published).days
            #        if delay < (-2000):
            #            print('cve= %s'%cve_id)
            #        days_to_exploit[cve_id]= delay
            #        if delay not in delay_counters:
            #            delay_counters[delay]=0
            #        delay_counters[delay] +=1

            # delay by CVSS score
            # for cve_id, entry in cve_lookup.iteritems():
            #    if cve_id in cve_expolit_lookup:
            #        exploited = cve_expolit_lookup[cve_id]
            #        delay = (exploited - entry.published).days
            #        if entry.base_score is not None:
            #            if entry.base_score not in days_to_exploit:
            #               days_to_exploit[entry.base_score]= []
            #            days_to_exploit[entry.base_score].append(delay)

            # for score, delays in days_to_exploit.iteritems():
            #    avg_delay =  sum(delays)/len(delays)
            #    avg_delay_to_exploit[score] = avg_delay

            # delay by attack complexity
            for cve_id, entry in cve_lookup.iteritems():
                identifier = cve_id
                if identifier in processed: continue
                if identifier in cve_expolit_lookup:
                    exploited = cve_expolit_lookup[identifier]
                    delay = (exploited - entry.published).days
                    #if delay>2000:
                    #    print('cve=%s'%identifier)
                    if delay<0 and entry.priv_required=='NONE':  #entry.attack_complexity=='HIGH' and entry.attack_vector == 'NETWORK' and entry.priv_required == 'LOW':
                        user_int_none +=1
                        if delay not in delay_counters:
                            delay_counters[delay]=0
                        delay_counters[delay] +=1
                    #if delay>=0 and entry.attack_complexity=='HIGH': #and entry.attack_vector == 'LOCAL' and entry.priv_required == 'HIGH'
                    #    if delay not in delay_counters2:
                    #        delay_counters2[delay]=0
                    #    delay_counters2[delay] +=1
                    processed.append(identifier)

            # delay by attack vector
            '''
            for cve_id, entry in cve_lookup.iteritems():
                if cve_id in processed: continue
                if cve_id in cve_expolit_lookup:
                    exploited = cve_expolit_lookup[cve_id]
                    delay = (exploited - entry.published).days
                    if delay>250:
                        print('cve=%s'%cve_id)
                    if entry.attack_vector == 'LOCAL': # NETWORK, LOCAL, ADJACENT, PHYSICAL
                        if delay not in delay_counters:
                            delay_counters[delay]=0
                        delay_counters[delay] +=1
                    if entry.attack_vector == 'NETWORK': # NETWORK, LOCAL, ADJACENT, PHYSICAL
                        if delay not in delay_counters2:
                            delay_counters2[delay]=0
                        delay_counters2[delay] +=1
                    processed.append(cve_id)'''


            # delay by privileges required
            #for cve_id, entry in cve_lookup.iteritems():
            #    if cve_id in cve_expolit_lookup:
            #        exploited = cve_expolit_lookup[cve_id]
            #        delay = (exploited - entry.published).days
            #        if entry.priv_required == 'HIGH': # LOW, HIGH, NONE # check HIGH
            #            if delay not in delay_counters:
            #                delay_counters[delay]=0
            #            delay_counters[delay] +=1

            # delay by user interaction
            #for cve_id, entry in cve_lookup.iteritems():
            #    if cve_id in cve_expolit_lookup:
            #        exploited = cve_expolit_lookup[cve_id]
            #        delay = (exploited - entry.published).days
            #        if entry.user_interaction == 'NONE': # REQUIRED, NONE
            #            if delay not in delay_counters:
            #                delay_counters[delay]=0
            #            delay_counters[delay] +=1

            # delay by CI
            '''
            for cve_id, entry in cve_lookup.iteritems():
                if cve_id in processed: continue
                if cve_id in cve_expolit_lookup:
                    exploited = cve_expolit_lookup[cve_id]
                    delay = (exploited - entry.published).days
                    #if delay > 500: continue
                    if entry.confidentiality_impact == 'NONE': # LOW, HIGH, NONE
                        if delay not in delay_counters:
                            delay_counters[delay]=0
                        delay_counters[delay] +=1

                    elif entry.confidentiality_impact == 'LOW': # LOW, HIGH, NONE
                        if delay not in delay_counters2:
                            delay_counters2[delay]=0
                        delay_counters2[delay] +=1

                    elif entry.confidentiality_impact == 'HIGH': # LOW, HIGH, NONE
                        if delay not in delay_counters3:
                            delay_counters3[delay]=0
                        delay_counters3[delay] +=1
                    processed.append(cve_id)'''

            # delay by AI
            #for cve_id, entry in cve_lookup.iteritems():
            #    if cve_id in cve_expolit_lookup:
            #        exploited = cve_expolit_lookup[cve_id]
            #        delay = (exploited - entry.published).days
            #        if entry.avail_impact == 'NONE': # LOW, HIGH, NONE
            #            if delay not in delay_counters:
            #               delay_counters[delay]=0
            #            delay_counters[delay] +=1

            # delay by II
            #for cve_id, entry in cve_lookup.iteritems():
            #    if cve_id in cve_expolit_lookup:
            #        exploited = cve_expolit_lookup[cve_id]
            #        delay = (exploited - entry.published).days
            #        if entry.integrity_impact == 'NONE': # LOW, HIGH, NONE
            #            if delay not in delay_counters:
            #                delay_counters[delay]=0
            #            delay_counters[delay] +=1

        # find total entries
        #total=0
        #for key, val in delay_counters.iteritems():
        #    total = total+val
        #print('total count= %s'%total)

        print('user_int_none: %s'%user_int_none)
        return

        # order the dict
        #delay_counters_ord = collections.OrderedDict(sorted(delay_counters.items())) # delay_counters, avg_delay_to_exploit
        #delay_counters_ord2 = collections.OrderedDict(sorted(delay_counters2.items())) # delay_counters, avg_delay_to_exploit
        #delay_counters_ord3 = collections.OrderedDict(sorted(delay_counters3.items())) # delay_counters, avg_delay_to_exploit
        # combined = dict(Counter(delay_2018)+Counter(delay_2017)+Counter(delay_2016)+Counter(delay_2015)
        # +Counter(delay_2014)+Counter(delay_2013)+Counter(delay_2012)+Counter(delay_2011)+Counter(delay_2010))

        # CDF
        delay_cdf=dict()
        prev_key=None
        for key, val in delay_counters_ord.iteritems():
            if key>0:
                delay_cdf[key]= delay_cdf[prev_key]+val
            else:
                delay_cdf[key]=val
            prev_key=key

        '''
        delay_cdf2=dict()
        prev_key2=None
        for key, val in delay_counters_ord2.iteritems():
            if key>0:
                delay_cdf2[key]= delay_cdf2[prev_key2]+val
            else:
                delay_cdf2[key]=val
            prev_key2=key

        delay_cdf3=dict()
        prev_key3=None
        for key, val in delay_counters_ord3.iteritems():
            if key>0:
                delay_cdf3[key]= delay_cdf3[prev_key3]+val
            else:
                delay_cdf3[key]=val
            prev_key3=key'''

        delay_cdf_ord = collections.OrderedDict(sorted(delay_cdf.items()))      # delay_counters, avg_delay_to_exploit
        # delay_cdf_ord2 = collections.OrderedDict(sorted(delay_cdf2.items()))  # delay_counters, avg_delay_to_exploit
        # delay_cdf_ord3 = collections.OrderedDict(sorted(delay_cdf3.items()))  # delay_counters, avg_delay_to_exploit
        # delay_counters_ord = collections.OrderedDict(sorted(delay_counters_ord.items())) # delay_counters, avg_delay_to_exploit

        # major_ticks = np.arange(-2000, 2600, 200) # generic delay
        # major_ticks = np.arange(0, 10.5, 0.5)     # cvss3 score
        # major_ticks = np.arange(-200, 200, 10)    # AC
        # major_ticks = np.arange(-200, 400, 10)    # generic delay
        major_ticks = np.arange(0, 1000, 100)       # generic delay
        fig = plt.figure()
        ax = fig.add_subplot(1, 1, 1)
        ax.set_xticks(major_ticks)
        plt.plot(delay_cdf_ord.keys(), delay_cdf_ord.values())     # delay_counters_ord delay_cdf_ord
        # plt.plot(delay_cdf_ord2.keys(), delay_cdf_ord2.values()) # delay_counters_ord delay_cdf_ord
        # plt.plot(delay_cdf_ord3.keys(), delay_cdf_ord3.values()) # delay_counters_ord delay_cdf_ord

        # plt.axis([-2000, 2600, 0, 2000]) # generic delay
        # plt.axis([0, 10.5, -1250, 200]) # cvss3 score
        # plt.axis([-2000, 2600, 0, 5000])
        # plt.axis([-200, 400, 0, 1500])
        plt.axis([0, 1000, 0, 50]) # generic delay
        plt.show()

        #extracted[0:100]
        #extracted[0]
        #datetime.fromtimestamp(int(extracted[0]['exploit_published_date'])) #.day, .month, .year
        print('test')

    def test_course_data(self):
        return

        courses = ['x','y','z','a','b','c']
        props = ['level=ug','faculty=ecms', 'campus=north tce','mode=internal','exchange=false', 'enrolment_limit=1000',
                 'weight=3', 'offering=sem1',  'wnf_date=30/5/2018', 'cost=2500', 'enrolment_limit=500', 'enrolment_limit=800',
                 'weight=4', 'offering=sem2', 'cost=3000', 'enrolment_limit=800', 'cost=2200',
                 'weight=5', 'cost=2000']
        edge_list = [ Edge({'x'}, {'y'}, attributes=['level=ug','faculty=ecms', 'campus=north tce',
                                                     'mode=internal','exchange=false', 'enrolment_limit=1000',
                                                     'weight=3', 'offering=sem1',  'wnf_date=30/5/2018', 'cost=2500']),
                      Edge({'y', 'b'}, {'z'}, attributes=['level=ug','faculty=ecms', 'campus=north tce',
                                                          'mode=internal','exchange=false', 'enrolment_limit=500', 'enrolment_limit=800', # b.enrolment_limit=800, b.weight=5, b.offering=sem1, b.cost=2000
                                                          'weight=4', 'weight=5', 'offering=sem2','offering=sem1', 'wnf_date=30/5/2018', 'cost=3000', 'cost=2000'])
                    ]
        '''
        Edge({'x'},{'y'},attributes=['level=ug','faculty=ecms', 'campus=north tce',
                                                  'mode=internal','exchange=false', 'enrolment_limit=1000',
                                                  'weight=3', 'offering=sem1',  'wnf_date=30/5/2018', 'cost=2500']),
        Edge({'y'},{'z'},attributes=['level=ug','faculty=ecms', 'campus=north tce',
                                                  'mode=internal','exchange=false', 'enrolment_limit=500',
                                                  'weight=4', 'offering=sem2',  'wnf_date=30/5/2018', 'cost=3000']),
        Edge({'z'},{'a'},attributes=['level=ug','faculty=ecms', 'campus=north tce',
                                                  'mode=internal','exchange=false', 'enrolment_limit=800',
                                                  'weight=3', 'offering=sem1',  'wnf_date=30/5/2018', 'cost=2200']),

        Edge({'x'}, {'y','b'}, attributes=['level=ug','faculty=ecms', 'campus=north tce',
                                           'mode=internal','exchange=false', 'enrolment_limit=1000',
                                           'weight=3', 'offering=sem1',  'wnf_date=30/5/2018', 'cost=2500']),
        Edge({'y'}, {'z'}, attributes=['level=ug','faculty=ecms', 'campus=north tce',
                                       'mode=internal','exchange=false', 'enrolment_limit=500',
                                       'weight=4', 'offering=sem2',  'wnf_date=30/5/2018', 'cost=3000'])'''

        cmg = ConditionalMetagraph(set(courses), set(props))
        cmg.add_edges_from(edge_list)

        source = {'x', 'b'}
        target = {'z'} # a
        mps = cmg.get_all_metapaths_from(source, target, include_propositions=True)
        for mp in mps:
            crit_courses=set()
            course_attr=dict()
            if cmg.is_edge_dominant_metapath(mp):
                # identify critical courses
                for edge in mp.edge_list:
                    inv = edge.invertex.difference(edge.attributes)
                    outv = edge.outvertex
                    if len({'x'}.intersection(inv))==0 and len(target.intersection(inv))==0:
                        crit_courses = crit_courses.union(inv)
                        course_attr[str(inv)] = edge.attributes
                    # if len(source.intersection(outv))==0 and len(target.intersection(outv))==0:
                    #   crit_courses = crit_courses.union(outv)

        # working with node attrs (ie course attrs)
        # option 1: keep each course's attr separate (ie each gen. set elt is a composite object of course+attrs)
        # option 2: share course attrs on edge (ie each edge comprises of attrs appliable to one or more courses)
        #           => does not capture situation well?
        #
        print('here')

        #1. context: level, faculty, school, campus,
        #2. availability: mode, study abroad/exchange, non award, enrolment limit
        #3. impact: weight
        #4. schedule: offering, contact hrs, census date, WNF date, WF date, class schedule
        #5. cost: fees
        #6. requirements: pre-reqs, assumed K

        return

    def test_dist1(self):
        from scipy.stats import norm
        import matplotlib.pyplot as plt
        import numpy as np
        return

        # Generate an array of 200 random sample from a normal dist with
        # mean 0 and stdv 1
        # random_sample = norm.rvs(loc=0,scale=1,size=10)
        #l = random_sample.tolist()
        #data = [(-40,10),(-30,70),(-20,45),(-10,85),(0,100),(10,90),(20,50),(30,60),(40,20)]
        data = [(-40,10),(-30,20),(-20,45),(-10,85),(0,100),(10,90),(20,50),(30,20),(40,12)]
        word, frequency = zip(*data)
        indices = np.arange(len(data))

        # Distribution fitting
        # norm.fit(data) returns a list of two parameters
        # (mean, parameters[0] and std, parameters[1]) via a MLE approach
        # to data, which should be in array form.
        parameters = norm.fit(data) #(random_sample) data

        # now, parameters[0] and parameters[1] are the mean and
        # the standard deviation of the fitted distribution
        x = np.linspace(-40,40,100) #(-40,40,10)

        # Generate the pdf (fitted distribution)
        fitted_pdf = norm.pdf(x,loc = parameters[0],scale = parameters[1])
        # Generate the pdf (normal distribution non fitted)
        #normal_pdf = norm.pdf(x)

        # Type help(plot) for a ton of information on pyplot
        plt.plot(x,fitted_pdf,"red",label="Fitted normal dist",linestyle="dashed", linewidth=2)
        #plt.plot(x,normal_pdf,"blue",label="Normal dist", linewidth=2)
        # t = plt.bar(indices, frequency, color='b')

        plt.hist(data)#normed=1 (indices, frequency)#(data, normed=1) #,normed=1,color="cyan",alpha=.3) #alpha, from 0 (transparent) to 1 (opaque) #random_sample data
        #plt.title("Normal distribution fitting")
        # insert a legend in the plot (using label)
        #plt.legend()

        # we finally show our work
        plt.show()

    def test_dist2(self):
        import matplotlib.pyplot as plt
        from numpy.random import normal
        return

        gaussian_numbers = normal(size=10)
        #c = gaussian_numbers.tolist()
        #c[0:100]
        plt.hist(gaussian_numbers)
        plt.title("Gaussian Histogram")
        plt.xlabel("Value")
        plt.ylabel("Frequency")
        plt.show()

        if False:
            import numpy as np
            import random
            from matplotlib import pyplot as plt

            data = [0,1,2,3,4,5,6,7,8,9] #np.random.normal(0, 20, 1000)
            # fixed bin size
            # bins = np.arange(-100, 100, 5)
            bins = np.arange(0, 10, 1)
            plt.xlim([min(data)-1, max(data)+1])
            plt.hist(data, bins=bins, alpha=0.5)
            #plt.title('Random Gaussian data (fixed bin size)')
            #plt.xlabel('variable X (bin size = 5)')
            plt.ylabel('count')
            plt.show()

    def test_dist(self):
        import numpy as np
        import matplotlib.pyplot as plt
        return

        #example_list = [('dhr', 17838), ('mw', 13675), ('wel', 5499), ('goed', 5080),
        #        ('contact', 4506), ('medicatie', 3797), ('uur', 3792),
        #        ('gaan', 3473), ('kwam', 3463), ('kamer', 3447),
        #        ('mee', 3278), ('gesprek', 2978)]

        example_list = [(-40,10),(-30,70),(-20,45),(-10,85),(0,100),(10,90),(20,50),(30,60),(40,20)]
        word, frequency = zip(*example_list)
        indices = np.arange(len(example_list))
        plt.bar(indices, frequency, color='r')
        plt.xticks(indices, word, rotation='vertical')
        plt.tight_layout()
        plt.show()

    def populate_cvss3_data(self, cve, cve_entry):
        cve_entry.exp_score = cve['impact']['baseMetricV2']['exploitabilityScore']
        cve_entry.impact_score = cve['impact']['baseMetricV2']['impactScore']
        cve_entry.base_score = cve['impact']['baseMetricV2']['cvssV2']['baseScore']

        # convert CVSS2 to CVSS3
        cve_entry.attack_vector = cve['impact']['baseMetricV2']['cvssV2']['accessVector']
        auth = cve['impact']['baseMetricV2']['cvssV2']['authentication']
        if auth.lower()=='single':
            cve_entry.priv_required = 'LOW'
        elif auth.lower()=='multiple':
            cve_entry.priv_required = 'HIGH'
        else:
            cve_entry.priv_required = 'NONE'

        ac = cve['impact']['baseMetricV2']['cvssV2']['accessComplexity']
        if ac.lower()=='low':
            cve_entry.attack_complexity = 'LOW'
            cve_entry.user_interaction = 'NONE'
        else:
            # medium/high both map to high
            cve_entry.attack_complexity = 'HIGH'
            # TODO: check this - med/high access comp may not always mean
            # some user interaction is required for attack to succeed
            cve_entry.user_interaction ='REQUIRED'

        ci = cve['impact']['baseMetricV2']['cvssV2']['confidentialityImpact']
        if ci.lower() == 'partial':
            cve_entry.confidentiality_impact = 'LOW'
        elif ci.lower() == 'complete':
            cve_entry.confidentiality_impact = 'HIGH'
        else:
            cve_entry.confidentiality_impact = 'NONE'

        ai = cve['impact']['baseMetricV2']['cvssV2']['availabilityImpact']
        if ai.lower() == 'partial':
            cve_entry.avail_impact = 'LOW'
        elif ai.lower() == 'complete':
            cve_entry.avail_impact = 'HIGH'
        else:
            cve_entry.avail_impact = 'NONE'

        ii = cve['impact']['baseMetricV2']['cvssV2']['integrityImpact']
        if ii.lower() == 'partial':
            cve_entry.integrity_impact = 'LOW'
        elif ii.lower() == 'complete':
            cve_entry.integrity_impact = 'HIGH'
        else:
            cve_entry.integrity_impact = 'NONE'

        if cve_entry.confidentiality_impact=='HIGH' and \
           cve_entry.integrity_impact=='HIGH' and \
           cve_entry.avail_impact=='HIGH':
               cve_entry.scope = 'CHANGED'
        else:
            cve_entry.scope = 'UNCHANGED'

    def get_date_time(self, date_time_string):
        from datetime import datetime
        # 2018-03-09T11:29:00
        date_time_string = date_time_string.replace('T',' ')
        date_time_string = date_time_string.replace('Z','')
        date = datetime.strptime(date_time_string, '%Y-%m-%d %H:%M')
        return date.date()

    def get_date_time2(self, date_time_string):
        from datetime import datetime
        # 3/20/2017 9:23:46 AM
        date = date_time_string.split(' ')[0]
        date = datetime.strptime(date, '%m/%d/%Y')  # %H:%M %S
        return date.date()

    def get_subdict(self, source_dict):
        length = len(source_dict.keys())
        subdict = dict()
        keys = source_dict.keys()[0: length-4000]
        for key in keys:
            subdict[key] = source_dict[key]

        return subdict

    def test_draw_chart1(self):
        import matplotlib.pyplot as plt
        import numpy as np
        return

        import plotly
        plotly.tools.set_credentials_file(username='dineshar1979', api_key='N4aNtgsyq9foh19YOuMs')
        import plotly.plotly as py
        import plotly.tools as tls

        # Learn about API authentication here: https://plot.ly/python/getting-started
        # Find your api_key here: https://plot.ly/settings/api

        mpl_fig = plt.figure()
        ax = mpl_fig.add_subplot(111)

        N = 5
        Vendor1 = (0,1,3,1,35, 110, 87, 112, 84)
        Vendor2 = (0,0,1,1,12, 11, 14, 68, 68)
        Vendor3 = (0,0,1,1,7, 8, 4, 37, 40)
        OtherVendor = (0,0,2,2,54, 43, 31, 448, 759)

        width=1/1.5
        ind = [2010,2011,2012,2013,2014,2015,2016,2017,2018] # np.arange(N)  #the x locations for the groups

        p1 = ax.bar(ind, Vendor1, width, color=(0.2588,0.4433,1.0))
        p2 = ax.bar(ind, Vendor2, width, color=(1.0,0.5,0.62),
                     bottom=Vendor1)
        p3 = ax.bar(ind, Vendor3, width, color=(1.0,0.0,0.0),
                     bottom=Vendor2)
        p4 = ax.bar(ind, OtherVendor, width, color=(0.0,1.0,0.0),
                     bottom=Vendor3)

        ax.set_ylabel('#Under-populated CVEs')
        ax.set_xlabel('Year')
        ax.set_title('#Under-populated CVEs by year')

        ax.set_xticks(ind)
        ax.set_yticks(np.arange(0, 1100, 100))
        ax.set_xticklabels(('2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018'))

        plotly_fig = tls.mpl_to_plotly( mpl_fig )

        # For Legend
        plotly_fig["layout"]["showlegend"] = True
        plotly_fig["data"][0]["name"] = "Vendor1"
        plotly_fig["data"][1]["name"] = "Vendor2"
        plotly_fig["data"][2]["name"] = "Vendor3"
        plotly_fig["data"][3]["name"] = "Other Vendors"

        import os
        plot_url = py.plot(plotly_fig, filename='stacked-bar-chart')
        print('test')

    def test_draw_chart2(self):
        import plotly
        return
        plotly.tools.set_credentials_file(username='dineshar1979', api_key='N4aNtgsyq9foh19YOuMs')

        import matplotlib.pyplot as plt
        from matplotlib.dates import date2num
        import datetime
        import plotly.plotly as py

        multiple_bars = plt.figure()
        x = [datetime.datetime(2011, 1, 4, 0, 0),
             datetime.datetime(2011, 1, 5, 0, 0),
             datetime.datetime(2011, 1, 6, 0, 0)]
        x = date2num(x)

        from numpy import array
        x = array([2010,2011,2012,2013,2014,2015,2016,2017,2018])
        # x = [2010,2011,2012,2013,2014,2015,2016,2017,2018]

        y = [0,1,3,1,35, 110, 87, 112, 84]
        z = [0,0,1,1,12, 11, 14, 68, 68]
        k = [0,0,1,1,7, 8, 4, 37, 40]

        ax = plt.subplot(111)
        ax.bar(x-0.2, y,width=0.2,color='b',align='center')
        ax.bar(x, z,width=0.2,color='g',align='center')
        ax.bar(x+0.2, k,width=0.2,color='r',align='center')
        #ax.xaxis_date()

        plt.show()

        #plot_url = py.plot_mpl(multiple_bars, filename='mpl-multiple-bars')
        print('test')

    '''
    def test_mg_creation1(self):
        variable_set = {'students','staff','internet','dmz'}
        propositions_set = {'protocol=tcp', 'dest_port=80', 'malware_sigs=[wildfire_sigs]', 'malware_sigs=[pa_sigs,wildfire_sigs]', 'sig_present=true', 'sig_present=false', 'action=permit', 'action=deny', 'action=alert'}
        cm = ConditionalMetagraph(variable_set, propositions_set)

        cm.add_edges_from([
        Edge({'students'}, {'internet'}, attributes=['protocol=tcp', 'dest_port=80', 'malware_sigs=[wildfire_sigs]', 'sig_present=true', 'action=deny']),
        Edge({'students'}, {'internet'}, attributes=['protocol=tcp', 'dest_port=80', 'malware_sigs=[wildfire_sigs]', 'sig_present=false', 'action=permit']),

        Edge({'students'}, {'internet'}, attributes=['protocol=tcp', 'dest_port=80', 'malware_sigs=[pa_sigs,wildfire_sigs]', 'sig_present=true', 'action=alert']),
        Edge({'students'}, {'internet'}, attributes=['protocol=tcp', 'dest_port=80', 'malware_sigs=[pa_sigs,wildfire_sigs]', 'sig_present=false', 'action=permit'])])

        # check for conflicts
        mps = cm.get_all_metapaths_from({'students'}, {'internet'})
        for mp in mps:
          if cm.has_conflicts(mp):
             print('conflict detected: %s'%(repr(mp.edge_list)))

    def test_mg_creation(self):
        generating_set={'u1', 'u2', 'r1','r2','r3', 'r4'} #
        mg = Metagraph(generating_set)
        mg.add_edges_from([
            Edge({'u1','u2'},{'r1','r2'}),
            Edge({'u1','u2'},{'r3'}),
            Edge({'r2','r3'},{'r4'})])

        mps = mg.get_all_metapaths_from({'u1','u2'},{'r4'})
        subset={'u1','u2', 'r4'}
        p = mg.get_projection(subset)
        print('done')


    def test_cutsets(self):
        #generator_set = {'u1', 'u2', 'u3', 'r3', 'r4', 'r5', 'r6', 'r7', 'r8', 'r9'}
        #mg5 = Metagraph(generator_set)
        #mg5.add_edge(Edge({'u1','u2'},{'r3','r4'}))
        #mg5.add_edge(Edge({'r3'},{'r5','r6'}))
        #mg5.add_edge(Edge({'r6'},{'r7'}))
        #mg5.add_edge(Edge({'r7','r9'},{'r8'}))
        #mg5.add_edge(Edge({'u1','u2','u3'},{'r8'}))

        #generator_set = {'u1', 'u2', 'r3', 'r5', 'r6', 'r7'}
        #mg5 = Metagraph(generator_set)
        #mg5.add_edge(Edge({'u1','u2'},{'r3'}))
        #mg5.add_edge(Edge({'r3'},{'r5','r6'}))
        #mg5.add_edge(Edge({'r6'},{'r7'}))
        #mg5.add_edge(Edge({'u1','u2'},{'r5'}))

        #source = {'u1', 'u2'}
        #target = {'r7'}
        #metapaths = mg5.get_all_metapaths_from(source, target)
        #edge_list = []
        #edge_list.append(Edge({'u1','u2'},{'r3'}))
        #edge_list.append(Edge({'r3'},{'r5','r6'}))
        #edge_list.append(Edge({'u1','u2'},{'r5'}))
        #edge_list.append(Edge({'r6'},{'r7'}))

        # mg5.is_cutset(edge_list,source,target)
        #result = mg5.is_bridge(edge_list,source,target)
        #print('test')

        # define policy metagraph
        generating_set = {'u1','r1','r2','r3','r4'}
        mg = Metagraph(generating_set)
        mg.add_edges_from([
         Edge({'u1'}, {'r1','r2'}, label='e1'),
         Edge({'u1'}, {'r3'}, label='e2'),
         Edge({'r2','r3'}, {'r4'}, label='e3') ])

        # compute metapaths
        source={'u1'}
        target={'r4'}
        metapaths = mg.get_all_metapaths_from(source, target)
        for metapath in metapaths:
          print('%s'%(repr(metapath.edge_list)))
        print('test')

    def test_error(self):
        from itertools import combinations
        return
        generating_set = {'Disclosed', 'PoC Exploit', 'Patch Released', 'Exploit Seen in Real World', 'Merged into MetaSploit'}
        mg = Metagraph(generating_set)
        mg.add_edges_from([Edge({'Disclosed'}, {'Exploit Seen in Real World', 'Patch Released', 'PoC Exploit'}),
                           Edge({'PoC Exploit'}, {'Patch Released'}), Edge({'Patch Released'}, {'PoC Exploit'}),
                           Edge({'Patch Released'}, {'Exploit Seen in Real World'}),
                           Edge({'Exploit Seen in Real World'}, {'PoC Exploit'}),
                           Edge({'Patch Released', 'Exploit Seen in Real World'}, {'Merged into MetaSploit'}),
                           Edge({'Merged into MetaSploit'}, {'Patch Released'})])

        metapaths_disclosure_poc = mg.get_all_metapaths_from({'Disclosed'}, {'PoC Exploit'})
        filepath='/Users/a1070571/Documents/ITS/mg_view.dot'
        MetagraphHelper().generate_visualisation(mg.edges,filepath)# ,display_attributes=False, use_temp_label=True)

        for mp in metapaths_disclosure_poc:
            if mg.is_dominant_metapath(mp):
               print('dom mp: %s'%mp.edge_list)

        for i, j in combinations(range(len(metapaths_disclosure_poc)), 2):
            #print('{} {}'.format(i,j))
            print('mp1: (%s, %s)'%(str(metapaths_disclosure_poc[i].source), str(metapaths_disclosure_poc[i].target)))
            print('mp2: (%s, %s)'%(str(metapaths_disclosure_poc[j].source), str(metapaths_disclosure_poc[j].target)))
            print(metapaths_disclosure_poc[i].dominates(metapaths_disclosure_poc[j]))

        # dominant metapath vs metapath that dominates another:: diff concepts
        # DM - no redundant edges or input-elts
        # MP that dominates - M(B,C) dominates M(B',C') if B<=B', C'<=C
        #  - helps to evaluate when metagraphs are equivalent (ie need not be identical)
        #  - equivalence informs us if mgs can be integrated while preserving computations
        # M(B,C) = {e1,e2} where B = {1,2}, C={3,4}
        # M(B',C') = {e3,e4} where B'={1,2,5}, C'={3}

        #proj = mg.get_projection({'Disclosed', 'Exploit Seen in Real World', 'PoC Exploit'})

        return '''

if __name__ == '__main__':
    unittest.main()


