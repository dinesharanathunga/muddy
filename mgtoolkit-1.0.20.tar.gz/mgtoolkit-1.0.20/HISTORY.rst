=======
History
=======

1.0.0 (2017-04-07)
------------------

* First release on PyPI.
