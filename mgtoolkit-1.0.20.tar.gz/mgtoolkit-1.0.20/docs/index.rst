Welcome to mgtoolkit's documentation!
=====================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   installation
   usage
   reference
   contributing
   authors

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
