'''
muddy: Main module

Copyright 2014, dinesha ranathunga
Licensed under MIT.
'''


def main():
    '''
    Main function of the boilerplate code is the entry point of the 'muddy' executable script (defined in setup.py).
    
    Use doctests, those are very helpful.

    '''



