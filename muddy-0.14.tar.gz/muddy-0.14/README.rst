==================================================================
muddy: IETF MUD file generator and validator
==================================================================

TODO: Modify the whole file as necessary.

This is a "long description" file for the package that you are creating.
If you submit your package to PyPi, this text will be presented on the `public page <http://pypi.python.org/pypi/python_package_boilerplate>`_ of your package.

Note: This README has to be written using `reStructured Text <http://docutils.sourceforge.net/rst.html>`_, otherwise PyPi won't format it properly.

see 'usage instructions' in docs for guidelines on installation and use